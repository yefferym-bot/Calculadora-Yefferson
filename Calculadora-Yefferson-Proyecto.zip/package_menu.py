from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
from hashlib import sha256
import re
source=Path('/mnt/data/TruchAPP_4_8_3_animacion_fluida/Calculadora-Yefferson-Proyecto.zip')
root=Path('/mnt/data/truchapp_menu_work')
out=Path('/mnt/data/TruchAPP_4_8_4_menu_lateral/Calculadora-Yefferson-Proyecto.zip')
out.parent.mkdir(parents=True,exist_ok=True)
changes={
 'app/build.gradle':root/'app/build.gradle',
 'app/src/main/assets/index.html':root/'app/src/main/assets/index.html',
 'app/src/main/assets/ui/menu/side-menu.css':root/'app/src/main/assets/ui/menu/side-menu.css',
 'app/src/main/assets/ui/menu/side-menu.js':root/'app/src/main/assets/ui/menu/side-menu.js',
}
with ZipFile(source) as zin,ZipFile(out,'w',ZIP_DEFLATED,compresslevel=8) as zout:
 originals=set(zin.namelist())
 for info in zin.infolist():
  path=info.filename
  data=changes[path].read_bytes() if path in changes else zin.read(path)
  zout.writestr(info,data)
 zout.writestr('app/src/main/assets/ui/menu/','')
 for path in changes:
  if path not in originals:zout.write(changes[path],path)
with ZipFile(source) as zin, ZipFile(out) as znew:
 assert znew.testzip() is None
 orig=set(zin.namelist()); new=set(znew.namelist())
 assert set(new-orig)=={'app/src/main/assets/ui/menu/','app/src/main/assets/ui/menu/side-menu.css','app/src/main/assets/ui/menu/side-menu.js'}
 modified={p for p in orig if not p.endswith('/') and zin.read(p)!=znew.read(p)}
 assert modified=={'app/build.gradle','app/src/main/assets/index.html'},modified
 gr=znew.read('app/build.gradle').decode()
 assert re.search(r'versionCode\s+34',gr) and "versionName '4.8.4'" in gr
 css=znew.read('app/src/main/assets/ui/menu/side-menu.css')
 js=znew.read('app/src/main/assets/ui/menu/side-menu.js')
 html=znew.read('app/src/main/assets/index.html')
 assert b'ui/menu/side-menu.css' in html and b'ui/menu/side-menu.js' in html
 print('Output:',out)
 print('Size:',out.stat().st_size,'zip entries:',len(new),'testzip:',znew.testzip())
 print('Modified:',sorted(modified),'new:',sorted(new-orig))
 print('Sha256:',sha256(out.read_bytes()).hexdigest())
