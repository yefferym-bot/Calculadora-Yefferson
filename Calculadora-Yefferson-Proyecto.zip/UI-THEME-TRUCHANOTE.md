# TruchApp — Theme TruchaNote v1

Cambio visual aislado para extraer la estética del código TruchaNote recibido por el usuario.

- Paleta: verde agua/teal, fondo menta claro, blanco y coral.
- Tarjetas blancas redondeadas.
- Botones tipo píldora.
- Barra inferior blanca con estado activo teal.
- Chat claro con burbujas teal/menta.
- Calculadora con teclas blancas y operadores teal.
- No modifica IA, YKB/RAG, memoria, agenda, recordatorios, AndroidBridge ni lógica de cálculo.
