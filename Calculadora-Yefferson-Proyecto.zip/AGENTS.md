# TruchApp — reglas de continuidad

Leer este archivo y `CONTINUIDAD.md` antes de editar. Las instrucciones actuales
de Yefferson tienen prioridad. Estas reglas conservan los acuerdos del proyecto;
no son una autorización para ampliar el trabajo solicitado.

## Base y alcance

- Continuar desde la última entrega conocida o desde el ZIP que Yefferson
  identifique expresamente como base funcional. Comprobar versión e identidad;
  no elegir una copia solo por su nombre o fecha.
- Conservar la base sin sobrescribirla durante el trabajo. Registrar su SHA-256.
- Definir los archivos que requiere la solicitud y modificar solo esos archivos.
  No reconstruir módulos, reordenar todo el código ni aplicar cambios cosméticos
  generales para resolver un cambio localizado.
- Para una muestra HTML, trabajar aislado y conservar intacto el proyecto Android.
  Integrarla cuando Yefferson lo autorice. Si ya pide implementar un cambio en el
  APK/ZIP, esa instrucción autoriza el cambio solicitado; no repetir la aprobación.
- Las imágenes enviadas son referencias salvo que se indique que son el recurso
  que debe usarse. Conservar los diseños y funciones previamente aprobados.

## Datos e instalación

- Proteger `com.yefferson.calculadora`, la firma permanente, los datos existentes,
  Room/SQLite, respaldos y conexiones entre módulos. No cambiarlos por un ajuste UI.
- No incluir keystores, contraseñas, secretos ni datos reales del usuario en el ZIP.
- Aumentar versionCode/versionName cuando cambie la aplicación. La documentación
  y las herramientas de desarrollo por sí solas no requieren otra versión Android.
- Mantener ceros y campos sin registrar como valores diferentes. Sanidad no
  descuenta peces; las bajas se registran en el módulo diario. No duplicar registros.
- Preparar Play Store al terminar las funciones, cuando Yefferson lo solicite.

## Proyecto grande y verificación

- Buscar primero rutas y símbolos (`rg`); leer los fragmentos necesarios. No
  volcar imágenes base64, fuentes, modelos o archivos enormes al contexto del chat.
- Usar lectura por bloques para inventario, hashes y empaquetado. Trabajar por
  módulo; conservar puntos de avance escritos si la tarea se prolonga.
- Si falta la base correcta, obtenerla antes de escribir. No suplir código ausente
  con una reconstrucción de memoria ni omitir archivos para reducir el tamaño.
- Comparar cada entrega con la base mediante `tools/continuidad.py`. Cualquier
  cambio ajeno al alcance debe corregirse o justificarse dentro de la solicitud.
- Ejecutar validaciones relevantes al cambio. Distinguir sintaxis, pruebas de
  lógica, pruebas visuales, compilación e instalación; no afirmar pruebas no hechas.
- Antes de entregar: comprobar integridad del ZIP, cambios permitidos, versión y
  recursos. Conservar una base de recuperación hasta que se confirme el resultado.

## Entrega y relevo

- Nombre de entrega: `Calculadora-Yefferson-Proyecto.zip`.
- Yefferson compila y firma mediante su flujo de GitHub. No ejecutar Actions,
  publicar ni modificar su repositorio sin una solicitud que lo autorice.
- Actualizar `CONTINUIDAD.md` con versión entregada, alcance, archivos, pruebas,
  limitaciones y estado de instalación. Conservar lo pendiente para el siguiente turno.
- Git y estos archivos facilitan recuperar el trabajo. No prometer memoria
  ilimitada, ausencia total de errores ni capacidad de subida sin límites.
