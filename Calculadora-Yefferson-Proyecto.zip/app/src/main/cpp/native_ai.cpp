#include "llama.h"

#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "YeffersonAI", __VA_ARGS__)

namespace {
std::mutex g_mutex;
llama_model * g_model = nullptr;
llama_context * g_ctx = nullptr;
llama_sampler * g_sampler = nullptr;
const llama_vocab * g_vocab = nullptr;
bool g_backend_ready = false;
std::atomic<bool> g_ready{false};

void free_all() {
    g_ready.store(false, std::memory_order_release);
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_vocab = nullptr;
}

std::string jstring_to_string(JNIEnv * env, jstring value) {
    if (!value) return {};
    const char * chars = env->GetStringUTFChars(value, nullptr);
    std::string out(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return out;
}

std::string error_json(const std::string & msg) {
    return std::string("ERROR: ") + msg;
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_yefferson_calculadora_ai_AiNative_init(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_backend_ready) {
        llama_backend_init();
        g_backend_ready = true;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_yefferson_calculadora_ai_AiNative_loadModel(JNIEnv * env, jclass,
                                                            jstring model_path,
                                                            jint context_size,
                                                            jint threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_backend_ready) {
        llama_backend_init();
        g_backend_ready = true;
    }

    free_all();

    const std::string path = jstring_to_string(env, model_path);
    if (path.empty()) return JNI_FALSE;

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.load_mode = LLAMA_LOAD_MODE_MMAP;

    g_model = llama_model_load_from_file(path.c_str(), mp);
    if (!g_model) {
        LOGE("No se pudo cargar el modelo: %s", path.c_str());
        return JNI_FALSE;
    }

    g_vocab = llama_model_get_vocab(g_model);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(std::max(1024, static_cast<int>(context_size)));
    cp.n_batch = cp.n_ctx;
    cp.n_ubatch = std::min<uint32_t>(256, cp.n_batch);
    cp.n_threads = std::max(1, static_cast<int>(threads));
    cp.n_threads_batch = std::max(1, static_cast<int>(threads));

    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {
        LOGE("No se pudo crear el contexto");
        free_all();
        return JNI_FALSE;
    }

    g_sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (!g_sampler) {
        LOGE("No se pudo crear el sampler");
        free_all();
        return JNI_FALSE;
    }
    llama_sampler_chain_add(g_sampler, llama_sampler_init_min_p(0.05f, 1));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(0.75f));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    g_ready.store(true, std::memory_order_release);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_yefferson_calculadora_ai_AiNative_isReady(JNIEnv *, jclass) {
    // Esta consulta ocurre periódicamente desde el WebView. Nunca debe esperar
    // al mutex de carga/inferencia porque eso puede congelar toda la interfaz.
    return g_ready.load(std::memory_order_acquire) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_yefferson_calculadora_ai_AiNative_generate(JNIEnv * env, jclass,
                                                           jstring system_prompt,
                                                           jstring user_prompt,
                                                           jint max_tokens) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!(g_model && g_ctx && g_sampler && g_vocab)) {
        return env->NewStringUTF(error_json("La IA local todavía no está lista." ).c_str());
    }

    const std::string system = jstring_to_string(env, system_prompt);
    const std::string user = jstring_to_string(env, user_prompt);
    if (user.empty()) return env->NewStringUTF("");

    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_sampler_reset(g_sampler);

    llama_chat_message messages[2];
    messages[0] = {"system", system.c_str()};
    messages[1] = {"user", user.c_str()};

    const char * tmpl = llama_model_chat_template(g_model, nullptr);
    size_t capacity = std::max<size_t>(2048, system.size() + user.size() + 2048);
    std::vector<char> formatted(capacity);
    int32_t formatted_len = llama_chat_apply_template(tmpl, messages, 2, true,
                                                       formatted.data(), static_cast<int32_t>(formatted.size()));
    if (formatted_len > static_cast<int32_t>(formatted.size())) {
        formatted.resize(formatted_len + 16);
        formatted_len = llama_chat_apply_template(tmpl, messages, 2, true,
                                                  formatted.data(), static_cast<int32_t>(formatted.size()));
    }
    if (formatted_len < 0) {
        return env->NewStringUTF(error_json("No se pudo preparar la conversación." ).c_str());
    }

    std::string prompt(formatted.data(), static_cast<size_t>(formatted_len));

    int32_t probe = llama_tokenize(g_vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                                   nullptr, 0, true, true);
    // llama.cpp normalmente devuelve el tamaño requerido como un valor negativo
    // cuando el buffer es NULL/0. Algunas versiones devuelven directamente el
    // tamaño positivo. Aceptamos ambas variantes para evitar el falso error
    // "No se pudo tokenizar la pregunta".
    if (probe < 0) {
        probe = -probe;
    }
    if (probe <= 0) {
        return env->NewStringUTF(error_json("No se pudo tokenizar la pregunta: el tokenizador devolvió 0 tokens." ).c_str());
    }

    std::vector<llama_token> prompt_tokens(static_cast<size_t>(probe));
    int32_t token_count = llama_tokenize(g_vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                                         prompt_tokens.data(), static_cast<int32_t>(prompt_tokens.size()),
                                         true, true);
    if (token_count < 0) {
        return env->NewStringUTF(error_json("Falló la tokenización." ).c_str());
    }
    prompt_tokens.resize(static_cast<size_t>(token_count));

    const uint32_t ctx_size = llama_n_ctx(g_ctx);
    const int32_t safe_max = std::max<int32_t>(1, std::min<int32_t>(max_tokens, static_cast<int32_t>(ctx_size) - token_count - 8));
    if (safe_max <= 0) {
        return env->NewStringUTF(error_json("La conversación es demasiado larga para la memoria del teléfono." ).c_str());
    }

    llama_batch batch = llama_batch_get_one(prompt_tokens.data(), static_cast<int32_t>(prompt_tokens.size()));
    if (llama_decode(g_ctx, batch) != 0) {
        return env->NewStringUTF(error_json("Falló la inferencia inicial del modelo." ).c_str());
    }

    std::string response;
    llama_token next = LLAMA_TOKEN_NULL;
    for (int32_t i = 0; i < safe_max; ++i) {
        next = llama_sampler_sample(g_sampler, g_ctx, -1);
        if (llama_vocab_is_eog(g_vocab, next)) break;

        char buf[512];
        const int32_t n = llama_token_to_piece(g_vocab, next, buf, sizeof(buf), 0, true);
        if (n > 0) response.append(buf, n);

        llama_batch one = llama_batch_get_one(&next, 1);
        if (llama_decode(g_ctx, one) != 0) break;
    }

    return env->NewStringUTF(response.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_yefferson_calculadora_ai_AiNative_release(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_all();
}
