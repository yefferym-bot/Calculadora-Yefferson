#include "llama.h"

#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "TruchAppAI", __VA_ARGS__)

namespace {
std::mutex g_mutex;
llama_model * g_model = nullptr;
llama_context * g_ctx = nullptr;
const llama_vocab * g_vocab = nullptr;
bool g_backend_ready = false;
std::atomic<bool> g_ready{false};

// Tokens already evaluated in the live conversation. When the next formatted
// conversation starts with this exact sequence, only the new suffix is decoded.
std::vector<llama_token> g_cached_tokens;
bool g_cache_valid = false;

void clear_conversation_locked() {
    g_cached_tokens.clear();
    g_cache_valid = false;
    if (g_ctx) {
        llama_memory_clear(llama_get_memory(g_ctx), true);
    }
}

void free_all() {
    g_ready.store(false, std::memory_order_release);
    if (g_ctx) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
    g_vocab = nullptr;
    g_cached_tokens.clear();
    g_cache_valid = false;
}

std::string jstring_to_string(JNIEnv * env, jstring value) {
    if (!value) return {};
    const char * chars = env->GetStringUTFChars(value, nullptr);
    std::string out(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return out;
}

std::string error_json(const std::string & msg) {
    return std::string("ERROR: ") + msg;
}

bool decode_tokens(llama_context * ctx, const std::vector<llama_token> & tokens, size_t start) {
    if (start >= tokens.size()) return true;

    // llama_batch_get_one lets llama.cpp track sequence positions automatically
    // from the existing memory state, so a reused KV prefix can continue safely.
    const size_t remaining = tokens.size() - start;
    const size_t batch_limit = std::max<size_t>(1, llama_n_batch(ctx));

    size_t offset = start;
    while (offset < tokens.size()) {
        const size_t count = std::min(batch_limit, tokens.size() - offset);
        llama_batch batch = llama_batch_get_one(
                const_cast<llama_token *>(tokens.data() + offset),
                static_cast<int32_t>(count));
        if (llama_decode(ctx, batch) != 0) return false;
        offset += count;
    }
    return true;
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_yefferson_calculadora_ai_AiNative_init(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_backend_ready) {
        llama_backend_init();
        g_backend_ready = true;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_yefferson_calculadora_ai_AiNative_loadModel(JNIEnv * env, jclass,
                                                      jstring model_path,
                                                      jint context_size,
                                                      jint threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_backend_ready) {
        llama_backend_init();
        g_backend_ready = true;
    }

    free_all();

    const std::string path = jstring_to_string(env, model_path);
    if (path.empty()) return JNI_FALSE;

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.load_mode = LLAMA_LOAD_MODE_MMAP;

    g_model = llama_model_load_from_file(path.c_str(), mp);
    if (!g_model) {
        LOGE("No se pudo cargar el modelo: %s", path.c_str());
        return JNI_FALSE;
    }

    g_vocab = llama_model_get_vocab(g_model);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(std::max(1536, static_cast<int>(context_size)));
    cp.n_batch = std::min<uint32_t>(cp.n_ctx, 512);
    cp.n_ubatch = std::min<uint32_t>(256, cp.n_batch);
    cp.n_threads = std::max(1, static_cast<int>(threads));
    cp.n_threads_batch = std::max(1, static_cast<int>(threads));

    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {
        LOGE("No se pudo crear el contexto");
        free_all();
        return JNI_FALSE;
    }

    g_cached_tokens.clear();
    g_cache_valid = false;
    g_ready.store(true, std::memory_order_release);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_yefferson_calculadora_ai_AiNative_isReady(JNIEnv *, jclass) {
    return g_ready.load(std::memory_order_acquire) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_yefferson_calculadora_ai_AiNative_generateConversation(
        JNIEnv * env, jclass,
        jstring system_prompt,
        jobjectArray roles,
        jobjectArray contents,
        jint max_tokens,
        jboolean thinking) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!(g_model && g_ctx && g_vocab)) {
        return env->NewStringUTF(error_json("La IA local todavía no está lista.").c_str());
    }

    const std::string system = jstring_to_string(env, system_prompt);
    const jsize count = roles ? env->GetArrayLength(roles) : 0;
    const jsize content_count = contents ? env->GetArrayLength(contents) : 0;
    if (count != content_count || count <= 0) {
        return env->NewStringUTF(error_json("La conversación local está incompleta.").c_str());
    }

    std::vector<std::string> role_storage;
    std::vector<std::string> content_storage;
    role_storage.reserve(static_cast<size_t>(count) + 1);
    content_storage.reserve(static_cast<size_t>(count) + 1);

    // System prompt is stable across turns, which maximizes KV-cache reuse.
    std::vector<llama_chat_message> messages;
    messages.reserve(static_cast<size_t>(count) + 1);
    role_storage.push_back("system");
    content_storage.push_back(system);

    for (jsize i = 0; i < count; ++i) {
        jstring jr = static_cast<jstring>(env->GetObjectArrayElement(roles, i));
        jstring jc = static_cast<jstring>(env->GetObjectArrayElement(contents, i));
        role_storage.push_back(jstring_to_string(env, jr));
        content_storage.push_back(jstring_to_string(env, jc));
        if (jr) env->DeleteLocalRef(jr);
        if (jc) env->DeleteLocalRef(jc);
    }

    for (size_t i = 0; i < role_storage.size(); ++i) {
        messages.push_back({role_storage[i].c_str(), content_storage[i].c_str()});
    }

    const char * tmpl = llama_model_chat_template(g_model, nullptr);
    size_t capacity = std::max<size_t>(4096, system.size() + 4096);
    for (const auto & s : content_storage) capacity += s.size() + 64;
    std::vector<char> formatted(capacity);
    int32_t formatted_len = llama_chat_apply_template(
            tmpl,
            messages.data(),
            static_cast<int32_t>(messages.size()),
            true,
            formatted.data(),
            static_cast<int32_t>(formatted.size()));
    if (formatted_len > static_cast<int32_t>(formatted.size())) {
        formatted.resize(static_cast<size_t>(formatted_len) + 32);
        formatted_len = llama_chat_apply_template(
                tmpl,
                messages.data(),
                static_cast<int32_t>(messages.size()),
                true,
                formatted.data(),
                static_cast<int32_t>(formatted.size()));
    }
    if (formatted_len < 0) {
        return env->NewStringUTF(error_json("No se pudo preparar la conversación.").c_str());
    }

    std::string prompt(formatted.data(), static_cast<size_t>(formatted_len));

    int32_t probe = llama_tokenize(
            g_vocab,
            prompt.c_str(),
            static_cast<int32_t>(prompt.size()),
            nullptr,
            0,
            true,
            true);
    if (probe < 0) probe = -probe;
    if (probe <= 0) {
        return env->NewStringUTF(error_json("No se pudo tokenizar la conversación.").c_str());
    }

    std::vector<llama_token> prompt_tokens(static_cast<size_t>(probe));
    int32_t token_count = llama_tokenize(
            g_vocab,
            prompt.c_str(),
            static_cast<int32_t>(prompt.size()),
            prompt_tokens.data(),
            static_cast<int32_t>(prompt_tokens.size()),
            true,
            true);
    if (token_count < 0) {
        return env->NewStringUTF(error_json("Falló la tokenización.").c_str());
    }
    prompt_tokens.resize(static_cast<size_t>(token_count));

    const uint32_t ctx_size = llama_n_ctx(g_ctx);
    const int32_t requested = std::max<int32_t>(1, max_tokens);
    const size_t available = ctx_size > prompt_tokens.size() + 8
            ? static_cast<size_t>(ctx_size) - prompt_tokens.size() - 8
            : 0;
    if (available < 32) {
        return env->NewStringUTF(error_json("La conversación es demasiado larga para el contexto disponible.").c_str());
    }

    bool reuse = g_cache_valid && prompt_tokens.size() > g_cached_tokens.size();
    if (reuse) {
        reuse = std::equal(g_cached_tokens.begin(), g_cached_tokens.end(), prompt_tokens.begin());
    }

    size_t decode_from = 0;
    if (!reuse) {
        clear_conversation_locked();
    } else {
        decode_from = g_cached_tokens.size();
    }

    if (!decode_tokens(g_ctx, prompt_tokens, decode_from)) {
        // One clean retry protects against any rare cache mismatch.
        clear_conversation_locked();
        if (!decode_tokens(g_ctx, prompt_tokens, 0)) {
            return env->NewStringUTF(error_json("Falló la inferencia inicial del modelo.").c_str());
        }
    }

    g_cached_tokens = prompt_tokens;
    g_cache_valid = true;

    llama_sampler_chain_params sampler_params = llama_sampler_chain_default_params();
    llama_sampler * sampler = llama_sampler_chain_init(sampler_params);
    if (!sampler) {
        return env->NewStringUTF(error_json("No se pudo crear el sampler.").c_str());
    }

    // Qwen3 recommendations: non-thinking 0.7/TopP 0.8/TopK 20/MinP 0;
    // thinking 0.6/TopP 0.95/TopK 20/MinP 0.
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(20));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(thinking ? 0.95f : 0.80f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_min_p(0.0f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(thinking ? 0.60f : 0.70f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    std::string response;
    const int32_t safe_max = std::max<int32_t>(1, std::min<int32_t>(requested, static_cast<int32_t>(available)));

    for (int32_t i = 0; i < safe_max; ++i) {
        const llama_token next = llama_sampler_sample(sampler, g_ctx, -1);
        if (llama_vocab_is_eog(g_vocab, next)) break;

        char buf[1024];
        const int32_t n = llama_token_to_piece(g_vocab, next, buf, sizeof(buf), 0, true);
        if (n > 0) response.append(buf, n);

        llama_batch one = llama_batch_get_one(const_cast<llama_token *>(&next), 1);
        if (llama_decode(g_ctx, one) != 0) break;
        g_cached_tokens.push_back(next);
    }

    llama_sampler_free(sampler);

    // Thinking output is cleaned before being persisted by AiModule, so its token
    // sequence cannot always be replayed exactly. Force a safe rebuild after a
    // thinking turn; ordinary fast turns keep the cache hot.
    if (thinking) g_cache_valid = false;

    return env->NewStringUTF(response.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_yefferson_calculadora_ai_AiNative_clearConversation(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    clear_conversation_locked();
}

extern "C" JNIEXPORT void JNICALL
Java_com_yefferson_calculadora_ai_AiNative_release(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_all();
}
