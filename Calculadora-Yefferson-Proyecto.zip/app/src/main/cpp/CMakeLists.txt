cmake_minimum_required(VERSION 3.22.1)
project("yefferson_ai")

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# El workflow build-from-zip no ejecuta necesariamente el workflow incluido
# en este proyecto. Por eso descargamos llama.cpp durante la configuración
# de CMake si todavía no existe.
set(LLAMA_CPP_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../llama.cpp")
if(NOT EXISTS "${LLAMA_CPP_DIR}/CMakeLists.txt")
    message(STATUS "llama.cpp no está presente; descargándolo...")
    execute_process(
        COMMAND git clone --depth 1 https://github.com/ggml-org/llama.cpp.git "${LLAMA_CPP_DIR}"
        RESULT_VARIABLE LLAMA_CLONE_RESULT
        OUTPUT_VARIABLE LLAMA_CLONE_OUTPUT
        ERROR_VARIABLE LLAMA_CLONE_ERROR
    )
    if(NOT LLAMA_CLONE_RESULT EQUAL 0)
        message(FATAL_ERROR "No se pudo descargar llama.cpp. Resultado=${LLAMA_CLONE_RESULT}\n${LLAMA_CLONE_ERROR}")
    endif()
endif()

if(NOT EXISTS "${LLAMA_CPP_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "No se encontró llama.cpp en ${LLAMA_CPP_DIR}")
endif()

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
set(LLAMA_OPENSSL OFF CACHE BOOL "" FORCE)

add_subdirectory("${LLAMA_CPP_DIR}" llama.cpp-build EXCLUDE_FROM_ALL)

add_library(yefferson_ai SHARED native_ai.cpp)
target_include_directories(yefferson_ai PRIVATE "${LLAMA_CPP_DIR}/include")
target_link_libraries(yefferson_ai PRIVATE llama log android)
