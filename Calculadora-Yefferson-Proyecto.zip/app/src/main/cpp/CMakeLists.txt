cmake_minimum_required(VERSION 3.22.1)
project("yefferson_ai")

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# Both ABI configurations share the source, never their compiled objects.
# A lock prevents parallel ARM32/ARM64 configuration from cloning/checking out twice.
set(LLAMA_CPP_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../llama.cpp" CACHE PATH "llama.cpp sources")
file(STRINGS "${CMAKE_CURRENT_LIST_DIR}/llama-revision.txt" LLAMA_CPP_REVISION LIMIT_COUNT 1)
string(LENGTH "${LLAMA_CPP_REVISION}" LLAMA_CPP_REVISION_LENGTH)
if(NOT LLAMA_CPP_REVISION_LENGTH EQUAL 40 OR NOT LLAMA_CPP_REVISION MATCHES "^[0-9a-f]+$")
    message(FATAL_ERROR "La revisión fijada de llama.cpp no es válida")
endif()
file(LOCK "${LLAMA_CPP_DIR}.configure.lock" GUARD FILE TIMEOUT 300)
if(NOT EXISTS "${LLAMA_CPP_DIR}/CMakeLists.txt")
    message(STATUS "llama.cpp no está presente; descargándolo...")
    execute_process(
        COMMAND git clone --depth 1 https://github.com/ggml-org/llama.cpp.git "${LLAMA_CPP_DIR}"
        RESULT_VARIABLE LLAMA_CLONE_RESULT
        OUTPUT_VARIABLE LLAMA_CLONE_OUTPUT
        ERROR_VARIABLE LLAMA_CLONE_ERROR
    )
    if(NOT LLAMA_CLONE_RESULT EQUAL 0)
        message(FATAL_ERROR "No se pudo descargar llama.cpp. Resultado=${LLAMA_CLONE_RESULT}\n${LLAMA_CLONE_ERROR}")
    endif()
endif()

if(NOT EXISTS "${LLAMA_CPP_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "No se encontró llama.cpp en ${LLAMA_CPP_DIR}")
endif()

execute_process(COMMAND git -C "${LLAMA_CPP_DIR}" rev-parse HEAD
    OUTPUT_VARIABLE LLAMA_CURRENT_REVISION OUTPUT_STRIP_TRAILING_WHITESPACE
    RESULT_VARIABLE LLAMA_REVISION_RESULT)
if(NOT LLAMA_REVISION_RESULT EQUAL 0)
    message(FATAL_ERROR "No se pudo comprobar la revisión de llama.cpp")
endif()
if(NOT LLAMA_CURRENT_REVISION STREQUAL LLAMA_CPP_REVISION)
    execute_process(COMMAND git -C "${LLAMA_CPP_DIR}" fetch --depth 1 origin "${LLAMA_CPP_REVISION}"
        RESULT_VARIABLE LLAMA_FETCH_RESULT)
    if(NOT LLAMA_FETCH_RESULT EQUAL 0)
        message(FATAL_ERROR "No se pudo descargar la revisión fijada de llama.cpp")
    endif()
    execute_process(COMMAND git -C "${LLAMA_CPP_DIR}" checkout --detach "${LLAMA_CPP_REVISION}"
        RESULT_VARIABLE LLAMA_CHECKOUT_RESULT)
    if(NOT LLAMA_CHECKOUT_RESULT EQUAL 0)
        message(FATAL_ERROR "No se pudo seleccionar la revisión fijada de llama.cpp")
    endif()
endif()

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
set(LLAMA_OPENSSL OFF CACHE BOOL "" FORCE)

if(ANDROID_ABI STREQUAL "armeabi-v7a")
    # Keep the ARMv7 baseline; AArch64-only optimizations cannot be used here.
    set(GGML_CPU_ARM_ARCH "armv7-a" CACHE STRING "" FORCE)
    set(GGML_CPU_KLEIDIAI OFF CACHE BOOL "" FORCE)
endif()

add_subdirectory("${LLAMA_CPP_DIR}" llama.cpp-build EXCLUDE_FROM_ALL)

add_library(yefferson_ai SHARED native_ai.cpp)
target_include_directories(yefferson_ai PRIVATE "${LLAMA_CPP_DIR}/include")
target_link_libraries(yefferson_ai PRIVATE llama log android)
