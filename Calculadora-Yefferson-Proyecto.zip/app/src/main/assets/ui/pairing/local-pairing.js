/* LAN pairing UI; authorization and trust live in Android, never in the mode preference. */
(function(){
 'use strict';
 const $=id=>document.getElementById(id),requests=new Map(),drafts=new Map();
 let state={supported:false,peers:[],services:[],sessions:[],availableLots:[]},dialog=null,sequence=0,loading=false,refreshAgain=false,poll=null,busy=false,lastMode='',previous=null,reviewSession='';
 const node=(tag,text,cls)=>{const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(cls)el.className=cls;return el;};
 const button=(text,action,cls='lp-button')=>{const el=node('button',text,cls);el.type='button';if(action)el.addEventListener('click',action);return el;};
 function request(command,input={}){
  if(!window.AndroidAI?.localPairRequest)return Promise.reject(Error('La conexión local requiere esta versión instalada en Android.'));
  const id='lp-'+Date.now()+'-'+(++sequence);
  return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{requests.delete(id);reject(Error('No se recibió respuesta. Vuelve a consultar el estado antes de reintentar.'));},20000);requests.set(id,{resolve,reject,timer,parts:[],bytes:0});try{window.AndroidAI.localPairRequest(id,command,JSON.stringify(input));}catch(error){clearTimeout(timer);requests.delete(id);reject(error);}});
 }
 window.TruchAppLocalPairReceive=(id,ok,index,count,part)=>{
  const pending=requests.get(id);if(!pending)return;
  if(!Number.isInteger(index)||!Number.isInteger(count)||count<1||count>128||index<0||index>=count||typeof part!=='string'||pending.bytes+part.length>4*1024*1024){clearTimeout(pending.timer);requests.delete(id);pending.reject(Error('Respuesta local inválida'));return;}
  if(pending.parts[index]!==undefined)return;pending.bytes+=part.length;pending.parts[index]=part;
  if(pending.parts.filter(v=>v!==undefined).length!==count)return;
  clearTimeout(pending.timer);requests.delete(id);try{const value=JSON.parse(pending.parts.join(''));if(!ok)throw Error(value.error||'No se pudo completar la acción local');pending.resolve(value);}catch(error){pending.reject(error);}
 };
 function accept(value){
  if(!value||value.supported!==true||!['admin','collaborator'].includes(value.mode))throw Error('Estado de conexión local inválido');
  for(const key of ['peers','services','sessions'])if(!Array.isArray(value[key]))throw Error('Estado de conexión local inválido');
  const changed=JSON.stringify(state)!==JSON.stringify(value);state=value;if(dialog?.open)render();
  if(changed)window.dispatchEvent(new Event('truchapp-local-pair-updated'));
 }
 async function refresh(){if(!window.AndroidAI?.localPairRequest)return;if(loading){refreshAgain=true;return;}loading=true;try{accept(await request('status'));}catch(error){if(dialog?.open)errorText(error.message);}finally{loading=false;if(refreshAgain){refreshAgain=false;setTimeout(refresh,0);}}}
 function errorText(text){if($('lpError')){$('lpError').textContent=text;$('lpError').hidden=!text;}}
 async function action(command,input={}){
  if(busy)return;busy=true;errorText('');updateButtons();
  try{accept(await request(command,input));}catch(error){errorText(error.message);await refresh();}finally{busy=false;updateButtons();}
 }
 function updateButtons(){if(!dialog)return;dialog.querySelectorAll('[data-lp-command],[data-lp-connect]').forEach(el=>el.disabled=busy||!state.supported||(el.hasAttribute('data-lp-connect')&&state.retryAfterMs>0));$('lpBusy').textContent=busy?'Procesando…':'';}
 function activePeers(){return(state.peers||[]).filter(p=>p&&!p.revoked&&p.role==='admin'&&/^[0-9a-f]{64}$/.test(p.fingerprint));}
 function assigned(){const out=[];for(const peer of activePeers())if(Array.isArray(peer.lots))for(const lot of peer.lots)if(lot&&typeof lot.id==='string')out.push({...lot,owner:peer.fingerprint,ownerName:peer.name,permission:peer.permission});return out;}
 function connected(fingerprint){return state.sessions.some(s=>s.fingerprint===fingerprint&&s.state==='connected');}
 function build(){
  if(dialog)return;dialog=document.createElement('dialog');dialog.id='localPairingDialog';dialog.setAttribute('aria-labelledby','lpTitle');
  dialog.innerHTML='<header class="lp-header"><div><span class="lp-eyebrow">TU EQUIPO</span><h2 id="lpTitle">Conexión local</h2></div><button id="lpClose" type="button" aria-label="Cerrar conexión local"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg></button></header><div class="lp-body"><p class="lp-intro">Conecta ambos teléfonos a la misma Wi-Fi o conecta uno a la zona Wi-Fi del otro. Mantén TruchApp abierta en ambos.</p><p id="lpError" class="lp-error" role="alert" hidden></p><section class="lp-card"><h3 id="lpRoleTitle"></h3><p id="lpCapacity" class="lp-capacity" aria-live="polite"></p><div id="lpAdminActions" class="lp-actions"><button type="button" id="lpInvite" data-lp-command>Vincular colaborador</button><button type="button" id="lpListen" class="lp-secondary" data-lp-command>Activar reconexión</button></div><div id="lpCollaboratorActions"><button type="button" id="lpSearch" data-lp-command>Buscar administrador</button><details class="lp-manual"><summary>Conectar con dirección local</summary><label for="lpEndpoint">Dirección que muestra el administrador</label><input id="lpEndpoint" placeholder="192.168.1.5:41435" autocomplete="off" inputmode="text" maxlength="24"><button type="button" id="lpConnect" data-lp-command data-lp-connect>Conectar</button></details></div><p id="lpNotice" role="status" aria-live="polite"></p><p id="lpRetry" class="lp-note" role="status"></p><p id="lpAddress" class="lp-address" hidden></p><p id="lpExpiry" class="lp-note"></p><div id="lpServices"></div></section><div id="lpSessions"></div><section><h3 id="lpPeersTitle">Equipos vinculados</h3><div id="lpPeers"></div></section><p class="lp-note">En esta etapa se comparten la vinculación, los permisos y los nombres de los lotes asignados. El envío de registros diarios se añadirá después.</p><p class="lp-note">WebRTC por internet y escanear QR: próximamente.</p></div><footer class="lp-footer"><span id="lpBusy" role="status"></span><button type="button" id="lpStop" class="lp-secondary" data-lp-command>Desactivar conexión</button></footer>';
  document.body.append(dialog);$('lpClose').addEventListener('click',()=>dialog.close());
  $('lpInvite').addEventListener('click',()=>action('invite'));$('lpListen').addEventListener('click',()=>action('listen'));$('lpSearch').addEventListener('click',()=>action('search'));$('lpConnect').addEventListener('click',()=>action('connect',{endpoint:$('lpEndpoint').value.trim()}));$('lpStop').addEventListener('click',()=>action('stop'));
  dialog.addEventListener('close',()=>{if(dialog.open)return;clearInterval(poll);poll=null;previous?.focus?.({preventScroll:true});});
 }
 function controls(container,key,selection={}){
  const draft=drafts.get(key)||{permission:selection.permission==='record'?'record':'view',lotIds:new Set(Array.isArray(selection.lotIds)?selection.lotIds:[])};drafts.set(key,draft);
  const label=node('label','Permisos del colaborador');const select=node('select');select.setAttribute('aria-label','Permisos del colaborador');
  for(const [value,text] of [['view','Consultar lotes'],['record','Consultar y registrar (registro próximamente)']]){const option=node('option',text);option.value=value;select.append(option);}select.value=draft.permission;select.addEventListener('change',()=>draft.permission=select.value);label.append(select);container.append(label);
  const field=node('fieldset',undefined,'lp-lots');field.append(node('legend','Lotes asignados'));
  const available=Array.isArray(state.availableLots)?state.availableLots:[];
  if(!available.length)field.append(node('p','Aún no hay lotes. Puedes asignarlos después.','lp-note'));
  for(const lot of available){const row=node('label',undefined,'lp-lot-choice'),input=node('input');input.type='checkbox';input.value=lot.id;input.checked=draft.lotIds.has(lot.id);input.addEventListener('change',()=>{if(input.checked){if(draft.lotIds.size>=100){input.checked=false;errorText('Puedes asignar hasta 100 lotes por colaborador.');return;}draft.lotIds.add(lot.id);}else draft.lotIds.delete(lot.id);});row.append(input,node('span',lot.code||'Lote'));field.append(row);}
  container.append(field);return draft;
 }
 function renderSessions(){
  if(!state.sessions.some(s=>s.id===reviewSession&&s.state==='verify'))reviewSession=state.sessions.find(s=>s.state==='verify')?.id||'';
  const root=$('lpSessions'),key=JSON.stringify([state.sessions,state.availableLots,reviewSession]);if(root.dataset.key===key)return;root.dataset.key=key;root.replaceChildren();
  for(const session of state.sessions){
   const card=node('section',undefined,'lp-card lp-verification');card.dataset.session=session.id;card.append(node('h3',session.name||'Conectando equipo…'));
   if(session.state==='verify'&&session.id!==reviewSession){card.append(node('p','Solicitud pendiente de revisión.','lp-note'),button('Revisar solicitud',()=>{reviewSession=session.id;root.dataset.key='';renderSessions();}));root.append(card);continue;}
   if(['verify','waiting'].includes(session.state)){
    card.append(node('p','Comprueba que ambos teléfonos muestran exactamente este código.'),node('strong',session.code,'lp-code'));
    if(session.state==='verify'){
     const draft=state.mode==='admin'?controls(card,session.id):null;
     const check=node('label',undefined,'lp-lot-choice'),input=node('input');input.type='checkbox';input.setAttribute('aria-label','El código coincide en ambos teléfonos');check.append(input,node('span','El código coincide en ambos teléfonos'));card.append(check);
     const confirm=button(state.mode==='admin'?'Aprobar colaborador':'Confirmar código',()=>{if(!input.checked)return;action('confirm',{session:session.id,code:session.code,...(draft?{permission:draft.permission,lotIds:[...draft.lotIds]}:{})});});confirm.disabled=true;input.addEventListener('change',()=>confirm.disabled=!input.checked);card.append(confirm);
    }else card.append(node('p','Confirmado aquí. Esperando al otro teléfono…','lp-note'));
    card.append(button('Cancelar vinculación',()=>action('reject',{session:session.id}),'lp-secondary'));
   }else card.append(node('p',session.state==='connected'?'Conectado por red local.':session.state==='saving'?'Guardando vinculación…':'Estableciendo conexión cifrada…','lp-note'));
   root.append(card);
  }
 }
 function renderPeers(){
  const root=$('lpPeers'),key=JSON.stringify([state.peers,state.sessions.map(s=>[s.fingerprint,s.state]),state.availableLots]);if(root.dataset.key===key)return;root.dataset.key=key;root.replaceChildren();
  if(!state.peers.length)root.append(node('p','Todavía no hay equipos vinculados.','lp-empty'));
  for(const peer of state.peers){
   const card=node('article',undefined,'lp-card');card.dataset.peer=peer.fingerprint;card.append(node('h4',peer.name||'Equipo'));
   card.append(node('p',peer.revoked?'Acceso retirado':connected(peer.fingerprint)?'Conectado por red local':'Vinculado · Sin conexión','lp-tag'));
   card.append(node('p',peer.permission==='record'?'Consulta y registro autorizados · Registro próximamente':'Permiso de consulta','lp-note'));
   const count=state.mode==='admin'?(peer.lotIds||[]).length:(peer.lots||[]).length;card.append(node('p',count+' lote'+(count===1?'':'s')+' asignado'+(count===1?'':'s'),'lp-note'));
   if(!peer.revoked){
    if(connected(peer.fingerprint))card.append(button('Desconectar',()=>action('disconnect',{fingerprint:peer.fingerprint}),'lp-secondary'));
    if(state.mode==='admin'){
     const details=node('details',undefined,'lp-edit');details.append(node('summary','Editar lotes y permisos'));details.addEventListener('toggle',()=>{details.querySelector('.lp-perm-editor')?.remove();if(details.open){root.querySelectorAll('.lp-edit[open]').forEach(other=>{if(other!==details)other.open=false;});const editor=node('div',undefined,'lp-perm-editor'),draft=controls(editor,'peer-'+peer.fingerprint,peer);editor.append(button('Guardar permisos',()=>action('update',{fingerprint:peer.fingerprint,permission:draft.permission,lotIds:[...draft.lotIds]})));details.append(editor);}});card.append(details);
    }
    const removal=node('div');const remove=button(state.mode==='admin'?'Retirar acceso':'Desvincularme',()=>{removal.replaceChildren(node('p','¿Retirar esta vinculación? Tendrá que aprobarse de nuevo.'));removal.append(button('Cancelar',()=>{removal.replaceChildren(remove);},'lp-secondary'),button('Sí, retirar',()=>action('revoke',{fingerprint:peer.fingerprint}),'lp-danger'));},'lp-danger');removal.append(remove);card.append(removal);
   }
   root.append(card);
  }
 }
 function render(){
  if(!dialog)return;const admin=(state.mode||window.TruchAppAccess?.read().mode)==='admin';$('lpRoleTitle').textContent=admin?'Administrador':'Colaborador';$('lpAdminActions').hidden=!admin;$('lpCollaboratorActions').hidden=admin;$('lpPeersTitle').textContent=admin?'Colaboradores vinculados':'Administradores vinculados';
  const live=Number.isInteger(state.connectedCount)?state.connectedCount:state.sessions.filter(s=>s.state==='connected').length,max=state.maxConnections||20,pending=Math.max(0,(state.capacityUsed??state.sessions.length)-live);$('lpCapacity').hidden=!admin;$('lpCapacity').textContent=live+' / '+max+' colaboradores conectados'+(pending?' · '+pending+' pendientes':'');$('lpRetry').textContent=state.retryAfterMs>0?'Puedes volver a conectar en '+Math.ceil(state.retryAfterMs/1000)+' s.':'';
  $('lpNotice').textContent=state.notice||(!state.supported?'Instala esta versión en Android para vincular los equipos.':'Activa una conexión local para empezar.');$('lpAddress').hidden=!state.endpoint;$('lpAddress').textContent=state.endpoint?'Dirección local: '+state.endpoint:'';
  $('lpExpiry').textContent=state.invitationUntil>Date.now()?'Invitación abierta hasta '+new Date(state.invitationUntil).toLocaleTimeString('es-PE',{hour:'2-digit',minute:'2-digit'}):state.listening?'Invitación cerrada. Solo se admiten equipos ya vinculados.':'';
  const root=$('lpServices'),key=JSON.stringify(state.services);if(root.dataset.key!==key){root.dataset.key=key;root.replaceChildren();for(const service of state.services){const row=node('div',undefined,'lp-service');const connect=button('Conectar',()=>action('connect',{service:service.id}));connect.setAttribute('data-lp-connect','');row.append(node('span',service.name),connect);root.append(row);}}
  renderSessions();renderPeers();updateButtons();
 }
 function open(){
  if(document.getElementById('yb-intro'))return;build();previous=document.activeElement;window.TruchAppMenu?.close();$('coMenuDialog')?.close();if(!dialog.open)dialog.showModal();render();refresh();clearInterval(poll);poll=setInterval(refresh,1800);
 }
 document.addEventListener('click',event=>{if(event.target.closest('[data-local-pair]'))open();});
 window.addEventListener('truchapp-local-pair-changed',refresh);
 window.addEventListener('truchapp-storage-committed',()=>{const mode=window.TruchAppAccess?.read().mode;if(mode!==lastMode){lastMode=mode;refresh();}});
 window.addEventListener('truchapp-data-restored',()=>{action('stop');});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
 window.TruchAppLocalPair={open,refresh,getState:()=>state,activePeers,assigned,connected};refresh();
})();
