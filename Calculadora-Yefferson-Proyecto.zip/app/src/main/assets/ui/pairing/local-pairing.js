/* LAN pairing UI; authorization and trust live in Android, never in the mode preference. */
(function(){
 'use strict';
 const $=id=>document.getElementById(id),requests=new Map(),drafts=new Map();
 let state={supported:false,peers:[],services:[],sessions:[],availableLots:[]},dialog=null,sequence=0,loading=false,refreshAgain=false,poll=null,busy=false,qrDialog=null,qrValue=null,qrTimer=null,lastMode='',previous=null,reviewSession='',editingPeer='',selectedTab='connection',frameObserver=null,underlays=[];
 const node=(tag,text,cls)=>{const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(cls)el.className=cls;return el;};
 const svg=path=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+path+'"/></svg>';
 const initials=name=>Array.from(String(name||'Equipo').trim())[0]?.toLocaleUpperCase('es')||'E';
 const button=(text,action,cls='lp-button')=>{const el=node('button',text,cls);el.type='button';if(action)el.addEventListener('click',action);return el;};
 function request(command,input={}){
  if(!window.AndroidAI?.localPairRequest)return Promise.reject(Error('La conexión local requiere esta versión instalada en Android.'));
  const id='lp-'+Date.now()+'-'+(++sequence);
  return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{requests.delete(id);reject(Error('No se recibió respuesta. Vuelve a consultar el estado antes de reintentar.'));},command==='scan'?90000:20000);requests.set(id,{resolve,reject,timer,parts:[],bytes:0});try{window.AndroidAI.localPairRequest(id,command,JSON.stringify(input));}catch(error){clearTimeout(timer);requests.delete(id);reject(error);}});
 }
 window.TruchAppLocalPairReceive=(id,ok,index,count,part)=>{
  const pending=requests.get(id);if(!pending)return;
  if(!Number.isInteger(index)||!Number.isInteger(count)||count<1||count>128||index<0||index>=count||typeof part!=='string'||pending.bytes+part.length>4*1024*1024){clearTimeout(pending.timer);requests.delete(id);pending.reject(Error('Respuesta local inválida'));return;}
  if(pending.parts[index]!==undefined)return;pending.bytes+=part.length;pending.parts[index]=part;
  if(pending.parts.filter(v=>v!==undefined).length!==count)return;
  clearTimeout(pending.timer);requests.delete(id);try{const value=JSON.parse(pending.parts.join(''));if(!ok)throw Error(value.error||'No se pudo completar la acción local');pending.resolve(value);}catch(error){pending.reject(error);}
 };
 function accept(value){
  if(!value||value.supported!==true||!['admin','collaborator'].includes(value.mode))throw Error('Estado de conexión local inválido');
  for(const key of ['peers','services','sessions'])if(!Array.isArray(value[key]))throw Error('Estado de conexión local inválido');
  const changed=JSON.stringify(state)!==JSON.stringify(value);if(value.sessions.some(next=>next.state==='verify'&&!state.sessions.some(old=>old.id===next.id&&old.state==='verify')))selectedTab='connection';state=value;if(dialog?.open)render();if(qrDialog?.open)updateQr();
  if(changed)window.dispatchEvent(new Event('truchapp-local-pair-updated'));
 }
 async function refresh(){if(!window.AndroidAI?.localPairRequest)return;if(loading){refreshAgain=true;return;}loading=true;try{accept(await request('status'));}catch(error){if(dialog?.open)errorText(error.message);}finally{loading=false;if(refreshAgain){refreshAgain=false;setTimeout(refresh,0);}}}
 function errorText(text){for(const id of ['lpError','lpPeerError'])if($(id)){$(id).textContent='';$(id).hidden=true;}const target=selectedTab==='peers'&&$('lpPeerError')?$('lpPeerError'):$('lpError');if(target){target.textContent=text;target.hidden=!text;}}
 function isOn(){return !!state.enabled||!!state.listening||!!state.searching||state.sessions.some(s=>s.state!=='disconnected');}
 function selectTab(tab,focus=false){selectedTab=tab;applyTabs();renderPeers();if(focus)$(tab==='peers'?'lpTabPeers':'lpTabConnection').focus();}
 function applyTabs(){if(!dialog)return;for(const [tab,id,panel] of [['connection','lpTabConnection','lpPanelConnection'],['peers','lpTabPeers','lpPanelPeers']]){const active=selectedTab===tab;$(id).setAttribute('aria-selected',String(active));$(id).tabIndex=active?0:-1;$(panel).hidden=!active;}}

 async function action(command,input={}){
  if(busy)return;busy=true;errorText('');updateButtons();
  try{const value=await request(command,input);accept(value);if(value.qr)showQr(value.qr);return true;}catch(error){errorText(error.message);await refresh();return false;}finally{busy=false;updateButtons();}
 }
 function updateButtons(){if(!dialog)return;dialog.querySelectorAll('[data-lp-command],[data-lp-connect]').forEach(el=>el.disabled=busy||!state.supported||(el.hasAttribute('data-lp-connect')&&(state.retryAfterMs>0||(state.mode==='collaborator'&&state.sessions.length>0))));dialog.querySelectorAll('[data-lp-editable]').forEach(el=>el.disabled=busy);$('lpBusy').textContent=busy?'Procesando…':'';}
 function activePeers(){return(state.peers||[]).filter(p=>p&&!p.revoked&&p.role==='admin'&&/^[0-9a-f]{64}$/.test(p.fingerprint));}
 function hasAdminLink(){return state.supported===true&&state.mode==='collaborator'&&activePeers().length>0;}
 // Enrollment reuses the same request framing and native authorization as the full panel.
 async function enrollment(command,input={}){
  if(!['status','search','connect','scan','confirm','reject','stop'].includes(command))throw Error('Acción de vinculación no permitida.');
  if(busy)throw Error('Espera a que termine la acción actual.');busy=true;updateButtons();
  try{const value=await request(command,input);accept(value);return value;}finally{busy=false;updateButtons();}
 }
 function assigned(){const out=[];for(const peer of activePeers())if(Array.isArray(peer.lots))for(const lot of peer.lots)if(lot&&typeof lot.id==='string')out.push({...lot,owner:peer.fingerprint,ownerName:peer.name,permission:peer.permission});return out;}
 function connected(fingerprint){return state.sessions.some(s=>s.fingerprint===fingerprint&&s.state==='connected');}
 function build(){
  if(dialog)return;dialog=document.createElement('dialog');dialog.id='localPairingDialog';dialog.setAttribute('aria-labelledby','lpTitle');
  dialog.innerHTML=`<div class="lp-body"><header class="lp-top"><button id="lpClose" class="lp-back" type="button" aria-label="Volver">${svg('M15 6l-6 6 6 6')}</button><div><small>Tu equipo · <span id="lpRoleTitle"></span></small><h2 id="lpTitle">Conexión local</h2></div></header>
   <div class="lp-tabs" role="tablist" aria-label="Conexión y equipos"><button type="button" class="lp-tab" role="tab" id="lpTabConnection" aria-selected="true" aria-controls="lpPanelConnection">Conexión<span id="lpRequestsBadge" class="lp-tab-count" hidden></span></button><button type="button" class="lp-tab" role="tab" id="lpTabPeers" aria-selected="false" aria-controls="lpPanelPeers" tabindex="-1"><span id="lpPeersLabel">Colaboradores</span><span id="lpPeerCount" class="lp-tab-count">0</span></button></div>
   <p id="lpBusy" class="lp-note" role="status"></p><p id="lpError" class="lp-error" role="alert" hidden></p>
   <section class="lp-panel" id="lpPanelConnection" role="tabpanel" aria-labelledby="lpTabConnection"><div id="lpSessions"></div><section class="lp-card"><div class="lp-master"><span class="lp-master-icon">${svg('M2 9a15 15 0 0 1 20 0M5.5 12.5a10 10 0 0 1 13 0M9 16a5 5 0 0 1 6 0M12 19.5h.01')}</span><div class="lp-master-text"><b>Conexión local</b><span id="lpState" role="status">Desactivada</span></div><label class="lp-switch lp-master-switch"><input type="checkbox" role="switch" id="lpMaster" aria-label="Activar conexión local" data-lp-command><span></span></label></div><div class="lp-divider"></div>
   <div class="lp-slots-head"><span id="lpSlotsLabel">Colaboradores conectados</span><span><b id="lpLive">0</b> / <span id="lpLimit">20</span></span></div><span id="lpCapacity" class="lp-sr-only" aria-live="polite"></span><div id="lpSlots" class="lp-slots" aria-hidden="true"></div><p id="lpNotice" class="lp-note lp-slots-note" role="status"></p>
   <div id="lpAdminActions" class="lp-stack"><button type="button" id="lpQr" class="lp-button lp-secondary" data-lp-command>${svg('M3 3h6v6H3zM15 3h6v6h-6zM3 15h6v6H3zM15 15h2v2h-2zM19 15h2v6h-6v-2')}<span>Generar QR de vinculación</span></button><button type="button" id="lpInvite" class="lp-button" data-lp-command>${svg('M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1')}<span>Recibir solicitudes</span></button><button type="button" id="lpListen" class="lp-button lp-secondary" data-lp-command>${svg('M20 11a8 8 0 0 0-14.5-4.5L4 8M4 4v4h4M4 13a8 8 0 0 0 14.5 4.5L20 16M20 20v-4h-4')}<span>Activar servidor</span></button></div>
   <div id="lpCollaboratorActions"><div class="lp-stack"><button type="button" id="lpSearch" class="lp-button" data-lp-command>${svg('M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0')}<span>Buscar administrador</span></button><button type="button" id="lpScan" class="lp-button lp-secondary" data-lp-command>Escanear QR</button><button type="button" id="lpManualOpen" class="lp-button lp-secondary">${svg('M4 5h16v11H4zM8 20h8M12 16v4')}<span>Usar dirección local</span></button></div><details class="lp-manual" id="lpManualPanel"><summary>Conectar con dirección local</summary><label for="lpEndpoint">Dirección que muestra el administrador</label><input id="lpEndpoint" placeholder="192.168.1.5:41435" autocomplete="off" inputmode="text" maxlength="24"><button type="button" id="lpConnect" class="lp-button" data-lp-command data-lp-connect>Enviar solicitud</button></details></div>
   <div id="lpConnectionInfo" hidden><p id="lpRetry" class="lp-note" role="status"></p><p id="lpAddress" class="lp-address" hidden></p><p id="lpExpiry" class="lp-note"></p><div id="lpServices"></div></div></section>
   <section class="lp-card"><h3>Antes de empezar</h3><div class="lp-check"><span class="lp-tick">${svg('M5 12.5l4.5 4.5L19 7.5')}</span><p>Conecta ambos teléfonos a la <b>misma Wi-Fi</b>, o uno a la zona Wi-Fi del otro.</p></div><div class="lp-check"><span class="lp-tick">${svg('M5 12.5l4.5 4.5L19 7.5')}</span><p>Activa la conexión en ambos teléfonos. Puede continuar <b>en segundo plano</b>; apágala desde este panel o la notificación.</p></div></section></section>
   <section class="lp-panel" id="lpPanelPeers" role="tabpanel" aria-labelledby="lpTabPeers" hidden><h3 id="lpPeersTitle" class="lp-sr-only">Colaboradores vinculados</h3><div id="lpPeers"></div></section>
   <details class="lp-about"><summary>Acerca de esta conexión</summary><p class="lp-note">Se comparten la vinculación, los permisos y los nombres de los lotes asignados. El registro compartido estará disponible próximamente.</p><p class="lp-note">El QR permite localizar al administrador; requiere su aprobación. WebRTC por internet: próximamente.</p></details></div>`;
  document.body.append(dialog);$('lpClose').addEventListener('click',closeView);
  $('lpQr').addEventListener('click',()=>action('qr'));$('lpScan').addEventListener('click',()=>action('scan'));$('lpInvite').addEventListener('click',()=>action('invite'));$('lpListen').addEventListener('click',()=>action(isOn()?'stop':'listen'));$('lpSearch').addEventListener('click',()=>action('search'));$('lpConnect').addEventListener('click',()=>action('connect',{endpoint:$('lpEndpoint').value.trim()}));
  $('lpMaster').addEventListener('change',event=>{const wanted=event.target.checked;event.target.checked=isOn();action(wanted?(state.mode==='admin'?'listen':'search'):'stop');});
  $('lpManualOpen').addEventListener('click',()=>{$('lpManualPanel').open=true;$('lpEndpoint').focus();});
  for(const [id,tab] of [['lpTabConnection','connection'],['lpTabPeers','peers']]){$(id).addEventListener('click',()=>selectTab(tab));$(id).addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();selectTab(event.key==='Home'?'connection':event.key==='End'?'peers':selectedTab==='connection'?'peers':'connection',true);}});}
  dialog.addEventListener('close',()=>{if(dialog.open)return;frameObserver?.disconnect();frameObserver=null;restoreUnderlays();clearInterval(poll);poll=null;previous?.focus?.({preventScroll:true});});
 }

 function controls(container,key,selection={},compact=false){
  const draft=drafts.get(key)||{permission:selection.permission==='record'?'record':'view',lotIds:new Set(Array.isArray(selection.lotIds)?selection.lotIds:[])};drafts.set(key,draft);
  let permissions=container,advanced=null;if(compact){advanced=node('details',undefined,'lp-permission-more');advanced.append(node('summary','Permiso de registro'));permissions=node('div');advanced.append(permissions);}else container.append(node('h4','Permisos','lp-field-title'));
  function permissionRow(title,detail,checked,disabled,change){const row=node('label',undefined,'lp-option'),text=node('span',undefined,'lp-option-text');text.append(node('strong',title),node('small',detail));const toggle=node('span',undefined,'lp-switch'),input=node('input');input.type='checkbox';input.checked=checked;input.disabled=disabled;input.setAttribute('aria-label',title);if(!disabled){input.setAttribute('data-lp-editable','');input.addEventListener('change',change);}toggle.append(input,node('span'));row.append(text,toggle);permissions.append(row);}
  if(!compact)permissionRow('Consultar lotes','Puede ver los lotes asignados',true,true);
  permissionRow('Autorizar registro (próximamente)','El registro compartido aún no está disponible',draft.permission==='record',false,event=>draft.permission=event.target.checked?'record':'view');
  const field=node('fieldset',undefined,'lp-lots'),legend=node('legend','Lotes asignados · '),countLabel=node('span',String(draft.lotIds.size));legend.append(countLabel);field.append(legend);
  const available=Array.isArray(state.availableLots)?state.availableLots:[];
  if(!available.length)field.append(node('p','Aún no hay lotes. Puedes asignarlos después.','lp-note'));
  for(const lot of available){const row=node('label',undefined,'lp-lot-choice lp-chip'),input=node('input');input.type='checkbox';input.value=lot.id;input.checked=draft.lotIds.has(lot.id);input.setAttribute('aria-label','Asignar '+(lot.code||'Lote'));input.setAttribute('data-lp-editable','');input.addEventListener('change',()=>{if(input.checked){if(draft.lotIds.size>=100){input.checked=false;errorText('Puedes asignar hasta 100 lotes por colaborador.');return;}draft.lotIds.add(lot.id);}else draft.lotIds.delete(lot.id);countLabel.textContent=String(draft.lotIds.size);});const text=node('span');text.innerHTML=svg('M5 12.5l4.5 4.5L19 7.5');text.append(document.createTextNode(lot.code||'Lote'));row.append(input,text);field.append(row);}
  container.append(field);if(compact){container.append(node('p','Selecciona los lotes y guarda los cambios.','lp-hint'),advanced);}return draft;
 }
 function renderSessions(){
  if(!state.sessions.some(s=>s.id===reviewSession&&s.state==='verify'))reviewSession=state.sessions.find(s=>s.state==='verify')?.id||'';
  const root=$('lpSessions'),key=JSON.stringify([state.sessions,state.availableLots,reviewSession]);if(root.dataset.key===key)return;root.dataset.key=key;root.replaceChildren();
  for(const session of state.sessions){
   if(session.state==='connected')continue;
   const card=node('section',undefined,'lp-card lp-verification');card.dataset.session=session.id;card.append(node('h3',session.name||'Conectando equipo…'));
   if(session.state==='verify'&&session.id!==reviewSession){card.append(node('p','Solicitud pendiente de revisión.','lp-note'),button('Revisar solicitud',()=>{reviewSession=session.id;root.dataset.key='';renderSessions();}));root.append(card);continue;}
   if(['verify','waiting'].includes(session.state)){
    const admin=state.mode==='admin';
    card.append(node('p',admin?(session.state==='verify'?'Solicitud de vinculación. Elige los lotes y permisos antes de aprobar.':'Aprobada. Completando la vinculación…'):'Solicitud enviada. Esperando aprobación del administrador.','lp-note'));
    if(admin&&session.state==='verify'){
     const draft=controls(card,session.id);
     const approve=button('Aprobar solicitud',()=>action('confirm',{session:session.id,code:session.code,permission:draft.permission,lotIds:[...draft.lotIds]}));approve.setAttribute('data-lp-command','');card.append(approve);
    }
    if(!admin||session.state==='verify'){const cancel=button(admin?'Rechazar solicitud':'Cancelar solicitud',()=>action('reject',{session:session.id}),'lp-secondary');cancel.setAttribute('data-lp-command','');card.append(cancel);}
   }else card.append(node('p',session.state==='saving'?'Guardando vinculación…':'Estableciendo conexión cifrada…','lp-note'));
   root.append(card);
  }
 }
 function openPeer(fingerprint){editingPeer=fingerprint;$('lpPeers').dataset.key='';renderPeers();const control=$('lpPeers').querySelector('.lp-perm-editor .lp-lots input')||$('lpPeers').querySelector('.lp-save');control?.focus({preventScroll:true});}
 function renderPeers(){
  const root=$('lpPeers');if(selectedTab!=='peers'){root.replaceChildren();root.dataset.key='';return;}
  const active=state.peers.filter(p=>!p.revoked);if(!state.peers.some(p=>p.fingerprint===editingPeer&&!p.revoked))editingPeer=state.mode==='admin'&&active.length===1?active[0].fingerprint:'';
  const key=JSON.stringify([state.peers,state.sessions.map(s=>[s.fingerprint,s.state]),state.availableLots,state.mode,editingPeer]);if(root.dataset.key===key)return;root.dataset.key=key;root.replaceChildren();
  if(!state.peers.length)root.append(node('p','Todavía no hay equipos vinculados.','lp-empty'));
  for(const peer of state.peers){
   const card=node('article',undefined,'lp-card lp-peer');card.dataset.peer=peer.fingerprint;const person=button('',()=>openPeer(peer.fingerprint),'lp-person');person.setAttribute('aria-label','Ver ajustes de '+(peer.name||'Equipo'));const avatar=node('span',initials(peer.name),'lp-avatar'),info=node('span',undefined,'lp-person-info');info.append(node('strong',peer.name||'Equipo','lp-person-name'));
   const status=node('span',undefined,'lp-tag');status.append(node('i'),node('span',peer.revoked?'Acceso retirado':connected(peer.fingerprint)?'Conectado por red local':'Vinculado · Sin conexión'));person.classList.toggle('lp-connected',connected(peer.fingerprint)&&!peer.revoked);info.append(status);person.append(avatar,info);card.append(person);
   const list=node('div',undefined,'lp-permission-list');for(const [label,right,path,soon] of [['Consulta',peer.revoked?'Acceso retirado':'Autorizada','M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6',false],['Registro','Próximamente','M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z',true]]){const row=node('div',undefined,'lp-permission-row'+(soon?' lp-soon':'')),icon=node('span',undefined,'lp-mini-icon');icon.innerHTML=svg(path);row.append(icon,node('strong',label),node('span',right));list.append(row);}card.append(list);
   if(state.mode==='admin'&&!peer.revoked&&editingPeer===peer.fingerprint){const editor=node('div',undefined,'lp-perm-editor'),error=node('p','', 'lp-error');error.id='lpPeerError';error.hidden=true;error.setAttribute('role','alert');editor.append(error);const draft=controls(editor,'peer-'+peer.fingerprint,peer,true);const save=button('Guardar cambios',async()=>{if(await action('update',{fingerprint:peer.fingerprint,permission:draft.permission,lotIds:[...draft.lotIds]})){drafts.delete('peer-'+peer.fingerprint);root.dataset.key='';renderPeers();[...root.querySelectorAll('[data-peer]')].find(el=>el.dataset.peer===peer.fingerprint)?.querySelector('.lp-save')?.focus({preventScroll:true});}},'lp-button lp-save');save.setAttribute('data-lp-command','');editor.append(save);card.append(editor);
   }else{const lots=state.mode==='admin'?(peer.lotIds||[]).map(id=>({code:state.availableLots?.find(lot=>lot.id===id)?.code||'Lote asignado'})):(peer.lots||[]);card.append(node('p','Lotes asignados · '+lots.length,'lp-field-title'));const chips=node('div',undefined,'lp-readonly-chips');for(const lot of lots)chips.append(node('span',lot.code||'Lote','lp-assigned-chip'));if(!lots.length)chips.append(node('span','Sin lotes asignados','lp-hint'));card.append(chips);if(state.mode==='admin'&&!peer.revoked)card.append(button('Editar lotes y permisos',()=>openPeer(peer.fingerprint),'lp-button lp-secondary'));}
   if(!peer.revoked){if(connected(peer.fingerprint)){const disconnect=button('Desconectar equipo',()=>action('disconnect',{fingerprint:peer.fingerprint}),'lp-button lp-secondary');disconnect.setAttribute('data-lp-command','');card.append(disconnect);}const removal=node('div',undefined,'lp-removal'),remove=button(state.mode==='admin'?'Desvincular a '+(peer.name||'este equipo'):'Desvincularme',()=>{removal.replaceChildren(node('p','¿Retirar esta vinculación? Tendrá que aprobarse de nuevo.','lp-note'));removal.append(button('Cancelar',()=>removal.replaceChildren(remove),'lp-button lp-secondary'),button('Sí, retirar',()=>action('revoke',{fingerprint:peer.fingerprint}),'lp-button lp-danger'));},'lp-button lp-danger');removal.append(remove);card.append(node('div',undefined,'lp-divider'),removal);}root.append(card);
  }
  updateButtons();
 }

 function render(){
  if(!dialog)return;syncFrame();const admin=(state.mode||window.TruchAppAccess?.read().mode)==='admin';$('lpRoleTitle').textContent=admin?'Administrador':'Colaborador';$('lpAdminActions').hidden=!admin;$('lpCollaboratorActions').hidden=admin;$('lpPeersTitle').textContent=admin?'Colaboradores vinculados':'Administradores vinculados';
  $('lpPeersLabel').textContent=admin?'Colaboradores':'Administradores';applyTabs();const live=Number.isInteger(state.connectedCount)?state.connectedCount:state.sessions.filter(s=>s.state==='connected').length,limit=admin?(state.maxConnections||20):1,pending=state.sessions.filter(s=>['verify','waiting','saving','handshake'].includes(s.state)).length,on=isOn();
  $('lpMaster').setAttribute('aria-label',on?(admin?'Apagar servidor':'Apagar conexión local'):(admin?'Activar servidor':'Activar conexión local'));$('lpMaster').checked=on;$('lpListen').querySelector('span').textContent=on?'Apagar servidor':'Activar servidor';dialog.classList.toggle('lp-on',on);$('lpState').textContent=!on?'Desactivada':live?(admin?'Activa · '+live+' conectado'+(live===1?'':'s'):'Conectada al administrador'):state.reconnecting?'Reconectando automáticamente…':state.enabled&&!state.listening&&admin?'Servidor activo · esperando red':state.searching?'Buscando administrador…':pending?'Vinculando equipo…':'Activa · esperando colaboradores';$('lpLive').textContent=String(live);$('lpLimit').textContent=String(limit);$('lpSlotsLabel').textContent=admin?'Colaboradores conectados':'Administradores conectados';$('lpCapacity').textContent=live+' / '+limit+' '+(admin?'colaboradores':'administradores')+' conectados';
  const slots=$('lpSlots');if(slots.children.length!==limit){slots.replaceChildren();for(let i=0;i<limit;i++)slots.append(node('span',undefined,'lp-slot'));}for(const [i,slot] of [...slots.children].entries()){slot.classList.toggle('lp-full',i<live);slot.classList.toggle('lp-waiting',on&&i===live);}
  $('lpPeerCount').textContent=String(state.peers.filter(p=>!p.revoked).length);$('lpRequestsBadge').hidden=!pending;$('lpRequestsBadge').textContent=String(pending);$('lpRetry').textContent=state.retryAfterMs>0?(state.reconnecting?'Próximo reintento automático en ':'Puedes volver a conectar en ')+Math.ceil(state.retryAfterMs/1000)+' s.':'';
  const note=state.notice||(!state.supported?'Instala esta versión en Android para vincular los equipos.':on?'Pide al otro equipo que abra TruchApp para conectarse.':'Activa una conexión local para empezar.');$('lpNotice').textContent=note;$('lpNotice').hidden=!$('lpError').hidden&&$('lpError').textContent===note;$('lpAddress').hidden=!state.endpoint;$('lpAddress').textContent=state.endpoint?'Dirección local: '+state.endpoint:'';
  $('lpExpiry').textContent=state.invitationUntil>Date.now()?'Recepción de solicitudes hasta '+new Date(state.invitationUntil).toLocaleTimeString('es-PE',{hour:'2-digit',minute:'2-digit'}):state.listening?'Servidor activo en segundo plano. Recepción cerrada; se admiten equipos ya vinculados.':state.enabled?'La conexión se recuperará cuando vuelva la red.':'';
  const root=$('lpServices'),key=JSON.stringify(state.services);if(root.dataset.key!==key){root.dataset.key=key;root.replaceChildren();for(const service of state.services){const row=node('div',undefined,'lp-service');const connect=button('Enviar solicitud',()=>action('connect',{service:service.id}));connect.setAttribute('data-lp-connect','');row.append(node('span',service.name),connect);root.append(row);}}
  $('lpConnectionInfo').hidden=!(state.endpoint||state.searching||state.listening||state.services.length||state.retryAfterMs>0);renderSessions();renderPeers();updateButtons();
 }
 function showQr(value){
  if(!value||typeof value.image!=='string'||!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(value.image)||value.image.length>200000||!Number.isFinite(value.expires))throw Error('Imagen QR inválida');
  qrValue=value;if(!qrDialog){qrDialog=document.createElement('dialog');qrDialog.id='lpQrDialog';qrDialog.setAttribute('aria-labelledby','lpQrTitle');qrDialog.innerHTML='<button type="button" id="lpQrClose" class="lp-button lp-secondary">Cerrar</button><h2 id="lpQrTitle">Vincular con QR</h2><p>El colaborador debe conectarse a tu Wi-Fi o punto de acceso y escanear esta imagen. Después, aprueba su solicitud.</p><img id="lpQrImage" alt="QR de vinculación temporal del administrador"><p id="lpQrStatus" role="status"></p><button type="button" id="lpQrRenew" class="lp-button">Generar otro QR</button>';document.body.append(qrDialog);$('lpQrClose').addEventListener('click',()=>qrDialog.close());$('lpQrRenew').addEventListener('click',()=>action('qr'));qrDialog.addEventListener('close',()=>{clearInterval(qrTimer);qrTimer=null;qrValue=null;$('lpQrImage').removeAttribute('src');});}
  $('lpQrImage').src=value.image;if(!qrDialog.open)qrDialog.showModal();clearInterval(qrTimer);qrTimer=setInterval(updateQr,1000);updateQr();
 }
 function updateQr(){if(!qrValue||!qrDialog?.open)return;const valid=state.mode==='admin'&&state.listening&&state.qrExpires===qrValue.expires&&Date.now()<qrValue.expires;$('lpQrImage').hidden=!valid;$('lpQrStatus').textContent=valid?'QR válido durante '+Math.ceil((qrValue.expires-Date.now())/1000)+' s. Se necesita tu aprobación para completar el vínculo.':'Este QR venció o la conexión cambió. Genera otro QR.';}
 async function device(command,input={}){if(command!=='wifi')throw Error('Acción del dispositivo no permitida');const value=await request(command,input);accept(value);return value;}
 function closeView(){restoreUnderlays();dialog?.close();}
 function restoreUnderlays(){for(const item of underlays)item.el.inert=item.inert;underlays=[];}
 function visible(el){if(!el||!el.getClientRects().length)return false;const style=getComputedStyle(el);return style.display!=='none'&&style.visibility!=='hidden';}
 function chrome(){
  const collaborator=visible($('collaboratorApp'));
  return {surface:collaborator?document.querySelector('#collaboratorApp .co-app'):document.querySelector('.phone'),top:collaborator?document.querySelector('#collaboratorApp .co-top'):$('tnMenuOpen'),bottom:collaborator?document.querySelector('#collaboratorApp .co-nav'):$('bottomNav')};
 }
 function syncFrame(){
  if(!dialog?.open)return;const parts=chrome(),surface=parts.surface?.getBoundingClientRect();if(!surface)return;
  const viewport=window.visualViewport,viewTop=viewport?.offsetTop||0,viewBottom=viewTop+(viewport?.height||innerHeight);
  const top=visible(parts.top)?parts.top.getBoundingClientRect().bottom:surface.top;
  const bottom=visible(parts.bottom)?parts.bottom.getBoundingClientRect().top:surface.bottom;
  const start=Math.max(viewTop,surface.top,top+8),end=Math.min(viewBottom-8,surface.bottom,bottom-8);
  const width=Math.min(440,surface.width),left=surface.left+(surface.width-width)/2;
  for(const [name,value] of Object.entries({top:start,left,width,height:Math.max(0,end-start),'bottom-gap':Math.max(0,innerHeight-end)}))dialog.style.setProperty('--lp-frame-'+name,value+'px');
 }
 function open(){
  if(document.getElementById('yb-intro'))return;if(window.TruchAppAccess?.read().mode==='collaborator'&&!hasAdminLink()){window.TruchAppIntro?.openModePicker();return;}build();selectedTab='connection';previous=document.activeElement;window.TruchAppMenu?.close();$('coMenuDialog')?.close();dialog.classList.add('lp-framed');if(!dialog.open)dialog.show();
  restoreUnderlays();const background=visible($('collaboratorApp'))?$('coMain'):document.querySelector('.phone>.content');if(background){underlays=[{el:background,inert:background.inert}];background.inert=true;}syncFrame();frameObserver?.disconnect();if(window.ResizeObserver){frameObserver=new ResizeObserver(syncFrame);for(const el of Object.values(chrome()))if(el)frameObserver.observe(el);}
  render();refresh();clearInterval(poll);poll=setInterval(refresh,1800);
 }
 // Navigation is the original app chrome. Leaving this view never sends a native stop/revoke.
 document.addEventListener('click',event=>{if(dialog?.open&&event.target.closest('#tnMenuOpen,#bottomNav [data-target],#coMenu,#coProfile,[data-co-tab]')){previous=null;closeView();}},true);
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!event.defaultPrevented&&dialog?.open){event.preventDefault();closeView();}});
 window.addEventListener('resize',syncFrame);window.visualViewport?.addEventListener('resize',syncFrame);window.visualViewport?.addEventListener('scroll',syncFrame);
 document.addEventListener('click',event=>{if(event.target.closest('[data-local-pair]'))open();if(event.target.closest('[data-local-scan]'))action('scan');});
 window.addEventListener('truchapp-local-pair-changed',refresh);
 window.addEventListener('truchapp-storage-committed',()=>{const mode=window.TruchAppAccess?.read().mode;if(mode!==lastMode){lastMode=mode;refresh();}});
 window.addEventListener('truchapp-data-restored',()=>{action('stop');});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
 window.TruchAppLocalPair={open,refresh,getState:()=>state,activePeers,hasAdminLink,enrollment,assigned,connected,device};refresh();
})();
