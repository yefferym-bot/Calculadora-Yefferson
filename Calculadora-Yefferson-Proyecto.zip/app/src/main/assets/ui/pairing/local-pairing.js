/* LAN pairing UI; authorization and trust live in Android, never in the mode preference. */
(function(){
 'use strict';
 const $=id=>document.getElementById(id),requests=new Map(),drafts=new Map();
 let state={supported:false,peers:[],services:[],sessions:[],availableLots:[]},dialog=null,sequence=0,loading=false,refreshAgain=false,poll=null,busy=false,lastMode='',previous=null,reviewSession='',editingPeer='',sheetKey='',peerFocus=null;
 const node=(tag,text,cls)=>{const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(cls)el.className=cls;return el;};
 const svg=path=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+path+'"/></svg>';
 const initials=name=>Array.from(String(name||'Equipo').trim())[0]?.toLocaleUpperCase('es')||'E';
 const button=(text,action,cls='lp-button')=>{const el=node('button',text,cls);el.type='button';if(action)el.addEventListener('click',action);return el;};
 function request(command,input={}){
  if(!window.AndroidAI?.localPairRequest)return Promise.reject(Error('La conexión local requiere esta versión instalada en Android.'));
  const id='lp-'+Date.now()+'-'+(++sequence);
  return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{requests.delete(id);reject(Error('No se recibió respuesta. Vuelve a consultar el estado antes de reintentar.'));},20000);requests.set(id,{resolve,reject,timer,parts:[],bytes:0});try{window.AndroidAI.localPairRequest(id,command,JSON.stringify(input));}catch(error){clearTimeout(timer);requests.delete(id);reject(error);}});
 }
 window.TruchAppLocalPairReceive=(id,ok,index,count,part)=>{
  const pending=requests.get(id);if(!pending)return;
  if(!Number.isInteger(index)||!Number.isInteger(count)||count<1||count>128||index<0||index>=count||typeof part!=='string'||pending.bytes+part.length>4*1024*1024){clearTimeout(pending.timer);requests.delete(id);pending.reject(Error('Respuesta local inválida'));return;}
  if(pending.parts[index]!==undefined)return;pending.bytes+=part.length;pending.parts[index]=part;
  if(pending.parts.filter(v=>v!==undefined).length!==count)return;
  clearTimeout(pending.timer);requests.delete(id);try{const value=JSON.parse(pending.parts.join(''));if(!ok)throw Error(value.error||'No se pudo completar la acción local');pending.resolve(value);}catch(error){pending.reject(error);}
 };
 function accept(value){
  if(!value||value.supported!==true||!['admin','collaborator'].includes(value.mode))throw Error('Estado de conexión local inválido');
  for(const key of ['peers','services','sessions'])if(!Array.isArray(value[key]))throw Error('Estado de conexión local inválido');
  const changed=JSON.stringify(state)!==JSON.stringify(value);state=value;if(dialog?.open)render();
  if(changed)window.dispatchEvent(new Event('truchapp-local-pair-updated'));
 }
 async function refresh(){if(!window.AndroidAI?.localPairRequest)return;if(loading){refreshAgain=true;return;}loading=true;try{accept(await request('status'));}catch(error){if(dialog?.open)errorText(error.message);}finally{loading=false;if(refreshAgain){refreshAgain=false;setTimeout(refresh,0);}}}
 function errorText(text){for(const id of ['lpError','lpPeerError'])if($(id)){$(id).textContent='';$(id).hidden=true;}const target=$('lpPeerDialog')?.open?$('lpPeerError'):$('lpError');if(target){target.textContent=text;target.hidden=!text;}}
 async function action(command,input={}){
  if(busy)return;busy=true;errorText('');updateButtons();
  try{accept(await request(command,input));return true;}catch(error){errorText(error.message);await refresh();return false;}finally{busy=false;updateButtons();}
 }
 function updateButtons(){if(!dialog)return;dialog.querySelectorAll('[data-lp-command],[data-lp-connect]').forEach(el=>el.disabled=busy||!state.supported||(el.hasAttribute('data-lp-connect')&&state.retryAfterMs>0));dialog.querySelectorAll('[data-lp-editable]').forEach(el=>el.disabled=busy);$('lpBusy').textContent=busy?'Procesando…':'';$('lpPeerBusy').textContent=busy?'Procesando…':'';}
 function activePeers(){return(state.peers||[]).filter(p=>p&&!p.revoked&&p.role==='admin'&&/^[0-9a-f]{64}$/.test(p.fingerprint));}
 function assigned(){const out=[];for(const peer of activePeers())if(Array.isArray(peer.lots))for(const lot of peer.lots)if(lot&&typeof lot.id==='string')out.push({...lot,owner:peer.fingerprint,ownerName:peer.name,permission:peer.permission});return out;}
 function connected(fingerprint){return state.sessions.some(s=>s.fingerprint===fingerprint&&s.state==='connected');}
 function build(){
  if(dialog)return;dialog=document.createElement('dialog');dialog.id='localPairingDialog';dialog.setAttribute('aria-labelledby','lpTitle');
  dialog.innerHTML=`<div class="lp-body">
   <header class="lp-hero"><div class="lp-bar"><div><span class="lp-eyebrow">Tu equipo · <span id="lpRoleTitle"></span></span><h2 id="lpTitle">Conexión local</h2></div><button id="lpClose" class="lp-close" type="button" aria-label="Cerrar conexión local">${svg('M6 6l12 12M18 6L6 18')}</button></div>
    <div class="lp-gauge"><div class="lp-ring" aria-hidden="true"><svg viewBox="0 0 120 120"><circle class="lp-ring-bg" cx="60" cy="60" r="54" fill="none" stroke-width="9"/><circle class="lp-ring-fg" id="lpArc" cx="60" cy="60" r="54" fill="none" stroke-width="9" stroke-dasharray="339.3" stroke-dashoffset="339.3"/></svg><span class="lp-pulse"></span><div class="lp-ring-mid"><b id="lpLive">0</b><span id="lpRingLabel">de 20 conectados</span></div></div><span id="lpCapacity" class="lp-sr-only" aria-live="polite"></span><div class="lp-pill"><i></i><span id="lpState">Sin conexión local</span></div><span id="lpPending" class="lp-pending" hidden></span></div>
   </header>
   <main class="lp-content"><div id="lpAdminActions" class="lp-actions lp-tiles"><button type="button" id="lpInvite" class="lp-tile lp-main" data-lp-command><span class="lp-ico">${svg('M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1')}</span><span>Vincular colaborador</span></button><button type="button" id="lpListen" class="lp-tile" data-lp-command><span class="lp-ico">${svg('M20 11a8 8 0 0 0-14.5-4.5L4 8M4 4v4h4M4 13a8 8 0 0 0 14.5 4.5L20 16M20 20v-4h-4')}</span><span>Activar reconexión</span></button></div>
   <div id="lpCollaboratorActions"><div class="lp-actions lp-tiles"><button type="button" id="lpSearch" class="lp-tile lp-main" data-lp-command><span class="lp-ico">${svg('M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0')}</span><span>Buscar administrador</span></button><button type="button" id="lpManualOpen" class="lp-tile"><span class="lp-ico">${svg('M4 5h16v11H4zM8 20h8M12 16v4')}</span><span>Usar dirección local</span></button></div><details class="lp-manual" id="lpManualPanel"><summary>Conectar con dirección local</summary><label for="lpEndpoint">Dirección que muestra el administrador</label><input id="lpEndpoint" placeholder="192.168.1.5:41435" autocomplete="off" inputmode="text" maxlength="24"><button type="button" id="lpConnect" class="lp-button" data-lp-command data-lp-connect>Conectar</button></details></div>
   <p id="lpError" class="lp-error" role="alert" hidden></p><section id="lpConnectionInfo" class="lp-card lp-connection-info" hidden><p id="lpNotice" role="status" aria-live="polite"></p><p id="lpRetry" class="lp-note" role="status"></p><p id="lpAddress" class="lp-address" hidden></p><p id="lpExpiry" class="lp-note"></p><div id="lpServices"></div></section><div id="lpSessions"></div>
   <section class="lp-block" aria-labelledby="lpHowTitle"><div class="lp-block-head"><h3 id="lpHowTitle">Cómo conectar</h3></div><div class="lp-steps"><div class="lp-step"><span>1</span><p>Conecta ambos teléfonos a la <b>misma Wi-Fi</b>, o uno a la zona Wi-Fi del otro.</p></div><div class="lp-step"><span>2</span><p>Mantén <b>TruchApp abierta</b> en ambos.</p></div><div class="lp-step"><span>3</span><p id="lpThirdStep">Activa una conexión local para empezar.</p></div></div></section>
   <section class="lp-block" aria-labelledby="lpPeersTitle"><div class="lp-block-head"><h3 id="lpPeersTitle">Colaboradores vinculados</h3><span id="lpPeerCount" class="lp-count">0</span></div><div id="lpPeers"></div></section>
   <footer class="lp-footer"><span id="lpBusy" role="status"></span><button type="button" id="lpStop" class="lp-off" data-lp-command>${svg('M12 3v8M6.3 6.8a8 8 0 1 0 11.4 0')}<span>Desactivar conexión</span></button></footer>
   <details class="lp-about"><summary>Acerca de esta conexión</summary><p class="lp-note">Se comparten la vinculación, los permisos y los nombres de los lotes asignados. El registro compartido estará disponible próximamente.</p><p class="lp-note">WebRTC por internet y escanear QR: próximamente.</p></details>
   </main></div>
   <dialog id="lpPeerDialog" aria-labelledby="lpPeerTitle"><div class="lp-grab"></div><header class="lp-sheet-head"><span id="lpPeerAvatar" class="lp-avatar"></span><h3 id="lpPeerTitle"></h3><button type="button" id="lpPeerClose" class="lp-sheet-close" aria-label="Cerrar ajustes del equipo">${svg('M6 6l12 12M18 6L6 18')}</button></header><p id="lpPeerError" class="lp-error" role="alert" hidden></p><div id="lpPeerContent"></div><p id="lpPeerBusy" role="status"></p></dialog>`;
  document.body.append(dialog);$('lpClose').addEventListener('click',()=>dialog.close());
  $('lpInvite').addEventListener('click',()=>action('invite'));$('lpListen').addEventListener('click',()=>action('listen'));$('lpSearch').addEventListener('click',()=>action('search'));$('lpConnect').addEventListener('click',()=>action('connect',{endpoint:$('lpEndpoint').value.trim()}));$('lpStop').addEventListener('click',()=>action('stop'));
  $('lpManualOpen').addEventListener('click',()=>{$('lpManualPanel').open=true;$('lpEndpoint').focus();});
  $('lpPeerClose').addEventListener('click',()=>$('lpPeerDialog').close());
  $('lpPeerDialog').addEventListener('click',event=>{if(event.target===$('lpPeerDialog')){const rect=event.target.getBoundingClientRect();if(event.clientY<rect.top||event.clientY>rect.bottom||event.clientX<rect.left||event.clientX>rect.right)event.target.close();}});
  $('lpPeerDialog').addEventListener('close',()=>{editingPeer='';sheetKey='';$('lpPeerContent').replaceChildren();$('lpPeerError').hidden=true;if(dialog.open)(peerFocus?.isConnected?peerFocus:$('lpClose')).focus({preventScroll:true});});
  dialog.addEventListener('close',()=>{if(dialog.open)return;if($('lpPeerDialog').open)$('lpPeerDialog').close();clearInterval(poll);poll=null;previous?.focus?.({preventScroll:true});});
 }
 function controls(container,key,selection={}){
  const draft=drafts.get(key)||{permission:selection.permission==='record'?'record':'view',lotIds:new Set(Array.isArray(selection.lotIds)?selection.lotIds:[])};drafts.set(key,draft);
  container.append(node('h4','Permisos','lp-field-title'));
  function permissionRow(title,detail,checked,disabled,change){const row=node('label',undefined,'lp-option'),text=node('span',undefined,'lp-option-text');text.append(node('strong',title),node('small',detail));const toggle=node('span',undefined,'lp-switch'),input=node('input');input.type='checkbox';input.checked=checked;input.disabled=disabled;input.setAttribute('aria-label',title);if(!disabled){input.setAttribute('data-lp-editable','');input.addEventListener('change',change);}toggle.append(input,node('span'));row.append(text,toggle);container.append(row);}
  permissionRow('Consultar lotes','Puede ver los lotes asignados',true,true);
  permissionRow('Autorizar registro (próximamente)','El registro compartido aún no está disponible',draft.permission==='record',false,event=>draft.permission=event.target.checked?'record':'view');
  const field=node('fieldset',undefined,'lp-lots');field.append(node('legend','Lotes asignados'));
  const available=Array.isArray(state.availableLots)?state.availableLots:[];
  if(!available.length)field.append(node('p','Aún no hay lotes. Puedes asignarlos después.','lp-note'));
  for(const lot of available){const row=node('label',undefined,'lp-lot-choice lp-option'),input=node('input');input.type='checkbox';input.value=lot.id;input.checked=draft.lotIds.has(lot.id);input.setAttribute('aria-label','Asignar '+(lot.code||'Lote'));input.setAttribute('data-lp-editable','');input.addEventListener('change',()=>{if(input.checked){if(draft.lotIds.size>=100){input.checked=false;errorText('Puedes asignar hasta 100 lotes por colaborador.');return;}draft.lotIds.add(lot.id);}else draft.lotIds.delete(lot.id);});const text=node('span',undefined,'lp-option-text');text.append(node('strong',lot.code||'Lote'));if(lot.stage||lot.unit)text.append(node('small',[lot.stage,lot.unit].filter(Boolean).join(' · ')));const toggle=node('span',undefined,'lp-switch');toggle.append(input,node('span'));row.append(text,toggle);field.append(row);}
  container.append(field);return draft;
 }
 function renderSessions(){
  if(!state.sessions.some(s=>s.id===reviewSession&&s.state==='verify'))reviewSession=state.sessions.find(s=>s.state==='verify')?.id||'';
  const root=$('lpSessions'),key=JSON.stringify([state.sessions,state.availableLots,reviewSession]);if(root.dataset.key===key)return;root.dataset.key=key;root.replaceChildren();
  for(const session of state.sessions){
   if(session.state==='connected')continue;
   const card=node('section',undefined,'lp-card lp-verification');card.dataset.session=session.id;card.append(node('h3',session.name||'Conectando equipo…'));
   if(session.state==='verify'&&session.id!==reviewSession){card.append(node('p','Solicitud pendiente de revisión.','lp-note'),button('Revisar solicitud',()=>{reviewSession=session.id;root.dataset.key='';renderSessions();}));root.append(card);continue;}
   if(['verify','waiting'].includes(session.state)){
    card.append(node('p','Comprueba que ambos teléfonos muestran exactamente este código.'),node('strong',session.code,'lp-code'));
    if(session.state==='verify'){
     const draft=state.mode==='admin'?controls(card,session.id):null;
     const check=node('label',undefined,'lp-lot-choice'),input=node('input');input.type='checkbox';input.setAttribute('aria-label','El código coincide en ambos teléfonos');check.append(input,node('span','El código coincide en ambos teléfonos'));card.append(check);
     const confirm=button(state.mode==='admin'?'Aprobar colaborador':'Confirmar código',()=>{if(!input.checked)return;action('confirm',{session:session.id,code:session.code,...(draft?{permission:draft.permission,lotIds:[...draft.lotIds]}:{})});});confirm.disabled=true;input.addEventListener('change',()=>confirm.disabled=!input.checked);card.append(confirm);
    }else card.append(node('p','Confirmado aquí. Esperando al otro teléfono…','lp-note'));
    card.append(button('Cancelar vinculación',()=>action('reject',{session:session.id}),'lp-secondary'));
   }else card.append(node('p',session.state==='connected'?'Conectado por red local.':session.state==='saving'?'Guardando vinculación…':'Estableciendo conexión cifrada…','lp-note'));
   root.append(card);
  }
 }
 function openPeer(fingerprint){editingPeer=fingerprint;peerFocus=document.activeElement;sheetKey='';renderPeerSheet();if(editingPeer&&!$('lpPeerDialog').open){$('lpPeerDialog').showModal();$('lpPeerClose').focus();}}
 function renderPeerSheet(){
  if(!editingPeer)return;const peer=state.peers.find(p=>p.fingerprint===editingPeer);if(!peer){$('lpPeerDialog').close();return;}
  const key=JSON.stringify([peer,connected(peer.fingerprint),state.availableLots,state.mode]);if(sheetKey===key)return;sheetKey=key;
  $('lpPeerTitle').textContent=peer.name||'Equipo';$('lpPeerAvatar').textContent=initials(peer.name);const content=$('lpPeerContent');content.replaceChildren();
  content.append(node('p',peer.revoked?'Acceso retirado':connected(peer.fingerprint)?'Conectado por red local':'Vinculado · Sin conexión','lp-tag'));
  if(peer.revoked){content.append(node('p','Para volver a conectar este equipo, abre una nueva invitación y aprueba el código en ambos teléfonos.','lp-note'));return;}
  if(state.mode==='admin'){
   const editor=node('div',undefined,'lp-perm-editor'),draft=controls(editor,'peer-'+peer.fingerprint,peer);
   const save=button('Guardar cambios',async()=>{if(await action('update',{fingerprint:peer.fingerprint,permission:draft.permission,lotIds:[...draft.lotIds]}))$('lpPeerDialog').close();});save.setAttribute('data-lp-command','');editor.append(save);content.append(editor);
  }else{
   content.append(node('p',peer.permission==='record'?'Consulta y registro autorizados · Registro próximamente':'Permiso de consulta','lp-note'));
   const lots=node('div',undefined,'lp-assigned');for(const lot of peer.lots||[])lots.append(node('p',lot.code||'Lote','lp-option'));content.append(node('h4','Lotes asignados','lp-field-title'),lots);
  }
  if(connected(peer.fingerprint)){const disconnect=button('Desconectar equipo',async()=>{if(await action('disconnect',{fingerprint:peer.fingerprint}))$('lpPeerDialog').close();},'lp-button lp-secondary');disconnect.setAttribute('data-lp-command','');content.append(disconnect);}
  const removal=node('div',undefined,'lp-removal');const remove=button(state.mode==='admin'?'Retirar acceso':'Desvincularme',()=>{removal.replaceChildren(node('p','¿Retirar esta vinculación? Tendrá que aprobarse de nuevo.','lp-note'));removal.append(button('Cancelar',()=>{removal.replaceChildren(remove);},'lp-button lp-secondary'),button('Sí, retirar',async()=>{if(await action('revoke',{fingerprint:peer.fingerprint}))$('lpPeerDialog').close();},'lp-button lp-danger'));},'lp-button lp-danger');removal.append(remove);content.append(removal);updateButtons();
 }
 function renderPeers(){
  const root=$('lpPeers'),key=JSON.stringify([state.peers,state.sessions.map(s=>[s.fingerprint,s.state]),state.mode]);if(root.dataset.key===key)return;root.dataset.key=key;root.replaceChildren();
  if(!state.peers.length)root.append(node('p','Todavía no hay equipos vinculados.','lp-empty'));
  for(const peer of state.peers){
   const card=node('article',undefined,'lp-peer');card.dataset.peer=peer.fingerprint;const person=button('',()=>openPeer(peer.fingerprint),'lp-person');person.setAttribute('aria-label','Ver ajustes de '+(peer.name||'Equipo'));
   const avatar=node('span',initials(peer.name),'lp-avatar'),info=node('span',undefined,'lp-person-info');info.append(node('strong',peer.name||'Equipo','lp-person-name'));
   const status=node('span',undefined,'lp-tag');status.append(node('i'),node('span',peer.revoked?'Acceso retirado':connected(peer.fingerprint)?'Conectado por red local':'Vinculado · Sin conexión'));person.classList.toggle('lp-connected',connected(peer.fingerprint)&&!peer.revoked);person.classList.toggle('lp-revoked',!!peer.revoked);info.append(status);
   const count=state.mode==='admin'?(peer.lotIds||[]).length:(peer.lots||[]).length;info.append(node('span',(peer.permission==='record'?'Consulta y registro (próximamente)':'Solo consulta')+' · '+count+' lote'+(count===1?'':'s')+' asignado'+(count===1?'':'s'),'lp-person-meta'));
   const arrow=node('span',undefined,'lp-person-go');arrow.innerHTML=svg('M9 6l6 6-6 6');person.append(avatar,info,arrow);card.append(person);root.append(card);
  }
 }

 function render(){
  if(!dialog)return;const admin=(state.mode||window.TruchAppAccess?.read().mode)==='admin';$('lpRoleTitle').textContent=admin?'Administrador':'Colaborador';$('lpAdminActions').hidden=!admin;$('lpCollaboratorActions').hidden=admin;$('lpPeersTitle').textContent=admin?'Colaboradores vinculados':'Administradores vinculados';
  const live=Number.isInteger(state.connectedCount)?state.connectedCount:state.sessions.filter(s=>s.state==='connected').length,max=state.maxConnections||20,pending=Math.max(0,(state.capacityUsed??state.sessions.length)-live);$('lpCapacity').textContent=admin?live+' / '+max+' colaboradores conectados'+(pending?' · '+pending+' pendientes':''):live+' administrador'+(live===1?'':'es')+' conectado'+(live===1?'':'s');$('lpLive').textContent=String(live);$('lpRingLabel').textContent=admin?'de '+max+' conectados':live===1?'administrador conectado':'administradores conectados';$('lpArc').style.strokeDashoffset=String(339.3*(1-Math.min(live/(admin?max:1),1)));dialog.classList.toggle('lp-on',!!state.listening||live>0);$('lpState').textContent=live?'Conexión local activa':state.listening?'Conexión local activa':state.searching?'Buscando administrador…':'Sin conexión local';$('lpPending').hidden=!pending;$('lpPending').textContent=pending+' solicitud'+(pending===1?'':'es')+' pendiente'+(pending===1?'':'s');$('lpPeerCount').textContent=String(state.peers.filter(p=>!p.revoked).length);$('lpThirdStep').textContent=state.sessions.some(s=>s.state==='verify')?'Compara y confirma el código en ambos teléfonos.':admin?'Activa una conexión local para empezar.':'Busca al administrador y compara el código en ambos teléfonos.';$('lpRetry').textContent=state.retryAfterMs>0?'Puedes volver a conectar en '+Math.ceil(state.retryAfterMs/1000)+' s.':'';
  $('lpNotice').textContent=state.notice||(!state.supported?'Instala esta versión en Android para vincular los equipos.':'Activa una conexión local para empezar.');$('lpAddress').hidden=!state.endpoint;$('lpAddress').textContent=state.endpoint?'Dirección local: '+state.endpoint:'';
  $('lpExpiry').textContent=state.invitationUntil>Date.now()?'Invitación abierta hasta '+new Date(state.invitationUntil).toLocaleTimeString('es-PE',{hour:'2-digit',minute:'2-digit'}):state.listening?'Invitación cerrada. Solo se admiten equipos ya vinculados.':'';
  const root=$('lpServices'),key=JSON.stringify(state.services);if(root.dataset.key!==key){root.dataset.key=key;root.replaceChildren();for(const service of state.services){const row=node('div',undefined,'lp-service');const connect=button('Conectar',()=>action('connect',{service:service.id}));connect.setAttribute('data-lp-connect','');row.append(node('span',service.name),connect);root.append(row);}}
  $('lpConnectionInfo').hidden=!(state.notice||state.endpoint||state.searching||state.listening||state.services.length||state.retryAfterMs>0);renderSessions();renderPeers();renderPeerSheet();updateButtons();
 }
 function open(){
  if(document.getElementById('yb-intro'))return;build();previous=document.activeElement;window.TruchAppMenu?.close();$('coMenuDialog')?.close();if(!dialog.open)dialog.showModal();render();refresh();clearInterval(poll);poll=setInterval(refresh,1800);
 }
 document.addEventListener('click',event=>{if(event.target.closest('[data-local-pair]'))open();});
 window.addEventListener('truchapp-local-pair-changed',refresh);
 window.addEventListener('truchapp-storage-committed',()=>{const mode=window.TruchAppAccess?.read().mode;if(mode!==lastMode){lastMode=mode;refresh();}});
 window.addEventListener('truchapp-data-restored',()=>{action('stop');});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
 window.TruchAppLocalPair={open,refresh,getState:()=>state,activePeers,assigned,connected};refresh();
})();
