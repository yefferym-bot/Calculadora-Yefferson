/* Sincroniza la etiqueta accesible con la selección que controla la aplicación. */
(function(){
 'use strict';
 const nav=document.getElementById('bottomNav');if(!nav)return;
 function sync(){nav.querySelectorAll('.nav[data-target]').forEach(button=>{if(button.classList.contains('active'))button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');});}
 sync();new MutationObserver(sync).observe(nav,{subtree:true,attributes:true,attributeFilter:['class']});
})();
