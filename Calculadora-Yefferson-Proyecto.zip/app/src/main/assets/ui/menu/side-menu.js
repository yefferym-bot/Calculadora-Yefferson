/* TruchAPP 4.9.4 — Menú lateral. No modifica bases de datos ni estado de otros módulos. */
(function () {
 'use strict';
 const $ = id => document.getElementById(id);
 const layer=$('tnSideMenu'), drawer=$('tnMenuDrawer'), phone=document.querySelector('.phone');
 const openBtn=$('tnMenuOpen'), closeBtn=$('tnMenuClose'), backdrop=$('tnMenuBackdrop');
 const scroll=$('tnMenuScroll'), detail=$('tnMenuDetail'), detailContent=$('tnMenuDetailContent');
 const reduced=$('tnMenuReducedMotion');
 if(!layer||!drawer||!phone||!openBtn||!closeBtn||!backdrop||!scroll||!detail||!detailContent)return;
 const PREF='truchapp_menu_reduce_motion_v1';
 let previousFocus=null;
 let open=false;
 try{reduced.checked=localStorage.getItem(PREF)==='1'}catch(_){}
 phone.classList.toggle('tn-menu-reduced',reduced.checked);
 function showMenu(){
    if(open)return;
    open=true;previousFocus=document.activeElement;
    drawer.inert=false;
    layer.setAttribute('aria-hidden','false');
    openBtn.setAttribute('aria-expanded','true');
    phone.classList.add('tn-menu-open');
    layer.classList.add('tn-open');
    drawer.focus({preventScroll:true});
 }
 function hideMenu(){
    if(!open)return;
    open=false;
    layer.classList.remove('tn-open');
    phone.classList.remove('tn-menu-open');
    openBtn.setAttribute('aria-expanded','false');
    layer.setAttribute('aria-hidden','true');
    drawer.inert=true;
    detail.hidden=true;scroll.hidden=false;
    window.TruchAppBackup?.onClose?.();
    if(previousFocus&&typeof previousFocus.focus==='function')previousFocus.focus({preventScroll:true});
    else openBtn.focus({preventScroll:true});
 }
 function route(target){
    const button=document.querySelector('.bottom .nav[data-target="'+target+'"]');
    if(button){button.click();return true}
    if(target==='calc'){
       document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active',s.id==='calc'));
       document.querySelectorAll('.bottom .nav').forEach(n=>n.classList.remove('active'));
       const main=document.querySelector('.content');
       if(main){main.classList.remove('ai-expanded');main.scrollTop=0}
       return true;
    }
    return false;
 }
 function quickAction(action){
   const map={
      'new-lot':['lotes','#createLoteTrigger'],
      'new-activity':['agenda','#addTaskBtn'],
      'new-product':['almacen','[data-action="new-item"]'],
      'performance':['lotes','#openPerformanceBtn'],
      'water':['lotes','#openWaterQualityBtn']
   };
   const entry=map[action];if(!entry)return;
   route(entry[0]);
   // Dejar que el módulo termine su primera representación antes de abrir su diálogo existente.
   requestAnimationFrame(()=>requestAnimationFrame(()=>{
      const button=document.querySelector('#'+entry[0]+' '+entry[1]);
      if(button && !button.disabled)button.click();
   }));
 }
 function openDetail(type){
    scroll.hidden=true;detail.hidden=false;detail.scrollTop=0;
    if(type==='backup'){
       detailContent.innerHTML='<h2>Copias de seguridad</h2><p>Guarda toda la información de TruchAPP en un archivo o recupera tus registros desde un respaldo anterior.</p>'+ 
        '<div class="tn-menu-backup-preview">'+
        '<button type="button" id="tnMenuBackupExport" class="tn-menu-backup-row"><span class="tn-menu-ico tn-tone-mint" aria-hidden="true"><svg class="tn-menu-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4M7 9l5-5 5 5M5 16v3h14v-3"/></svg></span><span><strong>Exportar datos</strong><small>Crear un archivo con la información de TruchAPP</small></span></button>'+ 
        '<button type="button" id="tnMenuBackupImport" class="tn-menu-backup-row"><span class="tn-menu-ico tn-tone-blue" aria-hidden="true"><svg class="tn-menu-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v12m-5-5 5 5 5-5M5 18v2h14v-2"/></svg></span><span><strong>Importar datos</strong><small>Restaurar registros desde un archivo de respaldo</small></span></button></div>'+ 
        '<div class="tn-menu-detail-box tn-backup-secret" id="tnMenuBackupExportSecret" hidden><strong>Proteger el respaldo</strong><p>Utiliza una contraseña de al menos 12 caracteres. Sin ella no podrás recuperar este archivo.</p><label for="tnMenuBackupPassword">Contraseña</label><input id="tnMenuBackupPassword" type="password" autocomplete="new-password" maxlength="256" placeholder="Mínimo 12 caracteres"><label for="tnMenuBackupPasswordAgain">Confirmar contraseña</label><input id="tnMenuBackupPasswordAgain" type="password" autocomplete="new-password" maxlength="256" placeholder="Repite tu contraseña"><button type="button" id="tnMenuBackupCreateEncrypted" class="tn-menu-detail-btn">Crear respaldo cifrado</button></div>'+ 
        '<div class="tn-menu-detail-box tn-backup-secret" id="tnMenuBackupUnlockSecret" hidden><strong>Desbloquear respaldo</strong><p>Este archivo está cifrado. Escribe la contraseña utilizada al exportarlo.</p><label for="tnMenuBackupUnlockPassword">Contraseña del respaldo</label><input id="tnMenuBackupUnlockPassword" type="password" autocomplete="off" maxlength="256" placeholder="Contraseña"><button type="button" id="tnMenuBackupDecrypt" class="tn-menu-detail-btn">Verificar y abrir respaldo</button></div>'+ 
        '<div class="tn-menu-detail-box tn-backup-confirm" id="tnMenuBackupConfirmPanel" hidden><strong>Vista previa del respaldo</strong><p id="tnMenuBackupSource"></p><p id="tnMenuBackupContents"></p><label class="tn-backup-consent"><input type="checkbox" id="tnMenuBackupConsent"><span>Comprendo que esta restauración reemplazará los datos actuales de todos los módulos.</span></label><button type="button" id="tnMenuBackupApply" class="tn-menu-detail-btn" disabled>Restaurar estos datos</button></div>'+ 
        '<p class="tn-menu-backup-note" id="tnMenuBackupStatus" role="status" aria-live="polite">Los archivos contienen información personal y financiera. Guárdalos en un lugar seguro.</p>'+ 
        '<button type="button" id="tnMenuBackupUndo" class="tn-backup-undo" hidden>Recuperar datos anteriores a la última importación</button>';
       window.TruchAppBackup?.onOpen();
    }else if(type==='about'){
       detailContent.innerHTML='<h2>Acerca de TruchAPP</h2><p>Aplicación de gestión acuícola con herramientas de producción, almacén, actividades y finanzas.</p><div class="tn-menu-detail-box"><strong>Versión 4.9.4</strong><p>Este menú es un acceso a las funciones ya disponibles. La información de los módulos se conserva en el almacenamiento del teléfono.</p></div><p>La inteligencia artificial sigue instalada en segundo plano. La grabadora con transcripción todavía no está incorporada.</p>';
    }else if(type==='report'){
       detailContent.innerHTML='<h2>Reportar un error</h2><p>Describe qué pasó. Puedes copiar el informe y enviarlo cuando lo necesites; no se transmite automáticamente.</p><div class="tn-menu-detail-box"><strong>Descripción</strong><textarea id="tnMenuReportText" placeholder="¿Qué estabas haciendo y qué ocurrió?" maxlength="2000"></textarea><button type="button" id="tnMenuCopyReport" class="tn-menu-detail-btn">Copiar informe</button><p id="tnMenuCopyStatus" class="tn-menu-copy-status" role="status"></p></div>';
    }
 }
 function copyReport(){
   const contents=($('tnMenuReportText')?.value||'').trim();
   if(!contents){$('tnMenuCopyStatus').textContent='Escribe primero lo que ocurrió.';return}
   const data='TruchAPP 4.9.4 — Reporte de error\n'+contents;
   const status=$('tnMenuCopyStatus');
   function failFallback(){
      const el=$('tnMenuReportText');el.value=data;el.focus();el.select();
      try{const ok=document.execCommand('copy');status.textContent=ok?'Informe copiado.':'Selecciona el texto y cópialo.'}catch(_){status.textContent='Selecciona el texto y cópialo.'}
   }
   if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(data).then(()=>{status.textContent='Informe copiado.'}).catch(failFallback);
   else failFallback();
 }
 openBtn.addEventListener('click',showMenu);
 closeBtn.addEventListener('click',hideMenu);
 backdrop.addEventListener('click',hideMenu);
 $('tnMenuDetailBack').addEventListener('click',()=>{window.TruchAppBackup?.onClose?.();detail.hidden=true;scroll.hidden=false});
 reduced.addEventListener('change',()=>{
   phone.classList.toggle('tn-menu-reduced',reduced.checked);
   try{localStorage.setItem(PREF,reduced.checked?'1':'0')}catch(_){}
 });
 drawer.addEventListener('click',event=>{
    if(event.target.closest('#tnMenuBackupExport')){window.TruchAppBackup?.prepareExport();return}
    if(event.target.closest('#tnMenuBackupImport')){window.TruchAppBackup?.importData();return}
    if(event.target.closest('#tnMenuBackupCreateEncrypted')){window.TruchAppBackup?.exportData();return}
    if(event.target.closest('#tnMenuBackupDecrypt')){window.TruchAppBackup?.unlockImport();return}
    if(event.target.closest('#tnMenuBackupApply')){window.TruchAppBackup?.applyRestore();return}
    if(event.target.closest('#tnMenuBackupUndo')){window.TruchAppBackup?.recovery();return}
    if(event.target.closest('#tnMenuCopyReport')){copyReport();return}
    const control=event.target.closest('[data-menu-target],[data-menu-action]');
    if(!control)return;
    const target=control.dataset.menuTarget,action=control.dataset.menuAction;
    if(target){hideMenu();route(target);return}
    if(action==='about'||action==='report'||action==='backup'){openDetail(action);return}
    hideMenu();quickAction(action);
 });
 document.addEventListener('keydown',event=>{
   if(!open)return;
   if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();hideMenu();return}
   if(event.key==='Tab'){
      const activeView=detail.hidden?scroll:detail;
      const focusable=[closeBtn, ...Array.from(activeView.querySelectorAll('button:not([disabled]),input:not([disabled]),textarea:not([disabled])'))].filter(el=>!el.inert&&!el.hidden);
      if(!focusable.length){event.preventDefault();drawer.focus();return}
      const first=focusable[0], last=focusable[focusable.length-1];
      if(event.shiftKey&&(document.activeElement===first||document.activeElement===drawer)){event.preventDefault();last.focus()}
      else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===drawer)){event.preventDefault();first.focus()}
   }
 },true);
 let startX=null,startY=null;
 drawer.addEventListener('touchstart',e=>{if(e.touches.length!==1)return;startX=e.touches[0].clientX;startY=e.touches[0].clientY},{passive:true});
 drawer.addEventListener('touchend',e=>{
   if(startX===null||e.changedTouches.length!==1)return;
   const dx=e.changedTouches[0].clientX-startX,dy=e.changedTouches[0].clientY-startY;
   startX=startY=null;
   if(dx< -75&&Math.abs(dx)>1.4*Math.abs(dy))hideMenu();
 },{passive:true});
 window.TruchAppMenu={open:showMenu,close:hideMenu,isOpen:()=>open};
})();
