/* TruchAPP 4.8.4 — Menú lateral. No modifica bases de datos ni estado de otros módulos. */
(function () {
 'use strict';
 const $ = id => document.getElementById(id);
 const layer=$('tnSideMenu'), drawer=$('tnMenuDrawer'), phone=document.querySelector('.phone');
 const openBtn=$('tnMenuOpen'), closeBtn=$('tnMenuClose'), backdrop=$('tnMenuBackdrop');
 const scroll=$('tnMenuScroll'), detail=$('tnMenuDetail'), detailContent=$('tnMenuDetailContent');
 const reduced=$('tnMenuReducedMotion');
 if(!layer||!drawer||!phone||!openBtn||!closeBtn||!backdrop||!scroll||!detail||!detailContent)return;
 const PREF='truchapp_menu_reduce_motion_v1';
 let previousFocus=null;
 let open=false;
 try{reduced.checked=localStorage.getItem(PREF)==='1'}catch(_){}
 phone.classList.toggle('tn-menu-reduced',reduced.checked);
 function showMenu(){
    if(open)return;
    open=true;previousFocus=document.activeElement;
    drawer.inert=false;
    layer.setAttribute('aria-hidden','false');
    openBtn.setAttribute('aria-expanded','true');
    phone.classList.add('tn-menu-open');
    layer.classList.add('tn-open');
    drawer.focus({preventScroll:true});
 }
 function hideMenu(){
    if(!open)return;
    open=false;
    layer.classList.remove('tn-open');
    phone.classList.remove('tn-menu-open');
    openBtn.setAttribute('aria-expanded','false');
    layer.setAttribute('aria-hidden','true');
    drawer.inert=true;
    detail.hidden=true;scroll.hidden=false;
    if(previousFocus&&typeof previousFocus.focus==='function')previousFocus.focus({preventScroll:true});
    else openBtn.focus({preventScroll:true});
 }
 function route(target){
    const button=document.querySelector('.bottom .nav[data-target="'+target+'"]');
    if(button){button.click();return true}
    if(target==='calc'){
       document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active',s.id==='calc'));
       document.querySelectorAll('.bottom .nav').forEach(n=>n.classList.remove('active'));
       const main=document.querySelector('.content');
       if(main){main.classList.remove('ai-expanded');main.scrollTop=0}
       return true;
    }
    return false;
 }
 function quickAction(action){
   const map={
      'new-lot':['lotes','#createLoteTrigger'],
      'new-activity':['agenda','#addTaskBtn'],
      'new-product':['almacen','[data-action="new-item"]'],
      'performance':['lotes','#openPerformanceBtn'],
      'water':['lotes','#openWaterQualityBtn']
   };
   const entry=map[action];if(!entry)return;
   route(entry[0]);
   // Dejar que el módulo termine su primera representación antes de abrir su diálogo existente.
   requestAnimationFrame(()=>requestAnimationFrame(()=>{
      const button=document.querySelector('#'+entry[0]+' '+entry[1]);
      if(button && !button.disabled)button.click();
   }));
 }
 function openDetail(type){
    scroll.hidden=true;detail.hidden=false;detail.scrollTop=0;
    if(type==='about'){
       detailContent.innerHTML='<h2>Acerca de TruchAPP</h2><p>Aplicación de gestión acuícola con herramientas de producción, almacén, actividades y finanzas.</p><div class="tn-menu-detail-box"><strong>Versión 4.8.4</strong><p>Este menú es un acceso a las funciones ya disponibles. La información de los módulos se conserva en el almacenamiento del teléfono.</p></div><p>La inteligencia artificial sigue instalada en segundo plano. La grabadora con transcripción todavía no está incorporada.</p>';
    }else if(type==='report'){
       detailContent.innerHTML='<h2>Reportar un error</h2><p>Describe qué pasó. Puedes copiar el informe y enviarlo cuando lo necesites; no se transmite automáticamente.</p><div class="tn-menu-detail-box"><strong>Descripción</strong><textarea id="tnMenuReportText" placeholder="¿Qué estabas haciendo y qué ocurrió?" maxlength="2000"></textarea><button type="button" id="tnMenuCopyReport" class="tn-menu-detail-btn">Copiar informe</button><p id="tnMenuCopyStatus" class="tn-menu-copy-status" role="status"></p></div>';
    }
 }
 function copyReport(){
   const contents=($('tnMenuReportText')?.value||'').trim();
   if(!contents){$('tnMenuCopyStatus').textContent='Escribe primero lo que ocurrió.';return}
   const data='TruchAPP 4.8.4 — Reporte de error\n'+contents;
   const status=$('tnMenuCopyStatus');
   function failFallback(){
      const el=$('tnMenuReportText');el.value=data;el.focus();el.select();
      try{const ok=document.execCommand('copy');status.textContent=ok?'Informe copiado.':'Selecciona el texto y cópialo.'}catch(_){status.textContent='Selecciona el texto y cópialo.'}
   }
   if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(data).then(()=>{status.textContent='Informe copiado.'}).catch(failFallback);
   else failFallback();
 }
 openBtn.addEventListener('click',showMenu);
 closeBtn.addEventListener('click',hideMenu);
 backdrop.addEventListener('click',hideMenu);
 $('tnMenuDetailBack').addEventListener('click',()=>{detail.hidden=true;scroll.hidden=false});
 reduced.addEventListener('change',()=>{
   phone.classList.toggle('tn-menu-reduced',reduced.checked);
   try{localStorage.setItem(PREF,reduced.checked?'1':'0')}catch(_){}
 });
 drawer.addEventListener('click',event=>{
    if(event.target.closest('#tnMenuCopyReport')){copyReport();return}
    const control=event.target.closest('[data-menu-target],[data-menu-action]');
    if(!control)return;
    const target=control.dataset.menuTarget,action=control.dataset.menuAction;
    if(target){hideMenu();route(target);return}
    if(action==='about'||action==='report'){openDetail(action);return}
    hideMenu();quickAction(action);
 });
 document.addEventListener('keydown',event=>{
   if(!open)return;
   if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();hideMenu();return}
   if(event.key==='Tab'){
      const activeView=detail.hidden?scroll:detail;
      const focusable=[closeBtn, ...Array.from(activeView.querySelectorAll('button:not([disabled]),input:not([disabled]),textarea:not([disabled])'))].filter(el=>!el.inert&&!el.hidden);
      if(!focusable.length){event.preventDefault();drawer.focus();return}
      const first=focusable[0], last=focusable[focusable.length-1];
      if(event.shiftKey&&(document.activeElement===first||document.activeElement===drawer)){event.preventDefault();last.focus()}
      else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===drawer)){event.preventDefault();first.focus()}
   }
 },true);
 let startX=null,startY=null;
 drawer.addEventListener('touchstart',e=>{if(e.touches.length!==1)return;startX=e.touches[0].clientX;startY=e.touches[0].clientY},{passive:true});
 drawer.addEventListener('touchend',e=>{
   if(startX===null||e.changedTouches.length!==1)return;
   const dx=e.changedTouches[0].clientX-startX,dy=e.changedTouches[0].clientY-startY;
   startX=startY=null;
   if(dx< -75&&Math.abs(dx)>1.4*Math.abs(dy))hideMenu();
 },{passive:true});
 window.TruchAppMenu={open:showMenu,close:hideMenu,isOpen:()=>open};
})();
