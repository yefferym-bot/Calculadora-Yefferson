/* TruchAPP 4.8.8 — Backup UI and careful localStorage migration. No module-specific mutations. */
(function () {
 'use strict';
 const $ = id => document.getElementById(id);
 const native = () => window.AndroidAI || null;
 let importedWeb = null;
 let inProgress = false;
 function resetPasswords(){['tnMenuBackupPassword','tnMenuBackupPasswordAgain','tnMenuBackupUnlockPassword'].forEach(id=>{const el=$(id);if(el)el.value='';});}
 function concealSecrets(){['tnMenuBackupExportSecret','tnMenuBackupUnlockSecret'].forEach(id=>{const el=$(id);if(el)el.hidden=true;});resetPasswords();}
 function prepareExport(){if(inProgress)return;concealSecrets();$('tnMenuBackupConfirmPanel').hidden=true;$('tnMenuBackupExportSecret').hidden=false;status('Crea una contraseña para cifrar todo el respaldo. No se guardará en TruchAPP.');$('tnMenuBackupPassword')?.focus();}
 function status(message, error) {
    const target = $('tnMenuBackupStatus');
    if (!target) return;
    target.textContent = message;
    target.classList.toggle('tn-backup-error', !!error);
 }
 function localSnapshot() {
    const web = {};
    for (let i=0;i<localStorage.length;i++) {
       const key=localStorage.key(i);
       if (key !== null) web[key]=localStorage.getItem(key);
    }
    return web;
 }
 function replaceLocalStorage(web) {
    localStorage.clear();
    Object.keys(web).forEach(k => localStorage.setItem(k, web[k]));
 }
 function dateLabel(time) {
    const ms = Number(time);
    if (!ms || !Number.isFinite(ms)) return 'Fecha no disponible';
    return new Date(ms).toLocaleString('es-PE',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
 }
 function formatSummary(web) {
    function count(key) {
      try { const x=JSON.parse(web[key]||'null');return Array.isArray(x)?x.length:0; } catch (_) {return 0}
    }
    const groups = [
      ['Lotes', count('truchapp_lotes_v1')],
      ['Granjas', count('truchapp_lotes_water_farms_v1')],
      ['Mediciones de agua', count('truchapp_lotes_water_quality_v1')],
      ['Agenda', count('activities')]
    ];
    return groups.map(([label,n])=>label+': '+n).join(' · ');
 }
 function setBusy(flag) {
    inProgress=flag;
    ['tnMenuBackupExport','tnMenuBackupImport','tnMenuBackupApply','tnMenuBackupUndo','tnMenuBackupCreateEncrypted','tnMenuBackupDecrypt'].forEach(id=>{
       const btn=$(id); if(btn)btn.disabled=flag || (id==='tnMenuBackupApply' && !$('tnMenuBackupConsent')?.checked);
    });
 }
 function exportData() {
    if (inProgress)return;
    if (!native() || typeof native().exportAppBackup!=='function') {
       status('La exportación está disponible dentro del APK instalado en Android.',true);return;
    }
    const first=$('tnMenuBackupPassword')?.value||'', second=$('tnMenuBackupPasswordAgain')?.value||'';
    if(first.length<12||first.length>256){status('La contraseña debe tener entre 12 y 256 caracteres.',true);return}
    if(first!==second){status('Las contraseñas no coinciden. Vuelve a comprobarlas.',true);return}
    setBusy(true);
    status('Comprimiendo y cifrando todo el respaldo…');
    try { native().exportAppBackup(JSON.stringify(localSnapshot()),first);concealSecrets(); }
    catch(e){setBusy(false);status('No se pudo iniciar: '+e.message,true)}
 }
 function importData() {
    if(inProgress)return;
    if(!native() || typeof native().chooseAppBackup!=='function') {
       status('La importación necesita el APK Android.',true);return;
    }
    importedWeb=null;
    concealSecrets();
    $('tnMenuBackupConfirmPanel').hidden=true;
    setBusy(true);
    status('Selecciona un archivo .truchapp guardado anteriormente…');
    try{ native().chooseAppBackup(); }catch(e){setBusy(false);status('No se pudo seleccionar: '+e.message,true)}
 }
 function recovery() {
    if(inProgress)return;
    if(!native() || typeof native().chooseRecoveryCopy!=='function')return;
    concealSecrets();
    setBusy(true);
    status('Preparando el respaldo anterior…');
    try { native().chooseRecoveryCopy(); } catch(e){setBusy(false);status('No se pudo abrir la copia anterior.',true)}
 }
 function onImportPasswordRequired(){setBusy(false);concealSecrets();const box=$('tnMenuBackupUnlockSecret');if(box)box.hidden=false;status('Respaldo cifrado: escribe la contraseña para revisar sus datos.');$('tnMenuBackupUnlockPassword')?.focus();}
 function unlockImport(){
    if(inProgress)return;
    const value=$('tnMenuBackupUnlockPassword')?.value||'';
    if(!value){status('Escribe la contraseña del respaldo.',true);return;}
    if(!native()?.unlockAppBackup){status('Debes usar la versión actualizada del APK.',true);return;}
    setBusy(true);status('Comprobando contraseña y autenticidad del archivo…');
    try{native().unlockAppBackup(value);const field=$('tnMenuBackupUnlockPassword');if(field)field.value='';}
    catch(e){setBusy(false);status('No se pudo verificar el archivo.',true)}
 }
 function onSelected(metaJson) {
    setBusy(false);
    try {
       const meta=JSON.parse(metaJson);
       if(meta.database){
         importedWeb={database:true};concealSecrets();
         $('tnMenuBackupSource').textContent=dateLabel(meta.createdAt)+' · Respaldo verificado';
         const counts=meta.counts||{};$('tnMenuBackupContents').textContent=[['lots','Lotes'],['water','Agua'],['daily','Registros diarios'],['samples','Biometrías'],['tasks','Tareas'],['movements','Movimientos']].map(([key,name])=>name+': '+(counts[key]||0)).join(' · ');
         $('tnMenuBackupConsent').checked=false;$('tnMenuBackupApply').disabled=true;$('tnMenuBackupConfirmPanel').hidden=false;
         status('La copia se comprobó en una base temporal. Al restaurar se conservará la base anterior.');return;
       }
       const raw=native()?.readImportedWebData?.();
       if(!raw)throw new Error('El archivo ya no está disponible');
       const web=JSON.parse(raw);
       if(!web || Array.isArray(web) || typeof web!=='object')throw new Error('Datos web no compatibles');
       const keys=Object.keys(web);
       if(keys.length>500 || keys.some(k => k.length>180 || typeof web[k]!=='string'))throw new Error('Datos no válidos');
       importedWeb=web;
       concealSecrets();
       $('tnMenuBackupSource').textContent = dateLabel(meta.createdAt)+' · '+keys.length+' entradas guardadas';
       $('tnMenuBackupContents').textContent = formatSummary(web)+(meta.encrypted?' · Protección: AES-256':' · AVISO: respaldo antiguo SIN cifrar');
       $('tnMenuBackupConsent').checked=false;
       $('tnMenuBackupApply').disabled=true;
       $('tnMenuBackupConfirmPanel').hidden=false;
       status(meta.encrypted?'Archivo cifrado y autenticado. Revisa los datos antes de restaurar.':'Este respaldo antiguo no está cifrado. Puedes importarlo y después exportar una nueva copia protegida.',!meta.encrypted);
    } catch(e) {
       importedWeb=null;
       $('tnMenuBackupConfirmPanel').hidden=true;
       status('No se pudo verificar el respaldo: '+e.message,true);
    }
 }
 async function applyRestore() {
    if (inProgress || !importedWeb || !$('tnMenuBackupConsent')?.checked) return;
    if(importedWeb.database&&window.TruchAppStorage){
      setBusy(true);status('Conservando los datos actuales y activando la copia verificada…');
      try{await window.TruchAppStorage.restore();status('Restauración completada. Abriendo tus registros…');setTimeout(()=>location.reload(),300);}catch(e){setBusy(false);status(e.message,true);}return;
    }
    if (!native() || typeof native().saveRecoveryCopy!=='function' || typeof native().restoreNativeBackup!=='function') {
      status('Para restaurar necesitas el APK Android.',true);return;
    }
    setBusy(true);
    status('Guardando copia de seguridad de los datos actuales…');
    let before;
    try {
       before=localSnapshot();
       if (!native().saveRecoveryCopy(JSON.stringify(before)))throw new Error('No se pudo crear una copia de recuperación. No se modificó nada.');
       // Commit web data and native preferences only after verification and recovery copy.
       replaceLocalStorage(importedWeb);
       if(!native().restoreNativeBackup())throw new Error('No se pudieron restaurar los datos de Android.');
       importedWeb=null;
       $('tnMenuBackupConfirmPanel').hidden=true;
       status('¡Datos restaurados! TruchAPP se actualizará para mostrar tus registros.');
       const undo=$('tnMenuBackupUndo');if(undo)undo.hidden=false;
       setTimeout(()=>window.location.reload(),1500);
    } catch(e) {
       if(before){try{replaceLocalStorage(before)}catch(restoreErr){status('Error al restaurar los datos anteriores. Conserva tu archivo de respaldo.',true);setBusy(false);return}}
       status('Restauración cancelada: '+e.message,true);
    }
    setBusy(false);
 }
 function onExportResult(success,message){setBusy(false);status(message,!success)}
 function onImportError(message){setBusy(false);status(message,true)}
 function onClose(){resetPasswords();}
 function onOpen(){
   importedWeb=null;inProgress=false;concealSecrets();
   const panel=$('tnMenuBackupConfirmPanel');if(panel)panel.hidden=true;
   const undo=$('tnMenuBackupUndo');if(undo){try{undo.hidden=!native()?.hasRecoveryCopy?.()}catch(e){undo.hidden=true}}
   status('Los nuevos respaldos se cifran con contraseña (AES-256). Sin ella no se podrán recuperar.');
   window.TruchAppRecoveryUI?.open();
 }
 // Called by the menu when the preview sub-page is opened.
 window.TruchAppBackup={onOpen,onClose,prepareExport,exportData,importData,unlockImport,recovery,applyRestore,onExportResult,onImportSelected:onSelected,onImportPasswordRequired,onImportError};
 document.addEventListener('change',e=>{
    if(e.target?.id==='tnMenuBackupConsent'){
       const btn=$('tnMenuBackupApply');if(btn)btn.disabled=!e.target.checked || inProgress;
    }
 });
})();
