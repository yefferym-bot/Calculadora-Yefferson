(function(root,factory){const api=factory();if(typeof module==='object')module.exports=api;else root.TruchAppHistoryPerformance=api;})(typeof window==='undefined'?globalThis:window,function(){
 'use strict';
 // Representative real points: retain extrema and discontinuities, never invent a measurement.
 function extrema(rows,limit=240){
  if(rows.length<=limit)return rows.map((row,index)=>({row,index}));
  const width=Math.ceil(rows.length/Math.max(1,Math.floor(limit/5))),selected=new Set([0,rows.length-1]);
  for(let first=0;first<rows.length;first+=width){
   const last=Math.min(rows.length,first+width);let min=-1,max=-1,gap=-1;
   selected.add(first);selected.add(last-1);
   for(let i=first;i<last;i++){const value=rows[i].value;if(typeof value!=='number'||!Number.isFinite(value)){gap=i;continue;}if(min<0||value<rows[min].value)min=i;if(max<0||value>rows[max].value)max=i;}
   for(const index of [min,max,gap])if(index>=0)selected.add(index);
  }
  return [...selected].sort((a,b)=>a-b).map(index=>({row:rows[index],index}));
 }
 function sums(rows,limit=120){
  if(rows.length<=limit)return rows;
  const width=Math.ceil(rows.length/limit),result=[];
  for(let i=0;i<rows.length;i+=width){const group=rows.slice(i,i+width),known=group.filter(r=>typeof r.value==='number'&&Number.isFinite(r.value));result.push({...group.at(-1),start:group[0].date,end:group.at(-1).date,grouped:group.length>1,count:group.length,known:known.length,value:known.length?known.reduce((s,r)=>s+r.value,0):null,status:known.length===group.length?'complete':'partial'});}
  return result;
 }
 return {extrema,sums};
});
