/* Display preferences only; production records and native backup stay unchanged. */
(function(){
 'use strict';
 const KEY='truchapp_display_preferences_v1',child=document.documentElement.dataset.displayDocument==='detail';
 const themes=['light','contrast','dark'];
 const defaults={highContrast:false,lotView:'expanded',theme:'light'};
 const labels={light:'Modo diurno. Activar contornos resaltados',contrast:'Contornos resaltados. Activar modo oscuro',dark:'Modo oscuro. Activar modo diurno'};
 const names={light:'Diurno',contrast:'Contornos resaltados',dark:'Oscuro'};
 const icons={sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/>',moon:'<path d="M20.7 13.1A8.7 8.7 0 0 1 10.9 3.3 8.8 8.8 0 1 0 20.7 13.1Z"/>'};
 let current={...defaults};
 function normalize(value){
  const theme=themes.includes(value?.theme)?value.theme:(value?.highContrast===true?'contrast':'light');
  return{highContrast:theme==='contrast',lotView:value?.lotView==='compact'?'compact':'expanded',theme};
 }
 function read(){
  if(child)return{...current};
  try{return normalize(JSON.parse(localStorage.getItem(KEY)||'null'));}catch(_){return{...defaults};}
 }
 function send(frame){frame.contentWindow?.postMessage({type:'truchapp-display-preferences',highContrast:current.highContrast,theme:current.theme},'*');}
 function refresh(){
  if(!child)current=read();
  document.documentElement.dataset.highContrast=String(current.highContrast);
  document.documentElement.dataset.theme=current.theme;
  document.querySelectorAll('[data-display-contrast]').forEach(b=>{
   b.setAttribute('aria-pressed',String(current.theme!=='light'));
   b.setAttribute('aria-label',labels[current.theme]);b.setAttribute('title',labels[current.theme]);
   const svg=b.querySelector('svg');if(svg)svg.innerHTML=icons[current.theme==='dark'?'moon':'sun'];
   const caption=b.querySelector('[data-display-theme-label]');if(caption)caption.textContent=names[current.theme]+' · tocar para cambiar';
  });
  document.querySelectorAll('[data-lotes-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.lotesView===current.lotView)));
  document.querySelectorAll('#lotesList').forEach(list=>{list.dataset.view=current.lotView;});
  if(!child)document.querySelectorAll('.approvedLotFrame').forEach(send);
 }
 function set(patch){
  if(child)return;
  const previous=read(),input={...previous,...patch};
  if(!Object.prototype.hasOwnProperty.call(patch,'theme')&&Object.prototype.hasOwnProperty.call(patch,'highContrast'))input.theme=patch.highContrast===true?'contrast':'light';
  const next=normalize(input);
  localStorage.setItem(KEY,JSON.stringify(next));current=next;refresh();
  if(previous.lotView!==next.lotView&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches&&!document.querySelector('.phone.tn-menu-reduced')){
   document.querySelectorAll('#lotesList .lotesLote').forEach(card=>{const r=card.getBoundingClientRect();if(r.bottom>0&&r.top<window.innerHeight)card.animate?.([{opacity:.65,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:180,easing:'cubic-bezier(.2,0,0,1)'});});
  }
 }
 window.addEventListener('message',event=>{
  const message=event.data;
  if(child){if(event.source===window.parent&&message?.type==='truchapp-display-preferences'&&typeof message.highContrast==='boolean'&&(message.theme===undefined||themes.includes(message.theme))){current=normalize({...current,highContrast:message.highContrast,theme:message.theme});refresh();}return;}
  if(message?.type==='truchapp-detail-ready')document.querySelectorAll('.approvedLotFrame').forEach(frame=>{if(frame.contentWindow===event.source)send(frame);});
 });
 if(!child){
  document.addEventListener('click',event=>{
   const contrast=event.target.closest('[data-display-contrast]'),view=event.target.closest('[data-lotes-view]'),backup=event.target.closest('[data-display-backup]');
   try{if(contrast)set({theme:themes[(themes.indexOf(read().theme)+1)%themes.length]});else if(view)set({lotView:view.dataset.lotesView});else if(backup)window.TruchAppMenu?.openBackup?.();}catch(_){refresh();}
  });
  window.addEventListener('truchapp-storage-committed',refresh);
  window.addEventListener('truchapp-data-restored',refresh);
 }
 window.TruchAppDisplay={read,set,refresh};refresh();
})();
