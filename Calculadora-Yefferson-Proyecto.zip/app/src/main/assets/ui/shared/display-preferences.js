/* Display preferences only; production records and native backup stay unchanged. */
(function(){
 'use strict';
 const KEY='truchapp_display_preferences_v1',child=document.documentElement.dataset.displayDocument==='detail';
 const defaults={highContrast:false,lotView:'expanded'};
 let current={...defaults};
 function read(){
  if(child)return{...current};
  try{const value=JSON.parse(localStorage.getItem(KEY)||'null');return{highContrast:value?.highContrast===true,lotView:value?.lotView==='compact'?'compact':'expanded'};}catch(_){return{...defaults};}
 }
 function send(frame){frame.contentWindow?.postMessage({type:'truchapp-display-preferences',highContrast:current.highContrast},'*');}
 function refresh(){
  if(!child)current=read();
  document.documentElement.dataset.highContrast=String(current.highContrast);
  document.querySelectorAll('[data-display-contrast]').forEach(b=>b.setAttribute('aria-pressed',String(current.highContrast)));
  document.querySelectorAll('[data-lotes-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.lotesView===current.lotView)));
  document.querySelectorAll('#lotesList').forEach(list=>{list.dataset.view=current.lotView;});
  if(!child)document.querySelectorAll('.approvedLotFrame').forEach(send);
 }
 function set(patch){
  if(child)return;
  const previous=read(),next={...previous,...patch};next.highContrast=next.highContrast===true;next.lotView=next.lotView==='compact'?'compact':'expanded';
  localStorage.setItem(KEY,JSON.stringify(next));current=next;refresh();
  if(previous.lotView!==next.lotView&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches&&!document.querySelector('.phone.tn-menu-reduced')){
   document.querySelectorAll('#lotesList .lotesLote').forEach(card=>{const r=card.getBoundingClientRect();if(r.bottom>0&&r.top<window.innerHeight)card.animate?.([{opacity:.65,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:180,easing:'cubic-bezier(.2,0,0,1)'});});
  }
 }
 window.addEventListener('message',event=>{
  const message=event.data;
  if(child){if(event.source===window.parent&&message?.type==='truchapp-display-preferences'&&typeof message.highContrast==='boolean'){current.highContrast=message.highContrast;refresh();}return;}
  if(message?.type==='truchapp-detail-ready')document.querySelectorAll('.approvedLotFrame').forEach(frame=>{if(frame.contentWindow===event.source)send(frame);});
 });
 if(!child){
  document.addEventListener('click',event=>{
   const contrast=event.target.closest('[data-display-contrast]'),view=event.target.closest('[data-lotes-view]'),backup=event.target.closest('[data-display-backup]');
   try{if(contrast)set({highContrast:!read().highContrast});else if(view)set({lotView:view.dataset.lotesView});else if(backup)window.TruchAppMenu?.openBackup?.();}catch(_){refresh();}
  });
  window.addEventListener('truchapp-storage-committed',refresh);
  window.addEventListener('truchapp-data-restored',refresh);
 }
 window.TruchAppDisplay={read,set,refresh};refresh();
})();
