/* One confirmed store shared by the five modules. The UI cache is never a backup. */
(function(root){
 'use strict';
 const original=root.localStorage,native=root.AndroidAI,requests=new Map();
 const production=new Set(['truchapp_lotes_v1','truchapp_lotes_water_quality_v1','truchapp_lotes_water_farms_v1','activities','truchapp_almacen_kardex_v1','truchapp_agenda_workbook_v1','truchapp_finance_v1','truchapp_inicio_control_v1']);
 let values=new Map(),revision=0,depth=0,locked=false,callbacks=[],rollbackCallbacks=[],label='Preferencias',busyTimer;
 const parsed=new Map(),identity=()=>root.crypto?.randomUUID?.()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
 const clone=value=>typeof structuredClone==='function'?structuredClone(value):JSON.parse(JSON.stringify(value));
 function message(error){root.dispatchEvent(new CustomEvent('truchapp-storage-error',{detail:{message:error.message||String(error)}}));}
 function validate(key,value){
  if(value===null||!production.has(key))return;
  let data;try{data=JSON.parse(value)}catch(_){throw new Error('No se pudo validar '+key+'. Los datos anteriores se conservan.');}
  const array=['truchapp_lotes_v1','truchapp_lotes_water_quality_v1','truchapp_lotes_water_farms_v1','activities'].includes(key);
  if(array?(!Array.isArray(data)||data.some(r=>!r||typeof r!=='object'||Array.isArray(r))):(!data||Array.isArray(data)||typeof data!=='object'))throw new Error('Formato no válido en '+key);
  if(key==='truchapp_almacen_kardex_v1'&&(!Array.isArray(data.items)||!Array.isArray(data.movements)))throw new Error('El almacén no contiene listas válidas.');
  if(key==='truchapp_agenda_workbook_v1'&&(data.schema!==2||!Array.isArray(data.records)))throw new Error('Versión de Agenda no compatible.');
 }
 root.TruchAppStorageReceive=function(id,ok,index,count,part){
  const pending=requests.get(id);if(!pending)return;pending.parts[index]=part;
  if(pending.parts.filter(v=>v!==undefined).length!==count)return;
  requests.delete(id);clearTimeout(pending.timer);
  try{const result=JSON.parse(pending.parts.join(''));ok?pending.resolve(result):pending.reject(new Error(result.error||'No se pudo completar la operación.'));}catch(e){pending.reject(e)}
 };
 function request(command,input={}){
  if(!native?.farmRequest)return Promise.reject(new Error('Esta operación necesita el APK actualizado.'));
  return new Promise((resolve,reject)=>{
   const id=identity(),pending={resolve,reject,parts:[]};pending.timer=setTimeout(()=>{requests.delete(id);const error=new Error('No se recibió la confirmación. Vuelve a abrir la pantalla para comprobar el estado antes de reintentar.');error.code='ACK_TIMEOUT';reject(error);},command==='commit'?15000:180000);requests.set(id,pending);
   try{native.farmRequest(id,command,JSON.stringify(input));}catch(e){clearTimeout(pending.timer);requests.delete(id);reject(e)}
  });
 }
 function difference(before){const patch={};for(const key of new Set([...before.keys(),...values.keys()])){const a=before.get(key)??null,b=values.get(key)??null;if(a!==b)patch[key]=b;}return patch;}
 function notify(){for(const fn of callbacks.splice(0))try{fn()}catch(e){message(e)}rollbackCallbacks=[];root.dispatchEvent(new CustomEvent('truchapp-storage-committed',{detail:{revision}}));}
 function payload(before){return {patch:difference(before),revision,operation:identity(),label};}
 function fallbackWrite(patch){
  // HTML previews retain an interruption journal. Android uses the Room transaction instead.
  const old={};for(const key of Object.keys(patch))old[key]=original.getItem(key);
  original.setItem('truchapp_storage_journal_v1',JSON.stringify(old));
  try{for(const [key,value]of Object.entries(patch))value===null?original.removeItem(key):original.setItem(key,value);original.removeItem('truchapp_storage_journal_v1');}
  catch(e){for(const [key,value]of Object.entries(old))value===null?original.removeItem(key):original.setItem(key,value);original.removeItem('truchapp_storage_journal_v1');throw e;}
  return {revision:revision+1};
 }
 function rollback(before){values=before;parsed.clear();callbacks=[];for(const fn of rollbackCallbacks.splice(0))try{fn()}catch(_){} }
 function busy(active){
  clearTimeout(busyTimer);const node=document.getElementById('farmSaving');
  if(!active){node?.remove();document.documentElement.classList.remove('farm-saving');return;}
  document.documentElement.classList.add('farm-saving');busyTimer=setTimeout(()=>{if(!locked)return;const el=document.createElement('div');el.id='farmSaving';el.className='farm-saving-note';el.setAttribute('role','status');el.textContent='Guardando registro…';document.body.append(el);},180);
 }
 function atomic(title,work){
  if(depth)return work();if(locked)throw new Error('Espera a que termine el guardado actual.');
  const before=new Map(values);label=title||'Preferencias';depth=1;
  try{
   const result=work();if(result?.then)throw new Error('La operación debe preparar los cambios antes de guardarlos.');
   const input=payload(before);let committed={revision};
   if(Object.keys(input.patch).length){
    if(native?.farmCommitSync){const answer=JSON.parse(native.farmCommitSync(JSON.stringify(input)));if(!answer.ok)throw new Error(answer.error||'No se confirmó el guardado.');committed=answer.result;}
    else committed=fallbackWrite(input.patch);
   }
   revision=committed.revision;depth=0;notify();return result;
  }catch(error){rollback(before);depth=0;message(error);throw error;}
 }
 async function runAsync(title,work){
  if(depth)return work();if(locked)throw new Error('Espera a que termine el guardado actual.');
  const before=new Map(values);label=title;depth=1;locked=true;busy(true);
  try{
   const result=work();if(result?.then)throw new Error('Los cambios deben prepararse de forma síncrona.');
   const input=payload(before);depth=0;
   if(Object.keys(input.patch).length){
    let committed;if(native?.farmRequest){try{committed=await request('commit',input);}catch(error){if(error.code!=='ACK_TIMEOUT')throw error;const receipt=await request('receipt',{operation:input.operation});if(!receipt.found)throw error;committed=receipt;}}
    else committed=fallbackWrite(input.patch);revision=committed.revision;
   }
   locked=false;busy(false);notify();return result;
  }catch(error){rollback(before);depth=0;locked=false;busy(false);message(error);throw error;}
 }
 function change(key,value){key=String(key);if(key.startsWith('__system/'))throw new Error('Clave reservada.');validate(key,value);if(value===null)values.delete(key);else values.set(key,String(value));parsed.delete(key);}
 const facade={
  get length(){return values.size},key:index=>[...values.keys()][index]??null,getItem:key=>values.get(String(key))??null,
  setItem(key,value){key=String(key);value=String(value);if(values.get(key)===value)return;if(depth)change(key,value);else atomic(production.has(key)?'Actualizar registros':'Preferencias',()=>change(key,value));},
  removeItem(key){key=String(key);if(!values.has(key))return;if(depth)change(key,null);else atomic('Eliminar datos',()=>change(key,null));},
  clear(){return atomic('Vaciar almacenamiento',()=>{for(const key of [...values.keys()])change(key,null)})},
  json(key,fallback,copy=true){const raw=facade.getItem(key);if(raw===null)return copy?clone(fallback):fallback;let entry=parsed.get(key);if(!entry||entry.raw!==raw){let value;try{value=JSON.parse(raw)}catch(_){throw new Error('No se pudieron leer los registros. El original se conserva.');}entry={raw,value};parsed.set(key,entry);}return copy?clone(entry.value):entry.value;},
  atomic,runAsync,request,get revision(){return revision},get pending(){return locked},get inTransaction(){return depth>0||locked},
  afterCommit(fn){if(depth||locked)callbacks.push(fn);else fn()},onRollback(fn){if(depth||locked)rollbackCallbacks.push(fn)},
  snapshot:()=>Object.fromEntries(values),
  async reload(){const data=await request('snapshot');values=new Map(Object.entries(data.web));revision=data.revision;parsed.clear();root.dispatchEvent(new Event('truchapp-data-restored'));return data;},
  async restore(){if(locked)throw new Error('Espera al guardado actual.');locked=true;busy(true);try{const result=await request('applyRestore');native?.reconcileStorageReminders?.(result.oldReminders||'[]');return result;}catch(e){locked=false;busy(false);throw e;}},
  native:!!native?.farmRequest
 };
 function installBridge(){
  if(!native?.farmRequest)return;
  const aliases={getLots:['truchapp_lotes_v1','[]'],getActivities:['activities','[]'],getProfile:['profile','{}'],getMemories:['memories','[]']};
  const writes={saveLots:'truchapp_lotes_v1',saveActivities:'activities',saveProfile:'profile',saveMemories:'memories'};
  // Legacy consumers share the same authoritative cache rather than writing a second preference copy.
  root.AndroidAI=new Proxy({},{get(target,key){if(aliases[key])return ()=>facade.getItem(aliases[key][0])??aliases[key][1];if(writes[key])return value=>facade.setItem(writes[key],value);const value=native[key];return typeof value==='function'?value.bind(native):value;}});
 }
 async function initialize(){
  const web={};
  try{const oldJournal=original.getItem('truchapp_storage_journal_v1');if(oldJournal){for(const [key,value]of Object.entries(JSON.parse(oldJournal)))value===null?original.removeItem(key):original.setItem(key,value);original.removeItem('truchapp_storage_journal_v1');}
   for(let i=0;i<original.length;i++){const key=original.key(i);if(key!==null)web[key]=original.getItem(key);}
  }catch(e){if(!native?.farmRequest)throw e;}
  const data=native?.farmRequest?await request('bootstrap',{web}):{web,revision:0};
  for(const [key,value]of Object.entries(data.web))validate(key,value);
  values=new Map(Object.entries(data.web));revision=data.revision;
  Object.defineProperty(root,'localStorage',{configurable:true,get:()=>facade});root.TruchAppStorage=facade;installBridge();return data;
 }
 root.TruchAppStorageBootstrap={initialize,request,original};
 if(typeof module!=='undefined')module.exports={facade,initialize,validate,receive:root.TruchAppStorageReceive};
})(typeof window==='undefined'?globalThis:window);
