/* A confirmation follows the existing store's confirmed commit, never a click. */
(function(){
 'use strict';
 const keys=['truchapp_lotes_v1','truchapp_lotes_water_quality_v1','truchapp_lotes_water_farms_v1','activities','truchapp_almacen_kardex_v1','truchapp_agenda_workbook_v1','truchapp_finance_v1','truchapp_inicio_control_v1'];
 const capture=()=>new Map(keys.map(key=>[key,localStorage.getItem(key)]));
 let before=capture(),armed=false,pending=null,timer=null,element=null;
 function hide(){if(element)element.hidden=true;clearTimeout(timer);}
 function show(message){
  if(!element){element=document.createElement('div');element.id='truchappSaveFeedback';element.className='truchapp-save-feedback';element.setAttribute('role','status');element.setAttribute('aria-live','polite');element.setAttribute('aria-atomic','true');
   element.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg><span></span><button type="button" aria-label="Cerrar aviso de guardado">×</button>';
   (document.querySelector('.phone')||document.body).append(element);element.querySelector('button').addEventListener('click',hide);
  }
  const nav=document.getElementById('bottomNav'),height=nav?.getBoundingClientRect().height||79;
  element.style.bottom=(height+12)+'px';element.querySelector('span').textContent=message;element.hidden=false;
  clearTimeout(timer);timer=setTimeout(hide,4000);
 }
 function arm(){before=capture();armed=true;}
 window.addEventListener('truchapp-storage-ready',arm);setTimeout(arm,0);
 window.addEventListener('truchapp-storage-committed',()=>{
  const after=capture(),changed=keys.filter(key=>before.get(key)!==after.get(key));before=after;
  if(!armed||!changed.length)return;
  if(window.TruchAppLotDetailHost?.isOpen?.())return; // The detail keeps its confirmed toast and Undo.
  const message=changed.includes('truchapp_lotes_v1')?'Cambios guardados':changed.includes('truchapp_almacen_kardex_v1')?'Movimiento guardado':changed.some(k=>k.includes('water'))?'Medición guardada':changed.some(k=>k==='activities'||k.includes('agenda'))?'Actividad guardada':'Datos actualizados';
  clearTimeout(pending);pending=setTimeout(()=>show(message),0);
 });
 window.addEventListener('truchapp-storage-error',()=>{clearTimeout(pending);before=capture();});
 window.TruchAppFeedback={show,hide};
})();
