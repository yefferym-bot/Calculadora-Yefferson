(function(){
 'use strict';
 const ready=()=>new Promise(resolve=>document.readyState==='loading'?document.addEventListener('DOMContentLoaded',resolve,{once:true}):resolve());
 function panel(){let host=document.getElementById('farmBoot');if(!host){host=document.createElement('section');host.id='farmBoot';host.className='farm-boot';host.innerHTML='<div class="farm-boot-card"><span class="farm-boot-mark" aria-hidden="true">≈</span><h1>TruchApp</h1><p id="farmBootMessage" role="status">Preparando tus registros…</p><div id="farmBootActions" hidden><button id="farmBootRetry">Volver a intentar</button><button id="farmBootImport">Restaurar respaldo externo</button></div><div id="farmBootRestore" hidden><label>Contraseña del respaldo<input id="farmBootPassword" type="password" autocomplete="off"></label><button id="farmBootUnlock">Revisar respaldo</button><p id="farmBootPreview"></p><button id="farmBootApply" hidden>Restaurar esta copia</button></div></div>';document.body.append(host);}return host;}
 async function boot(){
  await ready();const host=panel();
  try{
   const initialized=await window.TruchAppStorageBootstrap.initialize();
   for(const original of [...document.querySelectorAll('script[data-storage-inline],script[data-storage-src]')]){
    const script=document.createElement('script');
    if(original.dataset.storageSrc){await new Promise((resolve,reject)=>{script.src=original.dataset.storageSrc;script.onload=resolve;script.onerror=()=>reject(new Error('No se pudo cargar una parte de la aplicación.'));original.after(script);});}
    else{script.textContent=original.textContent;original.after(script);}original.remove();
   }
   host.remove();document.documentElement.classList.remove('farm-preparing');window.dispatchEvent(new Event('truchapp-storage-ready'));if(initialized.backupWarning)window.dispatchEvent(new CustomEvent('truchapp-storage-error',{detail:{message:initialized.backupWarning}}));
  }catch(error){
   document.getElementById('farmBootMessage').textContent=error.message+' Los datos originales se conservan.';
   document.getElementById('farmBootActions').hidden=false;
   document.getElementById('farmBootRetry').onclick=()=>location.reload();
   document.getElementById('farmBootImport').onclick=()=>{window.AndroidAI?.chooseAppBackup?.();};
   document.getElementById('farmBootUnlock').onclick=()=>{const input=document.getElementById('farmBootPassword');window.AndroidAI?.unlockAppBackup?.(input.value);input.value='';};
   document.getElementById('farmBootApply').onclick=async()=>{try{const restored=await window.TruchAppStorageBootstrap.request('applyRestore');window.AndroidAI?.reconcileStorageReminders?.(restored.oldReminders||'[]');location.reload();}catch(e){document.getElementById('farmBootPreview').textContent=e.message;}};
   window.TruchAppBackup={onImportPasswordRequired(){document.getElementById('farmBootRestore').hidden=false;},onImportSelected(raw){const m=JSON.parse(raw);document.getElementById('farmBootRestore').hidden=false;document.getElementById('farmBootPreview').textContent='Copia del '+new Date(m.createdAt).toLocaleString('es-PE')+' · '+(m.counts?.lots||0)+' lotes. Se conservará la base anterior.';document.getElementById('farmBootApply').hidden=false;},onImportError(text){document.getElementById('farmBootMessage').textContent=text;}};
  }
 }
 boot();
})();
