/* Criterios de seguimiento compartidos por Inicio y Agenda. Funciones sin almacenamiento. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TruchAppDecisionData=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const number=v=>v===null||v===undefined||v===''||typeof v==='boolean'?null:Number.isFinite(Number(v))?Number(v):null;
 const has=(o,k)=>Object.prototype.hasOwnProperty.call(o||{},k);
 const bounded=(v,min,max,fallback)=>number(v)!==null&&Number(v)>=min&&Number(v)<=max?Number(v):fallback;
 function scheduled(task,day){
  if(day<task.date||(task.endDate&&day>task.endDate)||(task.cancelledFrom&&day>=task.cancelledFrom))return false;
  const kind=task.repeat||'once';if(kind==='once')return day===task.date;if(kind==='daily')return true;
  const weekday=new Date(day+'T12:00:00').getDay();
  if(kind==='weekdays')return weekday>=1&&weekday<=5;
  if(kind==='custom')return Array.isArray(task.repeatDates)?task.repeatDates.includes(day):(task.repeatDays||[]).includes(weekday);
  return day===task.date;
 }
 function completed(task,day,records=[]){
  const record=records.find(r=>String(r.taskId)===String(task.id)&&r.occurrenceDate===day);
  if(record)return record.complete!==false;
  return task.repeat&&task.repeat!=='once'?(task.completedDates||[]).includes(day):!!(task.done||task.completed);
 }
 function limits(home={},byLot={},lotId=''){
  const global=home.limits||{},own=byLot[String(lotId)]||{};
  const pick=(key,fallback,min,max)=>has(own,key)?(own[key]===null?null:bounded(own[key],min,max,fallback)):has(global,key)?(global[key]===null?null:bounded(global[key],min,max,fallback)):fallback;
  const result={oxygenMin:pick('oxygenMin',5.5,0,30),temperatureMin:pick('temperatureMin',null,-5,50),temperatureMax:pick('temperatureMax',null,-5,50),
   phMin:pick('phMin',6.5,0,14),phMax:pick('phMax',8.5,0,14),co2Max:pick('co2Max',2,.01,200),
   maxAgeHours:bounded(own.maxAgeHours,1,720,bounded(home.freshnessHours,1,720,24)),source:Object.keys(own).length?'lote':'general'};
  return result;
 }
 function issues(values,config){
  const problems=[];
  for(const [parameter,minKey,maxKey]of [['oxygen','oxygenMin',null],['temperature','temperatureMin','temperatureMax'],['ph','phMin','phMax'],['carbonDioxide',null,'co2Max']]){
   const value=number(values[parameter]);if(value===null)continue;
   if(minKey&&config[minKey]!==null&&value<config[minKey])problems.push({parameter,direction:'low',limit:config[minKey]});
   if(maxKey&&config[maxKey]!==null&&(parameter==='carbonDioxide'?value>=config[maxKey]:value>config[maxKey]))problems.push({parameter,direction:'high',limit:config[maxKey]});
  }
  return problems;
 }
 return{number,scheduled,completed,limits,issues};
});
