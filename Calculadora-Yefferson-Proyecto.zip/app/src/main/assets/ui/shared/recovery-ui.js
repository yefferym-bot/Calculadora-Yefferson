(function(){
 'use strict';
 const storage=window.TruchAppStorage,$=id=>document.getElementById(id);
 const date=value=>value?new Date(value).toLocaleString('es-PE',{dateStyle:'medium',timeStyle:'short'}):'Todavía no hay una copia';
 const size=value=>(Number(value||0)/1048576).toLocaleString('es-PE',{maximumFractionDigits:1})+' MiB';
 let errorTimer;
 window.addEventListener('truchapp-storage-error',event=>{
  let node=$('farmStorageNotice');if(!node){node=document.createElement('div');node.id='farmStorageNotice';node.className='farm-storage-notice';node.setAttribute('role','alert');document.body.append(node);}
  node.textContent=event.detail.message;clearTimeout(errorTimer);errorTimer=setTimeout(()=>node.remove(),9000);
 });
 function renderHost(){
  const target=$('tnMenuBackupStatus');if(!target||$('farmRecovery'))return;
  const host=document.createElement('section');host.id='farmRecovery';host.className='farm-recovery';
  host.innerHTML='<h3>Estado y recuperación</h3><p id="farmHealth" role="status">Consultando almacenamiento…</p><div class="farm-recovery-actions"><button data-recovery="verify">Comprobar datos</button><button data-recovery="checkpoint">Crear copia local</button><button data-recovery="recoveries">Copias anteriores</button><button data-recovery="operations">Deshacer operación</button></div><div class="farm-recovery-list" id="farmRecoveryList"></div><p>Las copias locales ayudan ante errores de la app. Exporta también un respaldo cifrado fuera del teléfono para protegerte de pérdida o desinstalación.</p><p>Se conservan hasta 7 copias diarias, 4 semanales y 6 mensuales, sujetas al espacio reservado. Las operaciones se pueden deshacer durante 30 días si no existen cambios posteriores relacionados.</p>';
  target.after(host);host.addEventListener('click',action);
 }
 async function open(){
  renderHost();if(!$('farmHealth'))return;
  if(!storage?.native){$('farmHealth').textContent='La recuperación completa está disponible dentro del APK actualizado.';return;}
  try{const h=await storage.request('health');$('farmHealth').textContent=h.engine+' · '+size(h.bytes)+' · '+h.lots+' lotes · '+h.daily+' días registrados · '+h.water+' lecturas de agua. Última copia local: '+date(h.recovery.lastBackup)+'. '+(h.maintenanceWarning||'');}
  catch(e){$('farmHealth').textContent=e.message;}
 }
 function row(text,label,onClick){const el=document.createElement('div');el.className='farm-recovery-row';const content=document.createElement('span');content.textContent=text;const button=document.createElement('button');button.type='button';button.textContent=label;button.onclick=onClick;el.append(content,button);return el;}
 async function action(event){
  const button=event.target.closest('[data-recovery]');if(!button||!storage?.native)return;
  button.disabled=true;const list=$('farmRecoveryList');
  try{
   const command=button.dataset.recovery;
   if(command==='verify'){await storage.request('verify');$('farmHealth').textContent='Comprobación completada: estructura y documentos válidos.';}
   else if(command==='checkpoint'){await storage.request('checkpoint');await open();}
   else if(command==='recoveries'){
    const data=await storage.request('recoveries');list.replaceChildren();
    for(const copy of data.copies)list.append(row(date(copy.date)+' · '+size(copy.bytes),'Revisar',async()=>{
     try{const meta=await storage.request('stageRecovery',{id:copy.id});if(confirm('Copia del '+date(meta.createdAt)+' con '+(meta.counts?.lots||0)+' lotes. ¿Restaurarla? Se conservarán los datos actuales.')){await storage.restore();location.reload();}}
     catch(e){$('farmHealth').textContent=e.message;}
    }));if(!data.copies.length)list.textContent='Todavía no hay copias locales.';
   }else if(command==='operations'){
    const data=await storage.request('operations');list.replaceChildren();
    for(const operation of data.operations)list.append(row(operation.label+' · '+date(operation.date),'Deshacer',async()=>{
     if(!confirm('¿Deshacer esta operación y sus cambios relacionados?'))return;
     try{await storage.request('undo',{id:operation.id,revision:storage.revision});location.reload();}catch(e){$('farmHealth').textContent=e.message;}
    }));if(!data.operations.length)list.textContent='No hay operaciones recientes para deshacer.';
   }
  }catch(e){$('farmHealth').textContent=e.message;}finally{button.disabled=false;}
 }
 window.TruchAppRecoveryUI={open};
})();
