/* TruchApp V4.1 - Bienvenida de 5 portadas + perfil, aislada de la app principal */
(function(){
  'use strict';

  // Nueva clave para que esta nueva secuencia de 5 portadas se muestre una vez tras instalar/actualizar.
  const KEY='truchapp_intro_v4_1_profile_done';
  const OB=[
    ['Tome notas<br>sin soltar la red','Hable durante el recorrido. TruchApp convierte su voz en registros estructurados del tanque.'],
    ['Todo sobre cada tanque en un solo lugar','Muestreos, mortalidad, alimentación y próximas tareas forman un historial claro. Siempre sabrá qué ocurrió y qué sigue.'],
    ['Planifique el trabajo y las finanzas con claridad','Clima local, calidad del agua y finanzas le ayudan a planificar y ver cuánto genera y cuesta la crianza.'],
    ['Vea qué necesita atención','Use tendencias, alertas de oxígeno y temperatura y registros guardados para decidir el trabajo de cada tanque.']
  ];

  function fishSvg(x,y,s,r=0,o=1){
    return `<use href="#yb-fish" x="${x}" y="${y}" width="${90*s}" height="${60*s}" opacity="${o}" transform="rotate(${r} ${x+45*s} ${y+30*s})"/>`;
  }

  function fishBody(){
    return `<svg width="0" height="0" style="position:absolute" aria-hidden="true">
      <symbol id="tf" viewBox="-30 -8 336 118">
        <defs>
          <linearGradient id="yb-fb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1e40af"/><stop offset=".45" stop-color="#3b82f6"/><stop offset="1" stop-color="#7dd3fc"/></linearGradient>
          <linearGradient id="yb-ff" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2563eb"/><stop offset="1" stop-color="#93c5fd"/></linearGradient>
          <linearGradient id="yb-mf"><stop offset=".14" stop-color="#000"/><stop offset=".32" stop-color="#fff"/></linearGradient>
          <mask id="yb-mk"><rect x="0" y="0" width="282" height="110" fill="url(#yb-mf)"/></mask>
          <pattern id="yb-sc" width="8" height="8" patternUnits="userSpaceOnUse"><path d="M0 8A4 4 0 018 8M-4 4A4 4 0 014 4M4 4A4 4 0 0112 4" stroke="#dbeafe" stroke-opacity=".5" fill="none" stroke-width=".7"/></pattern>
        </defs>
        <g fill="#fff" fill-opacity=".18" stroke="#bae6fd" stroke-width=".8"><circle cx="-12" cy="42" r="5.5"/><circle cx="-20" cy="29" r="3.5"/><circle cx="-9" cy="21" r="2.5"/><circle cx="-24" cy="52" r="2"/></g>
        <g fill="url(#yb-ff)" stroke="#1e3a8a" stroke-width="1" stroke-linejoin="round">
          <path d="M129 22C140 10 150 4 158 1 163 8 168 16 173 25 158 26 142 25 129 22Z"/>
          <path d="M210 25C214 19 222 20 224 27 219 28 214 28 210 25Z"/>
          <path d="M236 32C252 24 276 10 296 -4 289 12 280 36 276 49 281 62 290 78 294 92 275 82 255 72 243 66Z"/>
          <path d="M72 82C85 86 98 94 108 101 92 100 80 96 70 90Z"/>
          <path d="M143 89C150 92 162 98 173 102 160 102 150 100 138 94Z"/>
          <path d="M192 80C202 78 214 76 222 70 220 80 214 88 205 91 200 88 195 84 192 80Z"/>
        </g>
        <g stroke="#bfdbfe" stroke-opacity=".6" stroke-width=".6" fill="none"><path d="M141 12L152 24M149 7L158 25M157 4L165 25M246 34C262 24 278 12 292 0M248 42C264 36 280 28 286 20M250 49H274M248 58C264 62 282 72 288 80M246 64C262 72 278 84 292 90"/></g>
        <path d="M2 71C14 58 30 48 52 40 78 30 105 24 132 22 160 21 190 24 215 26 226 27 233 30 240 33L244 64C230 70 205 80 160 88 125 93 95 92 71 90 50 92 30 90 8 82 2 80 0 75 2 71Z" fill="url(#yb-fb)" stroke="#1e3a8a" stroke-width="1.1" stroke-linejoin="round"/>
        <path d="M2 71C14 58 30 48 52 40 78 30 105 24 132 22 160 21 190 24 215 26 226 27 233 30 240 33L244 64C230 70 205 80 160 88 125 93 95 92 71 90 50 92 30 90 8 82 2 80 0 75 2 71Z" fill="url(#yb-sc)" mask="url(#yb-mk)"/>
        <path d="M60 56C100 52 170 50 240 48" stroke="#bae6fd" stroke-opacity=".55" stroke-width="1.6" fill="none" stroke-linecap="round"/>
        <path d="M74 50C62 60 62 78 74 90" stroke="#1e3a8a" stroke-opacity=".6" stroke-width="1.2" fill="none"/><path d="M3 73C10 76 18 77 25 76" stroke="#1e3a8a" stroke-width="1.3" fill="none" stroke-linecap="round"/>
        <circle cx="29" cy="65" r="7" fill="#e0f2fe" stroke="#1e3a8a" stroke-width="1.2"/><circle cx="29" cy="65" r="4.6" fill="#0f172a"/><circle cx="27.4" cy="63.2" r="1.6" fill="#fff"/>
      </symbol>
      <symbol id="yb-fish" viewBox="0 0 300 120">
        <path class="fb" d="M0 62C10 50 28 38 52 31 76 24 104 20 130 20L150 21V88C120 92 90 90 64 86 40 88 18 80 8 72 2 70 0 66 0 62Z"/>
        <path class="fb" d="M104 22C114 8 126 2 138 -4 142 6 148 14 154 22Z"/>
        <path class="pf" d="M58 76C70 82 82 90 92 98 78 98 66 94 54 86Z"/>
        <path class="pf" d="M118 88C126 92 134 98 142 104 130 104 120 100 112 94Z"/>
        <path class="fr" d="M140 20C170 20 205 24 238 36V62C205 76 172 86 140 89Z"/>
        <path class="fr" d="M190 22C194 15 202 16 204 23Z"/>
        <path class="fr" d="M168 82C178 84 188 90 196 98 184 98 174 94 164 88Z"/>
        <path class="tl" d="M234 36C252 28 272 14 292 -6 284 10 278 32 276 49 279 66 286 82 292 104 272 88 252 74 240 64Z"/>
        <circle class="ey" cx="24" cy="54" r="4"/>
      </symbol>
    </svg>`;
  }

  function mainFish(){
    return `<svg width="80" height="32" viewBox="0 -8 306 118" aria-hidden="true"><use href="#tf"/></svg>`;
  }

  function makeIntro(){
    if(document.getElementById('yb-intro')) return;
    const host=document.createElement('div');
    host.id='yb-intro';
    host.className='yb-intro';
    host.innerHTML=`
      <div class="i-wrap">
        ${fishBody()}
        <section id="yb-ob" style="padding-top:env(safe-area-inset-top)">
          <div class="i-bg">
            <i class="sun"></i><i class="sun2"></i>
            <svg class="mt" viewBox="0 0 500 150" preserveAspectRatio="none"><path fill="#020617" d="M0,150 L0,90 L80,30 L160,80 L240,20 L340,100 L420,40 L500,85 L500,150 Z"/></svg>
            <i class="rp" style="top:33%;left:40px;width:96px;height:32px"></i><i class="rp" style="top:50%;right:32px;width:144px;height:40px;animation-delay:2s"></i>
            <div class="sc">
              <div class="f" style="left:90px;top:0;width:130px;opacity:.85" data-d="0"></div>
              <div class="f" style="left:0;top:46px;width:106px;opacity:.7" data-d="1.1"></div>
              <div class="f" style="left:172px;top:80px;width:94px;opacity:.6" data-d="2.2"></div>
              <div class="f" style="left:40px;top:112px;width:58px;opacity:.55" data-d=".6"></div>
              <div class="f" style="left:236px;top:20px;width:50px;opacity:.5" data-d="1.7"></div>
            </div>
            <i class="fade"></i>
          </div>
          <div class="z" style="padding:48px 24px 0"><div class="lg">${mainFish()}</div><h1>Truch<em>App</em></h1><div class="stp"></div></div>
          <div class="z" style="padding:0 28px"><h3>Sus piscigranjas, bajo control</h3><p>Más control sobre la crianza de Trucha Arcoíris. Menos papeleo.</p><div class="bd"><span>💧 Calidad de Agua</span><span>🌾 Bio-Alimentación</span><span>⚖️ Biomasa</span></div></div>
          <div class="z" style="padding:16px 24px calc(40px + env(safe-area-inset-bottom))"><button class="i-btn" id="yb-start">Empezar con TruchApp →</button><p style="font-size:11px;color:#94a3b8;margin-top:14px">Optimizado para ríos, estanques y tanques</p></div>
        </section>
        <section id="yb-slides" hidden>
          <div class="i-art" id="yb-art"></div>
          <div class="i-tx" id="yb-tx"><h1></h1><p></p></div>
          <div class="i-ft"><div class="i-pg"><div class="i-bar"><i id="yb-obar"></i></div><span id="yb-onum"></span></div><button class="i-btn" id="yb-next"></button><button class="i-sk" id="yb-skip">Omitir</button></div>
        </section>
      </div>`;
    document.body.appendChild(host);
    bindSchool();
  }

  function bindSchool(){
    const FISH=`<svg viewBox="-4 -10 300 120"><g class="fb"><path d="M0 62C10 50 28 38 52 31 76 24 104 20 130 20L150 21V88C120 92 90 90 64 86 40 88 18 80 8 72 2 70 0 66 0 62Z"/><path d="M104 22C114 8 126 2 138 -4 142 6 148 14 154 22Z"/><path class="pf" d="M58 76C70 82 82 90 92 98 78 98 66 94 54 86Z"/><path class="pf" d="M118 88C126 92 134 98 142 104 130 104 120 100 112 94Z"/><circle class="ey" cx="24" cy="54" r="4"/></g><g class="fr"><path d="M140 20C170 20 205 24 238 36V62C205 76 172 86 140 89Z"/><path d="M190 22C194 15 202 16 204 23Z"/><path d="M168 82C178 84 188 90 196 98 184 98 174 94 164 88Z"/><path class="tl" d="M234 36C252 28 272 14 292 -6 284 10 278 32 276 49 279 66 286 82 292 104 272 88 252 74 240 64Z"/></g></svg>`;
    document.querySelectorAll('#yb-ob .sc .f').forEach((f)=>{
      const d=Number(f.dataset.d||0);
      let b='';
      [[5,0],[7,1.1],[4,2.2]].forEach(x=>b+=`<i class="bu" style="width:${x[0]}px;height:${x[0]}px;animation-delay:${(d+x[1]).toFixed(1)}s"></i>`);
      f.innerHTML=b+FISH;
      const svg=f.querySelector('svg');
      if(svg) svg.style.animationDelay=d+'s';
      const fr=svg&&svg.querySelector('.fr');
      if(fr) fr.style.animationDelay=-(d)+'s';
    });
  }

  function art(i){
    if(i===0){
      return `<svg class="yb-slide-art" viewBox="0 0 400 420" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="yb-g0" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0f766e"/><stop offset="1" stop-color="#38bdf8"/></linearGradient></defs><rect width="400" height="420" fill="url(#yb-g0)"/><path d="M0 330Q100 305 200 330T400 320V420H0Z" fill="#fff" opacity=".1"/><rect x="58" y="120" width="284" height="145" rx="24" fill="#fff" opacity=".13"/><path d="M50 265h300M80 220v70M140 210v80M200 205v85M260 215v75M320 220v70" stroke="#e0f2fe" stroke-opacity=".65" stroke-width="3"/><path d="M60 150L340 150M60 190L340 190M60 230L340 230" stroke="#dbeafe" stroke-opacity=".35" stroke-width="2"/><path d="M0 340Q120 305 240 338T400 330V420H0Z" fill="#0f172a" opacity=".24"/>${fishSvg(70,250,1.2,-8,.95)}${fishSvg(250,290,.9,8,.8)}</svg>`;
    }
    if(i===1){
      let s=`<svg class="yb-slide-art" viewBox="0 0 400 420" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="yb-g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#155e75"/><stop offset="1" stop-color="#2dd4bf"/></linearGradient></defs><rect width="400" height="420" fill="url(#yb-g1)"/>`;
      for(let k=0;k<6;k++){const cx=90+(k%3)*110,cy=110+(k>2)*115;s+=`<circle cx="${cx}" cy="${cy}" r="42" fill="#fff" opacity="${k===1?.4:.17}" stroke="${k===1?'#f0734f':'#fff'}" stroke-width="${k===1?4:1.5}"/>${fishSvg(cx-24,cy-16,.55,k*25)}`}
      return s+'</svg>';
    }
    if(i===2){
      let s=`<svg class="yb-slide-art" viewBox="0 0 400 420" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="yb-g2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0e7490"/><stop offset="1" stop-color="#fbbf24"/></linearGradient></defs><rect width="400" height="420" fill="url(#yb-g2)"/><rect x="110" y="70" width="180" height="250" rx="24" fill="#fff" opacity=".93"/><rect x="124" y="84" width="152" height="100" rx="14" fill="#cfe9e4"/><path d="M200 108a15 15 0 0115 15c0 15-15 32-15 32s-15-17-15-32a15 15 0 0115-15z" fill="#f0734f"/><circle cx="200" cy="123" r="5" fill="#fff"/><circle cx="252" cy="108" r="11" fill="#fbbf24"/>`;
      [40,62,36,84,56,72].forEach((h,k)=>s+=`<rect x="${130+k*24}" y="${300-h}" width="14" height="${h}" rx="4" fill="${k%2?'#f0734f':'#0d9488'}"/>`);
      return s+'</svg>';
    }
    return `<svg class="yb-slide-art" viewBox="0 0 400 420" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="yb-g3" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#134e4a"/><stop offset="1" stop-color="#60a5fa"/></linearGradient></defs><rect width="400" height="420" fill="url(#yb-g3)"/><rect x="60" y="80" width="280" height="210" rx="18" fill="#fff" opacity=".94"/><polyline points="85,170 130,150 170,160 215,120 260,135 315,100" fill="none" stroke="#f0734f" stroke-width="5" stroke-linecap="round"/>`+(()=>{let s='';[30,50,38,66,48,72,58].forEach((h,k)=>s+=`<rect x="${88+k*34}" y="${272-h}" width="18" height="${h}" rx="4" fill="#0d9488" opacity=".8"/>`);return s})()+fishSvg(280,300,.8,6,.9)+'</svg>';
  }

  let oi=0;
  let selectedExperience='';
  let transitionBusy=false;

  function profileDraft(){
    try{return JSON.parse(localStorage.getItem('profile')||'{}')||{}}catch(e){return {}}
  }

  function escapeHtml(s){
    return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  }

  function renderProfileForm(){
    const p=profileDraft();
    const artBox=document.getElementById('yb-art');
    artBox.innerHTML=`<svg class="yb-slide-art" viewBox="0 0 400 420" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="yb-g4" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0f766e"/><stop offset="1" stop-color="#38bdf8"/></linearGradient></defs><rect width="400" height="420" fill="url(#yb-g4)"/><circle cx="200" cy="165" r="82" fill="#fff" opacity=".12"/><circle cx="200" cy="140" r="34" fill="#fff" opacity=".92"/><path d="M135 245c10-46 120-46 130 0" fill="#fff" opacity=".92"/><circle cx="126" cy="85" r="5" fill="#fff" opacity=".45"/><circle cx="282" cy="103" r="7" fill="#fff" opacity=".35"/><circle cx="306" cy="160" r="4" fill="#fff" opacity=".4"/></svg>`;
    document.getElementById('yb-slides').classList.add('yb-profile-page');
    document.getElementById('yb-tx').innerHTML=`
      <h1>Personalicemos TruchApp</h1>
      <p>Cuéntame un poco sobre ti para adaptar mejor TruchApp IA.</p>
      <div class="profile-intro">
        <label for="yb-profile-name">¿Cómo te llamas?</label>
        <input id="yb-profile-name" type="text" maxlength="40" autocomplete="name" placeholder="Escribe tu nombre" value="${escapeHtml(p.name||'')}">
        <label class="exp-title">¿Cuál es tu experiencia en este rubro?</label>
        <div class="exp-grid">
          <button type="button" class="exp-btn ${p.experience==='principiante'?'on':''}" data-exp="principiante">🌱 Recién inicio</button>
          <button type="button" class="exp-btn ${p.experience==='experiencia'?'on':''}" data-exp="experiencia">🐟 Tengo experiencia</button>
        </div>
        <div class="hint">Estos datos se guardarán en la memoria local de TruchApp IA y podrás cambiarlos después desde Memoria.</div>
      </div>`;
    selectedExperience=p.experience||'';
    document.querySelectorAll('#yb-slides .exp-btn').forEach(btn=>{
      btn.addEventListener('click',()=>{
        selectedExperience=btn.dataset.exp||'';
        document.querySelectorAll('#yb-slides .exp-btn').forEach(b=>b.classList.toggle('on',b===btn));
      });
    });
  }

  function renderSlide(){
    const slides=document.getElementById('yb-slides');
    slides.classList.remove('yb-profile-page');
    if(oi===4){
      renderProfileForm();
    }else{
      document.getElementById('yb-art').innerHTML=art(oi);
      document.getElementById('yb-tx').innerHTML=`<h1 id="yb-ot">${OB[oi][0]}</h1><p id="yb-od">${OB[oi][1]}</p>`;
    }
    const current=oi+2; // portada hero = 1/5, cada pantalla siguiente = 2/5 ... 5/5
    document.getElementById('yb-onum').textContent=`${current} / 5`;
    document.getElementById('yb-obar').style.width=((current/5)*100)+'%';
    document.getElementById('yb-next').textContent=oi===4?'Comenzar':'Siguiente';
  }

  function enterApp(){
    const root=document.getElementById('yb-intro');
    if(!root) return;
    localStorage.setItem(KEY,'1');
    const ob=document.getElementById('yb-ob');
    if(ob) ob.hidden=true;
    root.style.opacity='0';
    root.style.transition='opacity .35s ease';
    setTimeout(()=>{
      root.remove();
      document.body.style.overflow='';
      document.documentElement.classList.remove('truchapp-boot');
    },360);
  }

  function saveIntroProfile(){
    const input=document.getElementById('yb-profile-name');
    const name=(input&&input.value||'').trim();
    if(!name){
      if(input){
        input.focus();
        input.setCustomValidity('Escribe tu nombre para continuar.');
        input.reportValidity();
      }
      return false;
    }
    if(input) input.setCustomValidity('');
    const old=profileDraft();
    const profile={name,role:old.role||'',experience:selectedExperience||old.experience||''};
    try{localStorage.setItem('profile',JSON.stringify(profile));}catch(e){}
    try{
      if(typeof window.AndroidAI!=='undefined'&&AndroidAI.saveProfile) AndroidAI.saveProfile(JSON.stringify(profile));
    }catch(e){}
    return true;
  }

  function begin(){
    const root=document.getElementById('yb-intro');
    if(!root||transitionBusy)return;
    transitionBusy=true;
    oi=0;
    renderSlide();
    const slides=document.getElementById('yb-slides');
    const ob=document.getElementById('yb-ob');
    slides.hidden=false;
    ob.hidden=false;
    root.classList.remove('i-transition');
    if(window.matchMedia('(prefers-reduced-motion:reduce)').matches){
      ob.hidden=true;
      transitionBusy=false;
      return;
    }
    root.classList.add('i-transition');
    setTimeout(()=>{
      ob.hidden=true;
      root.classList.remove('i-transition');
      transitionBusy=false;
    },1420);
  }

  function next(){
    if(transitionBusy)return;
    if(oi<4){
      oi++;
      renderSlide();
      return;
    }
    if(saveIntroProfile()) enterApp();
  }

  function skip(){
    if(transitionBusy)return;
    enterApp();
  }

  function boot(){
    // Important: index.html hides the main app during the intro using
    // the truchapp-boot class. Once onboarding was already completed,
    // we must explicitly release that boot lock or relaunch would stay blank.
    if(localStorage.getItem(KEY)==='1'){
      document.documentElement.classList.remove('truchapp-boot');
      document.body.style.overflow='';
      return;
    }
    makeIntro();
    document.body.style.overflow='hidden';
    const start=document.getElementById('yb-start');
    const nextBtn=document.getElementById('yb-next');
    const skipBtn=document.getElementById('yb-skip');
    if(start) start.addEventListener('click',begin);
    if(nextBtn) nextBtn.addEventListener('click',next);
    if(skipBtn) skipBtn.addEventListener('click',skip);
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();
