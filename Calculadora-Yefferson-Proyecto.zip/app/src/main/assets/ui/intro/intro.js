/* TruchApp 4.13.2 — Bienvenida principal y cuatro portadas blancas. */
(function(){
  'use strict';
  const KEY='truchapp_intro_v4_1_profile_done';
  const WELCOME_KEY='truchapp_welcome_design_20261022_done';
  const STEPS_KEY='truchapp_onboarding_white_apk_v1_done';
  const PROGRESS_KEY='truchapp_onboarding_white_apk_v1_step';
  const topics=['Producción','Alimentación','Tu jornada','Empezar'];
  let host=null,slides=[],segments=[],options=[],index=0,experience='',experienceTouched=false;
  let transitionBusy=false,closing=false,avatarFish='',touch=null,selectedMode='admin',modePicker=false;
  const $=name=>document.getElementById('yb-step-'+name);
  const read=key=>{try{return localStorage.getItem(key);}catch(_){return null;}};
  function object(raw){try{const v=JSON.parse(raw||'null');return v&&typeof v==='object'&&!Array.isArray(v)?v:null;}catch(_){return null;}}
  const canonical=value=>value==='nuevo'?'principiante':value==='experto'?'experiencia':value||'';
  function profile(){
    const current=object(read('profile'));if(current)return current;
    const legacy=object(read('truchapp_perfil'));
    return legacy?{name:legacy.nombre||'',role:'',experience:canonical(legacy.experiencia)}:{};
  }
  function reduced(){return !!window.matchMedia?.('(prefers-reduced-motion:reduce)').matches;}
  function unlock(){document.body.style.overflow='';document.documentElement.classList.remove('truchapp-boot');window.TruchAppAccess?.apply();}
  function makeIntro(){
    if(document.getElementById('yb-intro'))return;
    host=document.createElement('div');host.id='yb-intro';host.className='yb-intro';
    host.innerHTML=`<div class="i-wrap"><section id="yb-ob">
          <div class="yb-welcome-rayos"></div>
          <div class="yb-welcome-burbujas"></div>
        
          <section class="yb-welcome-hero">
            <div class="yb-welcome-school-stage yb-welcome-entra" style="--i:0" role="img" aria-label="Logo de TruchApp con un cardumen de cinco truchas nadando al fondo">
              <div class="yb-welcome-school-scale" aria-hidden="true"><div class="yb-welcome-sc"><div class="yb-welcome-f" style="left:90px;top:0px;width:130px;opacity:0.85;--delay:0s;--rear-delay:-0s"><svg viewBox="-4 -10 300 120"><g class="yb-welcome-fb"><path d="M0 62C10 50 28 38 52 31 76 24 104 20 130 20L150 21V88C120 92 90 90 64 86 40 88 18 80 8 72 2 70 0 66 0 62Z"/><path d="M104 22C114 8 126 2 138 -4 142 6 148 14 154 22Z"/><path class="yb-welcome-pf" d="M58 76C70 82 82 90 92 98 78 98 66 94 54 86Z"/><path class="yb-welcome-pf" d="M118 88C126 92 134 98 142 104 130 104 120 100 112 94Z"/><circle class="yb-welcome-ey" cx="24" cy="54" r="4"/></g><g class="yb-welcome-fr"><path d="M140 20C170 20 205 24 238 36V62C205 76 172 86 140 89Z"/><path d="M190 22C194 15 202 16 204 23Z"/><path d="M168 82C178 84 188 90 196 98 184 98 174 94 164 88Z"/><path class="yb-welcome-tl" d="M234 36C252 28 272 14 292 -6 284 10 278 32 276 49 279 66 286 82 292 104 272 88 252 74 240 64Z"/></g></svg></div>
        <div class="yb-welcome-f" style="left:0px;top:46px;width:106px;opacity:0.7;--delay:1.1s;--rear-delay:-1.1s"><svg viewBox="-4 -10 300 120"><g class="yb-welcome-fb"><path d="M0 62C10 50 28 38 52 31 76 24 104 20 130 20L150 21V88C120 92 90 90 64 86 40 88 18 80 8 72 2 70 0 66 0 62Z"/><path d="M104 22C114 8 126 2 138 -4 142 6 148 14 154 22Z"/><path class="yb-welcome-pf" d="M58 76C70 82 82 90 92 98 78 98 66 94 54 86Z"/><path class="yb-welcome-pf" d="M118 88C126 92 134 98 142 104 130 104 120 100 112 94Z"/><circle class="yb-welcome-ey" cx="24" cy="54" r="4"/></g><g class="yb-welcome-fr"><path d="M140 20C170 20 205 24 238 36V62C205 76 172 86 140 89Z"/><path d="M190 22C194 15 202 16 204 23Z"/><path d="M168 82C178 84 188 90 196 98 184 98 174 94 164 88Z"/><path class="yb-welcome-tl" d="M234 36C252 28 272 14 292 -6 284 10 278 32 276 49 279 66 286 82 292 104 272 88 252 74 240 64Z"/></g></svg></div>
        <div class="yb-welcome-f" style="left:172px;top:80px;width:94px;opacity:0.6;--delay:2.2s;--rear-delay:-2.2s"><svg viewBox="-4 -10 300 120"><g class="yb-welcome-fb"><path d="M0 62C10 50 28 38 52 31 76 24 104 20 130 20L150 21V88C120 92 90 90 64 86 40 88 18 80 8 72 2 70 0 66 0 62Z"/><path d="M104 22C114 8 126 2 138 -4 142 6 148 14 154 22Z"/><path class="yb-welcome-pf" d="M58 76C70 82 82 90 92 98 78 98 66 94 54 86Z"/><path class="yb-welcome-pf" d="M118 88C126 92 134 98 142 104 130 104 120 100 112 94Z"/><circle class="yb-welcome-ey" cx="24" cy="54" r="4"/></g><g class="yb-welcome-fr"><path d="M140 20C170 20 205 24 238 36V62C205 76 172 86 140 89Z"/><path d="M190 22C194 15 202 16 204 23Z"/><path d="M168 82C178 84 188 90 196 98 184 98 174 94 164 88Z"/><path class="yb-welcome-tl" d="M234 36C252 28 272 14 292 -6 284 10 278 32 276 49 279 66 286 82 292 104 272 88 252 74 240 64Z"/></g></svg></div>
        <div class="yb-welcome-f" style="left:40px;top:112px;width:58px;opacity:0.55;--delay:0.6s;--rear-delay:-0.6s"><svg viewBox="-4 -10 300 120"><g class="yb-welcome-fb"><path d="M0 62C10 50 28 38 52 31 76 24 104 20 130 20L150 21V88C120 92 90 90 64 86 40 88 18 80 8 72 2 70 0 66 0 62Z"/><path d="M104 22C114 8 126 2 138 -4 142 6 148 14 154 22Z"/><path class="yb-welcome-pf" d="M58 76C70 82 82 90 92 98 78 98 66 94 54 86Z"/><path class="yb-welcome-pf" d="M118 88C126 92 134 98 142 104 130 104 120 100 112 94Z"/><circle class="yb-welcome-ey" cx="24" cy="54" r="4"/></g><g class="yb-welcome-fr"><path d="M140 20C170 20 205 24 238 36V62C205 76 172 86 140 89Z"/><path d="M190 22C194 15 202 16 204 23Z"/><path d="M168 82C178 84 188 90 196 98 184 98 174 94 164 88Z"/><path class="yb-welcome-tl" d="M234 36C252 28 272 14 292 -6 284 10 278 32 276 49 279 66 286 82 292 104 272 88 252 74 240 64Z"/></g></svg></div>
        <div class="yb-welcome-f" style="left:236px;top:20px;width:50px;opacity:0.5;--delay:1.7s;--rear-delay:-1.7s"><svg viewBox="-4 -10 300 120"><g class="yb-welcome-fb"><path d="M0 62C10 50 28 38 52 31 76 24 104 20 130 20L150 21V88C120 92 90 90 64 86 40 88 18 80 8 72 2 70 0 66 0 62Z"/><path d="M104 22C114 8 126 2 138 -4 142 6 148 14 154 22Z"/><path class="yb-welcome-pf" d="M58 76C70 82 82 90 92 98 78 98 66 94 54 86Z"/><path class="yb-welcome-pf" d="M118 88C126 92 134 98 142 104 130 104 120 100 112 94Z"/><circle class="yb-welcome-ey" cx="24" cy="54" r="4"/></g><g class="yb-welcome-fr"><path d="M140 20C170 20 205 24 238 36V62C205 76 172 86 140 89Z"/><path d="M190 22C194 15 202 16 204 23Z"/><path d="M168 82C178 84 188 90 196 98 184 98 174 94 164 88Z"/><path class="yb-welcome-tl" d="M234 36C252 28 272 14 292 -6 284 10 278 32 276 49 279 66 286 82 292 104 272 88 252 74 240 64Z"/></g></svg></div></div></div>
              <img class="yb-welcome-brand-logo" id="yb-welcome-logo" src="ui/intro/logo-truchapp.png" alt="" aria-hidden="true" width="1254" height="1254" decoding="async">
            </div>
            <div class="yb-welcome-marca yb-welcome-entra" style="--i:1">TruchApp</div>
            <div class="yb-welcome-etapa yb-welcome-entra" style="--i:1">Gestión acuícola</div>
            <h1 class="yb-welcome-entra" style="--i:2">Tus piscigranjas, bajo control</h1>
            <p class="yb-welcome-sub yb-welcome-entra" style="--i:2">Lleva la crianza de trucha arcoíris con menos papeleo.</p>
        
            <div class="yb-welcome-funciones yb-welcome-entra" style="--i:3">
              <div>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3c3.5 4.2 6 7.2 6 10.2A6 6 0 0 1 6 13.2C6 10.2 8.5 7.2 12 3z"/><path d="M9.5 14a2.6 2.6 0 0 0 2.2 2.4"/></svg>
                Calidad del agua
              </div>
              <div>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21V8"/><path d="M12 8c-2.5 0-4-1.6-4-4 2.5 0 4 1.6 4 4zM12 8c2.5 0 4-1.6 4-4-2.5 0-4 1.6-4 4zM12 14c-2.5 0-4-1.6-4-4 2.5 0 4 1.6 4 4zM12 14c2.5 0 4-1.6 4-4-2.5 0-4 1.6-4 4z"/></svg>
                Alimentación
              </div>
              <div>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v16M7 20h10M5 8h14"/><path d="M5 8l-2.5 6a3 3 0 0 0 5 0L5 8zM19 8l-2.5 6a3 3 0 0 0 5 0L19 8z"/></svg>
                Biomasa
              </div>
            </div>
          </section>
        
          <section class="yb-welcome-base">
            <button id="yb-start" class="yb-welcome-entra" style="--i:4" type="button">Empezar</button>
            <p class="yb-welcome-pie yb-welcome-entra" style="--i:5">Para ríos, estanques y tanques · v1.0</p>
          </section>
        </section>
<section id="yb-slides" aria-label="Introducción a TruchApp" hidden>
<svg class="yb-step-sprite" aria-hidden="true"><defs>
<symbol id="yb-step-sil" viewBox="0 -6 200 90"><path d="M16 40C36 12 96 6 150 31L182 12 172 40 182 68 150 49C96 74 36 68 16 40Z"/><path d="M84 15 104 -2 112 19ZM92 62 106 78 112 60Z"/></symbol>
<symbol id="yb-step-arrow" viewBox="0 0 24 24"><path d="M5 12h14m-5-5 5 5-5 5"/></symbol>
<symbol id="yb-step-back" viewBox="0 0 24 24"><path d="M19 12H5m5-5-5 5 5 5"/></symbol>
<symbol id="yb-step-water" viewBox="0 0 24 24"><path d="M12 3c-3 4-7 8-7 12a7 7 0 0 0 14 0c0-4-4-8-7-12Z"/><path d="M8 15c0 2 1 3 3 3"/></symbol>
<symbol id="yb-step-ruler" viewBox="0 0 24 24"><path d="m3 16 13-13 5 5L8 21Zm5-5 2 2m1-5 2 2m1-5 2 2"/></symbol>
<symbol id="yb-step-stock" viewBox="0 0 24 24"><path d="m3 7 9-4 9 4v11l-9 4-9-4Zm0 0 9 4 9-4M12 11v11M8 5l9 4"/></symbol>
<symbol id="yb-step-calendar" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4M17 3v4M3 10h18m-13 5 3 3 5-5"/></symbol>
<symbol id="yb-step-shield" viewBox="0 0 24 24"><path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Zm-4 9 3 3 5-6"/></symbol>
<symbol id="yb-step-sprout" viewBox="0 0 24 24"><path d="M12 21V10m0 1c-5 0-7-3-7-7 5 0 7 3 7 7Zm0 4c0-5 3-7 7-7 0 5-3 7-7 7Z"/></symbol>
<symbol id="yb-step-check" viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></symbol>
<symbol id="yb-step-close" viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></symbol>
</defs></svg>
  <header class="yb-step-top">
    <button id="yb-step-atras" class="yb-step-back" type="button" aria-label="Volver al paso anterior" disabled><svg class="yb-step-icon" aria-hidden="true"><use href="#yb-step-back"/></svg></button>
    <div class="yb-step-wordmark">TruchApp</div>
    <button id="yb-step-omitir" class="yb-step-skip" type="button">Omitir</button>
  </header>
  <div class="yb-step-slides">
    <article class="yb-step-slide yb-step-on" aria-labelledby="yb-step-titulo-1" aria-label="Paso 1 de 4" aria-hidden="false">
      <div class="yb-step-scene"><div class="yb-step-scene-inner">
        <div class="yb-step-scene-card" aria-label="Ejemplo ilustrativo de un lote">
          <div class="yb-step-card-head">
            <div class="yb-step-card-heading"><div class="yb-step-tile-icon"><svg class="yb-step-fish" viewBox="0 -6 200 90" aria-hidden="true"><use href="#yb-step-sil"/></svg></div><div><div class="yb-step-kicker">Mis lotes</div><h3>Lote A</h3></div></div>
            <span class="yb-step-example">Ejemplo</span>
          </div>
          <div class="yb-step-lot-meta"><span>Alevinaje</span><i aria-hidden="true"></i><span>Jaula 1</span></div>
          <div class="yb-step-metrics">
            <div class="yb-step-metric"><strong>10 000</strong><span>Peces</span></div>
            <div class="yb-step-metric"><strong>20 <small>g</small></strong><span>Peso promedio</span></div>
            <div class="yb-step-metric"><strong>200 <small>kg</small></strong><span>Biomasa</span></div>
          </div>
          <div class="yb-step-record-labels"><span><svg class="yb-step-icon" aria-hidden="true"><use href="#yb-step-ruler"/></svg>Biometría</span><span><svg class="yb-step-icon" aria-hidden="true"><use href="#yb-step-water"/></svg>Calidad del agua</span></div>
        </div>
        <p class="yb-step-scene-caption">Cada registro forma parte de su historial.</p>
      </div></div>
      <div class="yb-step-text"><div class="yb-step-kicker">Producción</div><h2 id="yb-step-titulo-1">Tus lotes, con su historial completo</h2><p>Registra biometrías, bajas y calidad del agua para seguir el crecimiento de tus truchas.</p></div>
    </article>

    <article class="yb-step-slide" aria-labelledby="yb-step-titulo-2" aria-label="Paso 2 de 4" aria-hidden="true" inert>
      <div class="yb-step-scene"><div class="yb-step-scene-inner">
        <div class="yb-step-scene-card yb-step-feed-card" aria-label="Ejemplo: entrega de 3 kg, saldo de 97 kg y costo de 12 soles">
          <div class="yb-step-card-head"><div class="yb-step-card-heading"><div class="yb-step-tile-icon"><svg class="yb-step-icon" aria-hidden="true"><use href="#yb-step-stock"/></svg></div><div><div class="yb-step-kicker">Almacén</div><h3>Alimento 3 mm</h3></div></div><span class="yb-step-example">Ejemplo</span></div>
          <div class="yb-step-stock-flow"><div class="yb-step-stock"><strong>100 <small>kg</small></strong><span>Antes</span></div><div class="yb-step-flow-arrow" aria-hidden="true"><b>−3 kg</b><svg class="yb-step-icon"><use href="#yb-step-arrow"/></svg><i class="yb-step-flow-dot"></i></div><div class="yb-step-stock yb-step-after"><strong>97 <small>kg</small></strong><span>Disponible</span></div></div>
          <div class="yb-step-delivery-info"><span>Entrega al <b>Lote A</b></span><b>3 kg</b></div>
          <div class="yb-step-delivery-cost"><div>Costo de esta entrega<small>A S/4 por kg registrado</small></div><strong>S/12</strong></div>
        </div>
        <div class="yb-step-connections" aria-label="Datos conectados entre Lotes, Almacén y Finanzas"><span>Lotes</span><b aria-hidden="true">↔</b><span>Almacén</span><b aria-hidden="true">↔</b><span>Finanzas</span></div>
      </div></div>
      <div class="yb-step-text"><div class="yb-step-kicker">Alimentación</div><h2 id="yb-step-titulo-2">Cada entrega, con stock y costo</h2><p>Vincula el alimento suministrado al almacén y consulta cuánto consume y cuesta cada lote.</p></div>
    </article>

    <article class="yb-step-slide" aria-labelledby="yb-step-titulo-3" aria-label="Paso 3 de 4" aria-hidden="true" inert>
      <div class="yb-step-scene"><div class="yb-step-scene-inner">
        <div class="yb-step-day-head"><span>Tu jornada</span><span class="yb-step-example">Ejemplo</span></div>
        <div class="yb-step-day-list">
          <div class="yb-step-day-card"><div class="yb-step-tile-icon"><svg class="yb-step-icon" aria-hidden="true"><use href="#yb-step-water"/></svg></div><div class="yb-step-day-copy"><h3>Jaula 1 · Oxígeno</h3><p>Último registro: ayer, 07:00</p><div class="yb-step-state-row"><span class="yb-step-state">Actualizar</span><small>Control del agua</small></div></div></div>
          <div class="yb-step-day-card"><div class="yb-step-tile-icon"><svg class="yb-step-icon" aria-hidden="true"><use href="#yb-step-calendar"/></svg></div><div class="yb-step-day-copy"><h3>Biometría · Lote A</h3><p>Hoy · 09:00</p><div class="yb-step-state-row"><span class="yb-step-state yb-step-pending">Pendiente</span><small>Agenda</small></div></div></div>
        </div>
        <p class="yb-step-day-note">Los avisos usan tus registros y los rangos que configures.</p>
      </div></div>
      <div class="yb-step-text"><div class="yb-step-kicker">Inicio y Agenda</div><h2 id="yb-step-titulo-3">Empieza el día sabiendo qué revisar</h2><p>Consulta avisos, mediciones y tareas pendientes para organizar el trabajo de tu piscigranja.</p></div>
    </article>

    <article class="yb-step-slide yb-role-slide" aria-labelledby="yb-step-titulo-4" aria-label="Paso 4 de 4" aria-hidden="true" inert>
      <div class="yb-role-brand"><img src="ui/intro/logo-truchapp.png" width="86" height="86" alt=""><span>TruchApp</span></div><div class="yb-role-progress" aria-label="Paso 4 de 4"><i></i><i></i><i></i><i></i><span>4 de 4</span></div>
      <h2 id="yb-step-titulo-4">Elige tu modo de trabajo</h2><p class="yb-role-subtitle">Selecciona cómo participarás en tu granja.</p>
      <div class="yb-role-cards" id="yb-role-choices" role="radiogroup" aria-labelledby="yb-step-titulo-4">
       <button type="button" class="yb-role-card" data-role-mode="admin" role="radio" aria-checked="true"><span class="yb-role-icon">${window.TruchAppAccess.icon('shield')}</span><span class="yb-role-copy"><strong>Administrador</strong><span>Gestiona tus lotes, registros y equipo.</span><small class="yb-role-chip">Gestión completa</small></span><span class="yb-role-radio" aria-hidden="true">✓</span></button>
       <button type="button" class="yb-role-card" data-role-mode="collaborator" role="radio" aria-checked="false" tabindex="-1"><span class="yb-role-icon">${window.TruchAppAccess.icon('group')}</span><span class="yb-role-copy"><strong>Colaborador</strong><span>Registra datos de los lotes que te asignen.</span></span><span class="yb-role-radio" aria-hidden="true">✓</span></button>
      </div>
      <div class="yb-role-info" id="yb-role-admin-info">${window.TruchAppAccess.icon('info')}<p>El administrador define los permisos de su equipo.</p></div>
      <section id="yb-role-link" class="yb-role-link-form" aria-labelledby="yb-role-link-title" hidden><h3 id="yb-role-link-title">${window.TruchAppAccess.icon('link')}Datos de vinculación</h3>
       <label for="yb-role-name">Tu nombre</label><input id="yb-role-name" type="text" maxlength="40" autocomplete="given-name" placeholder="Nombre del colaborador">
       <label for="yb-role-code">Código del administrador</label><input id="yb-role-code" type="text" maxlength="120" autocomplete="off" spellcheck="false" placeholder="Ingresa el código de invitación">
       <button type="button" class="yb-role-qr" disabled>${window.TruchAppAccess.icon('qr')}Escanear QR · Próximamente</button>
       <div class="yb-role-future">Conexión entre dispositivos<br><small>Misma red Wi-Fi</small><div class="co-connection-grid"><button type="button" data-intro-local>${window.TruchAppAccess.icon('wifi')}<span>Local</span></button><button type="button" disabled>${window.TruchAppAccess.icon('globe')}<span>Por internet · Próximamente</span></button></div></div>
       <p>Para vincular en local, continúa y busca al administrador. Comprobarás un código en ambos teléfonos; el código escrito arriba queda como borrador.</p><button type="button" class="yb-role-vincular" data-intro-local>Continuar y vincular en local</button>
      </section><p id="yb-role-error" class="yb-role-error" role="alert" hidden></p>
      <details class="yb-role-profile" id="yb-role-admin-profile"><summary>Completar perfil (opcional)</summary><span id="yb-step-avatar" hidden></span>      <div class="yb-step-profile">
        <div class="yb-step-label-row"><label for="yb-step-nombre">Tu nombre</label><small>Opcional</small></div>
        <input id="yb-step-nombre" type="text" autocomplete="given-name" autocapitalize="words" maxlength="40" placeholder="¿Cómo te llamas?" aria-describedby="yb-step-perfil-ayuda yb-step-perfil-error">
        <div class="yb-step-label-row yb-step-experience-label"><span id="yb-step-lblexp">Tu experiencia</span><small>Opcional</small></div>
        <div class="yb-step-options" role="group" aria-labelledby="yb-step-lblexp">
          <button class="yb-step-option" type="button" data-v="principiante" aria-pressed="false"><svg class="yb-step-icon" aria-hidden="true"><use href="#yb-step-sprout"/></svg>Recién inicio</button>
          <button class="yb-step-option" type="button" data-v="experiencia" aria-pressed="false"><svg class="yb-step-fish" viewBox="0 -6 200 90" width="23" height="20" aria-hidden="true"><use href="#yb-step-sil"/></svg>Tengo experiencia</button>
        </div>
        <p class="yb-step-error" id="yb-step-perfil-error" role="alert" hidden></p>
      </div>
<p id="yb-step-perfil-ayuda">Tus registros se guardan en este dispositivo.</p></details>
    </article>
  </div>
  <footer class="yb-step-footer">
<p id="yb-step-save-error" class="yb-step-error" role="alert" hidden></p>
    <div class="yb-step-progress"><div class="yb-step-progress-meta"><b id="yb-step-paso-texto" role="status" aria-live="polite" aria-atomic="true">1 de 4</b><span id="yb-step-paso-tema">Producción</span></div><div class="yb-step-segments" id="yb-step-pasos" aria-hidden="true"><i class="yb-step-hecho"></i><i></i><i></i><i></i></div></div>
    <button class="yb-step-btn" id="yb-step-sig" type="button"><span id="yb-step-sig-texto">Siguiente</span><svg class="yb-step-icon" aria-hidden="true"><use href="#yb-step-arrow"/></svg></button>
    <button class="yb-step-secondary" id="yb-step-ir-inicio" type="button" hidden>Ir a Inicio</button>
  </footer>
</section></div>`;
    document.body.appendChild(host);
    const bubbles=host.querySelector('#yb-ob .yb-welcome-burbujas');
    if(bubbles)for(let i=0;i<5;i++){
      const bubble=document.createElement('i');bubble.className='yb-welcome-burbuja';
      bubble.style.left=(9+i*20)+'%';bubble.style.setProperty('--s',(4+(i*3)%5)+'px');
      bubble.style.setProperty('--d',(12+(i*2)%7)+'s');bubble.style.animationDelay=-(i*2.7)+'s';bubbles.appendChild(bubble);
    }
    slides=Array.from(host.querySelectorAll('#yb-slides .yb-step-slide'));
    segments=Array.from(host.querySelectorAll('#yb-step-pasos i'));
    options=Array.from(host.querySelectorAll('#yb-slides .yb-step-option'));
    avatarFish=$('avatar').innerHTML;loadProfile();
    const saved=Number(read(PROGRESS_KEY));go(Number.isInteger(saved)?saved:0,false);
    document.getElementById('yb-start').addEventListener('click',begin);
    $('sig').addEventListener('click',()=>{if(index<slides.length-1)go(index+1);else finish(true,'home');});
    $('atras').addEventListener('click',()=>go(index-1));
    $('omitir').addEventListener('click',()=>go(slides.length-1));
    $('ir-inicio').addEventListener('click',()=>{if(modePicker)cancelPicker();else go(index-1);});
    $('nombre').addEventListener('input',()=>{clearError();updateAvatar();});
    $('nombre').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();finish(true,'home');}});
    options.forEach(button=>button.addEventListener('click',()=>{
      const chosen=button.getAttribute('data-v');experience=experience===chosen?'':chosen;experienceTouched=true;
      options.forEach(option=>option.setAttribute('aria-pressed',option.getAttribute('data-v')===experience?'true':'false'));
    }));
    const access=window.TruchAppAccess.read();selectedMode=access.mode;
    document.getElementById('yb-role-name').value=access.collaborator.name;
    document.getElementById('yb-role-code').value=access.collaborator.invitationCode;
    const choices=document.getElementById('yb-role-choices');
    host.addEventListener('keydown',event=>{if(modePicker&&event.key==='Escape'){event.preventDefault();event.stopPropagation();cancelPicker();}});
    choices.addEventListener('click',event=>{const button=event.target.closest('[data-role-mode]');if(button)selectMode(button.dataset.roleMode);});
    choices.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;event.preventDefault();event.stopPropagation();selectMode(selectedMode==='admin'?'collaborator':'admin');host.querySelector('[data-role-mode="'+selectedMode+'"]').focus();});
    host.querySelectorAll('[data-intro-local]').forEach(button=>button.addEventListener('click',()=>finish(true,'local-pair')));
    selectMode(selectedMode);window.TruchAppAccess.apply();
    const steps=document.getElementById('yb-slides');
    steps.addEventListener('touchstart',event=>{
      touch=null;if(closing||transitionBusy||event.touches.length!==1||event.target.closest('input,textarea,button,a,select'))return;
      touch={x:event.touches[0].clientX,y:event.touches[0].clientY};
    },{passive:true});
    steps.addEventListener('touchend',event=>{
      if(!touch||!event.changedTouches.length)return;
      const dx=event.changedTouches[0].clientX-touch.x,dy=event.changedTouches[0].clientY-touch.y;touch=null;
      if(Math.abs(dx)>60&&Math.abs(dx)>Math.abs(dy)*1.3)go(index+(dx<0?1:-1));
    },{passive:true});
    steps.addEventListener('touchcancel',()=>{touch=null;},{passive:true});
    steps.addEventListener('keydown',event=>{
      if(event.target.closest('input,textarea,select,[role=radiogroup]')||event.altKey||event.ctrlKey||event.metaKey)return;
      if(event.key==='ArrowRight'||event.key==='ArrowLeft'){event.preventDefault();go(index+(event.key==='ArrowRight'?1:-1));}
    });
    document.addEventListener('visibilitychange',visibility);visibility();
  }
  function visibility(){if(host)host.setAttribute('data-paused',document.hidden?'true':'false');}
  function updateAvatar(){
    const value=$('nombre').value.trim();
    if(value)$('avatar').textContent=Array.from(value)[0].toLocaleUpperCase('es');else $('avatar').innerHTML=avatarFish;
  }
  function loadProfile(){
    const p=profile();$('nombre').value=typeof p.name==='string'?p.name:'';
    experience=canonical(p.experience);experienceTouched=false;
    options.forEach(button=>button.setAttribute('aria-pressed',button.getAttribute('data-v')===experience?'true':'false'));
    updateAvatar();
  }
  function clearError(){
    $('perfil-error').hidden=true;$('perfil-error').textContent='';$('nombre').removeAttribute('aria-invalid');$('nombre').setCustomValidity('');
    $('save-error').hidden=true;$('save-error').textContent='';
  }
  function go(n,persist=true){
    if(closing||transitionBusy)return;
    n=modePicker?slides.length-1:Math.max(0,Math.min(slides.length-1,n));
    if(n!==index&&document.activeElement&&slides[index]?.contains(document.activeElement))$('sig').focus();
    index=n;
    slides.forEach((slide,k)=>{
      slide.classList.toggle('yb-step-on',k===index);slide.classList.toggle('yb-step-antes',k<index);
      slide.setAttribute('aria-hidden',k===index?'false':'true');slide.inert=k!==index;if(k===index)slide.scrollTop=0;
    });
    segments.forEach((segment,k)=>segment.classList.toggle('yb-step-hecho',k<=index));
    $('paso-texto').textContent=(index+1)+' de '+slides.length;$('paso-tema').textContent=topics[index];
    document.getElementById('yb-slides').dataset.roleStep=String(index===slides.length-1);
    $('sig-texto').textContent=index===slides.length-1?(selectedMode==='collaborator'?'Continuar como colaborador':'Continuar como administrador'):'Siguiente';
    $('ir-inicio').textContent=modePicker?'Cancelar':'← Atrás';
    $('ir-inicio').hidden=index!==slides.length-1;$('atras').disabled=index===0;
    if(persist&&!modePicker)try{localStorage.setItem(PROGRESS_KEY,String(index));}catch(_){}
  }
  function begin(){
    if(!host||closing||transitionBusy)return;
    const cover=document.getElementById('yb-ob'),steps=document.getElementById('yb-slides');
    steps.hidden=false;
    function showSteps(){cover.hidden=true;cover.inert=true;cover.setAttribute('aria-hidden','true');host.classList.remove('i-transition');transitionBusy=false;$('sig').focus();}
    if(reduced()){showSteps();return;}
    transitionBusy=true;host.classList.add('i-transition');setTimeout(showSteps,1420);
  }
  function navigate(target){
    if(window.TruchAppAccess.read().mode==='collaborator'){window.TruchAppAccess.go('home');if(target==='local-pair')window.TruchAppLocalPair?.open();return;}
    const button=document.querySelector('.bottom .nav[data-target="'+(target==='new-lot'?'lotes':'inicio')+'"]');
    if(button)button.click();
    if(target!=='new-lot')return;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      // Leave the module's tutorial preference intact while opening the requested real form.
      document.getElementById('lotesTutorial')?.classList.remove('open');
      document.getElementById('createLoteTrigger')?.click();
    }));
  }
  function finish(save,target){
    if(closing||transitionBusy)return;
    let p=profile(),saveProfile=false,access;
    try{access=window.TruchAppAccessData.selection(selectedMode,document.getElementById('yb-role-name').value,document.getElementById('yb-role-code').value,window.TruchAppAccess.read());}catch(error){const node=document.getElementById('yb-role-error');node.textContent=error.message;node.hidden=false;node.scrollIntoView({block:'nearest'});return;}
    if(save&&selectedMode==='admin'){
      const name=$('nombre').value.trim();
      if(name.length>40){$('perfil-error').textContent='Usa un nombre de hasta 40 caracteres.';$('perfil-error').hidden=false;$('nombre').setAttribute('aria-invalid','true');$('nombre').focus();return;}
      if(name||experienceTouched||experience){
        p=Object.assign({},p,{role:p.role||''});if(name)p.name=name;
        if(experienceTouched||experience)p.experience=experience;saveProfile=true;
      }
    }
    const persist=()=>{
      localStorage.setItem(window.TruchAppAccessData.KEY,JSON.stringify(access));
      if(saveProfile)localStorage.setItem('profile',JSON.stringify(p));
      localStorage.setItem(KEY,'1');localStorage.setItem(WELCOME_KEY,'1');localStorage.setItem(STEPS_KEY,'1');localStorage.removeItem(PROGRESS_KEY);
    };
    try{
      if(window.TruchAppStorage?.atomic)window.TruchAppStorage.atomic('Completar bienvenida',persist);else persist();
    }catch(error){
      $('save-error').textContent=error.message||'No se pudo guardar. Inténtalo de nuevo.';$('save-error').hidden=false;return;
    }
    clearError();closing=true;$('sig').disabled=true;$('omitir').disabled=true;$('atras').disabled=true;$('ir-inicio').disabled=true;
    if(document.activeElement&&host.contains(document.activeElement))document.activeElement.blur();
    function enter(){host.remove();host=null;modePicker=false;unlock();document.removeEventListener('visibilitychange',visibility);navigate(target);}
    if(reduced()){enter();return;}
    host.style.opacity='0';host.style.transition='opacity .35s ease';setTimeout(enter,360);
  }
  function selectMode(mode){
    selectedMode=mode;const steps=document.getElementById('yb-slides');steps.dataset.selectedMode=mode;
    host.querySelectorAll('[data-role-mode]').forEach(button=>{const chosen=button.dataset.roleMode===mode;button.setAttribute('aria-checked',String(chosen));button.tabIndex=chosen?0:-1;});
    document.getElementById('yb-role-link').hidden=mode!=='collaborator';document.getElementById('yb-role-admin-info').hidden=mode!=='admin';document.getElementById('yb-role-admin-profile').hidden=mode!=='admin';document.getElementById('yb-role-error').hidden=true;
    if(index===slides.length-1)$('sig-texto').textContent=mode==='collaborator'?'Continuar como colaborador':'Continuar como administrador';
  }
  function cancelPicker(){
    if(!modePicker||closing)return;host.remove();host=null;modePicker=false;document.removeEventListener('visibilitychange',visibility);unlock();
    const target=document.querySelector('#collaboratorApp:not([hidden]) [data-co-tab][aria-current=page],.phone .bottom .nav.active');target?.focus({preventScroll:true});
  }
  function openModePicker(){
    if(host||window.TruchAppStorage?.pending)return;closing=false;transitionBusy=false;modePicker=true;window.TruchAppLotDetailHost?.close();makeIntro();host.setAttribute('role','dialog');host.setAttribute('aria-modal','true');host.setAttribute('aria-labelledby','yb-step-titulo-4');
    const cover=document.getElementById('yb-ob'),steps=document.getElementById('yb-slides');cover.hidden=true;cover.inert=true;steps.hidden=false;go(slides.length-1,false);document.body.style.overflow='hidden';window.TruchAppAccess.apply();$('sig').focus();
  }
  window.TruchAppIntro={openModePicker};
  function boot(){
    if(read(KEY)==='1'&&read(WELCOME_KEY)==='1'&&read(STEPS_KEY)==='1'){unlock();return;}
    makeIntro();document.body.style.overflow='hidden';
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
