/* TruchApp Finanzas. Sin dependencias externas. Valores editables y calculados localmente. */
(function(){
  const KEY='truchapp_finance_v1';
  const $=id=>document.getElementById(id);
  function get(){try{return JSON.parse(localStorage.getItem(KEY))||{}}catch{return {}}}
  function set(v){try{localStorage.setItem(KEY,JSON.stringify(v))}catch{}}
  function n(id){const v=parseFloat($(id)?.value||'');return Number.isFinite(v)?v:0}
  function money(v){return 'S/ '+Number(v||0).toLocaleString('es-PE',{minimumFractionDigits:2,maximumFractionDigits:2})}
  function pct(v){return Number(v||0).toLocaleString('es-PE',{minimumFractionDigits:1,maximumFractionDigits:1})+'%'}
  function render(){
    const root=$('financeRoot'); if(!root)return;
    const saved=get();
    root.innerHTML=`
      <div class="finance-wrap">
        <div class="finance-head"><div><h2>Finanzas</h2><p>Evalúa costos, ingresos y rentabilidad de tu producción.</p></div><span class="finance-badge">🐟 Trucha arcoíris</span></div>
        <div class="card hero"><h3>Control económico del ciclo</h3><p>Registra datos reales de tu granja. El cálculo separa producción, punto de equilibrio e inversión para evitar confundir costos con capital inicial.</p></div>
        <div class="card">
          <div class="label">Usar datos de un lote registrado</div>
          <p class="finance-note">Puedes copiar peces sembrados, pesos y supervivencia desde Lotes. Los costos y precios continúan siendo los que ingreses aquí.</p>
          <div class="finance-field full"><label for="financeLotSelect">Seleccionar lote</label><select id="financeLotSelect" class="finance-input"><option value="">No hay lotes disponibles</option></select></div>
          <button class="primary" style="width:100%;margin-top:9px" type="button" id="financeUseLot">Usar datos del lote seleccionado</button>
          <p class="finance-note" id="financeLotStatus" role="status" style="margin-top:7px"></p>
        </div>
        <div class="card">
          <div class="label">Producción</div>
          <div class="finance-form">
            <div class="finance-field"><label>Peces sembrados</label><input class="finance-input" id="fn" type="number" min="0" step="1" value="${saved.n??1000}"></div>
            <div class="finance-field"><label>Peso inicial (g)</label><input class="finance-input" id="fw0" type="number" min="0" step="0.1" value="${saved.w0??20}"></div>
            <div class="finance-field"><label>Peso de cosecha (g)</label><input class="finance-input" id="fw1" type="number" min="0" step="0.1" value="${saved.w1??350}"></div>
            <div class="finance-field"><label>Supervivencia (%)</label><input class="finance-input" id="fs" type="number" min="0" max="100" step="0.1" value="${saved.s??90}"></div>
            <div class="finance-field"><label>FCR del ciclo</label><input class="finance-input" id="ffcr" type="number" min="0" step="0.01" value="${saved.fcr??1.2}"></div>
            <div class="finance-field"><label>Precio de venta (S/ kg)</label><input class="finance-input" id="fprice" type="number" min="0" step="0.01" value="${saved.price??0}"></div>
            <div class="finance-field"><label>Precio alimento (S/ kg)</label><input class="finance-input" id="ffeed" type="number" min="0" step="0.01" value="${saved.feed??0}"></div>
            <div class="finance-field"><label>Semilla / alevines (S/)</label><input class="finance-input" id="fseed" type="number" min="0" step="0.01" value="${saved.seed??0}"></div>
          </div>
        </div>
        <div class="card">
          <div class="label">Otros costos del ciclo</div>
          <div class="finance-form">
            <div class="finance-field"><label>Mano de obra (S/)</label><input class="finance-input" id="flabor" type="number" min="0" step="0.01" value="${saved.labor??0}"></div>
            <div class="finance-field"><label>Energía / bombeo (S/)</label><input class="finance-input" id="fenergy" type="number" min="0" step="0.01" value="${saved.energy??0}"></div>
            <div class="finance-field"><label>Transporte (S/)</label><input class="finance-input" id="ftransport" type="number" min="0" step="0.01" value="${saved.transport??0}"></div>
            <div class="finance-field"><label>Sanidad / insumos (S/)</label><input class="finance-input" id="fhealth" type="number" min="0" step="0.01" value="${saved.health??0}"></div>
            <div class="finance-field"><label>Mantenimiento (S/)</label><input class="finance-input" id="fmaint" type="number" min="0" step="0.01" value="${saved.maint??0}"></div>
            <div class="finance-field"><label>Otros (S/)</label><input class="finance-input" id="fother" type="number" min="0" step="0.01" value="${saved.other??0}"></div>
            <div class="finance-field full"><label>Inversión inicial / capital (S/) — se usa aparte de los costos del ciclo</label><input class="finance-input" id="finvest" type="number" min="0" step="0.01" value="${saved.invest??0}"></div>
          </div>
          <button class="primary" style="width:100%;margin-top:10px" id="fcalc">Calcular ciclo</button>
        </div>
        <div id="financeResult"></div>
        <div class="card"><h3 class="finance-subtitle">Qué significa cada resultado</h3>
          <p class="finance-note"><b>Ingreso bruto:</b> producción cosechada × precio de venta.</p>
          <p class="finance-note"><b>Costo de producción:</b> suma de costos operativos del ciclo, incluido el alimento estimado por FCR.</p>
          <p class="finance-note"><b>Punto de equilibrio:</b> precio que cubre el costo del ciclo sin generar utilidad.</p>
          <p class="finance-note"><b>Inversión:</b> capital inicial para instalar o equipar la unidad; no se mezcla automáticamente con los costos operativos.</p>
        </div>
        <div class="card"><h3 class="finance-subtitle">Referencias técnicas</h3>
          <div class="finance-ref"><b>FAO (2011), Technical Paper 561 — Small-scale rainbow trout farming.</b><br>Propone llevar registros de existencias, mortalidad, alimentación, almacén y balance mensual; estos datos permiten calcular costos de producción, precios unitarios y utilidad. También presenta VAN, TIR y periodo de recuperación para la evaluación de inversiones.</div>
          <div class="finance-ref"><b>UNAP / Puno, estudio de viabilidad de conserva de trucha (2023).</b><br>Usó registros de costos a precios de mercado y flujo de caja para evaluar VANf, TIR, relación beneficio/costo y recuperación de la inversión.</div>
          <div class="finance-ref"><b>Demircan et al. (2024), análisis económico de granjas de trucha en jaulas.</b><br>En la muestra estudiada, las granjas de mayor tamaño tuvieron menor costo por tonelada y mayores márgenes; este hallazgo es comparativo y no debe trasladarse como un precio o rentabilidad para una granja peruana.</div>
          <p class="finance-source-note">Los precios y costos del módulo deben ser ingresados con datos reales de tu granja. Las cifras de estudios externos sirven como referencia metodológica, no como tarifas actuales para Perú.</p>
        </div>
      </div>`;
    root.querySelectorAll('input').forEach(i=>i.addEventListener('change',()=>saveInputs()));
    $('fcalc').addEventListener('click',calculate);
    $('financeUseLot')?.addEventListener('click',importSelectedLot);
    updateFinanceLotOptions();
    calculate();
  }
  function getSharedLots(){try{return window.TruchAppData&&typeof window.TruchAppData.getLots==='function'?window.TruchAppData.getLots():[]}catch{return []}}
  function updateFinanceLotOptions(){
    const select=$('financeLotSelect');if(!select)return;
    const previous=select.value;const lots=getSharedLots();
    select.innerHTML='<option value="">Selecciona un lote</option>'+lots.map(l=>'<option value="'+String(l.id).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))+'">'+String(l.code||l.id).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))+' · '+String(l.stage||'Producción')+'</option>').join('');
    if(previous&&lots.some(l=>String(l.id)===previous))select.value=previous;
    if(!lots.length){select.innerHTML='<option value="">Todavía no hay lotes registrados</option>';const status=$('financeLotStatus');if(status)status.textContent='Primero registra un lote en el módulo Lotes.';}
  }
  function importSelectedLot(){
    const id=$('financeLotSelect')?.value;const status=$('financeLotStatus');
    const lot=getSharedLots().find(l=>String(l.id)===String(id));
    if(!lot){if(status)status.textContent='Selecciona un lote válido.';return;}
    if(lot.initialN>0)$('fn').value=lot.initialN;
    if(lot.initialWeight>0)$('fw0').value=lot.initialWeight;
    if(lot.weightG>0)$('fw1').value=lot.weightG;
    if(Number.isFinite(Number(lot.survivalPct)))$('fs').value=Number(lot.survivalPct).toFixed(1);
    if(lot.fcr!==null&&lot.fcr!==undefined&&Number(lot.fcr)>0)$('ffcr').value=Number(lot.fcr).toFixed(2);
    saveInputs();calculate();
    if(status)status.textContent='Datos de '+(lot.code||lot.id)+' copiados. Revisa los campos y confirma que el FCR corresponda al periodo económico que deseas evaluar.';
  }
  window.updateFinanceLotOptions=updateFinanceLotOptions;
  function saveInputs(){
    set({n:n('fn'),w0:n('fw0'),w1:n('fw1'),s:n('fs'),fcr:n('ffcr'),price:n('fprice'),feed:n('ffeed'),seed:n('fseed'),labor:n('flabor'),energy:n('fenergy'),transport:n('ftransport'),health:n('fhealth'),maint:n('fmaint'),other:n('fother'),invest:n('finvest')});
  }
  function calculate(){
    saveInputs();
    const N=n('fn'),W0=n('fw0'),W1=n('fw1'),S=n('fs')/100,FCR=n('ffcr'),price=n('fprice'),feedPrice=n('ffeed');
    const seed=n('fseed'),labor=n('flabor'),energy=n('fenergy'),transport=n('ftransport'),health=n('fhealth'),maint=n('fmaint'),other=n('fother'),invest=n('finvest');
    const harvestFish=N*S;
    const initialBio=N*W0/1000;
    const finalBio=harvestFish*W1/1000;
    const gain=Math.max(0,finalBio-initialBio);
    const feedKg=gain*FCR;
    const feedCost=feedKg*feedPrice;
    const operating=feedCost+seed+labor+energy+transport+health+maint+other;
    const revenue=finalBio*price;
    const profit=revenue-operating;
    const breakEven=finalBio>0?operating/finalBio:0;
    const breakEvenWithInvest=finalBio>0?(operating+invest)/finalBio:0;
    const roi=invest>0?(profit/invest)*100:null;
    const result=$('financeResult'); if(!result)return;
    const positive=profit>=0;
    result.innerHTML=`
      <div class="card"><div class="label">Resultado estimado</div><div class="finance-grid">
        <div class="card finance-stat"><div class="icon">🐟</div><b>${finalBio.toFixed(2)} kg</b><span>Biomasa cosechada</span></div>
        <div class="card finance-stat"><div class="icon">🌾</div><b>${feedKg.toFixed(2)} kg</b><span>Alimento estimado</span></div>
        <div class="card finance-stat"><div class="icon">💰</div><b>${money(revenue)}</b><span>Ingreso bruto</span></div>
        <div class="card finance-stat"><div class="icon">📉</div><b>${money(operating)}</b><span>Costo del ciclo</span></div>
      </div></div>
      <div class="card ${positive?'finance-profit':'finance-loss'}"><div class="finance-row"><span>${positive?'Utilidad estimada':'Pérdida estimada'}</span><b>${money(profit)}</b></div></div>
      <div class="card"><div class="label">Indicadores</div>
        <div class="finance-results">
          <div class="finance-row"><span>Ganancia de biomasa</span><b>${gain.toFixed(2)} kg</b></div>
          <div class="finance-row"><span>Precio de equilibrio (sin inversión)</span><b>${money(breakEven)}/kg</b></div>
          <div class="finance-row"><span>Precio para cubrir ciclo + inversión</span><b>${money(breakEvenWithInvest)}/kg</b></div>
          <div class="finance-row"><span>Margen sobre ventas</span><b>${revenue>0?pct((profit/revenue)*100):'—'}</b></div>
          <div class="finance-row"><span>ROI simple del ciclo*</span><b>${roi===null?'—':pct(roi)}</b></div>
        </div>
        <p class="finance-source-note">*ROI simple = utilidad del ciclo ÷ inversión inicial × 100. No reemplaza un flujo de caja completo, VAN o TIR.</p>
      </div>`;
  }
  window.renderFinance=render;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',render);else render();
})();
