/* Acceso compartido al alimento del almacén y a las entregas guardadas en los lotes. */
(function(){
 'use strict';
 const KEY='truchapp_almacen_kardex_v1',engine=window.TruchAppFeedingData;
 function inventory(){const raw=localStorage.getItem(KEY);if(!raw)return{items:[],movements:[]};let data;try{data=JSON.parse(raw);}catch(_){throw new Error('No se pudo leer el almacén. Conserva tu respaldo y revisa sus registros.');}if(!Array.isArray(data.items)||!Array.isArray(data.movements))throw new Error('El almacén tiene un formato no válido.');return data;}
 const lots=()=>window.TruchAppData?.getLots?.()||[];
 function snapshot(){const data=inventory(),all=lots();return{items:data.items,movements:engine.combinedMovements(data,all)};}
 function reports(){
  const all=lots(),stock=inventory(),movements=engine.combinedMovements(stock,all);
  const current=all.map(lot=>{
   const data=window.TruchAppLotDetailData.fromLot({...lot,n:lot.fish,w:lot.weightG,m:lot.mortalityTotal,discarded:lot.discardTotal,alimentoConsumido:lot.feedConsumedKg,l:lot.lengthCm,pelletCalibre:lot.pelletCalibreMm}),metrics=window.TruchAppLotDetailData.summary(data);
   return{id:lot.id,code:lot.code,stage:lot.stage,unit:lot.unit,...engine.costReport(data,metrics,movements)};
  });
  const archived=(stock.feedArchivedLots||[]).filter(r=>!current.some(l=>String(l.id)===String(r.id))).map(report=>{
   const rows=movements.filter(m=>m.source==='feeding'&&String(m.linkedLotId)===String(report.id)),cost=rows.reduce((n,m)=>n+m.qty*m.unitCost,0),p=report.period;
   if(!p)return{...report,cost};const periodCost=rows.filter(m=>m.date>p.start&&m.date<=p.end).reduce((n,m)=>n+m.qty*m.unitCost,0);
   return{...report,cost,period:{...p,cost:periodCost,costPerKgGain:p.ready?periodCost/p.gain:null}};
  });
  return[...current,...archived];
 }
 function preserveDeletedLot(id){const data=inventory(),all=lots(),lot=all.find(l=>String(l.id)===String(id));if(!lot)return;const rows=engine.feedMovements(lot);if(!rows.length)return;data.feedArchive=[...(data.feedArchive||[]).filter(m=>String(m.linkedLotId)!==String(id)),...rows];const report=reports().find(r=>String(r.id)===String(id));data.feedArchivedLots=[...(data.feedArchivedLots||[]).filter(r=>String(r.id)!==String(id)),{...report,archived:true,archivedAt:Date.now()}];const payload=JSON.stringify(data);localStorage.setItem(KEY,payload);if(localStorage.getItem(KEY)!==payload)throw new Error('No se pudo conservar el historial de alimento. El lote no se eliminó.');}
 function prepareDetail(current,next){const signature=d=>JSON.stringify(d.daily.map(r=>[r.date,r.feed,r.feedStock]));if(signature(current)===signature(next)||![...current.daily,...next.daily].some(r=>r.feedStock?.lines?.length))return next;return engine.prepareDetail(inventory(),lots(),current,next);}
 window.TruchAppFeeding={snapshot,reports,preserveDeletedLot,prepareDetail,validateInventory:next=>engine.assertStockChange(snapshot().movements,engine.combinedMovements(next,lots()))};
})();
