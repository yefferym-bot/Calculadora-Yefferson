/* Acceso compartido al alimento del almacén y a las entregas guardadas en los lotes. */
(function(){
 'use strict';
 const KEY='truchapp_almacen_kardex_v1',engine=window.TruchAppFeedingData;
 function inventory(){const raw=localStorage.getItem(KEY);if(!raw)return{items:[],movements:[]};let data;try{data=JSON.parse(raw);}catch(_){throw new Error('No se pudo leer el almacén. Conserva tu respaldo y revisa sus registros.');}if(!Array.isArray(data.items)||!Array.isArray(data.movements))throw new Error('El almacén tiene un formato no válido.');return data;}
 const lots=()=>window.TruchAppData?.getLots?.()||[];
 function snapshot(){const data=inventory(),all=lots();return{items:data.items,movements:engine.combinedMovements(data,all)};}
 function reports(){
  const all=lots(),stock=inventory(),movements=engine.combinedMovements(stock,all);
  const current=all.map(lot=>{
   const data=window.TruchAppLotDetailData.fromLot({...lot,n:lot.fish,w:lot.weightG,m:lot.mortalityTotal,discarded:lot.discardTotal,alimentoConsumido:lot.feedConsumedKg,l:lot.lengthCm,pelletCalibre:lot.pelletCalibreMm}),metrics=window.TruchAppLotDetailData.summary(data);
   return{id:lot.id,code:lot.code,stage:lot.stage,unit:lot.unit,...engine.costReport(data,metrics,movements)};
  });
  const archived=(stock.feedArchivedLots||[]).filter(r=>!current.some(l=>String(l.id)===String(r.id))).map(report=>{
   const rows=movements.filter(m=>m.source==='feeding'&&String(m.linkedLotId)===String(report.id)),cost=rows.reduce((n,m)=>n+m.qty*m.unitCost,0)+(report.allocatedConsumedCost||0),p=report.period;
   if(!p)return{...report,cost};const periodCost=rows.filter(m=>m.date>p.start&&m.date<=p.end).reduce((n,m)=>n+m.qty*m.unitCost,0)+(report.periodAllocatedCost||0);
   return{...report,cost,period:{...p,cost:periodCost,costPerKgGain:p.ready?periodCost/p.gain:null}};
  });
  return[...current,...archived];
 }
 function preserveDeletedLot(id){const data=inventory(),all=lots(),lot=all.find(l=>String(l.id)===String(id));if(!lot)return;const rows=engine.feedMovements(lot);if(!rows.length)return;data.feedArchive=[...(data.feedArchive||[]).filter(m=>String(m.linkedLotId)!==String(id)),...rows];const report=reports().find(r=>String(r.id)===String(id));data.feedArchivedLots=[...(data.feedArchivedLots||[]).filter(r=>String(r.id)!==String(id)),{...report,archived:true,archivedAt:Date.now()}];const payload=JSON.stringify(data);localStorage.setItem(KEY,payload);if(localStorage.getItem(KEY)!==payload)throw new Error('No se pudo conservar el historial de alimento. El lote no se eliminó.');}
 function prepareDetail(current,next){
  const data=JSON.parse(JSON.stringify(next)),stock=inventory(),all=lots(),id=String(data.lot.id),old=new Map((current.feedAllocations||[]).map(a=>[a.id,a]));
  const chosen=[];for(const request of (data.feedAllocations||[]).slice().sort((a,b)=>(a.date+'T'+a.time).localeCompare(b.date+'T'+b.time))){const previous=old.get(request.id);if(previous){if(JSON.stringify(previous)!==JSON.stringify(request))throw Error('Una asignación conserva su costo original. Retira la asignación sin consumir y crea otra para corregirla.');chosen.push(request);}else{const version={...data,feedAllocations:chosen},working=all.map(l=>String(l.id)===id?{...l,detailState:version}:l);chosen.push(engine.quoteAllocation(stock,engine.combinedMovements(stock,working),data.lot,request));}}
  if(data.feedAllocations!==undefined)data.feedAllocations=chosen;
  engine.validateAllocations(data);
  const signature=d=>JSON.stringify([d.daily.map(r=>[r.date,engine.linkedFeed(r),r.feedStock]),d.feedAllocations||[]]);
  if(signature(current)===signature(data)||![...current.daily,...data.daily].some(r=>r.feedStock?.lines?.length)&&!(current.feedAllocations?.length||data.feedAllocations?.length))return data;
  return engine.prepareDetail(stock,all,current,data);
 }
 function validateInventory(next){const before=snapshot().movements,after=engine.combinedMovements(next,lots());engine.assertStockChange(before,after);const assigned=new Set(after.filter(m=>m.source==='lot-allocation').map(m=>m.itemId));for(const id of assigned)if(engine.batchBalances(after,id).some(b=>b.value<-engine.EPS))throw Error('La corrección dejaría sin respaldo el costo de los sacos asignados. Revisa la compra o retira primero las asignaciones sin consumir.');}

 window.TruchAppFeeding={snapshot,reports,preserveDeletedLot,prepareDetail,validateInventory};
})();
