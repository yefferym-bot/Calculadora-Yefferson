/* Entregas de alimento: el registro diario es la fuente de la salida y de su costo. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TruchAppFeedingData=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const EPS=1e-6,copy=v=>JSON.parse(JSON.stringify(v)),finite=v=>typeof v==='number'&&Number.isFinite(v),round=v=>Math.round(v*1e9)/1e9;
 const incoming=m=>['entrada','devolucion','ajuste+'].includes(m.type);
 const key=m=>String(m.itemId)+'\u0000'+String(m.batch||'SIN-LOTE').trim();
 const detail=lot=>lot.detailState||lot;
 function unitKg(item){if(item.unit==='kg')return 1;if(item.unit==='g')return .001;if(item.unit==='saco'&&finite(item.kgPerUnit)&&item.kgPerUnit>0)return item.kgPerUnit;return null;}
 function feedItem(item){return item.category==='Alimento balanceado'&&unitKg(item)!==null;}
 function ordered(rows){return rows.slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))||Number(incoming(b))-Number(incoming(a))||(Number(a.createdAt)||0)-(Number(b.createdAt)||0)||String(a.id).localeCompare(String(b.id)));}
 function feedMovements(lot){
  const data=detail(lot),id=String(data.lot?.id||lot.id),code=String(data.lot?.code||lot.code||id),rows=[];
  for(const day of data.daily||[])for(const line of day.feedStock?.lines||[]){
   if(!finite(line.kg)||line.kg<=0||!finite(line.kgPerUnit)||line.kgPerUnit<=0||!finite(line.unitCost)||line.unitCost<0)throw new Error('Una entrega de alimento tiene datos de valoración incompletos.');
   rows.push({id:'feed:'+id+':'+day.date+':'+line.id,source:'feeding',linkedLotId:id,linkedLot:code,recordDate:day.date,itemId:line.itemId,itemName:line.itemName,itemCode:line.itemCode,stockUnit:line.unit,type:'salida',date:day.date,time:day.time,qty:line.kg/line.kgPerUnit,feedKg:line.kg,batch:line.batch,expiry:line.expiry||'',unitCost:line.unitCost,createdAt:line.issuedAt||0,doc:'Alimentación · '+code,destination:code,notes:'Entrega vinculada al registro diario. Se corrige desde el lote.'});
  }
  return rows;
 }
 function combinedMovements(inventory,lots){
  const ids=new Set(lots.map(l=>String(l.id||detail(l).lot.id))),pools=new Map();
  const rows=[...(inventory.movements||[]),...(inventory.feedArchive||[]).filter(m=>!ids.has(String(m.linkedLotId))),...lots.flatMap(feedMovements)];
  // Promedio móvil por lote de alimento. Una corrección anterior revalora las salidas posteriores sin duplicarlas.
  return ordered(rows).map(original=>{
   const k=key(original);if(!pools.has(k))pools.set(k,{qty:0,value:0});const pool=pools.get(k),qty=Number(original.qty)||0,avg=pool.qty>EPS?pool.value/pool.qty:0;
   const m=original.source==='feeding'&&pool.qty>EPS&&avg>=0?{...original,unitCost:avg}:original;
   if(incoming(m)){pool.qty+=qty;pool.value+=qty*(Number(m.unitCost)||0);}
   else{pool.value-=m.source==='feeding'?qty*m.unitCost:Math.min(qty,Math.max(0,pool.qty))*avg;pool.qty-=qty;}
   if(Math.abs(pool.qty)<EPS)pool.qty=0;if(Math.abs(pool.value)<EPS)pool.value=0;return m;
  });
 }
 function batchBalances(rows,itemId,through='9999-12-31'){
  const batches=new Map();
  for(const m of ordered(rows.filter(m=>m.itemId===itemId&&m.date<=through))){
   const batch=String(m.batch||'SIN-LOTE').trim(),qty=Number(m.qty)||0;
   if(!batches.has(batch))batches.set(batch,{batch,qty:0,value:0,expiry:'',firstDate:m.date,lastDate:m.date});
   const b=batches.get(batch);
   if(incoming(m)){b.qty+=qty;b.value+=qty*(Number(m.unitCost)||0);if(m.expiry&&(!b.expiry||m.expiry<b.expiry))b.expiry=m.expiry;}
   else{const taken=Math.min(qty,Math.max(0,b.qty)),avg=b.qty>EPS?b.value/b.qty:0;b.qty-=qty;b.value-=m.source==='feeding'?qty*m.unitCost:taken*avg;}
   if(Math.abs(b.qty)<EPS)b.qty=0;if(Math.abs(b.value)<EPS)b.value=0;b.lastDate=m.date;
  }
  return[...batches.values()].map(b=>({...b,cost:b.qty>EPS?b.value/b.qty:0}));
 }
 function assertStockChange(before,after){
  // Se comparan cierres diarios: los movimientos antiguos incompletos no bloquean correcciones que los mejoren.
  const totals=rows=>{const map=new Map();for(const m of rows){const k=key(m);if(!map.has(k))map.set(k,new Map());const by=map.get(k);by.set(m.date,(by.get(m.date)||0)+(incoming(m)?1:-1)*(Number(m.qty)||0));}return map;};
  const old=totals(before),next=totals(after);
  for(const [k,by]of next){const dates=[...new Set([...by.keys(),...(old.get(k)?.keys()||[])])].sort();let a=0,b=0;for(const date of dates){a+=old.get(k)?.get(date)||0;b+=by.get(date)||0;if(b<Math.min(0,a)-EPS)throw new Error('Stock insuficiente en el lote de alimento para la fecha '+date+'. Revisa la cantidad y las entradas del almacén.');}}
 }
 function quoteDay(inventory,movements,lotId,record,previous=null){
  if(!record.feedStock)return copy(record);
  const result=copy(record),raw=result.feedStock;
  if(raw.version!==1||!Array.isArray(raw.lines)||raw.lines.length>30)throw new Error('Revisa las líneas de alimento del día.');
  const rows=movements.filter(m=>!(m.source==='feeding'&&m.linkedLotId===String(lotId)&&m.recordDate===record.date)),ids=new Set(),lines=[];
  for(const requested of raw.lines){
   const item=inventory.items.find(i=>i.id===requested.itemId),old=previous?.feedStock?.lines?.find(l=>l.id===requested.id&&l.itemId===requested.itemId&&l.batch===requested.batch);
   if(!requested.id||ids.has(requested.id)||!finite(requested.kg)||requested.kg<=0)throw new Error('Cada línea debe tener una cantidad de alimento mayor que cero.');ids.add(requested.id);
   if(!item||!feedItem(item)||item.active===false&&!old)throw new Error('Selecciona un alimento en kg, g o sacos con su contenido en kg definido en Almacén.');
   const factor=unitKg(item);if(old&&(old.kgPerUnit!==factor||old.unit!==item.unit))throw new Error('Cambió la unidad del producto. Revisa su ficha en Almacén.');
   const balance=batchBalances(rows,item.id,record.date).find(b=>b.batch===requested.batch);
   if(!balance||requested.kg/factor>balance.qty+EPS)throw new Error('Stock insuficiente de '+item.name+' · '+String(requested.batch||'sin lote')+' para '+record.date+'.');
   if(balance.expiry&&balance.expiry<record.date)throw new Error('El lote de alimento estaba vencido en la fecha de entrega.');
   const price=balance.cost;if(!finite(price)||price<0)throw new Error('Revisa el costo registrado para ese lote de alimento.');
   const line={id:String(requested.id),itemId:item.id,itemName:old?.itemName||item.name,itemCode:old?.itemCode||item.code||'',unit:item.unit,kgPerUnit:factor,batch:balance.batch,expiry:balance.expiry,kg:round(requested.kg),unitCost:price,issuedAt:old?.issuedAt||Date.now()};lines.push(line);
   rows.push(...feedMovements({lot:{id:String(lotId),code:''},daily:[{...result,feedStock:{version:1,lines:[line]}}]}));
  }
  const total=lines.reduce((sum,l)=>sum+l.kg,0);
  if(!finite(record.feed)&&lines.length||finite(record.feed)&&Math.abs(total-record.feed)>EPS)throw new Error('El total del día debe coincidir con las líneas de alimento seleccionadas.');
  result.feedStock={version:1,lines};return result;
 }
 function prepareDetail(inventory,lots,current,next){
  const data=copy(next),id=String(next.lot.id),before=combinedMovements(inventory,lots),working=copy(current);
  // Primero se valora cada línea; la comprobación final incluye las entregas de los demás lotes y las fechas posteriores.
  const replacement=()=>lots.map(l=>String(l.id||detail(l).lot.id)===id?{...l,detailState:working}:l);
  working.daily=current.daily.filter(old=>data.daily.some(r=>r.date===old.date&&r.feed===old.feed&&JSON.stringify(r.feedStock)===JSON.stringify(old.feedStock)));
  data.daily=data.daily.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(r=>{
   const old=current.daily.find(v=>v.date===r.date);
   const quoted=JSON.stringify(r.feedStock)===JSON.stringify(old?.feedStock)&&r.feed===old?.feed?r:quoteDay(inventory,combinedMovements(inventory,replacement()),id,r,old);
   working.daily=working.daily.filter(d=>d.date!==r.date);working.daily.push(quoted);return quoted;
  });
  assertStockChange(before,combinedMovements(inventory,replacement()));return data;
 }
 function costReport(data,metrics={},movements=null){
  const prices=new Map((movements||[]).map(m=>[m.id,m])),id=String(data.lot?.id||'');
  const costOf=r=>(r.feedStock?.lines||[]).reduce((n,l)=>{const m=prices.get('feed:'+id+':'+r.date+':'+l.id);return n+(m?m.qty*m.unitCost:l.kg*l.unitCost/l.kgPerUnit);},0);
  const days=data.daily||[],legacy=[...(data.samples||[]).filter(s=>s.legacyPeriod),...(data.openingBalance?[data.openingBalance]:[])];
  const known=[...legacy,...days].filter(r=>finite(r.feed)),recordedKg=known.reduce((n,r)=>n+r.feed,0),lines=days.flatMap(r=>r.feedStock?.lines||[]),linkedKg=lines.reduce((n,l)=>n+l.kg,0),cost=days.reduce((n,r)=>n+costOf(r),0),unpricedKg=Math.max(0,recordedKg-linkedKg);
  const p=metrics.period||metrics.periods?.at(-1),periodDays=p?days.filter(r=>r.date>p.previous.date&&r.date<=p.last.date):[];
  const periodCost=periodDays.reduce((n,r)=>n+costOf(r),0),periodLinked=periodDays.flatMap(r=>r.feedStock?.lines||[]).reduce((n,l)=>n+l.kg,0);
  let reason='Añade dos biometrías para comparar alimento y aumento neto de biomasa.';
  if(p){if(p.legacy)reason='El período conserva consumos antiguos sin valoración vinculada.';else if(!p.complete)reason='Completa alimento y bajas de todos los días entre las dos biometrías.';else if(p.gain<=0)reason='El período no tiene aumento neto positivo de biomasa.';else if(Math.abs(periodLinked-p.feed)>EPS)reason='Hay alimento del período sin producto y costo vinculados.';else reason='Costo de alimento del período dividido entre su aumento neto de biomasa estimada.';}
  const periodReady=!!p&&!p.legacy&&p.complete&&p.gain>0&&Math.abs(periodLinked-p.feed)<=EPS;
  return{recordedKg,linkedKg,cost,unpricedKg,hasRecords:known.length>0,priced:unpricedKg<EPS,period:p?{start:p.previous.date,end:p.last.date,gain:p.gain,feed:p.feed,cost:periodCost,ready:periodReady,costPerKgGain:periodReady?periodCost/p.gain:null,reason}:null,reason};
 }
 return{EPS,unitKg,feedItem,ordered,feedMovements,combinedMovements,batchBalances,assertStockChange,quoteDay,prepareDetail,costReport};
});
