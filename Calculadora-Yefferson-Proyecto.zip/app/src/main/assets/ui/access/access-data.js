/* Modo local de presentación. Una invitación guardada no concede membresía. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TruchAppAccessData=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const KEY='truchapp_access_mode_v1';
 const text=(v,max)=>typeof v==='string'?v.trim().slice(0,max):'';
 function normalize(value){
  const legacy=value===null||value===undefined;
  return{schema:1,mode:legacy||value?.schema===1&&value.mode==='admin'?'admin':'collaborator',collaborator:{name:text(value?.collaborator?.name,40),invitationCode:text(value?.collaborator?.invitationCode,120),linkState:'pending',welcomeSeen:value?.collaborator?.welcomeSeen===true}};
 }
 function read(storage){try{const raw=storage.getItem(KEY);return normalize(raw===null?null:JSON.parse(raw));}catch(_){return normalize({});}}
 function selection(mode,name,invitationCode,previous){
  if(!['admin','collaborator'].includes(mode))throw Error('Elige Administrador o Colaborador.');
  const next=normalize(previous);next.mode=mode;
  if(mode==='collaborator'){
   if(typeof name!=='string'||!name.trim()||name.trim().length>40)throw Error('Escribe tu nombre, de hasta 40 caracteres.');
   if(typeof invitationCode!=='string'||invitationCode.trim().length>120)throw Error('Usa un código de hasta 120 caracteres.');
   next.collaborator={name:name.trim(),invitationCode:invitationCode.trim(),linkState:'pending',welcomeSeen:next.collaborator.welcomeSeen};
  }
  return next;
 }
 return{KEY,normalize,read,selection};
});
