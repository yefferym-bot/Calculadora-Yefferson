/* Shared lot workspace. Native Android is authoritative for trust, assignments and queued writes. */
(function(){
 'use strict';
 const rows=new Map(),pending=new Map(),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),key=(owner,id)=>owner+':'+id;
 let active=null,busy=false,updated=0,lastStamp='',refreshing=false,listError='';
 // UI correlation IDs only; native Android generates pairing secrets and operation receipts.
 const uuid=()=>{const c=window.crypto;if(c?.randomUUID)return c.randomUUID();if(c?.getRandomValues){const b=c.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const h=Array.from(b,n=>n.toString(16).padStart(2,'0')).join('');return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);}return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,k=>{const n=Math.floor(Math.random()*16);return(k==='x'?n:(n&3)|8).toString(16);});};

 const api=(command,input)=>window.TruchAppLocalPair.data(command,input),event=()=>window.dispatchEvent(new Event('truchapp-shared-updated'));
 const assigned=()=>window.TruchAppLocalPair?.assigned()||[];
 const allowed=(owner,id)=>assigned().find(l=>l.owner===owner&&l.id===id);
 const num=(n,d=2)=>typeof n==='number'&&Number.isFinite(n)?n.toLocaleString('es-PE',{maximumFractionDigits:d}):'—';
 function cards(lots){
  const values=lots.map(l=>({...l,...rows.get(key(l.owner,l.id)),owner:l.owner,permission:l.permission})),fish=values.reduce((n,l)=>n+(Number(l.n)||0),0),biomass=values.reduce((n,l)=>n+(Number(l.n)||0)*(Number(l.w)||0)/1000,0);
  return '<section class="co-lots">'+(listError?'<p class="co-shared-error" role="alert">'+esc(listError)+'</p>':'')+'<div class="co-section-title"><h2>Mis lotes</h2><span class="co-tag">'+lots.length+(lots.length===1?' asignado':' asignados')+'</span></div><div class="co-shared-overview"><div><strong>'+lots.length+'</strong><span>Lotes asignados</span></div><div><strong>'+num(fish,0)+'</strong><span>Peces en existencia</span></div><div><strong>'+num(biomass,1)+' kg</strong><span>Biomasa</span></div></div><div class="co-shared-tools"><button type="button" data-shared-refresh>↻ Actualizar datos</button><small>'+(updated?'Última consulta '+new Date(updated).toLocaleTimeString('es-PE',{hour:'2-digit',minute:'2-digit'}):'Conecta para recibir los datos del administrador')+'</small></div>'+values.map(l=>{
   const cache=rows.get(key(l.owner,l.id)),queue=pending.get(key(l.owner,l.id))||[],n=Number(l.n),w=Number(l.w),survival=l.initialN>0?n/l.initialN*100:null,progress=w>0&&l.targetWeight>0?Math.min(100,w/l.targetWeight*100):0;
   let metrics=null;if(cache?.detail)try{metrics=window.TruchAppListCards.metrics(cache.detail);}catch(_){}
   const raw={fish:l.n,consumed:l.alimentoConsumido,feed:l.todayFeed,survival,growth:l.w,length:l.l,biomass:Number.isFinite(n)&&Number.isFinite(w)?n*w/1000:null,condition:l.l>0&&w>=0?100*w/(l.l**3):null,fcr:l.fcr},selection=window.TruchAppListCards.selection(l),writable=l.permission==='record',error=queue.find(q=>q.error)?.error;
   return '<article class="co-card co-assigned-lot co-shared-lot"><div class="co-shared-title"><div><h3>'+esc(l.code||'Lote')+'</h3><p>'+esc([l.stage,l.date?'ingreso '+l.date:'',l.unit,l.origin].filter(Boolean).join(' · '))+'</p></div><span class="co-tag">'+(writable?'Registro completo':'Solo consulta')+'</span></div><div class="co-lot-metrics">'+selection.map(id=>{const c=window.TruchAppListCards.byId[id],value=metrics?.[id]?.value??(num(raw[id],c.digits)+(c.unit?(c.unit==='%'?'':' ')+c.unit:''));return'<div><strong>'+esc(value)+'</strong><span>'+esc(c.short)+'</span></div>';}).join('')+'</div><progress max="100" value="'+progress+'" aria-label="Progreso del peso objetivo"></progress><div class="co-lot-foot"><span>Progreso hacia '+esc(l.targetWeight??'—')+' g: '+num(progress,1)+'%</span><span>Mortalidad: '+esc(l.m??'—')+' · Descarte: '+esc(l.discarded??'—')+'</span></div><p class="co-shared-state '+(error?'co-shared-error':'')+'">'+esc(error||queue.length+' registro'+(queue.length===1?'':'s')+' pendiente'+(queue.length===1?'':'s')+' de envío'+(!queue.length?' · '+(window.TruchAppLocalPair.connected(l.owner)?'Administrador conectado':'Copia local · sin conexión'):''))+'</p><div class="co-shared-actions"><button type="button" data-shared-open="'+esc(l.id)+'" data-owner="'+esc(l.owner)+'">Ver / actualizar lote</button><button type="button" data-shared-register="'+esc(l.id)+'" data-owner="'+esc(l.owner)+'" '+(!writable?'disabled':'')+'>Registrar datos</button></div>'+(error?'<div class="co-draft-actions"><button type="button" data-shared-current="'+esc(l.id)+'" data-owner="'+esc(l.owner)+'">Cargar versión actual</button><button type="button" data-shared-archived="'+esc(l.id)+'" data-owner="'+esc(l.owner)+'">Ver borrador anterior</button></div>':'')+'</article>';
  }).join('')+'</section>';
 }
 async function refresh(){
  if(refreshing||document.hidden||window.TruchAppAccess?.read().mode!=='collaborator'||!window.TruchAppLocalPair?.hasAdminLink())return;refreshing=true;
  try{for(const peer of window.TruchAppLocalPair.activePeers()){
   const value=await api('shared-list',{owner:peer.fingerprint});for(const row of value?.lots||[]){const k=key(peer.fingerprint,row.id),old=rows.get(k)||{};const hasLocal=(value?.status?.pending||[]).some(job=>job.lotId===row.id);const next=hasLocal?{...row,...old}:{...old,...row};if(!hasLocal&&['n','w','m','discarded','alimentoConsumido'].some(field=>old[field]!==undefined&&old[field]!==row[field]))delete next.detail;rows.set(k,next);}
   for(const k of [...pending.keys()])if(k.startsWith(peer.fingerprint+':'))pending.delete(k);
   for(const job of value?.status?.pending||[]){const k=key(peer.fingerprint,job.lotId);if(!pending.has(k))pending.set(k,[]);pending.get(k).push(job);}updated=value?.updated||updated;
  }listError='';event();}catch(error){listError=error.message||'No se pudo actualizar. Se conserva la copia local.';event();}finally{refreshing=false;}
 }
 function viewport(){if(!active)return;const top=document.querySelector('.co-top')?.getBoundingClientRect().bottom||0,bottom=document.querySelector('.co-nav')?.getBoundingClientRect().top||innerHeight;active.overlay.style.setProperty('--co-shared-bar-height',(active.overlay.querySelector('.co-shared-detail-bar')?.getBoundingClientRect().height||54)+'px');active.overlay.style.top=top+'px';active.overlay.style.height=Math.max(0,bottom-top)+'px';}
 function note(text){if(active)active.note.textContent=text;}
 function clearLoadTimers(a){for(const name of ['timeout','readyTimer','renderTimer'])clearTimeout(a[name]);}
 function loadingText(a,text){if(active!==a)return;note(text);a.loadingMessage.textContent=text;viewport();}
 function loadFailed(a,text){if(active!==a||a.failed)return;a.failed=true;clearLoadTimers(a);a.frame.inert=true;a.frame.style.visibility='hidden';a.frame.setAttribute('aria-hidden','true');a.loadingPane.hidden=false;a.loadingPane.classList.add('is-error');a.loadingTitle.textContent='No se pudo abrir el formulario';loadingText(a,text||'Vuelve a intentarlo para cargar la ficha.');a.retry.hidden=false;a.frame.contentWindow?.postMessage({type:'truchapp-detail-suspend',session:a.token},'*');}
 function close(){if(!active)return true;if(busy)return false;active.frame.contentWindow?.postMessage({type:'truchapp-detail-suspend',session:active.token},'*');clearLoadTimers(active);active.overlay.remove();active=null;return true;}
 function boot(){
  if(!active?.ready||!active.cache||active.sent||active.failed)return;const a=active,permission=allowed(a.owner,a.id);if(!permission){close();return;}
  try{
   if(!a.cache.document?.lot||!Array.isArray(a.cache.document.water))throw Error('La ficha recibida no es válida. Actualízala desde el administrador y reintenta.');
   a.state=window.TruchAppLotDetailData.fromLot(a.cache.document.lot,a.cache.document.water);a.sent=true;loadingText(a,'Preparando el formulario…');
   a.renderTimer=setTimeout(()=>loadFailed(a,'No se pudo preparar el formulario. Pulsa Reintentar.'),18000);
   a.frame.contentWindow.postMessage({type:'truchapp-detail-boot',session:a.token,state:a.state,revision:a.revision,feeding:{items:[],movements:[],error:'Las salidas de almacén se gestionan desde el administrador.'},shared:{readOnly:permission.permission!=='record'||a.archived}},'*');
  }catch(error){loadFailed(a,error.message||'No se pudo preparar esta ficha.');}
 }

 async function open(owner,id,action=null,options={}){
  if(!close()||!allowed(owner,id))return;const overlay=document.createElement('section');overlay.className='co-shared-detail';overlay.setAttribute('aria-label','Ficha completa del lote compartido');
  const status=document.createElement('div');status.className='co-shared-detail-bar';const back=document.createElement('button');back.type='button';back.textContent='← Mis lotes';back.onclick=close;const info=document.createElement('span');info.setAttribute('role','status');info.textContent='Recibiendo ficha del lote…';status.append(back,info);if(!options.archived){const draft=document.createElement('button');draft.type='button';draft.textContent='Borrador anterior';draft.onclick=()=>open(owner,id,null,{archived:true});status.append(draft);}
  const frame=document.createElement('iframe');frame.title='Ficha completa del lote';frame.style.visibility='hidden';frame.inert=true;frame.setAttribute('aria-hidden','true');
  const pane=document.createElement('div');pane.className='co-shared-loading';pane.innerHTML='<span class="co-shared-loading-spinner" aria-hidden="true"></span><h2>Cargando formulario</h2><p role="status">Recibiendo ficha del lote…</p><button type="button" hidden>Reintentar</button>';
  overlay.append(status,frame,pane);
  const a={owner,id,overlay,frame,note:info,token:'shared-'+uuid(),revision:0,ready:false,cache:null,sent:false,action,archived:!!options.archived,loadingPane:pane,loadingTitle:pane.querySelector('h2'),loadingMessage:pane.querySelector('p'),retry:pane.querySelector('button'),failed:false};active=a;
  a.retry.addEventListener('click',()=>{if(active===a)open(owner,id,a.action,{archived:options.archived});});
  frame.addEventListener('error',()=>loadFailed(a,'No se pudo cargar el formulario. Pulsa Reintentar.'));
  frame.addEventListener('load',()=>{if(active===a&&!a.failed)frame.contentWindow?.postMessage({type:'truchapp-detail-hello'},'*');});
  document.querySelector('#collaboratorApp .co-app').append(overlay);viewport();
  a.readyTimer=setTimeout(()=>loadFailed(a,'El formulario no respondió. Pulsa Reintentar para volver a cargarlo.'),18000);
  a.timeout=setTimeout(()=>loadFailed(a,'No se recibió la ficha a tiempo. Comprueba la conexión con el administrador y reintenta.'),120000);
  frame.src='ui/lotes/detail/index.html';
  try{a.cache=options.cache||await api(options.archived?'shared-draft':'shared-read',{owner,lotId:id});if(active!==a||a.failed)return;if(!a.cache||typeof a.cache!=='object')throw Error('La ficha recibida no es válida. Actualízala desde el administrador y reintenta.');clearTimeout(a.timeout);loadingText(a,a.ready?'Preparando el formulario…':'Abriendo el formulario…');boot();}catch(error){loadFailed(a,error.message);}
 }

 function displayCache(a){const queue=a.cache.status?.pending||[],error=queue.find(q=>q.lotId===a.id&&q.error)?.error;note(error||(a.archived?'Borrador conservado · solo consulta':a.cache.pending?'Guardado en este teléfono · pendiente de envío al administrador':a.cache.offline?'Copia local · conecta para actualizar':'Datos recibidos del administrador'));}
 function waterDocument(data,previous){
  const byId=new Map();for(const row of data.water){const id=String(row.sourceReadingId||row.id);let r=byId.get(id);if(!r){const old=previous.find(x=>String(x.id)===id);r=old?JSON.parse(JSON.stringify(old)):{id,date:row.date,time:row.time,point:row.point,lotId:data.lot.id,lotCode:data.lot.code,site:'',farmId:'',farmName:'',params:{},custom:null,note:row.note||''};r.params={};byId.set(id,r);}r.lotId=data.lot.id;r.lotCode=data.lot.code;r.date=row.date;r.time=row.time;r.point=row.point;r.note=row.note||'';if(row.customEntry)r.custom=JSON.parse(JSON.stringify(row.customEntry));else r.params[row.param]={value:row.value,unit:row.unit};}return [...byId.values()];
 }
 async function save(a,data){
  const permission=allowed(a.owner,a.id);if(!permission||permission.permission!=='record'||a.archived)throw Error('No tienes acceso de registro completo a este lote.');
  const engine=window.TruchAppLotDetailData,old=a.cache.document.lot;engine.validate(data,old);const document={lot:engine.toLot(old,data),water:waterDocument(data,a.cache.document.water)},request={lotId:a.id,baseHash:a.cache.hash,document};
  const text=JSON.stringify(request),ticket=uuid(),base={owner:a.owner,lotId:a.id,ticket};
  await api('shared-begin',{...base,operation:uuid(),length:text.length});
  for(let offset=0;offset<text.length;){let end=Math.min(offset+8000,text.length);if(end<text.length&&/[\uD800-\uDBFF]/.test(text[end-1]))end--;const result=await api('shared-chunk',{...base,offset,text:text.slice(offset,end)});if(result.offset!==end)throw Error('No se confirmó el fragmento del registro.');offset=end;}
  a.cache=await api('shared-save',base);a.state=engine.fromLot(a.cache.document.lot,a.cache.document.water);rows.set(key(a.owner,a.id),{...a.cache.document.lot,detail:a.state});displayCache(a);refresh();return a.state;
 }
 window.addEventListener('message',async e=>{
  const a=active;if(!a||e.source!==a.frame.contentWindow)return;const m=e.data;if(!m||typeof m!=='object')return;
  if(a.failed)return;if(m.type==='truchapp-detail-ready'){a.ready=true;clearTimeout(a.readyTimer);boot();return;}if(m.session!==a.token)return;
  if(m.type==='truchapp-detail-load-failed'){loadFailed(a,'No se pudo preparar esta ficha. Reintenta o actualiza sus datos desde el administrador.');return;}
  if(m.type==='truchapp-detail-rendered'){clearLoadTimers(a);a.frame.inert=false;a.frame.style.removeProperty('visibility');a.frame.removeAttribute('aria-hidden');a.loadingPane.hidden=true;a.frame.dataset.rendered='true';rows.set(key(a.owner,a.id),{...a.cache.document.lot,detail:a.state});displayCache(a);if(a.action){a.frame.contentWindow.postMessage({type:'truchapp-detail-action',session:a.token,action:a.action},'*');a.action=null;}return;}
  if(m.type==='truchapp-detail-close'){close();event();return;}if(m.type==='truchapp-detail-open-stock'){note('El almacén se gestiona desde el administrador.');return;}
  if(m.type==='truchapp-detail-save'&&!busy){busy=true;note('Guardando registro compartido…');try{if(m.baseRevision!==a.revision)throw Error('La ficha cambió; vuelve a abrir el lote.');const state=await save(a,m.state);a.revision++;a.frame.contentWindow.postMessage({type:'truchapp-detail-saved',session:a.token,request:m.request,revision:a.revision,state},'*');}catch(error){note(error.message);a.frame.contentWindow.postMessage({type:'truchapp-detail-failed',session:a.token,request:m.request,error:error.message},'*');}finally{busy=false;}}
 });
 document.addEventListener('click',async e=>{const b=e.target.closest('[data-shared-open],[data-shared-register],[data-shared-refresh],[data-shared-current],[data-shared-archived]');if(!b)return;
  if(b.hasAttribute('data-shared-refresh')){b.disabled=true;try{await refresh();}finally{if(b.isConnected)b.disabled=false;}return;}
  const owner=b.dataset.owner,id=b.dataset.sharedOpen||b.dataset.sharedRegister||b.dataset.sharedCurrent||b.dataset.sharedArchived;
  if(b.hasAttribute('data-shared-current')){if(!window.confirm('Se conservará el borrador anterior y se cargará la versión actual del administrador. ¿Continuar?'))return;try{const cache=await api('shared-archive',{owner,lotId:id});await open(owner,id,null,{cache});await refresh();}catch(error){window.alert(error.message);}return;}
  open(owner,id,b.hasAttribute('data-shared-register')?'daily':null,{archived:b.hasAttribute('data-shared-archived')});
 });
 window.addEventListener('resize',viewport);
 window.addEventListener('truchapp-local-pair-updated',()=>{if(active&&!allowed(active.owner,active.id)){note('El acceso a este lote fue retirado.');if(!busy)close();}refreshExternal();if(!refreshing&&Date.now()-updated>10000)refresh();});
 let externalBusy=false;
 async function refreshExternal(){const state=window.TruchAppLocalPair?.getState();if(!state?.dataStamp)return;if(!lastStamp){lastStamp=state.dataStamp;return;}if(lastStamp===state.dataStamp||state.mode!=='admin'||externalBusy||window.TruchAppStorage?.inTransaction)return;externalBusy=true;try{await window.TruchAppStorage.reload({external:true});lastStamp=state.dataStamp;window.renderLots?.();window.renderLotsForSharedViews?.();}catch(_){}finally{externalBusy=false;}}
 setInterval(()=>{refresh();refreshExternal();if(active&&!busy)api('shared-status',{owner:active.owner}).then(status=>{const jobs=status.pending.filter(j=>j.lotId===active.id);if(jobs.length)note(jobs.find(j=>j.error)?.error||jobs.length+' registros pendientes de envío');else if(active.cache.pending)note('El administrador recibió los registros.');}).catch(()=>{});},10000);
 window.TruchAppSharedLots={cards,open,close,refresh,isOpen:()=>!!active};setTimeout(()=>{refresh();event();},0);
})();
