/* Espacio del colaborador; la vinculación y el catálogo autorizado proceden de Android. */
(function(){
 'use strict';
 const data=window.TruchAppAccessData,$=id=>document.getElementById(id);
 const shapes={menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',person:'<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3H4Z"/>',group:'<circle cx="8" cy="7" r="3"/><circle cx="18" cy="8" r="3"/><path d="M1 21v-3a7 7 0 0 1 14 0v3H1Zm15 0h7v-3a6 6 0 0 0-5-6"/>',home:'<path d="m3 11 9-8 9 8v10h-6v-7H9v7H3V11Z"/>',fish:'<path d="M2 12s5-7 11-4c2 1 4 2 4 2l5-4v12l-5-4s-2 1-4 2C7 19 2 12 2 12Z"/><circle cx="8" cy="11" r=".7"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 2v6M17 2v6M3 10h18m5 6 3 3 5-6"/>',link:'<path d="m10 14 4-4M8 16l-2 2a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0m2 1 2-2a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0" transform="translate(1 -1)"/>',wifi:'<path d="M2 8a16 16 0 0 1 20 0M5 12a11 11 0 0 1 14 0m-10 4a5 5 0 0 1 6 0M12 20h.01"/>',globe:'<circle cx="12" cy="12" r="10"/><ellipse cx="12" cy="12" rx="4" ry="10"/><path d="M2 12h20M4 6h16M4 18h16"/>',shield:'<path d="m12 2 9 4v7c0 5-9 9-9 9s-9-4-9-9V6Z"/><circle cx="12" cy="9" r="3"/><path d="M7 18a5 5 0 0 1 10 0"/>',qr:'<path d="M3 3h6v6H3zm12 0h6v6h-6zM3 15h6v6H3zm12 0h3v3h-3zm3 3h3v3h-3zM15 21h.01M21 15h.01"/>',close:'<path d="m6 6 12 12M18 6 6 18"/>',info:'<circle cx="12" cy="12" r="10"/><path d="M12 11v6m0-10h.01"/>'};
 const icon=name=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(shapes[name]||shapes.info)+'</svg>';
 let host=null,tab='home',lastRaw;
 const safe=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const peers=()=>window.TruchAppLocalPair?.activePeers()||[];
 const read=()=>data.read(localStorage);
 function connectionCard(){return'<section class="co-card co-connections"><h2>Conexión del equipo</h2><div class="co-connection-grid"><button type="button" data-local-pair>'+icon('wifi')+'<span>Local<small>Vincular equipo</small></span></button><button type="button" disabled>'+icon('globe')+'<span>Por internet<small>Próximamente</small></span></button></div><p class="co-note">'+icon('info')+'La vinculación local se verifica en ambos teléfonos.</p></section>';}
 function lots(){
  const assigned=window.TruchAppLocalPair?.assigned()||[];
  if(assigned.length)return '<section class="co-lots"><div class="co-section-title"><h2>Mis lotes</h2><span class="co-tag">'+assigned.length+(assigned.length===1?' asignado':' asignados')+'</span></div>'+assigned.map(lot=>'<article class="co-card co-assigned-lot"><h3>'+safe(lot.code||'Lote')+'</h3><p>'+safe([lot.stage,lot.unit].filter(Boolean).join(' · '))+'</p><span class="co-tag">'+safe(lot.ownerName)+'</span><p>'+(lot.permission==='record'?'Consulta y registro autorizados':'Permiso de consulta')+'</p><button type="button" class="co-primary" disabled>Registro compartido · Próximamente</button></article>').join('')+'</section>';
  return'<section class="co-lots"><div class="co-section-title"><h2>Mis lotes</h2><span class="co-tag">0 asignados</span></div><div class="co-card co-empty">'+icon('fish')+'<h3>Sin lotes asignados</h3><p>Cuando vincules tu equipo, aquí aparecerán los lotes que te asigne tu administrador.</p><button type="button" class="co-primary" disabled>＋ Registrar datos</button></div></section>';}
 function tasks(){return'<section class="co-card co-empty">'+icon('calendar')+'<h2>Mis tareas</h2><p>Las tareas compartidas estarán disponibles en una próxima etapa.</p></section>';}
 function build(){
  if(host)return;
  host=document.createElement('section');host.id='collaboratorApp';host.setAttribute('aria-label','Espacio del colaborador');host.hidden=true;
  host.innerHTML='<div class="co-app"><header class="co-top"><button type="button" id="coMenu" aria-label="Menú del colaborador">'+icon('menu')+'</button><div class="co-brand"><img src="ui/intro/logo-truchapp.png" width="52" height="52" alt=""><span>TruchApp</span></div><button type="button" id="coProfile" aria-label="Mi equipo">'+icon('person')+'</button></header><main class="co-main" id="coMain" tabindex="-1"></main><nav class="co-nav" aria-label="Navegación del colaborador">'+[['home','Inicio','home'],['lots','Mis lotes','fish'],['tasks','Tareas','calendar'],['team','Equipo','group']].map(([id,label,shape])=>'<button type="button" data-co-tab="'+id+'">'+icon(shape)+'<span>'+label+'</span></button>').join('')+'</nav><dialog id="coMenuDialog" class="co-dialog" aria-labelledby="coMenuTitle"><button type="button" id="coMenuClose" class="co-close" aria-label="Cerrar menú">'+icon('close')+'</button><h2 id="coMenuTitle">Mi espacio</h2><button type="button" data-co-open-team>'+icon('group')+' Mi equipo</button><button type="button" data-local-pair>'+icon('wifi')+' Conexión local</button><button type="button" data-app-access>'+icon('shield')+' Modo de trabajo</button><button type="button" data-display-contrast>'+icon('globe')+'<span>Apariencia<small data-display-theme-label></small></span></button></dialog></div>';
  document.body.append(host);
  host.addEventListener('click',event=>{const button=event.target.closest('[data-co-tab]');if(button)go(button.dataset.coTab);if(event.target.closest('[data-co-open-team]')){$('coMenuDialog').close();go('team');}});
  $('coMenu').addEventListener('click',()=>{$('coMenuDialog').showModal();window.TruchAppDisplay?.refresh();});
  $('coMenuClose').addEventListener('click',()=>$('coMenuDialog').close());$('coProfile').addEventListener('click',()=>go('team'));
  host.addEventListener('submit',event=>{if(event.target.id!=='coLinkForm')return;event.preventDefault();try{save('collaborator',$('coName').value,$('coCode').value);$('coLinkStatus').textContent='Datos guardados. La vinculación sigue pendiente.';}catch(error){$('coLinkStatus').textContent=error.message;}});
 }
 function render(){
  if(!host)return;const mode=read(),name=mode.collaborator.name||'colaborador';
  const greeting='<div class="co-greeting"><span class="co-tag">Colaborador</span><h1 id="coGreeting"></h1><p>Equipo por vincular</p></div>';
  const linked=peers(),team=linked[0],connected=team&&window.TruchAppLocalPair.connected(team.fingerprint);
  const pending=team?'<section class="co-card co-team-state">'+icon('link')+'<div><h2>Equipo de '+safe(team.name)+'</h2><p>'+(connected?'Conectado por red local':'Vinculado · Sin conexión')+'</p><button type="button" class="co-secondary co-linked-action" data-local-pair>Administrar conexión</button></div></section>':'<section class="co-card co-team-state">'+icon('link')+'<div><h2>Tu equipo</h2><p>Vinculación pendiente</p></div></section>';
  let content;
  if(tab==='home')content=greeting+pending+lots()+connectionCard()+tasks();
  else if(tab==='lots')content='<h1>Mis lotes</h1>'+lots()+connectionCard();
  else if(tab==='tasks')content='<h1>Mi jornada</h1>'+tasks();
  else content='<h1>Mi equipo</h1>'+pending+'<form id="coLinkForm" class="co-card co-link-form"><h2>Datos de vinculación</h2><label for="coName">Tu nombre</label><input id="coName" maxlength="40" autocomplete="given-name" required><label for="coCode">Código del administrador</label><input id="coCode" maxlength="120" placeholder="Puedes añadirlo más adelante" autocomplete="off"><button type="button" class="co-secondary" disabled>'+icon('qr')+' Escanear QR · Próximamente</button><p>El código se conserva como borrador. Todavía no concede acceso a una granja.</p><button type="submit" class="co-primary">Guardar datos</button><p id="coLinkStatus" role="status" aria-live="polite"></p></form>'+connectionCard()+'<button type="button" class="co-mode-link" data-app-access>Cambiar modo de trabajo</button>';
  $('coMain').innerHTML=content;
  if($('coGreeting')){$('coGreeting').textContent='Hola, '+name;if(team)$('coGreeting').nextElementSibling.textContent='Equipo de '+team.name;}
  if($('coName')){$('coName').value=mode.collaborator.name;$('coCode').value=mode.collaborator.invitationCode;}
  host.querySelectorAll('[data-co-tab]').forEach(b=>b.setAttribute('aria-current',b.dataset.coTab===tab?'page':'false'));
 }
 function go(next){if(!['home','lots','tasks','team'].includes(next))return;tab=next;render();$('coMain').scrollTop=0;$('coMain').focus({preventScroll:true});}
 function apply(){
  const value=read(),collaborator=value.mode==='collaborator',intro=!!$('yb-intro'),phone=document.querySelector('.phone');
  document.documentElement.dataset.appMode=value.mode;
  if(phone)phone.inert=collaborator||intro;
  if(collaborator){build();host.hidden=false;host.inert=intro;}
  else if(host){$('coMenuDialog')?.close();host.hidden=true;host.inert=true;}
  const raw=localStorage.getItem(data.KEY);if(raw!==lastRaw){lastRaw=raw;if(collaborator)render();}
  document.querySelectorAll('[data-access-mode-label]').forEach(el=>el.textContent=collaborator?'Colaborador':'Administrador');
 }
 function save(mode,name='',code=''){
  const next=data.selection(mode,name,code,read());
  const persist=()=>localStorage.setItem(data.KEY,JSON.stringify(next));
  if(window.TruchAppStorage?.atomic)window.TruchAppStorage.atomic('Guardar modo de trabajo',persist);else persist();
  apply();return next;
 }
 function picker(){if(window.TruchAppStorage?.pending)return;window.TruchAppMenu?.close();$('coMenuDialog')?.close();window.TruchAppIntro?.openModePicker();}
 document.addEventListener('click',event=>{if(event.target.closest('[data-app-access]'))picker();});
 window.addEventListener('truchapp-storage-committed',apply);window.addEventListener('truchapp-data-restored',()=>{lastRaw=undefined;apply();});
 window.addEventListener('truchapp-local-pair-updated',()=>{if(host&&!host.hidden&&!document.querySelector('#coLinkForm:focus-within')){const scroll=$('coMain').scrollTop;render();$('coMain').scrollTop=scroll;}});
 window.TruchAppAccess={read,save,apply,go,icon};apply();
})();
