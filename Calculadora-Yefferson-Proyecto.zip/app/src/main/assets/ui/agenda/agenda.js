(()=>{
  'use strict';
  const agendaStore=window.TruchAppAgendaStore;
  const STORE_KEY='activities';

  const agendaRoot=document.getElementById('agendaRoot');
  if(!agendaRoot)return;
  const $=id=>agendaRoot.querySelector('#'+id);
  const pad=n=>String(n).padStart(2,'0');
  const fmtDate=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  const fromDate=s=>{const [y,m,d]=s.split('-').map(Number);return new Date(y,m-1,d,12,0,0,0)};
  const startOfToday=()=>{const d=new Date();return new Date(d.getFullYear(),d.getMonth(),d.getDate(),0,0,0,0)};
  const dateLong=d=>new Intl.DateTimeFormat('es-PE',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(d);
  const dateShort=d=>new Intl.DateTimeFormat('es-PE',{day:'numeric',month:'short'}).format(d);
  const timeLabel=t=>{const [h,m]=t.split(':').map(Number);return `${pad(h)}:${pad(m)}`};
  const categoryMeta={
    'Producción':{emoji:'🐟',color:'#0d9488',bg:'#ddf5ef',ink:'#0f766e'},
    'Calidad de agua':{emoji:'💧',color:'#3988c9',bg:'#e3f1ff',ink:'#1c67a4'},
    'Sanidad':{emoji:'',color:'#b89158',bg:'#faf2e3',ink:'#826732'},
    'Mantenimiento':{emoji:'',color:'#7c9b83',bg:'#edf4ec',ink:'#527254'},
    'Estudio':{emoji:'📘',color:'#9270bd',bg:'#f0eafd',ink:'#7650a4'},
    'Personal':{emoji:'☀️',color:'#db8a3b',bg:'#fff0df',ink:'#a85c1a'},
    'Trabajo':{emoji:'🗂️',color:'#527c8c',bg:'#e8f1f4',ink:'#416675'},
    'Otro':{emoji:'✦',color:'#8b9c97',bg:'#eef3f1',ink:'#62756f'}
  };
  let selectedDate=fmtDate(new Date()),view='day',category='all',summaryFilter=null,editingId=null,toastTimer=null;
  let progressInitialized=false;
  let repeatDatesSelected=new Set(),repeatCalendarCursor=fromDate(selectedDate),repeatCalendarInitialized=false;
  let stripInitialized=false,stripReady=false,adjustingStrip=false,stripPointer=null,suppressDateClickUntil=0,monthFocusDate=fromDate(selectedDate),monthPickerCursor=new Date(new Date().getFullYear(),new Date().getMonth(),1,12,0,0,0),monthUpdateFrame=0;
  function makeDefaults(){return [];}
  function cryptoId(){return globalThis.crypto?.randomUUID?globalThis.crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)}
  function normalizeStoredTask(source,index){
    const t=source&&typeof source==='object'?source:{};
    const priorityMap={Alta:'high',alta:'high',Normal:'normal',normal:'normal',Baja:'low',baja:'low',high:'high',low:'low'};
    const assignmentType=t.assignmentType||(t.campaignId?'campaign':(t.lotId||t.lotCode?'lot':''));
    const assignmentId=String(t.assignmentId??(assignmentType==='campaign'?t.campaignId:t.lotId)??'');
    const assignmentLabel=String(t.assignmentLabel||(assignmentType==='campaign'?t.campaignName:t.lotCode)||'');
    return {...t,
      id:t.id??(Date.now()+index), title:String(t.title||t.name||''),
      date:/^\d{4}-\d{2}-\d{2}$/.test(String(t.date||''))?String(t.date):fmtDate(new Date()),
      time:/^\d{2}:\d{2}$/.test(String(t.time||''))?String(t.time):'09:00',
      category:categoryMeta[t.category]?t.category:'Producción',
      priority:priorityMap[t.priority]||'normal', note:String(t.note||''),
      reminder:t.reminder===undefined?true:!!t.reminder, repeat:t.repeat||'once',
      repeatDays:Array.isArray(t.repeatDays)?t.repeatDays:[], repeatDates:Array.isArray(t.repeatDates)?t.repeatDates:[],
      completedDates:Array.isArray(t.completedDates)?t.completedDates:[], done:!!t.done,
      assignmentType,assignmentId,assignmentLabel,
      assignmentSubtitle:String(t.assignmentSubtitle||''),assignmentCampaign:String(t.assignmentCampaign||t.lotCampaign||t.campaignName||''),
      lotId:assignmentType==='lot'?assignmentId:'',lotCode:assignmentType==='lot'?assignmentLabel:'',
      campaignId:assignmentType==='campaign'?assignmentId:'',campaignName:assignmentType==='campaign'?assignmentLabel:''
    };
  }
  function loadTasks(){return agendaStore.activities().map(normalizeStoredTask).filter(t=>t.title)}
  let tasks=loadTasks();
  const LOTS_KEY='truchapp_lotes_v1';
  const CAMPAIGN_KEYS=['truchapp_campaigns_v1','truchapp_campanas_v1','campaigns'];
  const normalizeSearch=value=>String(value??'').toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
  function readStoredArray(key){try{const value=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(value)?value:[]}catch(e){return []}}
  function rawLots(){
    try{if(window.TruchAppData&&typeof window.TruchAppData.getLots==='function'){const rows=window.TruchAppData.getLots();if(Array.isArray(rows))return rows}}catch(e){}
    try{if(window.AndroidAI&&typeof window.AndroidAI.getLots==='function'){const rows=JSON.parse(window.AndroidAI.getLots()||'[]');if(Array.isArray(rows))return rows}}catch(e){}
    return readStoredArray(LOTS_KEY);
  }
  function rawCampaigns(){
    try{if(window.TruchAppData&&typeof window.TruchAppData.getCampaigns==='function'){const rows=window.TruchAppData.getCampaigns();if(Array.isArray(rows))return rows}}catch(e){}
    return CAMPAIGN_KEYS.flatMap(readStoredArray);
  }
  function availableAssignments(){
    const lots=lotCatalog.map((lot,index)=>{
      const label=String(lot.code||lot.id||lot.name||`Lote ${index+1}`);
      const id=String(lot.id??lot.code??label);
      const campaign=String(lot.campaignName||lot.campaign||lot.campaignCode||lot.campaignLabel||'');
      const subtitle=[campaign?`Campaña ${campaign}`:'',lot.stage||lot.stageName||'',lot.unit||'',lot.origin||''].filter(Boolean).join(' · ')||'Lote registrado';
      return {id,type:'lot',label,campaign,subtitle,searchText:[label,lot.id,lot.code,lot.name,lot.stage,lot.stageName,lot.unit,lot.origin,campaign].filter(Boolean).join(' ')};
    });
    const campaigns=rawCampaigns().map((campaign,index)=>{
      const label=String(campaign.name||campaign.label||campaign.title||campaign.code||campaign.id||`Campaña ${index+1}`);
      const id=String(campaign.id??campaign.code??label);
      const subtitle=[campaign.code&&campaign.code!==label?campaign.code:'',campaign.season||campaign.period||campaign.year||'',campaign.status||''].filter(Boolean).join(' · ')||'Campaña registrada';
      return {id,type:'campaign',label,campaign:label,subtitle,searchText:[label,campaign.name,campaign.label,campaign.title,campaign.code,campaign.season,campaign.period,campaign.year,campaign.status].filter(Boolean).join(' ')};
    });
    const seen=new Set();return [...lots,...campaigns].filter(item=>{const key=item.type+':'+item.id;if(seen.has(key))return false;seen.add(key);return true});
  }
  function setAssignment(item){
    $('taskAssignmentId').value=item?.id||'';$('taskAssignmentType').value=item?.type||'';$('taskAssignmentLabel').value=item?.label||'';$('taskAssignmentSubtitle').value=item?.subtitle||'';$('taskAssignmentCampaign').value=item?.campaign||'';
    if(item?.type==='lot'&&$('taskCenter')){const lot=lotCatalog.find(l=>l.id===item.id);if(lot)$('taskCenter').value=lot.centerId}
    const selected=!!item;$('lotSelectionSummary').hidden=!selected;$('clearLotAssignment').hidden=!selected;
    $('lotSelectedLabel').textContent=selected?`${item.type==='campaign'?'Campaña':'Lote'}: ${item.label}`:'';$('lotSelectedSubtitle').textContent=selected?(item.subtitle||'Registro vinculado'):'';
    if(selected){$('lotResults').hidden=true;$('lotSearchInput').value='';$('lotPickerHelp').textContent='Registro vinculado a esta actividad. Pulsa “Quitar” si deseas desasignarlo.'}
    else {$('lotPickerHelp').textContent=''}
  }
  function renderAssignmentResults(){
    const box=$('lotResults');if(!box)return;const query=normalizeSearch($('lotSearchInput').value);const all=availableAssignments();const matches=all.filter(item=>!query||normalizeSearch(item.searchText).includes(query));box.innerHTML='';box.hidden=false;
    if(!matches.length){const msg=document.createElement('div');msg.className='lotNoResults';msg.textContent=all.length?'No se encontraron lotes o campañas con esa búsqueda.':'Todavía no hay lotes registrados. Crea uno en Lotes para vincularlo a una actividad.';box.appendChild(msg);return}
    matches.slice(0,30).forEach(item=>{const btn=document.createElement('button');btn.type='button';btn.className='lotResult';btn.setAttribute('role','option');const main=document.createElement('span');main.className='lotResultMain';const title=document.createElement('strong');title.textContent=item.label;const sub=document.createElement('small');sub.textContent=item.subtitle;main.append(title,sub);const badge=document.createElement('span');badge.className='lotTypeBadge';badge.textContent=item.type==='campaign'?'Campaña':'Lote';btn.append(main,badge);btn.addEventListener('click',()=>{setAssignment(item);});box.appendChild(btn)});
  }
  function restoreAssignment(task){
    const type=task?.assignmentType||(task?.campaignId?'campaign':(task?.lotId||task?.lotCode?'lot':''));
    const id=String(task?.assignmentId||(type==='campaign'?(task?.campaignId||task?.campaignName):(task?.lotId||task?.lotCode))||'');
    const label=String(task?.assignmentLabel||(type==='campaign'?(task?.campaignName||id):(task?.lotCode||id))||'');
    if(!type||!id||!label){setAssignment(null);return}
    const found=availableAssignments().find(item=>item.type===type&&(item.id===id||item.label===label));
    setAssignment(found||{id,type,label,campaign:task?.assignmentCampaign||task?.lotCampaign||task?.campaignName||'',subtitle:task?.assignmentSubtitle||'Registro guardado en esta actividad'});
  }
  function refreshAssignmentPicker(){if(!$('lotSearchInput'))return;const selectedId=$('taskAssignmentId').value;const selectedType=$('taskAssignmentType').value;const selectedLabel=$('taskAssignmentLabel').value;if(selectedId&&selectedLabel){$('lotSelectionSummary').hidden=false;$('clearLotAssignment').hidden=false;$('lotSelectedLabel').textContent=`${selectedType==='campaign'?'Campaña':'Lote'}: ${selectedLabel}`;$('lotSelectedSubtitle').textContent=$('taskAssignmentSubtitle').value||'Registro vinculado'}if(document.activeElement===$('lotSearchInput')||!$('lotResults').hidden)renderAssignmentResults()}
  window.addEventListener('truchapp-lots-updated',refreshAssignmentPicker);window.addEventListener('storage',e=>{if(!e.key||e.key===LOTS_KEY||CAMPAIGN_KEYS.includes(e.key))refreshAssignmentPicker()});
  window.refreshAgendaLotOptions=refreshAssignmentPicker;
  function save(){return opSave()}
  function toast(msg){showToast(msg)}
  function showToast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2300)}
  function isOverdue(t){if(t.done)return false;const now=new Date();const today=fmtDate(now);return t.date<today||(t.date===today&&t.time<`${pad(now.getHours())}:${pad(now.getMinutes())}`)}
  function repeatType(t){return t.repeat||'once'}
  function isRecurring(t){return repeatType(t)!=='once'}
  function repeatLabel(t){const kind=repeatType(t);if(kind==='daily')return'Diariamente';if(kind==='weekdays')return'Lun. a vie.';if(kind==='custom'){if(Array.isArray(t.repeatDates))return `Personalizado (${t.repeatDates.length} fechas)`;const names=['dom','lun','mar','mié','jue','vie','sáb'];return (t.repeatDays||[]).slice().sort((a,b)=>a-b).map(n=>names[n]).join(', ')||'Personalizado'}return'Una vez'}
  function occursOnDate(t,key){return isScheduled(t,key)}
  function occurrenceDone(t,key){return window.TruchAppDecisionData.completed(t,key,opRecords)}
  function nextReminderOccurrence(t){
    if(!t||t.done||!t.reminder||!t.date||!t.time)return null;
    const today=fmtDate(new Date()),start=t.date>today?t.date:today;const cursor=fromDate(start);
    for(let i=0;i<370;i++){
      const key=fmtDate(cursor);
      if(occursOnDate({...t,done:false},key)&&!occurrenceDone(t,key)){
        const when=new Date(key+'T'+t.time).getTime();if(Number.isFinite(when)&&when>Date.now())return {date:key,when};
      }
      cursor.setDate(cursor.getDate()+1);
    }
    return null;
  }
  function nativeReminderId(t){const value=Number(t.id);if(Number.isSafeInteger(value)&&value>0)return value;let hash=0;for(const ch of String(t.id||''))hash=(hash*31+ch.charCodeAt(0))&0x7fffffff;return hash||Date.now()}
  function scheduleNativeReminder(t){
    if(!t||!t.reminder||!window.AndroidAI||typeof window.AndroidAI.scheduleReminder!=='function')return;
    const next=nextReminderOccurrence(t);if(!next)return;
    const assigned=t.assignmentLabel||t.lotCode||t.campaignName||'';const title=t.title+(assigned?' · '+(t.assignmentType==='campaign'?'Campaña ':'Lote ')+assigned:'');
    try{window.AndroidAI.scheduleReminder(nativeReminderId(t),title,next.when)}catch(e){}
  }
  function occurrenceFor(t,key,done=occurrenceDone(t,key)){return {...t,date:key,occurrenceDate:key,done,isRepeatOccurrence:isRecurring(t)}}
  function matchesSearchAndCategory(t,q){if(category!=='all'&&t.category!==category)return false;return !q||`${t.title} ${t.note||''} ${t.category} ${t.lotCode||''} ${t.campaignName||''} ${t.assignmentLabel||''} ${t.assignmentCampaign||''}`.toLocaleLowerCase('es').includes(q)}
  function viewTasks(){return opViewTasks()}
  function renderTodayProgress(){opRenderStats()}
  function renderStats(){opRenderStats()}
  const weekdayShort=['dom','lun','mar','mié','jue','vie','sáb'];
  const monthText=d=>new Intl.DateTimeFormat('es-PE',{month:'long',year:'numeric'}).format(d);
  function updateMonthLabel(){const raw=monthText(monthFocusDate),text=raw.charAt(0).toLocaleUpperCase('es-PE')+raw.slice(1);$('monthLabel').textContent=text;$('monthLabel').setAttribute('aria-label',`Elegir fecha. Mes visible: ${text}`)}
  function makeDayButton(date){
    const d=fromDate(fmtDate(date)),key=fmtDate(d),btn=document.createElement('button');
    btn.type='button';btn.className='dayBtn';btn.dataset.date=key;
    btn.innerHTML=`<span class="dayName">${weekdayShort[d.getDay()]}</span><span class="dayNum">${d.getDate()}</span><span class="dayDots" aria-hidden="true"></span>`;
    btn.setAttribute('aria-label',dateLong(d));btn.addEventListener('click',()=>{
      if(Date.now()<suppressDateClickUntil)return;
      selectedDate=btn.dataset.date;monthFocusDate=fromDate(selectedDate);summaryFilter=null;view='day';syncViewButtons();render();
    });
    return btn;
  }
  function updateDayButtons(){
    const today=fmtDate(new Date()),priorityOrder=['low','normal','high'];
    const priorityLabels={low:'baja',normal:'normal',high:'alta'};
    $('weekStrip').querySelectorAll('.dayBtn').forEach(btn=>{
      const key=btn.dataset.date;
      const scheduled=dayOccurrences(key);
      const priorities=new Set(scheduled.map(t=>priorityOrder.includes(t.priority)?t.priority:'normal'));
      btn.classList.toggle('selected',key===selectedDate);
      btn.classList.toggle('today',key===today);
      btn.classList.toggle('hasTasks',scheduled.length>0);
      btn.setAttribute('aria-pressed',String(key===selectedDate));
      const dots=btn.querySelector('.dayDots');
      if(dots){
        dots.replaceChildren();
        priorityOrder.filter(priority=>priorities.has(priority)).forEach(priority=>{
          const dot=document.createElement('span');
          dot.className=`dayDot ${priority}`;
          dot.title=`Prioridad ${priorityLabels[priority]}`;
          dot.setAttribute('aria-hidden','true');
          dots.appendChild(dot);
        });
      }
      const priorityDescription=priorityOrder.filter(priority=>priorities.has(priority)).map(priority=>`prioridad ${priorityLabels[priority]}`);
      const accessibleSummary=scheduled.length?`; ${scheduled.length} actividades programadas; ${priorityDescription.join(', ')}`:'; sin actividades programadas';
      btn.setAttribute('aria-label',dateLong(fromDate(key))+accessibleSummary);
    });
  }
  function appendDates(count=21){
    let last=fromDate($('weekStrip').lastElementChild.dataset.date);const fragment=document.createDocumentFragment();
    for(let i=0;i<count;i++){last.setDate(last.getDate()+1);fragment.appendChild(makeDayButton(last))}
    $('weekStrip').appendChild(fragment);updateDayButtons();
  }
  function prependDates(count=21){
    const strip=$('weekStrip');let first=fromDate(strip.firstElementChild.dataset.date);const oldWidth=strip.scrollWidth,oldLeft=$('weekCarousel').scrollLeft,fragment=document.createDocumentFragment();
    for(let i=count;i>=1;i--){const d=fromDate(fmtDate(first));d.setDate(d.getDate()-i);fragment.appendChild(makeDayButton(d))}
    adjustingStrip=true;strip.insertBefore(fragment,strip.firstChild);const addedWidth=strip.scrollWidth-oldWidth;$('weekCarousel').scrollLeft=oldLeft+addedWidth;updateDayButtons();
    requestAnimationFrame(()=>{adjustingStrip=false});
  }
  function ensureDateInStrip(key){
    const strip=$('weekStrip');if(!strip.firstElementChild)return;
    let guard=0;while(key<strip.firstElementChild.dataset.date&&guard++<200)prependDates(21);
    guard=0;while(key>strip.lastElementChild.dataset.date&&guard++<200)appendDates(21);
  }
  function sizeDateStrip(){
    const viewport=$('weekCarousel');
    if(viewport.clientWidth)viewport.style.setProperty('--calendar-day-width',`${(viewport.clientWidth-36)/7}px`);
  }
  function scrollDateIntoView(key,behavior='smooth',weekAligned=false){
    let targetKey=key;
    if(weekAligned){const monday=fromDate(key);monday.setDate(monday.getDate()-(monday.getDay()+6)%7);targetKey=fmtDate(monday);const sunday=new Date(monday);sunday.setDate(sunday.getDate()+6);ensureDateInStrip(fmtDate(sunday))}
    ensureDateInStrip(targetKey);const strip=$('weekStrip'),viewport=$('weekCarousel'),btn=strip.querySelector(`[data-date="${targetKey}"]`);if(!btn)return;
    const v=viewport.getBoundingClientRect(),b=btn.getBoundingClientRect();let target=viewport.scrollLeft;
    if(weekAligned)target+=b.left-v.left;
    else if(b.left<v.left+8)target+=b.left-v.left-8;
    else if(b.right>v.right-8)target+=b.right-v.right+8;
    if(window.matchMedia('(prefers-reduced-motion: reduce)').matches)behavior='auto';
    if(behavior==='auto')viewport.scrollLeft=Math.max(0,target);else viewport.scrollTo({left:Math.max(0,target),behavior});
  }
  function initializeDateStrip(){
    sizeDateStrip();const strip=$('weekStrip');let start=fromDate(selectedDate);start.setDate(start.getDate()-(start.getDay()+6)%7-21);const fragment=document.createDocumentFragment();
    for(let i=0;i<43;i++){fragment.appendChild(makeDayButton(start));start.setDate(start.getDate()+1)}
    strip.appendChild(fragment);stripInitialized=true;updateDayButtons();updateMonthLabel();
    requestAnimationFrame(()=>{scrollDateIntoView(selectedDate,'auto',true);stripReady=true});
  }
  function renderWeek(){if(!stripInitialized)initializeDateStrip();else{updateDayButtons();updateMonthLabel()}}
  function extendDateStripIfNeeded(){
    if(!stripReady||adjustingStrip)return;const viewport=$('weekCarousel'),strip=$('weekStrip');
    if(viewport.scrollLeft<170)prependDates(21);
    else if(strip.scrollWidth-(viewport.scrollLeft+viewport.clientWidth)<360)appendDates(21);
  }
  function syncMonthToViewport(){
    const viewport=$('weekCarousel'),strip=$('weekStrip'),center=viewport.getBoundingClientRect().left+viewport.clientWidth/2;let best=null,bestDistance=Infinity;
    strip.querySelectorAll('.dayBtn').forEach(btn=>{const r=btn.getBoundingClientRect(),centerOfButton=r.left+r.width/2;const distance=Math.abs(centerOfButton-center);if(distance<bestDistance){best=btn;bestDistance=distance}});
    if(best){monthFocusDate=fromDate(best.dataset.date);updateMonthLabel()}
  }
  function handleDateStripScroll(){
    extendDateStripIfNeeded();if(monthUpdateFrame)return;monthUpdateFrame=requestAnimationFrame(()=>{monthUpdateFrame=0;syncMonthToViewport()});
  }
  let monthPickerDraftDate=selectedDate,monthPickerReturnFocus=null,monthSwipeState=null,monthSuppressClickUntil=0;
  function pickerDateTitle(key){const text=new Intl.DateTimeFormat('es-PE',{weekday:'long',day:'numeric',month:'long'}).format(fromDate(key));return text.charAt(0).toLocaleUpperCase('es-PE')+text.slice(1)}
  function renderMonthPicker(focusKey=null){
    const label=monthText(monthPickerCursor);$('monthPickerMonthLabel').textContent=label.charAt(0).toLocaleUpperCase('es-PE')+label.slice(1);
    $('monthPickerTitle').textContent=pickerDateTitle(monthPickerDraftDate);$('monthPickerTitle').setAttribute('aria-label',dateLong(fromDate(monthPickerDraftDate)));
    const grid=$('monthDays');grid.replaceChildren();grid.setAttribute('aria-label',label);
    const first=new Date(monthPickerCursor.getFullYear(),monthPickerCursor.getMonth(),1,12),last=new Date(first.getFullYear(),first.getMonth()+1,0,12),start=new Date(first);
    start.setDate(1-first.getDay());const cells=Math.ceil((first.getDay()+last.getDate())/7)*7,today=fmtDate(new Date());
    const draftVisible=monthPickerDraftDate>=fmtDate(start)&&monthPickerDraftDate<=fmtDate(new Date(start.getFullYear(),start.getMonth(),start.getDate()+cells-1,12));
    const tabKey=focusKey||(draftVisible?monthPickerDraftDate:fmtDate(first));
    const priorityOrder=['low','normal','high'],priorityLabels={low:'baja',normal:'normal',high:'alta'};
    for(let i=0;i<cells;i+=7){
      const row=document.createElement('div');row.className='monthWeek';row.setAttribute('role','row');
      for(let j=0;j<7;j++){
        const d=new Date(start);d.setDate(start.getDate()+i+j);const key=fmtDate(d),button=document.createElement('button'),pendingTasks=dayOccurrences(key).filter(t=>!t.done),pending=pendingTasks.length,priorities=new Set(pendingTasks.map(t=>priorityOrder.includes(t.priority)?t.priority:'normal'));
        button.type='button';button.dataset.date=key;button.className='monthDay'+(d.getMonth()!==monthPickerCursor.getMonth()?' otherMonth':'')+(key===monthPickerDraftDate?' selected':'')+(key===today?' today':'')+(pending?' hasTasks':'');
        button.textContent=d.getDate();button.tabIndex=key===tabKey?0:-1;button.setAttribute('role','gridcell');button.setAttribute('aria-label',dateLong(d)+(key===today?'; hoy':'')+(pending?`; ${pending} actividades pendientes`:''));button.setAttribute('aria-selected',String(key===monthPickerDraftDate));if(key===today)button.setAttribute('aria-current','date');
        if(pending){const dots=document.createElement('span');dots.className='monthPriorityDots';dots.setAttribute('aria-hidden','true');const labels=[];priorityOrder.filter(priority=>priorities.has(priority)).forEach(priority=>{const dot=document.createElement('span');dot.className='monthPriorityDot '+priority;dot.title='Prioridad '+priorityLabels[priority];dots.appendChild(dot);labels.push('prioridad '+priorityLabels[priority])});button.appendChild(dots);button.setAttribute('aria-label',button.getAttribute('aria-label')+'; '+labels.join(', '));}
        button.addEventListener('click',e=>{if(e.detail>0&&Date.now()<monthSuppressClickUntil)return;setMonthPickerDraft(key)});row.appendChild(button);
      }
      grid.appendChild(row);
    }
    if(focusKey)grid.querySelector(`[data-date="${focusKey}"]`)?.focus({preventScroll:true});
  }
  function setMonthPickerDraft(key){
    monthPickerDraftDate=key;const d=fromDate(key);monthPickerCursor=new Date(d.getFullYear(),d.getMonth(),1,12);renderMonthPicker(key);
  }
  function clearMonthSwipe(){
    const state=monthSwipeState,grid=$('monthDays');monthSwipeState=null;grid.style.transform='';grid.classList.remove('monthDragging');
    if(state&&grid.hasPointerCapture?.(state.id))grid.releasePointerCapture(state.id);
  }
  function animateMonthGrid(offset){
    const grid=$('monthDays');if(window.matchMedia('(prefers-reduced-motion: reduce)').matches||!grid.animate)return;
    grid.animate([{transform:`translateX(${offset}px)`},{transform:'translateX(0)'}],{duration:170,easing:'cubic-bezier(.2,.7,.2,1)'});
  }
  function moveMonthPicker(direction,focusGrid=false){
    const grid=$('monthDays');clearMonthSwipe();grid.getAnimations?.().forEach(animation=>animation.cancel());
    monthPickerCursor=new Date(monthPickerCursor.getFullYear(),monthPickerCursor.getMonth()+direction,1,12);renderMonthPicker();
    if(focusGrid)grid.querySelector('[tabindex="0"]')?.focus({preventScroll:true});animateMonthGrid(direction>0?24:-24);
  }
  function startMonthSwipe(e){
    if(!e.isPrimary){clearMonthSwipe();return}if(e.pointerType==='mouse'&&e.button!==0)return;
    clearMonthSwipe();$('monthDays').getAnimations?.().forEach(animation=>animation.cancel());monthSuppressClickUntil=0;
    monthSwipeState={id:e.pointerId,x:e.clientX,y:e.clientY,axis:null};
  }
  function dragMonthSwipe(e){
    const state=monthSwipeState;if(!state||state.id!==e.pointerId)return;
    const dx=e.clientX-state.x,dy=e.clientY-state.y,ax=Math.abs(dx),ay=Math.abs(dy),grid=$('monthDays');
    if(!state.axis&&Math.max(ax,ay)>8){if(ax>ay*1.3)state.axis='x';else if(ay>ax*1.1)state.axis='y'}
    if(state.axis!=='x')return;
    if(e.cancelable)e.preventDefault();if(!grid.hasPointerCapture(e.pointerId)){try{grid.setPointerCapture(e.pointerId)}catch(_){}}
    grid.classList.add('monthDragging');grid.style.transform=`translateX(${Math.max(-26,Math.min(26,dx*.22))}px)`;
  }
  function finishMonthSwipe(e){
    const state=monthSwipeState;if(!state||state.id!==e.pointerId)return;
    const dx=e.clientX-state.x,dy=e.clientY-state.y,horizontal=state.axis==='x',offset=Math.max(-26,Math.min(26,dx*.22));
    clearMonthSwipe();if(!horizontal)return;monthSuppressClickUntil=Date.now()+350;
    const threshold=Math.max(36,Math.min(56,$('monthDays').clientWidth*.14));
    if(Math.abs(dx)>=threshold&&Math.abs(dx)>Math.abs(dy)*1.3)moveMonthPicker(dx<0?1:-1,true);else animateMonthGrid(offset);
  }
  function cancelMonthSwipe(e){if(!monthSwipeState||monthSwipeState.id!==e.pointerId)return;if(monthSwipeState.axis==='x')monthSuppressClickUntil=Date.now()+350;clearMonthSwipe()}
  function openMonthPicker(){
    clearMonthSwipe();monthSuppressClickUntil=0;
    monthPickerDraftDate=selectedDate;monthPickerReturnFocus=document.activeElement;monthPickerCursor=new Date(monthFocusDate.getFullYear(),monthFocusDate.getMonth(),1,12);renderMonthPicker();
    $('monthPickerBackdrop').classList.add('open');$('monthPickerBackdrop').setAttribute('aria-hidden','false');agendaRoot.querySelector('.app').inert=true;agendaShellInert(true);
    requestAnimationFrame(()=>$('monthDays').querySelector('[tabindex="0"]')?.focus({preventScroll:true}));
  }
  function closeMonthPicker(){
    clearMonthSwipe();$('monthDays').getAnimations?.().forEach(animation=>animation.cancel());
    $('monthPickerBackdrop').classList.remove('open');$('monthPickerBackdrop').setAttribute('aria-hidden','true');agendaRoot.querySelector('.app').inert=false;agendaShellInert(false);
    if(monthPickerReturnFocus?.isConnected)monthPickerReturnFocus.focus({preventScroll:true});
  }
  function chooseMonthDate(key){
    selectedDate=key;monthFocusDate=fromDate(key);summaryFilter=null;view='day';closeMonthPicker();syncViewButtons();render();scrollDateIntoView(key,'auto',true);
  }
  function monthPickerKeydown(e){
    if(!$('monthPickerBackdrop').classList.contains('open'))return;
    if(e.key==='Escape'){e.preventDefault();closeMonthPicker();return}
    if(e.key==='Tab'){
      const controls=[...$('monthPickerBackdrop').querySelectorAll('button:not([tabindex="-1"])')].filter(n=>!n.disabled&&n.getClientRects().length),first=controls[0],last=controls[controls.length-1];
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}return;
    }
    const active=document.activeElement;if(!active?.classList.contains('monthDay'))return;
    const date=fromDate(active.dataset.date),offset={ArrowLeft:-1,ArrowRight:1,ArrowUp:-7,ArrowDown:7};let handled=true;
    if(e.key in offset)date.setDate(date.getDate()+offset[e.key]);
    else if(e.key==='Home')date.setDate(date.getDate()-date.getDay());
    else if(e.key==='End')date.setDate(date.getDate()+6-date.getDay());
    else if(e.key==='PageUp'||e.key==='PageDown'){const day=date.getDate();date.setDate(1);date.setMonth(date.getMonth()+(e.key==='PageUp'?-1:1));date.setDate(Math.min(day,new Date(date.getFullYear(),date.getMonth()+1,0).getDate()))}
    else handled=false;
    if(handled){e.preventDefault();setMonthPickerDraft(fmtDate(date))}
  }

  function renderAgendaHeading(items){
    let title,sub;
    if(summaryFilter==='pending'){title='Actividades pendientes';sub='Todas las actividades por completar'}
    else if(summaryFilter==='completed'){title='Actividades completadas';sub='Todas las actividades ya completadas'}
    else if(summaryFilter==='overdue'){title='Actividades vencidas';sub='Pendientes que superaron su fecha u hora'}
    else if(view==='day'){title=selectedDate===fmtDate(new Date())?'Agenda de hoy':`Agenda del ${dateLong(fromDate(selectedDate))}`;sub=selectedDate===fmtDate(new Date())?'Tus actividades para hoy':'Actividades del día seleccionado'}
    else if(view==='upcoming'){title='Próximas actividades';sub='Pendientes desde hoy en adelante'}
    else if(view==='done'){title='Actividades completadas';sub='Revisa lo que ya has logrado'}
    else{title='Todas las actividades';sub='Tu lista completa de actividades'}
    $('agendaTitle').textContent=title;$('agendaSub').textContent=sub;$('resultsLabel').textContent=`${items.length} ${items.length===1?'actividad':'actividades'}`;
  }
  function el(tag,cls,html){const node=document.createElement(tag);if(cls)node.className=cls;if(html!==undefined)node.innerHTML=html;return node}
  const quickActivityTemplates=[
    {title:'Alimentar',category:'Producción'},
    {title:'Medir temp. y O₂',category:'Calidad de agua'},
    {title:'Limpiar tanques',category:'Producción'},
    {title:'Registrar mortalidad',category:'Producción'}
  ];
  function renderEmptyAgenda(container){opEmpty(container)}
  function renderTasks(){opRenderTasks()}
  function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
  function syncViewButtons(){$$('.viewBtn').forEach(b=>{const active=!summaryFilter&&b.dataset.view===view;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active))});}
  function syncSummaryCards(){$$('.stat[data-summary-filter]').forEach(card=>{const active=card.dataset.summaryFilter===summaryFilter;card.classList.toggle('active',active);card.setAttribute('aria-pressed',String(active))})}
  function selectSummaryFilter(kind){summaryFilter=summaryFilter===kind?null:kind;view='day';category='all';$('searchInput').value='';selectedDate=fmtDate(new Date());monthFocusDate=fromDate(selectedDate);opTaskLimit=20;render();scrollDateIntoView(selectedDate,'auto',true);requestAnimationFrame(()=>{$('agendaSection').scrollIntoView({behavior:'smooth',block:'start'})})}
  function $$(s){return Array.from(agendaRoot.querySelectorAll(s))}
  function syncCategoryButtons(){opSyncFilter();$$('.catBtn').forEach(b=>{const active=b.dataset.category===category;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active))})}
  function render(){lotCatalog=makeLotCatalog();opRenderScopes();renderStats();renderWeek();renderTasks();opRenderAttention();opRenderWeek();$('heroDate').textContent='HOY · '+new Intl.DateTimeFormat('es-PE',{weekday:'long',day:'numeric',month:'long'}).format(new Date());syncViewButtons();syncSummaryCards();syncCategoryButtons()}
  function selectedRepeatDates(){return Array.from(repeatDatesSelected).sort()}
  function renderRepeatCalendar(){
    const label=monthText(repeatCalendarCursor),title=label.charAt(0).toLocaleUpperCase('es-PE')+label.slice(1);$('repeatCalendarMonth').textContent=title;
    const grid=$('repeatCalendarDays');grid.innerHTML='';const first=new Date(repeatCalendarCursor.getFullYear(),repeatCalendarCursor.getMonth(),1,12);const start=new Date(first);start.setDate(1-first.getDay());const today=fmtDate(new Date());const minDate=$('taskDate').value||selectedDate;
    for(let i=0;i<42;i++){const d=new Date(start);d.setDate(start.getDate()+i);const key=fmtDate(d),button=document.createElement('button');button.type='button';button.className='repeatCalDay'+(d.getMonth()!==repeatCalendarCursor.getMonth()?' otherMonth':'')+(repeatDatesSelected.has(key)?' selected':'')+(key===today?' today':'');button.textContent=d.getDate();button.setAttribute('role','gridcell');button.setAttribute('aria-label',dateLong(d));button.setAttribute('aria-pressed',String(repeatDatesSelected.has(key)));button.disabled=key<minDate;button.addEventListener('click',()=>{if(repeatDatesSelected.has(key))repeatDatesSelected.delete(key);else repeatDatesSelected.add(key);if(d.getMonth()!==repeatCalendarCursor.getMonth())repeatCalendarCursor=new Date(d.getFullYear(),d.getMonth(),1,12);renderRepeatCalendar()});grid.appendChild(button)}
    const dates=selectedRepeatDates();$('repeatCalendarSummary').textContent=dates.length?`${dates.length} fecha${dates.length===1?'':'s'}: ${dates.slice(0,4).map(key=>dateShort(fromDate(key))).join(', ')}${dates.length>4?'…':''}`:'Selecciona una o varias fechas.';
  }
  function updateRepeatDaysVisibility(){const custom=$('taskRepeat').value==='custom';$('repeatCalendarField').hidden=!custom;if(custom)renderRepeatCalendar()}
  function openModal(id=null){
    opClosePanel(false);editingId=id;const t=id?tasks.find(x=>String(x.id)===String(id)):null;
    $('modalTitle').textContent=t?'Editar actividad':'Nueva actividad';$('taskTitleInput').value=t?.title||'';$('taskDate').value=t?.date||selectedDate;$('taskTime').value=t?.time||'09:00';$('taskCategory').value=t?.category||'Producción';$('taskPriority').value=t?.priority||'normal';$('taskNote').value=t?.note||'';$('taskReminder').checked=t?.reminder??true;$('taskRepeat').value=t?.repeat||'once';$('lotSearchInput').value='';$('lotResults').hidden=true;restoreAssignment(t);
    repeatDatesSelected=new Set(t?.repeat==='custom'&&Array.isArray(t?.repeatDates)?t.repeatDates:[]);repeatCalendarInitialized=!!(t?.repeat==='custom'&&Array.isArray(t?.repeatDates));const startDate=t?.date||selectedDate;repeatCalendarCursor=new Date(fromDate(startDate).getFullYear(),fromDate(startDate).getMonth(),1,12);if(t?.repeat==='custom'&&!Array.isArray(t?.repeatDates)){repeatDatesSelected.add(startDate);repeatCalendarInitialized=true}updateRepeatDaysVisibility();
    opPrepareEditor(t);$('deleteTaskBtn').classList.toggle('visible',!!t);$('modalBackdrop').classList.add('open');document.body.style.overflow='hidden';setTimeout(()=>$('taskTitleInput').focus({preventScroll:true}),60)
  }
  function closeModal(){$('modalBackdrop').classList.remove('open');document.body.style.overflow='';editingId=null}

  // Planificación y resultados vinculados a los datos reales del APK.
  const OP_KEY='truchapp_agenda_workbook_v1';
  const opKinds={
    general:{label:'Actividad libre',action:'Completar',category:'Trabajo'},
    water:{label:'Control de agua',action:'Registrar medición',category:'Calidad de agua'},
    feeding:{label:'Alimentación',action:'Registrar alimento',category:'Producción'},
    losses:{label:'Bajas',action:'Registrar bajas',category:'Sanidad'},
    biometry:{label:'Biometría',action:'Registrar biometría',category:'Producción'},
    maintenance:{label:'Mantenimiento',action:'Registrar revisión',category:'Mantenimiento'}
  };
  const feedProducts=()=>agendaStore.products();
  let opBook=readOpBook(),opRecords=opBook?.records||[],opLimits=opBook?.limits||{};
  let scopeCenter=opBook?.scope?.center||'all',scopeLot=opBook?.scope?.lot||'all';
  let opReturnFocus=null,opPanelMode='',opTaskLimit=20,opAttentionExpanded=false,opCompletedExpanded=false;
  let lotCatalog=makeLotCatalog();
  function readOpBook(){return agendaStore.load()}
  function makeLotCatalog(){return agendaStore.catalog()}
  function kindOf(t){return opKinds[t?.kind]?t.kind:'general'}
  function lotOf(t){return lotCatalog.find(l=>l.id===String(t?.lotId||t?.assignmentId||''))||null}
  function centerOf(t){return lotOf(t)?.centerId||t?.centerId||''}
  function inScope(t){return (scopeLot==='all'||lotOf(t)?.id===scopeLot)&&(scopeCenter==='all'||centerOf(t)===scopeCenter)}
  function scopedLots(){return lotCatalog.filter(l=>(scopeCenter==='all'||l.centerId===scopeCenter)&&(scopeLot==='all'||l.id===scopeLot))}
  function centers(){return agendaStore.centers()}
  function opRecordId(task,key){return String(task.id)+'@'+key}
  function recordFor(task,key=task.occurrenceDate||task.date){return opRecords.find(r=>r.id===opRecordId(task,key))||null}
  function isScheduled(t,key){return window.TruchAppDecisionData.scheduled(t,key)}
  function dayOccurrences(key,scope=true){return tasks.filter(t=>(!scope||inScope(t))&&(isScheduled(t,key)||!!recordFor(t,key))).map(t=>occurrenceFor(t,key))}
  function nextOpenOccurrence(t,base){
    if(repeatType(t)==='once')return t.date>=base&&isScheduled(t,t.date)&&!occurrenceDone(t,t.date)?occurrenceFor(t,t.date,false):null;
    if(repeatType(t)==='custom'&&Array.isArray(t.repeatDates)){const key=[...t.repeatDates].sort().find(key=>key>=base&&isScheduled(t,key)&&!occurrenceDone(t,key));return key?occurrenceFor(t,key,false):null}
    const d=fromDate(base>t.date?base:t.date);for(let i=0;i<370;i++){const key=fmtDate(d);if(isScheduled(t,key)&&!occurrenceDone(t,key))return occurrenceFor(t,key,false);if(t.endDate&&key>t.endDate)break;d.setDate(d.getDate()+1)}return null;
  }
  function opViewTasks(){
    const today=fmtDate(new Date()),q=normalizeSearch($('searchInput').value);let items=[];
    if(summaryFilter){items=dayOccurrences(today).filter(t=>summaryFilter==='completed'?t.done:summaryFilter==='overdue'?isOverdue(t):!t.done)}
    else if(view==='day')items=dayOccurrences(selectedDate);
    else if(view==='upcoming')tasks.filter(inScope).forEach(t=>{const next=nextOpenOccurrence(t,today);if(next)items.push(next)});
    else if(view==='done')tasks.filter(inScope).forEach(t=>{if(isRecurring(t)){const keys=new Set([...(t.completedDates||[]),...opRecords.filter(r=>String(r.taskId)===String(t.id)).map(r=>r.occurrenceDate)]);keys.forEach(key=>{if(occurrenceDone(t,key))items.push(occurrenceFor(t,key,true))})}else if(occurrenceDone(t,t.date))items.push(occurrenceFor(t,t.date,true))});
    else tasks.filter(inScope).forEach(t=>{const next=nextOpenOccurrence(t,today);items.push(next||occurrenceFor(t,t.date))});
    items=items.filter(t=>(category==='all'||t.category===category)&&(!q||normalizeSearch([t.title,t.note,t.category,t.responsible,t.lotCode,t.assignmentLabel,lotOf(t)?.unit,lotOf(t)?.centerName].filter(Boolean).join(' ')).includes(q)));
    return items.sort((a,b)=>view==='done'?b.date.localeCompare(a.date)||b.time.localeCompare(a.time):a.date.localeCompare(b.date)||a.time.localeCompare(b.time));
  }
  function opSave(){
    try{agendaStore.commit({schema:2,tasks,records:opRecords,limits:opLimits,scope:{center:scopeCenter,lot:scopeLot}});if(window.TruchAppStorage)window.TruchAppStorage.afterCommit(()=>tasks.forEach(scheduleNativeReminder));else tasks.forEach(scheduleNativeReminder);return true}
    catch(e){const message=e.message||'No se pudo guardar. Revisa el almacenamiento disponible.';toast(message);if($('opError'))opError(message);return false}
  }
  async function opCommit(change){
    const backup=JSON.stringify({tasks,records:opRecords,limits:opLimits});
    try{const prepare=()=>{change();if(!opSave())throw new Error('No se pudo confirmar la operación.');return true;};if(window.TruchAppStorage)return await window.TruchAppStorage.runAsync('Guardar actividad y registros',prepare);return prepare();}catch(e){toast(e.message||'Revisa los datos antes de guardar.')}
    const old=JSON.parse(backup);tasks=old.tasks;opRecords=old.records;opLimits=old.limits;return false;
  }
  function opComplete(source,key,done=true){
    if(isRecurring(source)){const dates=new Set(source.completedDates||[]);done?dates.add(key):dates.delete(key);source.completedDates=[...dates].sort()}
    else source.done=done;
    if(done){source.completionTimes={...source.completionTimes,[key]:new Date().toISOString()}}
  }
  function opRenderScopes(){
    const centerSelect=$('scopeCenter'),lotSelect=$('scopeLot');
    centerSelect.replaceChildren(new Option('Todos los centros','all'),...centers().map(c=>new Option(c.name,c.id)));
    if(scopeCenter!=='all'&&!centers().some(c=>c.id===scopeCenter))scopeCenter='all';centerSelect.value=scopeCenter;
    const lots=lotCatalog.filter(l=>scopeCenter==='all'||l.centerId===scopeCenter);
    if(scopeLot!=='all'&&!lots.some(l=>l.id===scopeLot))scopeLot='all';
    lotSelect.replaceChildren(new Option('Todos los lotes','all'),...lots.map(l=>new Option(l.code,l.id)));lotSelect.value=scopeLot;
  }
  function opRenderStats(){
    const today=fmtDate(new Date()),items=dayOccurrences(today),done=items.filter(t=>t.done).length,overdue=items.filter(isOverdue).length;
    $('pendingCount').textContent=items.length-done;$('doneCount').textContent=done;$('overdueCount').textContent=overdue;
    $('pendingStat').setAttribute('aria-label',`${items.length-done} pendientes de hoy. Filtrar`);$('doneStat').setAttribute('aria-label',`${done} hechas de hoy. Filtrar`);$('overdueStat').setAttribute('aria-label',`${overdue} vencidas de hoy, incluidas en pendientes. Filtrar`);
    const percent=items.length?Math.round(done/items.length*100):0,circumference=2*Math.PI*29;
    $('todayProgressPercent').textContent=percent+'%';$('todayProgressCount').textContent=items.length?`${done} de ${items.length} completadas`:'Sin tareas hoy';
    $('todayProgressChart').setAttribute('aria-label',`Hoy: ${done} de ${items.length} actividades hechas, ${percent}%. ${scopeLot==='all'?'Todos los lotes seleccionados':lotCatalog.find(l=>l.id===scopeLot)?.code||''}`);
    $('todayProgressRing').style.strokeDasharray=String(circumference);$('todayProgressRing').style.strokeDashoffset=String(circumference*(1-percent/100));
  }
  function opLocation(t){const lot=lotOf(t);return lot?[lot.centerName,lot.unit,lot.code].filter(Boolean).join(' · '):[centers().find(c=>c.id===t.centerId)?.name,t.assignmentLabel||t.campaignName||'Actividad general'].filter(Boolean).join(' · ')}
  function opNumber(n,digits=1){return n===null||n===undefined||!Number.isFinite(Number(n))?'—':new Intl.NumberFormat('es-PE',{maximumFractionDigits:digits}).format(Number(n))}
  function opRecordSummary(r){
    if(!r)return 'Sin resultado vinculado';const v=r.values;
    if(r.kind==='water')return [v.temperature!==null?opNumber(v.temperature)+' °C':null,v.oxygen!==null?opNumber(v.oxygen)+' mg/L de O₂':null].filter(Boolean).join(' · ');
    if(r.kind==='feeding')return opNumber(v.quantity)+' kg ofrecidos'+(v.unitCost!==null?' · S/ '+opNumber(v.quantity*v.unitCost,2):'');
    if(r.kind==='losses')return `${opNumber(v.mortality,0)} mortalidad · ${opNumber(v.discard,0)} descarte`;
    if(r.kind==='biometry')return `${opNumber(v.weight)} g · ${v.sample} peces muestreados`;
    if(r.kind==='maintenance')return Object.values(v.checks).includes('incident')?'Revisión con incidencia':'Revisión registrada';
    return 'Resultado guardado';
  }
  function opRenderTasks(){
    const container=$('taskList');container.replaceChildren();const items=opViewTasks();renderAgendaHeading(items);
    if(summaryFilter)$('agendaTitle').textContent=summaryFilter==='completed'?'Hechas hoy':summaryFilter==='overdue'?'Vencidas hoy':'Pendientes de hoy';
    if(!items.length){opEmpty(container);return}
    const daily=view==='day'&&!summaryFilter;
    const ordered=(view==='day'||summaryFilter)?[...items].sort((a,b)=>groupRank(a)-groupRank(b)||a.time.localeCompare(b.time)):items;
    let previousGroup='',completedList=null;
    for(const t of ordered.slice(0,opTaskLimit)){
      let target=container;
      if(daily&&t.done){
        if(!completedList){
          const completed=el('details','completedGroup');completed.open=opCompletedExpanded;
          const summary=el('summary');summary.innerHTML='<span class="completedMark" aria-hidden="true">✓</span><strong>Hechas · '+items.filter(t=>t.done).length+'</strong><span class="controlChevron" aria-hidden="true">⌄</span>';
          completedList=el('div','completedList');completed.append(summary,completedList);container.appendChild(completed);
          completed.addEventListener('toggle',()=>{if(container.contains(completed))opCompletedExpanded=completed.open});
        }
        target=completedList;
      }else{
        const group=(view==='day'||summaryFilter)?groupLabel(t):'';
        if(group&&group!==previousGroup){const label=el('div','taskGroup');label.textContent=group;label.appendChild(el('span'));container.appendChild(label);previousGroup=group}
      }
      const kind=kindOf(t),record=recordFor(t),card=el('article','task opTask'+(t.done?' completed':'')+(isOverdue(t)?' overdue':''));card.dataset.taskId=String(t.id);card.dataset.occurrence=t.occurrenceDate||t.date;card.style.setProperty('--catcolor',categoryMeta[t.category]?.color||'#a5c4b0');
      const time=el('div','taskTime');time.innerHTML=`<strong>${escapeHtml(t.time)}</strong><span>${t.date===fmtDate(new Date())?'HOY':escapeHtml(dateShort(fromDate(t.date)))}</span>`;if(isOverdue(t))time.classList.add('overdueLabel');card.appendChild(time);
      const content=el('div','taskContent');const title=el('div','taskTitle');title.textContent=t.title;content.appendChild(title);const location=el('div','taskLocation');location.textContent=opLocation(t);content.appendChild(location);
      const line=el('div','taskStatusLine'),status=el('span','statusPill'+(t.done?' done':isOverdue(t)?' overdue':''));status.textContent=t.done?'Hecha':isOverdue(t)?'Vencida':'Pendiente';line.appendChild(status);
      const priorityValue=['low','normal','high'].includes(t.priority)?t.priority:'normal',priorityLabel={low:'Baja',normal:'Normal',high:'Alta'}[priorityValue],priorityBadge=el('span','taskPriorityBadge '+priorityValue);priorityBadge.textContent=priorityLabel;priorityBadge.setAttribute('aria-label','Prioridad '+priorityLabel.toLocaleLowerCase('es'));priorityBadge.title='Prioridad '+priorityLabel.toLocaleLowerCase('es');line.appendChild(priorityBadge);
      if(record){const saved=el('span','taskRecordSummary');saved.textContent=opRecordSummary(record);line.appendChild(saved)}else if(t.done&&kind!=='general'){const missing=el('span');missing.textContent='Sin resultado vinculado';line.appendChild(missing)}else if(isRecurring(t)){const repeat=el('span');repeat.textContent=repeatLabel(t);line.appendChild(repeat)}
      card.appendChild(content);const footer=el('div','taskFooter');footer.appendChild(line);
      const actions=el('div','taskActions'),primary=el('button','taskPrimary'+(record||t.done?' completeAction':''));primary.type='button';
      if(kind==='general'){
        primary.textContent=t.done?'Reabrir':'Completar';primary.setAttribute('aria-label',(t.done?'Reabrir ':'Completar ')+t.title);
        primary.addEventListener('click',async ()=>{const source=tasks.find(x=>String(x.id)===String(t.id));if(await opCommit(()=>opComplete(source,t.occurrenceDate||t.date,!t.done))){render();toast(t.done?'Actividad reabierta':'Actividad completada')}});
      }else{
        primary.textContent=record?(record.complete===false?'Completar':'Ver resultado'):t.date>fmtDate(new Date())?'Ver actividad':'Registrar';
        primary.setAttribute('aria-label',primary.textContent+': '+t.title);
        primary.addEventListener('click',()=>t.date>fmtDate(new Date())?opOpenDetail(t):opOpenRecord(t));
      }
      actions.appendChild(primary);footer.appendChild(actions);card.appendChild(footer);
      const more=el('button','taskMore','⋮');more.type='button';more.setAttribute('aria-label','Más opciones: '+t.title);more.setAttribute('aria-haspopup','dialog');more.setAttribute('aria-controls','opBackdrop');more.addEventListener('click',()=>opOpenTaskOptions(t));card.appendChild(more);target.appendChild(card);
    }
    if(ordered.length>opTaskLimit){const more=el('button','loadMoreTasks',`Ver ${Math.min(20,ordered.length-opTaskLimit)} actividades más`);more.type='button';more.addEventListener('click',()=>{opTaskLimit+=20;opRenderTasks()});container.appendChild(more)}
  }
  function opOpenTaskOptions(task){
    opOpenPanel('Opciones de la tarea',task.title,`<div class="taskOptionList"><button type="button" id="taskOptionDetails">Ver detalles <span aria-hidden="true">›</span></button><button type="button" id="taskOptionEdit">Editar tarea <span aria-hidden="true">›</span></button></div>`,'task-options');
    $('taskOptionDetails').addEventListener('click',()=>opOpenDetail(task));$('taskOptionEdit').addEventListener('click',()=>openModal(task.id));
  }
  function opSyncFilter(){
    const active=category!=='all';$('filterLabel').textContent=active?category:'Todas las áreas';$('filterCount').hidden=!active;
    $('filterBtn').classList.toggle('hasFilter',active);$('filterBtn').setAttribute('aria-label','Filtros. Área: '+(active?category:'Todas')+(active?'. 1 filtro activo.':''));
  }
  function opOpenFilters(){
    const options=[['all','Todas las áreas'],...Object.keys(categoryMeta).map(name=>[name,name])];
    opOpenPanel('Filtros de la agenda','Elige el área de las actividades que quieres ver.',`<form id="filterForm"><fieldset class="filterOptions"><legend>Área de trabajo</legend>${options.map(([value,label])=>`<label class="filterOption"><input type="radio" name="agendaArea" value="${escapeHtml(value)}"${category===value?' checked':''}><span>${escapeHtml(label)}</span></label>`).join('')}</fieldset><div class="filterActions"><button type="button" id="filterReset">Todas las áreas</button><button type="button" id="filterCancel">Cancelar</button><button type="submit" class="primary">Aplicar</button></div></form>`,'filters');
    $('filterReset').addEventListener('click',()=>{$('filterForm').querySelector('input[value="all"]').checked=true});
    $('filterCancel').addEventListener('click',()=>opClosePanel());
    $('filterForm').addEventListener('submit',e=>{e.preventDefault();category=$('filterForm').querySelector('input:checked').value;opTaskLimit=20;opCompletedExpanded=false;opClosePanel();render()});
  }
  function groupRank(t){return t.done?3:isOverdue(t)?0:t.date===fmtDate(new Date())&&new Date(t.date+'T'+t.time).getTime()-Date.now()<=7200000?1:2}
  function groupLabel(t){if(t.done)return'Hechas';if(isOverdue(t))return'Vencidas';if(t.date===fmtDate(new Date()))return groupRank(t)===1?'Ahora · próximas 2 horas':'Más tarde';return'Programadas'}
  function opCurrentTime(addMinutes=0){const d=new Date(Date.now()+addMinutes*60000);return pad(d.getHours())+':'+pad(d.getMinutes())}
  function opEmpty(container){
    const empty=el('div','empty quickStart');
    if(view==='day'&&!summaryFilter&&category==='all'&&!$('searchInput').value.trim()){
      const p=el('p');p.textContent='Sin actividades este día. Prepara tu plan de trabajo:';empty.appendChild(p);const actions=el('div','quickActions');
      [['Alimentar','feeding'],['Medir temp. y O₂','water'],['Revisar instalaciones','maintenance'],['Registrar mortalidad','losses']].forEach(([label,kind])=>{const b=el('button');b.type='button';b.textContent=label;b.addEventListener('click',()=>{openModal();$('taskTitleInput').value=label;$('taskKind').value=kind;opKindChanged()});actions.appendChild(b)});empty.appendChild(actions);
    }else{empty.innerHTML='<b>No hay actividades con estos filtros</b><p>Prueba otra búsqueda o consulta todas las actividades.</p>';const b=el('button','resetSearch','Ver todas las actividades');b.type='button';b.addEventListener('click',()=>{$('searchInput').value='';category='all';summaryFilter=null;view='all';render()});empty.appendChild(b)}
    container.appendChild(empty);
  }
  function opReadingDate(r){return new Date(r.measuredDate+'T'+r.time).getTime()}
  function latestWater(lotId){return agendaStore.waterControls().filter(r=>r.kind==='water'&&r.lotId===lotId&&opReadingDate(r)<=Date.now()).sort((a,b)=>opReadingDate(b)-opReadingDate(a)||b.savedAt.localeCompare(a.savedAt))[0]||null}
  function waterParameter(lotId,parameter){return agendaStore.waterControls().filter(r=>r.kind==='water'&&r.lotId===lotId&&r.values[parameter]!==null&&r.values[parameter]!==undefined&&opReadingDate(r)<=Date.now()).sort((a,b)=>opReadingDate(b)-opReadingDate(a)||b.savedAt.localeCompare(a.savedAt))[0]||null}
  function limitsFor(lotId){let home={};try{home=JSON.parse(localStorage.getItem('truchapp_inicio_control_v1')||'{}')}catch(_){}return window.TruchAppDecisionData.limits(home,opLimits,lotId)}
  function waterIssues(r,limits){if(!r)return[];return window.TruchAppDecisionData.issues(r.values,limits).map(issue=>(issue.parameter==='temperature'?'temperatura':'O₂')+(issue.direction==='low'?' bajo el mínimo':' sobre el máximo'));}
  function opAttentionItems(){
    const result=[],today=fmtDate(new Date());
    scopedLots().forEach(lot=>{
      const r=latestWater(lot.id),limits=limitsFor(lot.id),temperature=waterParameter(lot.id,'temperature'),oxygen=waterParameter(lot.id,'oxygen');
      const isFresh=item=>!!item&&(Date.now()-opReadingDate(item))/3600000<=limits.maxAgeHours;
      const fresh=isFresh(temperature)&&isFresh(oxygen),issues=[];
      if(isFresh(temperature))issues.push(...waterIssues({...temperature,values:{temperature:temperature.values.temperature,oxygen:null}},limits).map(text=>({text,record:temperature})));
      if(isFresh(oxygen))issues.push(...waterIssues({...oxygen,values:{temperature:null,oxygen:oxygen.values.oxygen}},limits).map(text=>({text,record:oxygen})));
      if(issues.length){const bad=issues[0].record,task=tasks.find(t=>String(t.id)===String(bad.taskId));result.push({rank:0,tone:'alert',title:'Fuera del rango configurado',text:lot.code+' · '+issues.map(i=>i.text).join(' y '),action:'Revisar',run:()=>task?opOpenDetail(occurrenceFor(task,bad.occurrenceDate)):opOpenRecord(opNewFollowup(lot,'water'))})}
      const dueWater=dayOccurrences(today).find(t=>lotOf(t)?.id===lot.id&&kindOf(t)==='water'&&isOverdue(t));
      if(dueWater)result.push({rank:2,tone:'pending',title:'Control de agua pendiente',text:lot.code+' · '+dueWater.time+' · falta registrar este control',action:'Registrar',taskId:String(dueWater.id),run:()=>opOpenRecord(dueWater)});
      else if(!fresh){const partial=r?.complete===false,source=partial?tasks.find(t=>String(t.id)===String(r.taskId)):null;result.push({rank:3,tone:'pending',title:partial?'Control de agua incompleto':r?'Medición de agua por actualizar':'Sin medición de agua',text:lot.code+' · '+(r?'última: '+dateShort(fromDate(r.measuredDate))+' '+r.time:'sin un control registrado'),action:partial?'Completar':'Medir',run:()=>opOpenRecord(source?occurrenceFor(source,r.occurrenceDate):opNewFollowup(lot,'water'))})}
    });
    dayOccurrences(today).filter(t=>isOverdue(t)&&t.priority==='high'&&kindOf(t)!=='water').forEach(t=>result.push({rank:1,tone:'pending',title:'Actividad prioritaria vencida',text:t.title+' · '+(lotOf(t)?.code||'General'),action:kindOf(t)==='general'?'Ver':'Registrar',run:()=>kindOf(t)==='general'?opOpenDetail(t):opOpenRecord(t)}));
    // Revisa hasta el día anterior: una rutina no desaparece de los pendientes al cambiar de día.
    tasks.filter(t=>inScope(t)&&t.priority==='high').forEach(t=>{let missed=null;if(!isRecurring(t)&&t.date<today&&!occurrenceDone(t,t.date))missed=t.date;else if(isRecurring(t)){const d=fromDate(today);for(let i=1;i<=7;i++){d.setDate(d.getDate()-1);const key=fmtDate(d);if(isScheduled(t,key)&&!occurrenceDone(t,key)){missed=key;break}}}if(missed)result.push({rank:1,tone:'pending',title:'Pendiente de un día anterior',text:t.title+' · '+dateShort(fromDate(missed)),action:'Ver',run:()=>opOpenDetail(occurrenceFor(t,missed))})});
    opRecords.filter(r=>r.kind==='maintenance'&&Object.values(r.values.checks||{}).includes('incident')&&!r.incidentClosed).forEach(r=>{const task=tasks.find(t=>String(t.id)===String(r.taskId));if(task&&inScope(task))result.push({rank:1,tone:'pending',title:'Incidencia de mantenimiento',text:lotCatalog.find(l=>l.id===r.lotId)?.code||task.title,action:'Revisar',run:()=>opOpenRecord(occurrenceFor(task,r.occurrenceDate))})});
    return result.sort((a,b)=>a.rank-b.rank).slice(0,3);
  }
  function opRenderAttention(){
    const panel=$('attentionList'),items=opAttentionItems();panel.replaceChildren();
    $('attentionTitle').textContent=items.length?`${items.length} ${items.length===1?'aviso requiere':'avisos requieren'} atención`:'Sin avisos prioritarios';
    const section=$('attentionTitle').closest('.attentionPanel');section.classList.toggle('quiet',!items.length);
    $('attentionDetails').hidden=!opAttentionExpanded;$('attentionToggle').innerHTML=(opAttentionExpanded?'Cerrar':'Ver')+' <span aria-hidden="true">'+(opAttentionExpanded?'⌃':'›')+'</span>';
    $('attentionToggle').setAttribute('aria-expanded',String(opAttentionExpanded));
    if(!items.length){const p=el('p','attentionQuiet','Sin pendientes prioritarios detectados en esta selección. Puedes revisar los rangos de seguimiento.');panel.appendChild(p);return}
    items.forEach(item=>{const row=el('div','attentionItem '+item.tone),copy=el('div');const title=el('strong');title.textContent=item.title;const desc=el('p');desc.textContent=item.text;copy.append(title,desc);const b=el('button');b.type='button';b.textContent=item.action;b.addEventListener('click',item.run);row.append(copy,b);panel.appendChild(row)});
  }
  function opWeekData(){const today=fromDate(fmtDate(new Date()));return Array.from({length:7},(_,i)=>{const d=new Date(today);d.setDate(d.getDate()-6+i);const key=fmtDate(d),items=dayOccurrences(key);return {key,total:items.length,done:items.filter(t=>t.done).length}})}
  function opRenderWeek(){
    const days=opWeekData(),total=days.reduce((s,d)=>s+d.total,0),done=days.reduce((s,d)=>s+d.done,0),rate=total?Math.round(done/total*100):0;
    $('weeklyRate').textContent=total?rate+'%':'—';$('weeklyCompact').textContent=total?`${done} de ${total} tareas completadas`:'Sin tareas esta semana';$('weeklyMeterFill').style.width=rate+'%';$('weeklyMeter').hidden=!total;$('weeklyRange').textContent=dateShort(fromDate(days[0].key))+' – '+dateShort(fromDate(days[6].key));$('weeklyTotals').textContent=total?`${done} de ${total} actividades hechas · ${total-done} pendientes`:'Sin actividades programadas en los últimos 7 días';
    const max=Math.max(1,...days.map(d=>d.total)),axisMax=Math.max(2,Math.ceil(max/2)*2),height=116,base=126,step=42;
    const shapes=[];for(const value of [0,axisMax/2,axisMax]){const y=base-value/axisMax*height;shapes.push(`<line x1="24" y1="${y}" x2="318" y2="${y}" stroke="#e5ece3" stroke-width="1"/><text x="18" y="${y+3}" text-anchor="end" fill="#899584" font-size="9">${value}</text>`)}
    days.forEach((d,i)=>{const x=35+i*step,h=d.total/axisMax*height,hd=d.done/axisMax*height;shapes.push(`<rect x="${x}" y="${base-h}" width="12" height="${h}" rx="3" fill="#dce8df"/><rect x="${x+14}" y="${base-hd}" width="12" height="${hd}" rx="3" fill="#43876b"/>`);if(!d.total)shapes.push(`<text x="${x+13}" y="${base-6}" text-anchor="middle" fill="#8d9988" font-size="10">—</text>`)});
    $('weeklyChart').innerHTML=`<svg class="weeklyChart" viewBox="0 0 324 136" role="img" aria-label="${done} de ${total} actividades hechas. ${days.map(d=>dateShort(fromDate(d.key))+': '+d.done+' de '+d.total).join('; ')}" xmlns="http://www.w3.org/2000/svg">${shapes.join('')}</svg>`;
    const labels=$('chartDays');labels.replaceChildren();days.forEach(d=>{const b=el('button');b.type='button';b.textContent=dateShort(fromDate(d.key));b.setAttribute('aria-label',dateLong(fromDate(d.key))+`: ${d.done} de ${d.total} hechas. Ver actividades`);b.addEventListener('click',()=>{selectedDate=d.key;summaryFilter=null;view='day';render();scrollDateIntoView(d.key,'auto',true);$('agendaSection').scrollIntoView({block:'start',behavior:'smooth'})});labels.appendChild(b)});
  }
  function agendaShellInert(value){document.querySelector('.phone > header')?.toggleAttribute('inert',value);document.getElementById('bottomNav')?.toggleAttribute('inert',value)}
  function opOpenPanel(title,subtitle,html,mode){
    const wasOpen=$('opBackdrop').classList.contains('open');if(!wasOpen)opReturnFocus=document.activeElement;
    $('modalBackdrop').classList.remove('open');$('monthPickerBackdrop').classList.remove('open');$('monthPickerBackdrop').setAttribute('aria-hidden','true');
    opPanelMode=mode||'';$('opTitle').textContent=title;$('opSubtitle').textContent=subtitle||'';$('opContent').innerHTML=html;$('opBackdrop').classList.add('open');$('opBackdrop').setAttribute('aria-hidden','false');agendaRoot.querySelector('.app').inert=true;agendaShellInert(true);
    requestAnimationFrame(()=>$('opClose').focus({preventScroll:true}));
  }
  function opClosePanel(restore=true){$('opBackdrop').classList.remove('open');$('opBackdrop').setAttribute('aria-hidden','true');agendaRoot.querySelector('.app').inert=false;agendaShellInert(false);opPanelMode='';if(restore&&opReturnFocus?.isConnected)opReturnFocus.focus({preventScroll:true})}
  function opField(id,label,type,value='',extra=''){return `<div class="opField"><label for="${id}">${label}</label><input id="${id}" type="${type}" value="${escapeHtml(value??'')}" ${extra}></div>`}
  function opSelect(id,label,options,value='',extra=''){return `<div class="opField"><label for="${id}">${label}</label><select id="${id}" ${extra}>${options.map(([v,text])=>`<option value="${escapeHtml(v)}"${String(v)===String(value)?' selected':''}>${escapeHtml(text)}</option>`).join('')}</select></div>`}
  function opError(message){const box=$('opError');if(box){box.textContent=message;box.setAttribute('tabindex','-1');box.focus({preventScroll:true});box.scrollIntoView({block:'nearest'})}}
  function opRow(label,value){return `<div class="opReadRow"><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`}
  function opNewFollowup(lot,kind){return normalizeStoredTask({id:'followup-'+cryptoId(),title:kind==='water'?'Control de agua':'Revisión de seguimiento',date:fmtDate(new Date()),time:opCurrentTime(),kind,category:opKinds[kind].category,priority:'high',assignmentType:'lot',assignmentId:lot.id,assignmentLabel:lot.code,lotId:lot.id,lotCode:lot.code,centerId:lot.centerId,reminder:false,repeat:'once'},0)}
  function opOpenDetail(task){
    const source=tasks.find(t=>String(t.id)===String(task.id))||task,record=recordFor(task),lot=lotOf(task),kind=kindOf(task),future=task.date>fmtDate(new Date());
    let rows=opRow('Programada',dateShort(fromDate(task.date))+' · '+task.time)+opRow('Ubicación',opLocation(task))+opRow('Tipo',opKinds[kind].label)+opRow('Estado',task.done?'Hecha':isOverdue(task)?'Vencida':'Pendiente');
    if(source.responsible)rows+=opRow('Responsable',source.responsible);if(isRecurring(source))rows+=opRow('Repetición',repeatLabel(source)+(source.endDate?' · hasta '+dateShort(fromDate(source.endDate)):''));if(source.plannedQuantity!==null&&source.plannedQuantity!==undefined&&kind==='feeding')rows+=opRow('Cantidad planificada',opNumber(source.plannedQuantity)+' kg');
    if(record)rows+=opRow('Resultado',opRecordSummary(record))+opRow('Control realizado',dateShort(fromDate(record.measuredDate))+' · '+record.time);if(source.note)rows+=opRow('Notas',source.note);
    const latest=lot?latestWater(lot.id):null;if(kind==='water'&&latest)rows+=opRow('Último control del lote',opRecordSummary(latest)+' · '+dateShort(fromDate(latest.measuredDate))+' '+latest.time);
    opOpenPanel(source.title,opLocation(task),`<dl class="opReadRows">${rows}</dl>${kind==='water'?'<p class="opHint">Una medición ausente es un dato pendiente. Los avisos por valores se comparan con los rangos que configures para este lote.</p>':''}<div class="opButtons"><button type="button" id="detailEdit">Editar actividad</button>${kind==='water'?'<button type="button" id="detailLimits">Rangos</button>':''}</div><div class="opButtons"><button type="button" class="primary" id="detailAction"${future?' disabled':''}>${record?'Ver / editar resultado':kind==='general'?(task.done?'Reabrir actividad':'Marcar como hecha'):opKinds[kind].action}</button></div>${future?'<p class="opHint">El resultado se registra el día de la actividad o después.</p>':''}`,'detail');
    $('detailEdit').addEventListener('click',()=>openModal(source.id));$('detailLimits')?.addEventListener('click',()=>opOpenLimits(lot?.id));$('detailAction').addEventListener('click',async ()=>{if(kind!=='general')opOpenRecord(task);else if(await opCommit(()=>opComplete(source,task.occurrenceDate||task.date,!task.done))){opClosePanel();render()}});
  }
  function opStock(productId,excludedId){return agendaStore.stock(productId,excludedId)}
  function opFishStock(lotId,excludedId){return agendaStore.fish(lotId,excludedId)}
  function opOpenRecord(task){
    if(!lotCatalog.length){toast('Crea un lote en Lotes antes de registrar un control.');return}
    const kind=kindOf(task);if(kind==='general'){opOpenDetail(task);return}if(task.date>fmtDate(new Date())){opOpenDetail(task);return}
    const key=task.occurrenceDate||task.date,existing=recordFor(task,key),lot=lotOf(task),v=existing?.values||{},now=new Date(),measuredDate=existing?.measuredDate||fmtDate(now),time=existing?.time||opCurrentTime(),id=opRecordId(task,key);
    let values='';
    if(kind==='water')values=opField('recordTemperature','Temperatura (°C)','number',v.temperature,'step="0.1" min="-5" max="50" inputmode="decimal"')+opField('recordOxygen','Oxígeno disuelto (mg/L)','number',v.oxygen,'step="0.1" min="0" max="50" inputmode="decimal"')+'<p class="opHint" style="grid-column:1/-1;margin:0">Puedes guardar un control parcial. La actividad se completa al registrar temperatura y O₂; un campo vacío permanece pendiente.</p>';
    if(kind==='feeding')values=opSelect('recordProduct','Alimento del almacén',feedProducts().map(p=>[p.id,p.name]),v.productId||feedProducts()[0]?.id||'','required')+opField('recordQuantity','Cantidad real ofrecida (kg)','number',v.quantity,'step="0.001" min="0" required inputmode="decimal"')+'<div class="opCallout" style="grid-column:1/-1;margin:0" id="feedPreview"></div>';
    if(kind==='losses')values=opField('recordMortality','Mortalidad de este control','number',v.mortality,'min="0" step="1" required inputmode="numeric"')+opField('recordDiscard','Descarte de este control','number',v.discard,'min="0" step="1" required inputmode="numeric"')+'<p class="opHint" style="grid-column:1/-1;margin:0">Escribe 0 para confirmar que no hubo bajas. No vuelvas a incluir bajas de un control anterior.</p>';
    if(kind==='biometry')values=opField('recordSample','Peces de la muestra','number',v.sample,'min="1" step="1" required inputmode="numeric"')+opField('recordWeight','Peso promedio (g)','number',v.weight,'min="0.001" step="0.001" required inputmode="decimal"')+opField('recordLength','Talla promedio (cm) · opcional','number',v.length,'min="0.1" step="0.1" inputmode="decimal"');
    if(kind==='maintenance'){
      const names=lot?.unit?.toLocaleLowerCase().includes('tanque')?['Entrada y salida de agua','Limpieza del tanque','Equipos e instrumentos']:['Mallas y estructura','Amarras y flotación','Equipos e instrumentos'];
      values=names.map((name,i)=>opSelect('recordCheck'+i,name,[['','Seleccionar'],['ok','Conforme'],['incident','Incidencia'],['na','No aplica']],v.checks?.['check'+i]||'','required')).join('');
      if(existing&&Object.values(v.checks||{}).includes('incident'))values+=`<div class="opField full"><label class="opInline"><input type="checkbox" id="recordIncidentClosed"${existing.incidentClosed?' checked':''}> Incidencia atendida</label><small>Describe en las notas la acción realizada antes de cerrar la incidencia.</small></div>`;
    }
    const lots=lotCatalog.filter(l=>!task.centerId||l.centerId===task.centerId||l.id===lot?.id);
    const context=opSelect('recordLot','Lote',[['','Seleccionar lote'],...lots.map(l=>[l.id,l.code+' · '+l.unit])],existing?.lotId||lot?.id||'','required')+opField('recordResponsible','Responsable · opcional','text',existing?.responsible||task.responsible||'','maxlength="50"');
    opOpenPanel(existing?(existing.complete===false?'Control parcial':'Resultado registrado'):opKinds[kind].action,task.title,`<form id="recordForm"><div class="opCallout"><strong>${escapeHtml(opLocation(task))}</strong>Actividad programada: ${escapeHtml(dateShort(fromDate(key)))} · ${escapeHtml(task.time)}${existing?'<br>Se actualiza este resultado; no se creará otro registro.':''}</div><div class="opGrid">${context}${opField('recordDate','Fecha del control','date',measuredDate,`required max="${fmtDate(now)}"`)}${opField('recordTime','Hora del control','time',time,'required')}${values}<div class="opField full"><label for="recordNote">Observaciones${kind==='feeding'?' · indica el motivo si ofreciste 0 kg':''}</label><textarea id="recordNote" maxlength="400" placeholder="Lo que observaste o la acción que realizaste">${escapeHtml(existing?.note||'')}</textarea></div></div><p class="opError" id="opError" role="alert"></p><div class="opButtons"><button type="button" id="recordCancel">Cerrar</button><button type="submit" class="primary">${existing?'Actualizar resultado':kind==='water'?'Guardar control':'Guardar y completar'}</button></div><p class="opSavedNote">El resultado queda vinculado a esta actividad y a su fecha programada.</p></form>`,'record');
    $('recordCancel').addEventListener('click',()=>opClosePanel());
    if(kind==='feeding'){
      const preview=()=>{const p=feedProducts().find(p=>p.id===$('recordProduct').value);if(!p){$('feedPreview').textContent='Registra un alimento y su entrada en Almacén para poder vincular esta entrega.';return}const raw=$('recordQuantity').value,qty=raw===''?null:Number(raw);$('feedPreview').innerHTML=`<strong>Stock disponible: ${opNumber(opStock(p.id,id),3)} kg</strong>Costo unitario: S/ ${opNumber(p.unitCost,2)} / kg${qty!==null?'<br>Costo estimado de este control: S/ '+opNumber(p.unitCost===null?null:qty*p.unitCost,2):''}${task.plannedQuantity!==null&&task.plannedQuantity!==undefined?'<br>Planificado: '+opNumber(task.plannedQuantity)+' kg':''}`};$('recordProduct').addEventListener('change',preview);$('recordQuantity').addEventListener('input',preview);preview();
    }
    $('recordForm').addEventListener('submit',async e=>{
      e.preventDefault();if(!$('recordForm').reportValidity())return;const chosenLot=lotCatalog.find(l=>l.id===$('recordLot').value),date=$('recordDate').value,time=$('recordTime').value,note=$('recordNote').value.trim();
      if(!chosenLot)return opError('Selecciona el lote de este control.');if(lot&&chosenLot.id!==lot.id)return opError('Este control pertenece al lote '+lot.code+'. Cambia la asignación de la actividad para otro lote.');
      const timestamp=new Date(date+'T'+time).getTime();if(!Number.isFinite(timestamp)||timestamp>Date.now()+60000)return opError('La fecha y hora del control no pueden estar en el futuro.');
      const num=id=>$(id).value.trim()===''?null:Number($(id).value),values={};
      if(kind==='water'){values.temperature=num('recordTemperature');values.oxygen=num('recordOxygen');if(values.temperature===null&&values.oxygen===null)return opError('Registra temperatura, oxígeno o ambos.');}
      if(kind==='feeding'){const p=feedProducts().find(p=>p.id===$('recordProduct').value);if(!p)return opError('Selecciona un alimento con existencias en Almacén.');values.productId=p.id;values.quantity=num('recordQuantity');values.unitCost=p.unitCost;if(values.quantity===0&&!note)return opError('Indica por qué no se ofreció alimento.');if(values.quantity>opStock(p.id,id)+1e-9)return opError('La cantidad supera el stock disponible.');}
      if(kind==='losses'){values.mortality=num('recordMortality');values.discard=num('recordDiscard');if(!Number.isInteger(values.mortality)||!Number.isInteger(values.discard))return opError('Las bajas deben ser cantidades enteras.');if(values.mortality+values.discard>opFishStock(chosenLot.id,id))return opError('Las bajas superan las existencias registradas del lote.');}
      if(kind==='biometry'){values.sample=num('recordSample');values.weight=num('recordWeight');values.length=num('recordLength');if(!Number.isInteger(values.sample)||values.sample>opFishStock(chosenLot.id,id))return opError('Revisa la cantidad de peces de la muestra.');}
      if(kind==='maintenance'){values.checks={check0:$('recordCheck0').value,check1:$('recordCheck1').value,check2:$('recordCheck2').value};if(Object.values(values.checks).includes('incident')&&!note)return opError('Describe la incidencia y la acción pendiente en las observaciones.');if($('recordIncidentClosed')?.checked&&!note)return opError('Describe cómo atendiste la incidencia.');}
      const complete=kind!=='water'||(values.temperature!==null&&values.oxygen!==null);
      const source=tasks.find(t=>String(t.id)===String(task.id));const r={id,taskId:String(task.id),occurrenceDate:key,kind,lotId:chosenLot.id,centerId:chosenLot.centerId,measuredDate:date,time,values,note,complete,responsible:$('recordResponsible').value.trim(),savedAt:new Date().toISOString(),incidentClosed:!!$('recordIncidentClosed')?.checked};
      if(await opCommit(()=>{let target=source;if(!target){target={...task};tasks.push(target)}if(!lotOf(target)&&!isRecurring(target)){Object.assign(target,{lotId:chosenLot.id,lotCode:chosenLot.code,assignmentId:chosenLot.id,assignmentType:'lot',assignmentLabel:chosenLot.code,centerId:chosenLot.centerId})}const index=opRecords.findIndex(item=>item.id===id);if(index>=0)opRecords[index]=r;else opRecords.push(r);opComplete(target,key,complete)})){opClosePanel();render();toast(!complete?'Control parcial guardado · falta un parámetro':existing?'Resultado actualizado':'Resultado guardado y actividad completada')}
    });
  }
  function opOpenLimits(preselected=scopeLot!=='all'?scopeLot:''){
    if(!lotCatalog.length){toast('Crea un lote para configurar sus rangos de seguimiento.');return}
    const chosen=preselected||scopedLots()[0]?.id||lotCatalog[0]?.id;
    opOpenPanel('Rangos de seguimiento','Configura cuándo quieres revisar un control de agua.',`<form id="limitsForm"><div class="opGrid">${opSelect('limitLot','Lote',lotCatalog.map(l=>[l.id,l.code+' · '+l.unit]),chosen)}${opField('limitAge','Antigüedad máxima del dato (h)','number',24,'min="1" max="720" step="1" required')}${opField('limitMin','Temperatura mínima (°C)','number','','step="0.1" min="-5" max="50"')}${opField('limitMax','Temperatura máxima (°C)','number','','step="0.1" min="-5" max="50"')}${opField('limitOxygen','O₂ mínimo (mg/L)','number','','step="0.1" min="0" max="50"')}</div><p class="opHint">Los rangos generales se comparten con Inicio. Los valores que guardes aquí se aplican a este lote en ambos módulos. Ajústalos a tu protocolo, etapa y sistema; un campo vacío desactiva el aviso por ese parámetro.</p><p class="opError" id="opError" role="alert"></p><div class="opButtons"><button type="button" id="limitsCancel">Cerrar</button><button type="submit" class="primary">Guardar rangos</button></div></form>`,'limits');
    const fill=()=>{const l=limitsFor($('limitLot').value);$('limitAge').value=l.maxAgeHours;$('limitMin').value=l.temperatureMin??'';$('limitMax').value=l.temperatureMax??'';$('limitOxygen').value=l.oxygenMin??''};fill();$('limitLot').addEventListener('change',fill);$('limitsCancel').addEventListener('click',()=>opClosePanel());$('limitsForm').addEventListener('submit',async e=>{e.preventDefault();if(!$('limitsForm').reportValidity())return;const number=id=>$(id).value===''?null:Number($(id).value),min=number('limitMin'),max=number('limitMax');if(min!==null&&max!==null&&min>=max)return opError('La temperatura mínima debe ser menor que la máxima.');if(await opCommit(()=>opLimits[$('limitLot').value]={temperatureMin:min,temperatureMax:max,oxygenMin:number('limitOxygen'),maxAgeHours:number('limitAge')})){opClosePanel();render();toast('Rangos guardados para este lote')}});
  }
  const routineTemplates=[
    {id:'water-am',title:'Control de agua · mañana',kind:'water',time:'06:30',priority:'high',detail:'Temperatura y O₂'},
    {id:'feed',title:'Alimentación y observación del apetito',kind:'feeding',time:'09:00',priority:'normal',detail:'Cantidad real ofrecida'},
    {id:'losses',title:'Retiro y registro de bajas',kind:'losses',time:'10:00',priority:'high',detail:'Mortalidad y descarte'},
    {id:'water-noon',title:'Control de agua · mediodía',kind:'water',time:'12:00',priority:'high',detail:'Temperatura y O₂'},
    {id:'water-pm',title:'Control de agua · tarde',kind:'water',time:'17:00',priority:'high',detail:'Temperatura y O₂'},
    {id:'maintenance',title:'Revisión de instalaciones',kind:'maintenance',time:'15:00',priority:'normal',detail:'Lista de comprobación'},
    {id:'biometry',title:'Biometría de seguimiento',kind:'biometry',time:'09:30',priority:'normal',detail:'Muestra, peso y talla',interval:'weekly'}
  ];
  function routineTitle(template,lot){
    if(template.kind==='feeding'&&String(lot.stage).toLocaleLowerCase('es').includes('alevin'))return 'Alimentación y observación del alevinaje';
    if(template.kind==='maintenance')return String(lot.unit).toLocaleLowerCase('es').includes('tanque')?'Revisión de limpieza y flujo del tanque':'Revisión de mallas, amarras y equipos';
    return template.title;
  }
  function routineDates(start,end,weekdays,interval){
    const dates=[],cursor=fromDate(start),last=fromDate(end);let guard=0;
    while(cursor<=last&&guard++<366){if(weekdays.includes(cursor.getDay()))dates.push(fmtDate(cursor));cursor.setDate(cursor.getDate()+1)}
    if(interval==='once')return dates.slice(0,1);
    if(interval==='weekly'&&dates.length)return dates.filter(key=>Math.round((fromDate(key)-fromDate(dates[0]))/86400000)%7===0);
    return dates;
  }
  function opOpenRoutines(){
    if(!lotCatalog.length){toast('Crea un lote en Lotes antes de preparar una rutina.');return}
    const start=selectedDate<fmtDate(new Date())?fmtDate(new Date()):selectedDate,end=fromDate(start);end.setDate(end.getDate()+27);
    const chosen=scopeLot!=='all'?scopeLot:scopedLots()[0]?.id||lotCatalog[0]?.id;
    opOpenPanel('Preparar una rutina','Elige el lote, las actividades y sus horarios.',`<form id="routineForm"><div class="opGrid">${opSelect('routineLot','Lote',lotCatalog.map(l=>[l.id,l.centerName+' · '+l.code]),chosen)}${opField('routineResponsible','Responsable · opcional','text','','maxlength="50"')}${opField('routineStart','Desde','date',start,'required')}${opField('routineEnd','Hasta','date',fmtDate(end),'required')}</div><p class="opHint" id="routineStage"></p><div class="routineOptions">${routineTemplates.map((t,i)=>`<div class="routineOption"><input id="routine-${t.id}" type="checkbox"${i===0?' checked':''}><label for="routine-${t.id}"><span id="routine-label-${t.id}">${escapeHtml(t.title)}</span><small>${escapeHtml(t.detail)}</small></label><input type="time" id="routine-time-${t.id}" value="${t.time}" aria-label="Hora de ${escapeHtml(t.title)}" required><select id="routine-interval-${t.id}" aria-label="Frecuencia de ${escapeHtml(t.title)}"><option value="plan">Días del plan</option><option value="weekly"${t.interval==='weekly'?' selected':''}>Cada 7 días</option><option value="once">Una vez</option></select></div>`).join('')}</div><p class="opLabel">Días de la semana</p><div class="routineDayList">${[['1','Lun'],['2','Mar'],['3','Mié'],['4','Jue'],['5','Vie'],['6','Sáb'],['0','Dom']].map(([n,label])=>`<label><input type="checkbox" name="routineWeekday" value="${n}" checked> ${label}</label>`).join('')}</div><p class="opHint">Horarios y frecuencias de ejemplo: ajústalos a tu protocolo. Para otra ronda de alimentación, crea una rutina con otra hora. La planificación no prescribe raciones.</p><p class="opHint" id="routinePreview"></p><p class="opError" id="opError" role="alert"></p><div class="opButtons"><button type="button" id="routineCancel">Cerrar</button><button type="submit" class="primary">Crear rutina</button></div></form>`,'routine');
    const preview=()=>{
      const lot=lotCatalog.find(l=>l.id===$('routineLot').value);$('routineStage').textContent=lot.stage+' · '+lot.unit+' · '+lot.centerName;
      routineTemplates.forEach(t=>$('routine-label-'+t.id).textContent=routineTitle(t,lot));
      const weekdays=[...$('routineForm').querySelectorAll('[name=routineWeekday]:checked')].map(n=>Number(n.value));
      const start=$('routineStart').value,end=$('routineEnd').value;
      const count=routineTemplates.filter(t=>$('routine-'+t.id).checked).reduce((n,t)=>n+routineDates(start,end,weekdays,$('routine-interval-'+t.id).value).length,0);
      $('routinePreview').textContent=`${count} actividades previstas. Las coincidencias existentes se conservarán.`;
    };preview();$('routineForm').addEventListener('change',preview);$('routineCancel').addEventListener('click',()=>opClosePanel());
    $('routineForm').addEventListener('submit',async e=>{
      e.preventDefault();if(!$('routineForm').reportValidity())return;
      const start=$('routineStart').value,end=$('routineEnd').value,weekdays=[...$('routineForm').querySelectorAll('[name=routineWeekday]:checked')].map(n=>Number(n.value)),templates=routineTemplates.filter(t=>$('routine-'+t.id).checked),lot=lotCatalog.find(l=>l.id===$('routineLot').value);
      if(end<start)return opError('La fecha final debe ser igual o posterior al inicio.');if(!templates.length||!weekdays.length)return opError('Selecciona al menos una actividad y un día de la semana.');
      const count=Math.round((fromDate(end)-fromDate(start))/86400000)+1;if(count>366)return opError('Prepara la rutina por un máximo de 366 días.');
      const dates=[],d=fromDate(start);for(let i=0;i<count;i++){if(weekdays.includes(d.getDay()))dates.push(fmtDate(d));d.setDate(d.getDate()+1)}if(!dates.length)return opError('El período no contiene ninguno de los días seleccionados.');
      let added=0,overlaps=0;const responsible=$('routineResponsible').value.trim();
      const prepared=templates.map(t=>({...t,title:routineTitle(t,lot),time:$('routine-time-'+t.id).value,dates:routineDates(start,end,weekdays,$('routine-interval-'+t.id).value)}));
      if(await opCommit(()=>{for(const t of prepared){const keys=t.dates.filter(key=>!tasks.some(existing=>kindOf(existing)===t.kind&&lotOf(existing)?.id===lot.id&&existing.time===t.time&&isScheduled(existing,key)));overlaps+=t.dates.length-keys.length;if(!keys.length)continue;tasks.push(normalizeStoredTask({id:'routine-'+cryptoId(),title:t.title,kind:t.kind,category:opKinds[t.kind].category,date:keys[0],time:t.time,repeat:'custom',repeatDates:keys,endDate:end,priority:t.priority,responsible,lotId:lot.id,lotCode:lot.code,assignmentType:'lot',assignmentId:lot.id,assignmentLabel:lot.code,centerId:lot.centerId,reminder:false,completedDates:[],done:false,routineId:t.id},tasks.length));added+=keys.length}})){
        opClosePanel();selectedDate=start;monthFocusDate=fromDate(start);view='day';summaryFilter=null;render();scrollDateIntoView(start,'auto',true);toast(added?`${added} actividades programadas${overlaps?' · '+overlaps+' coincidencias omitidas':''}`:'Las actividades de esa rutina ya estaban programadas');
      }
    });
  }
  function opKindChanged(){const kind=$('taskKind').value;$('taskKindPlan').hidden=kind!=='feeding';if(kind!=='general')$('taskCategory').value=opKinds[kind].category;$('taskKindHint').textContent=kind==='general'?'Se puede completar directamente.':'Al realizarla podrás guardar '+opKinds[kind].label.toLocaleLowerCase('es')+' y vincular el resultado.';}
  function opPrepareEditor(task){
    $('taskKind').value=kindOf(task);$('taskResponsible').value=task?.responsible||'';$('taskEndDate').value=task?.endDate||'';$('taskPlannedQuantity').value=task?.plannedQuantity??'';
    $('taskCenter').replaceChildren(new Option('Sin centro asignado',''),...centers().map(c=>new Option(c.name,c.id)));$('taskCenter').value=centerOf(task)||(scopeCenter==='all'?'':scopeCenter);
    if(!task&&scopeLot!=='all'){const item=availableAssignments().find(a=>a.type==='lot'&&a.id===scopeLot);if(item)setAssignment(item)}opKindChanged();if(task)$('taskCategory').value=task.category;
    const locked=!!task&&opRecords.some(r=>String(r.taskId)===String(task.id));$('taskKind').disabled=locked;$('taskDate').disabled=locked;$('taskRepeat').disabled=locked;$('lotSearchInput').disabled=locked;$('taskCenter').disabled=locked;$('clearLotAssignment').hidden=locked||!$('taskAssignmentId').value;
    $('repeatCalendarField').querySelectorAll('button:not(.repeatCalDay),input').forEach(control=>control.disabled=locked);
    if(locked)$('repeatCalendarField').querySelectorAll('.repeatCalDay').forEach(control=>control.disabled=true);
    else if($('taskRepeat').value==='custom')renderRepeatCalendar();
    $('taskKindHint').textContent=locked?'Ya tiene resultados: el tipo, lote, fecha inicial y repetición se conservan. Puedes editar el título, responsable y notas.':$('taskKindHint').textContent;
    $('deleteTaskBtn').textContent=locked&&isRecurring(task)?'Detener próximas fechas':'Eliminar';$('deleteTaskBtn').disabled=locked&&!isRecurring(task);
  }
  async function opSaveActivity(e){
    e.preventDefault();if(!$('taskForm').reportValidity())return;
    const title=$('taskTitleInput').value.trim(),kind=$('taskKind').value,assignmentType=$('taskAssignmentType').value,assignmentId=$('taskAssignmentId').value,lot=lotCatalog.find(l=>l.id===assignmentId&&assignmentType==='lot'),existing=tasks.find(t=>String(t.id)===String(editingId));
    if(!title)return;const repeat=$('taskRepeat').value,repeatDates=repeat==='custom'?selectedRepeatDates():[],date=$('taskDate').value,endDate=$('taskEndDate').value;
    if(kind!=='general'&&!lot){toast('Asigna un lote para vincular el resultado de esta actividad.');$('lotSearchInput').focus();return}
    if(endDate&&endDate<date){toast('La fecha final debe ser posterior o igual al inicio.');return}if(repeat==='custom'&&!repeatDates.length){toast('Selecciona al menos una fecha de repetición.');return}
    if(lot&&$('taskCenter').value&&$('taskCenter').value!==lot.centerId){toast('El centro seleccionado no corresponde al lote.');return}
    const assignmentLabel=$('taskAssignmentLabel').value,assignmentCampaign=$('taskAssignmentCampaign').value,planned=$('taskPlannedQuantity').value;
    const data={title,kind,date,time:$('taskTime').value,category:$('taskCategory').value,priority:$('taskPriority').value,note:$('taskNote').value.trim(),reminder:$('taskReminder').checked,repeat,repeatDates,repeatDays:[],endDate,responsible:$('taskResponsible').value.trim(),plannedQuantity:kind==='feeding'&&planned!==''?Number(planned):null,assignmentType,assignmentId,assignmentLabel,assignmentSubtitle:$('taskAssignmentSubtitle').value,assignmentCampaign,lotId:lot?.id||'',lotCode:lot?.code||'',centerId:lot?.centerId||$('taskCenter').value,campaignId:assignmentType==='campaign'?assignmentId:'',campaignName:assignmentType==='campaign'?assignmentLabel:''};
    let target;const saved=await opCommit(()=>{if(existing){Object.assign(existing,data);target=existing}else{target=normalizeStoredTask({id:cryptoId(),...data,createdAt:Date.now(),done:false,completedDates:[]},tasks.length);tasks.push(target)}});
    if(saved){selectedDate=date;monthFocusDate=fromDate(date);summaryFilter=null;view='day';closeModal();render();scrollDateIntoView(date,'auto',true);toast(existing?'Actividad actualizada':'Actividad programada')}
  }
  async function opDeleteActivity(){
    const task=tasks.find(t=>String(t.id)===String(editingId));if(!task)return;
    const hasRecords=opRecords.some(r=>String(r.taskId)===String(task.id));
    if(hasRecords){if(!isRecurring(task))return toast('Este resultado se conserva en su actividad.');if(!confirm('¿Detener las próximas fechas de esta rutina? Los resultados guardados se conservarán.'))return;const tomorrow=fromDate(fmtDate(new Date()));tomorrow.setDate(tomorrow.getDate()+1);if(await opCommit(()=>task.cancelledFrom=fmtDate(tomorrow))){closeModal();render();toast('Próximas fechas detenidas')}return}
    if(confirm('¿Eliminar esta actividad?')&&await opCommit(()=>tasks=tasks.filter(t=>String(t.id)!==String(task.id)))){closeModal();render();toast('Actividad eliminada')}
  }
  function opInit(){
    if(opBook)tasks=opBook.tasks.map(normalizeStoredTask);
    opRenderScopes();$('scopeCenter').addEventListener('change',()=>{scopeCenter=$('scopeCenter').value;scopeLot='all';opRenderScopes();opTaskLimit=20;opSave();render()});$('scopeLot').addEventListener('change',()=>{scopeLot=$('scopeLot').value;opTaskLimit=20;opSave();render()});
    $('filterBtn').addEventListener('click',opOpenFilters);$('routineBtn').addEventListener('click',opOpenRoutines);$('attentionRanges').addEventListener('click',()=>opOpenLimits());$('attentionToggle').addEventListener('click',()=>{opAttentionExpanded=!opAttentionExpanded;opRenderAttention()});$('opClose').addEventListener('click',()=>opClosePanel());$('opBackdrop').addEventListener('click',e=>{if(e.target===$('opBackdrop'))opClosePanel()});
    $('taskKind').addEventListener('change',opKindChanged);$('taskCenter').addEventListener('change',()=>{const lot=lotCatalog.find(l=>l.id===$('taskAssignmentId').value);if(lot&&lot.centerId!==$('taskCenter').value)setAssignment(null)});
    document.addEventListener('keydown',e=>{if(!$('opBackdrop').classList.contains('open'))return;if(e.key==='Escape'){e.preventDefault();opClosePanel();return}if(e.key==='Tab'){const focusables=[...$('opBackdrop').querySelectorAll('button,input,select,textarea,[tabindex="0"]')].filter(n=>!n.disabled&&n.getClientRects().length);const first=focusables[0],last=focusables.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}});
    $('weekDataBtn').addEventListener('click',()=>{const days=opWeekData();opOpenPanel('Balance semanal','Actividades según su fecha programada, en los últimos 7 días.',`<table class="weekReadTable"><thead><tr><th>Día</th><th>Programadas</th><th>Hechas</th><th>Pendientes</th></tr></thead><tbody>${days.map(d=>`<tr><td>${escapeHtml(dateShort(fromDate(d.key)))}</td><td>${d.total}</td><td>${d.done}</td><td>${d.total-d.done}</td></tr>`).join('')}</tbody></table><p class="opHint">Mide cumplimiento del trabajo. El estado del cultivo se evalúa con sus mediciones y resultados.</p><div class="opButtons"><button type="button" id="weekClose">Cerrar</button></div>`,'week');$('weekClose').addEventListener('click',()=>opClosePanel())});
    let day=fmtDate(new Date());setInterval(()=>{const today=fmtDate(new Date());if(today!==day){if(selectedDate===day)selectedDate=today;day=today}if(!$('opBackdrop').classList.contains('open')&&!$('modalBackdrop').classList.contains('open'))render()},60000);
    window.addEventListener('storage',e=>{if(e.key===OP_KEY||e.key===STORE_KEY||e.key===LOTS_KEY||e.key==='truchapp_lotes_water_quality_v1'||e.key==='truchapp_inicio_control_v1'){const saved=readOpBook();if(saved){tasks=saved.tasks.map(normalizeStoredTask);opRecords=saved.records;opLimits=saved.limits||{};render()}}});
  }
    $('addTaskBtn').addEventListener('click',()=>openModal());$('closeModal').addEventListener('click',closeModal);$('cancelModal').addEventListener('click',closeModal);$('modalBackdrop').addEventListener('click',e=>{if(e.target===$('modalBackdrop'))closeModal()});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('modalBackdrop').classList.contains('open'))closeModal()});
  $('taskRepeat').addEventListener('change',()=>{if($('taskRepeat').value==='custom'&&!repeatCalendarInitialized){const start=$('taskDate').value||selectedDate;repeatDatesSelected.add(start);const d=fromDate(start);repeatCalendarCursor=new Date(d.getFullYear(),d.getMonth(),1,12);repeatCalendarInitialized=true}updateRepeatDaysVisibility()});
  $('taskDate').addEventListener('change',()=>{const start=$('taskDate').value;if(!start)return;const d=fromDate(start);repeatCalendarCursor=new Date(d.getFullYear(),d.getMonth(),1,12);repeatDatesSelected=new Set(Array.from(repeatDatesSelected).filter(key=>key>=start));if($('taskRepeat').value==='custom')renderRepeatCalendar()});
  $('repeatCalendarPrev').addEventListener('click',()=>{repeatCalendarCursor.setMonth(repeatCalendarCursor.getMonth()-1);renderRepeatCalendar()});
  $('repeatCalendarNext').addEventListener('click',()=>{repeatCalendarCursor.setMonth(repeatCalendarCursor.getMonth()+1);renderRepeatCalendar()});
  $('clearRepeatDates').addEventListener('click',()=>{repeatDatesSelected.clear();renderRepeatCalendar()});
  $('lotSearchInput').addEventListener('focus',renderAssignmentResults);$('lotSearchInput').addEventListener('input',renderAssignmentResults);
  $('clearLotAssignment').addEventListener('click',()=>{setAssignment(null);$('lotResults').hidden=true;$('lotSearchInput').value='';});
  document.addEventListener('click',e=>{if(!$('lotResults').hidden&&!e.target.closest('.lotAssignField'))$('lotResults').hidden=true});
  $('taskForm').addEventListener('submit',opSaveActivity);
  $('deleteTaskBtn').addEventListener('click',opDeleteActivity);
  const weekCarousel=$('weekCarousel');
  $('prevWeek').addEventListener('click',()=>{const d=fromDate(selectedDate);d.setDate(d.getDate()-7);selectedDate=fmtDate(d);monthFocusDate=fromDate(selectedDate);summaryFilter=null;view='day';render();scrollDateIntoView(selectedDate,'smooth',true)});
  $('nextWeek').addEventListener('click',()=>{const d=fromDate(selectedDate);d.setDate(d.getDate()+7);selectedDate=fmtDate(d);monthFocusDate=fromDate(selectedDate);summaryFilter=null;view='day';render();scrollDateIntoView(selectedDate,'smooth',true)});
  $('monthLabel').addEventListener('click',openMonthPicker);
  $('closeMonthPicker').addEventListener('click',closeMonthPicker);$('monthPickerCancel').addEventListener('click',closeMonthPicker);
  $('monthPickerBackdrop').addEventListener('click',e=>{if(e.target===$('monthPickerBackdrop'))closeMonthPicker()});
  $('monthPickerPrev').addEventListener('click',()=>moveMonthPicker(-1));
  $('monthPickerNext').addEventListener('click',()=>moveMonthPicker(1));
  $('monthDays').addEventListener('pointerdown',startMonthSwipe);
  $('monthDays').addEventListener('pointermove',dragMonthSwipe,{passive:false});
  $('monthDays').addEventListener('pointerup',finishMonthSwipe);
  $('monthDays').addEventListener('pointercancel',cancelMonthSwipe);
  $('monthDays').addEventListener('lostpointercapture',e=>{if(e.target===$('monthDays'))cancelMonthSwipe(e)});
  $('monthDays').addEventListener('pointerleave',e=>{if(monthSwipeState?.axis!=='x')cancelMonthSwipe(e)});
  $('monthGoToday').addEventListener('click',()=>setMonthPickerDraft(fmtDate(new Date())));
  $('monthPickerAccept').addEventListener('click',()=>chooseMonthDate(monthPickerDraftDate));
  document.addEventListener('keydown',monthPickerKeydown);
  weekCarousel.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button!==0)return;stripPointer={id:e.pointerId,x:e.clientX,y:e.clientY,scrollLeft:weekCarousel.scrollLeft,moved:false}});
  weekCarousel.addEventListener('pointermove',e=>{if(!stripPointer||stripPointer.id!==e.pointerId)return;if(Math.abs(e.clientX-stripPointer.x)>8&&Math.abs(e.clientX-stripPointer.x)>Math.abs(e.clientY-stripPointer.y))stripPointer.moved=true},{passive:true});
  function finishStripPointer(e){if(!stripPointer||stripPointer.id!==e.pointerId)return;if(stripPointer.moved||Math.abs(weekCarousel.scrollLeft-stripPointer.scrollLeft)>8)suppressDateClickUntil=Date.now()+260;stripPointer=null}
  weekCarousel.addEventListener('pointerup',finishStripPointer);weekCarousel.addEventListener('pointercancel',finishStripPointer);
  weekCarousel.addEventListener('scroll',handleDateStripScroll,{passive:true});
  if(window.ResizeObserver){let previousWidth=0;const observer=new ResizeObserver(()=>{if(weekCarousel.clientWidth===previousWidth)return;previousWidth=weekCarousel.clientWidth;sizeDateStrip();if(stripInitialized)scrollDateIntoView(selectedDate,'auto',true)});observer.observe(weekCarousel)}
  $$('.viewBtn').forEach(b=>b.addEventListener('click',()=>{summaryFilter=null;view=b.dataset.view;render()}));$$('.catBtn').forEach(b=>b.addEventListener('click',()=>{category=b.dataset.category;render()}));$('searchInput').addEventListener('input',renderTasks);
  $$('.stat[data-summary-filter]').forEach(card=>{card.addEventListener('click',()=>selectSummaryFilter(card.dataset.summaryFilter));card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectSummaryFilter(card.dataset.summaryFilter)}})});
  opInit();save();render();refreshAssignmentPicker();
  window.TruchAppAgendaRender=function(){const book=readOpBook();if(book){tasks=book.tasks.map(normalizeStoredTask);opRecords=book.records;opLimits=book.limits||{}}render();refreshAssignmentPicker()};
  window.TruchAppAgendaOpenRecord=function(id,key){const book=readOpBook();tasks=book.tasks.map(normalizeStoredTask);opRecords=book.records;opLimits=book.limits||{};lotCatalog=makeLotCatalog();const task=tasks.find(t=>String(t.id)===String(id));if(!task)return false;const day=key||task.date,lot=lotOf(task);scopeLot=lot?.id||'all';scopeCenter=lot?.centerId||'all';selectedDate=day;monthFocusDate=fromDate(day);view='day';summaryFilter=null;render();scrollDateIntoView(day,'auto',true);opOpenRecord(occurrenceFor(task,day));return true};
  // Acceso desde Inicio a una actividad existente, conservando el editor de Agenda.
  window.TruchAppAgendaOpenTask=function(id){
    tasks=loadTasks();const task=tasks.find(t=>String(t.id)===String(id));
    if(!task)return false;openModal(task.id);return true;
  };
})();
