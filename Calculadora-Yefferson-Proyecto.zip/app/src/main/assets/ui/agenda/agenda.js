(()=>{
  'use strict';
  const STORE_KEY='activities';

  const TUTORIAL_KEY='truchapp_agenda_tutorial_seen_apk_v1';
  function tutorialSeen(){
    try{return localStorage.getItem(TUTORIAL_KEY)==='1'}catch(e){
      try{return sessionStorage.getItem(TUTORIAL_KEY)==='1'}catch(e2){return false}
    }
  }
  function rememberTutorial(){
    try{localStorage.setItem(TUTORIAL_KEY,'1')}catch(e){
      try{sessionStorage.setItem(TUTORIAL_KEY,'1')}catch(e2){}
    }
  }
  function closeWelcome(){
    const overlay=$('welcomeBackdrop');
    if(!overlay.classList.contains('open'))return;
    overlay.classList.remove('open');overlay.setAttribute('aria-hidden','true');document.body.style.overflow='';rememberTutorial();
  }
  function showWelcome(){
    if(tutorialSeen())return;
    const overlay=$('welcomeBackdrop');overlay.classList.add('open');overlay.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';
  }

  const agendaRoot=document.getElementById('agendaRoot');
  if(!agendaRoot)return;
  const $=id=>agendaRoot.querySelector('#'+id);
  const pad=n=>String(n).padStart(2,'0');
  const fmtDate=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  const fromDate=s=>{const [y,m,d]=s.split('-').map(Number);return new Date(y,m-1,d,12,0,0,0)};
  const startOfToday=()=>{const d=new Date();return new Date(d.getFullYear(),d.getMonth(),d.getDate(),0,0,0,0)};
  const dateLong=d=>new Intl.DateTimeFormat('es-PE',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(d);
  const dateShort=d=>new Intl.DateTimeFormat('es-PE',{day:'numeric',month:'short'}).format(d);
  const timeLabel=t=>{const [h,m]=t.split(':').map(Number);return `${pad(h)}:${pad(m)}`};
  const categoryMeta={
    'Producción':{emoji:'🐟',color:'#0d9488',bg:'#ddf5ef',ink:'#0f766e'},
    'Calidad de agua':{emoji:'💧',color:'#3988c9',bg:'#e3f1ff',ink:'#1c67a4'},
    'Estudio':{emoji:'📘',color:'#9270bd',bg:'#f0eafd',ink:'#7650a4'},
    'Personal':{emoji:'☀️',color:'#db8a3b',bg:'#fff0df',ink:'#a85c1a'},
    'Trabajo':{emoji:'🗂️',color:'#527c8c',bg:'#e8f1f4',ink:'#416675'},
    'Otro':{emoji:'✦',color:'#8b9c97',bg:'#eef3f1',ink:'#62756f'}
  };
  let selectedDate=fmtDate(new Date()),view='day',category='all',summaryFilter=null,editingId=null,toastTimer=null;
  let progressInitialized=false;
  let repeatDatesSelected=new Set(),repeatCalendarCursor=fromDate(selectedDate),repeatCalendarInitialized=false;
  let stripInitialized=false,stripReady=false,adjustingStrip=false,stripPointer=null,suppressDateClickUntil=0,monthFocusDate=fromDate(selectedDate),monthPickerCursor=new Date(new Date().getFullYear(),new Date().getMonth(),1,12,0,0,0),monthUpdateFrame=0;
  function makeDefaults(){return [];}
  function cryptoId(){return Date.now()+Math.floor(Math.random()*100000)}
  function normalizeStoredTask(source,index){
    const t=source&&typeof source==='object'?source:{};
    const priorityMap={Alta:'high',Alta:'high',Normal:'normal',Baja:'low',high:'high',normal:'normal',low:'low'};
    const assignmentType=t.assignmentType||(t.campaignId?'campaign':(t.lotId||t.lotCode?'lot':''));
    const assignmentId=String(t.assignmentId??(assignmentType==='campaign'?t.campaignId:t.lotId)??'');
    const assignmentLabel=String(t.assignmentLabel||(assignmentType==='campaign'?t.campaignName:t.lotCode)||'');
    return {...t,
      id:t.id??(Date.now()+index), title:String(t.title||t.name||''),
      date:/^\d{4}-\d{2}-\d{2}$/.test(String(t.date||''))?String(t.date):fmtDate(new Date()),
      time:/^\d{2}:\d{2}$/.test(String(t.time||''))?String(t.time):'09:00',
      category:categoryMeta[t.category]?t.category:'Producción',
      priority:priorityMap[t.priority]||'normal', note:String(t.note||''),
      reminder:t.reminder===undefined?true:!!t.reminder, repeat:t.repeat||'once',
      repeatDays:Array.isArray(t.repeatDays)?t.repeatDays:[], repeatDates:Array.isArray(t.repeatDates)?t.repeatDates:[],
      completedDates:Array.isArray(t.completedDates)?t.completedDates:[], done:!!t.done,
      assignmentType,assignmentId,assignmentLabel,
      assignmentSubtitle:String(t.assignmentSubtitle||''),assignmentCampaign:String(t.assignmentCampaign||t.lotCampaign||t.campaignName||''),
      lotId:assignmentType==='lot'?assignmentId:'',lotCode:assignmentType==='lot'?assignmentLabel:'',
      campaignId:assignmentType==='campaign'?assignmentId:'',campaignName:assignmentType==='campaign'?assignmentLabel:''
    };
  }
  function loadTasks(){
    let rows=null;
    try{const raw=localStorage.getItem(STORE_KEY);if(raw!==null){const value=JSON.parse(raw);if(Array.isArray(value))rows=value}}catch(e){}
    if((!Array.isArray(rows)||rows.length===0)&&window.AndroidAI&&typeof window.AndroidAI.getActivities==='function'){
      try{const value=JSON.parse(window.AndroidAI.getActivities()||'[]');if(Array.isArray(value)&&value.length)rows=value}catch(e){}
    }
    return (Array.isArray(rows)?rows:[]).map(normalizeStoredTask).filter(t=>t.title);
  }
  let tasks=loadTasks();
  const LOTS_KEY='truchapp_lotes_v1';
  const CAMPAIGN_KEYS=['truchapp_campaigns_v1','truchapp_campanas_v1','campaigns'];
  const normalizeSearch=value=>String(value??'').toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
  function readStoredArray(key){try{const value=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(value)?value:[]}catch(e){return []}}
  function rawLots(){
    try{if(window.TruchAppData&&typeof window.TruchAppData.getLots==='function'){const rows=window.TruchAppData.getLots();if(Array.isArray(rows))return rows}}catch(e){}
    try{if(window.AndroidAI&&typeof window.AndroidAI.getLots==='function'){const rows=JSON.parse(window.AndroidAI.getLots()||'[]');if(Array.isArray(rows))return rows}}catch(e){}
    return readStoredArray(LOTS_KEY);
  }
  function rawCampaigns(){
    try{if(window.TruchAppData&&typeof window.TruchAppData.getCampaigns==='function'){const rows=window.TruchAppData.getCampaigns();if(Array.isArray(rows))return rows}}catch(e){}
    return CAMPAIGN_KEYS.flatMap(readStoredArray);
  }
  function availableAssignments(){
    const lots=rawLots().map((lot,index)=>{
      const label=String(lot.code||lot.id||lot.name||`Lote ${index+1}`);
      const id=String(lot.id??lot.code??label);
      const campaign=String(lot.campaignName||lot.campaign||lot.campaignCode||lot.campaignLabel||'');
      const subtitle=[campaign?`Campaña ${campaign}`:'',lot.stage||lot.stageName||'',lot.unit||'',lot.origin||''].filter(Boolean).join(' · ')||'Lote registrado';
      return {id,type:'lot',label,campaign,subtitle,searchText:[label,lot.id,lot.code,lot.name,lot.stage,lot.stageName,lot.unit,lot.origin,campaign].filter(Boolean).join(' ')};
    });
    const campaigns=rawCampaigns().map((campaign,index)=>{
      const label=String(campaign.name||campaign.label||campaign.title||campaign.code||campaign.id||`Campaña ${index+1}`);
      const id=String(campaign.id??campaign.code??label);
      const subtitle=[campaign.code&&campaign.code!==label?campaign.code:'',campaign.season||campaign.period||campaign.year||'',campaign.status||''].filter(Boolean).join(' · ')||'Campaña registrada';
      return {id,type:'campaign',label,campaign:label,subtitle,searchText:[label,campaign.name,campaign.label,campaign.title,campaign.code,campaign.season,campaign.period,campaign.year,campaign.status].filter(Boolean).join(' ')};
    });
    const seen=new Set();return [...lots,...campaigns].filter(item=>{const key=item.type+':'+item.id;if(seen.has(key))return false;seen.add(key);return true});
  }
  function setAssignment(item){
    $('taskAssignmentId').value=item?.id||'';$('taskAssignmentType').value=item?.type||'';$('taskAssignmentLabel').value=item?.label||'';$('taskAssignmentSubtitle').value=item?.subtitle||'';$('taskAssignmentCampaign').value=item?.campaign||'';
    const selected=!!item;$('lotSelectionSummary').hidden=!selected;$('clearLotAssignment').hidden=!selected;
    $('lotSelectedLabel').textContent=selected?`${item.type==='campaign'?'Campaña':'Lote'}: ${item.label}`:'';$('lotSelectedSubtitle').textContent=selected?(item.subtitle||'Registro vinculado'):'';
    if(selected){$('lotResults').hidden=true;$('lotSearchInput').value='';$('lotPickerHelp').textContent='Registro vinculado a esta actividad. Pulsa “Quitar” si deseas desasignarlo.'}
    else {$('lotPickerHelp').textContent=''}
  }
  function renderAssignmentResults(){
    const box=$('lotResults');if(!box)return;const query=normalizeSearch($('lotSearchInput').value);const all=availableAssignments();const matches=all.filter(item=>!query||normalizeSearch(item.searchText).includes(query));box.innerHTML='';box.hidden=false;
    if(!matches.length){const msg=document.createElement('div');msg.className='lotNoResults';msg.textContent=all.length?'No se encontraron lotes o campañas con esa búsqueda.':'Todavía no hay lotes registrados disponibles en esta vista previa. Al abrir la agenda integrada, se consultarán los registros del módulo Lotes.';box.appendChild(msg);return}
    matches.slice(0,30).forEach(item=>{const btn=document.createElement('button');btn.type='button';btn.className='lotResult';btn.setAttribute('role','option');const main=document.createElement('span');main.className='lotResultMain';const title=document.createElement('strong');title.textContent=item.label;const sub=document.createElement('small');sub.textContent=item.subtitle;main.append(title,sub);const badge=document.createElement('span');badge.className='lotTypeBadge';badge.textContent=item.type==='campaign'?'Campaña':'Lote';btn.append(main,badge);btn.addEventListener('click',()=>{setAssignment(item);});box.appendChild(btn)});
  }
  function restoreAssignment(task){
    const type=task?.assignmentType||(task?.campaignId?'campaign':(task?.lotId||task?.lotCode?'lot':''));
    const id=String(task?.assignmentId||(type==='campaign'?(task?.campaignId||task?.campaignName):(task?.lotId||task?.lotCode))||'');
    const label=String(task?.assignmentLabel||(type==='campaign'?(task?.campaignName||id):(task?.lotCode||id))||'');
    if(!type||!id||!label){setAssignment(null);return}
    const found=availableAssignments().find(item=>item.type===type&&(item.id===id||item.label===label));
    setAssignment(found||{id,type,label,campaign:task?.assignmentCampaign||task?.lotCampaign||task?.campaignName||'',subtitle:task?.assignmentSubtitle||'Registro guardado en esta actividad'});
  }
  function refreshAssignmentPicker(){if(!$('lotSearchInput'))return;const selectedId=$('taskAssignmentId').value;const selectedType=$('taskAssignmentType').value;const selectedLabel=$('taskAssignmentLabel').value;if(selectedId&&selectedLabel){$('lotSelectionSummary').hidden=false;$('clearLotAssignment').hidden=false;$('lotSelectedLabel').textContent=`${selectedType==='campaign'?'Campaña':'Lote'}: ${selectedLabel}`;$('lotSelectedSubtitle').textContent=$('taskAssignmentSubtitle').value||'Registro vinculado'}if(document.activeElement===$('lotSearchInput')||!$('lotResults').hidden)renderAssignmentResults()}
  window.addEventListener('truchapp-lots-updated',refreshAssignmentPicker);window.addEventListener('storage',e=>{if(!e.key||e.key===LOTS_KEY||CAMPAIGN_KEYS.includes(e.key))refreshAssignmentPicker()});
  window.refreshAgendaLotOptions=refreshAssignmentPicker;
  function save(){
    const payload=JSON.stringify(tasks);
    try{localStorage.setItem(STORE_KEY,payload)}catch(e){showToast('No se pudo guardar en este dispositivo');return}
    try{if(window.AndroidAI&&typeof window.AndroidAI.saveActivities==='function')window.AndroidAI.saveActivities(payload)}catch(e){showToast('No se pudo sincronizar con el almacenamiento del teléfono')}
    try{if(typeof window.renderMemory==='function')window.renderMemory();if(typeof window.renderActivities==='function')window.renderActivities()}catch(e){}
  }
  function toast(msg){showToast(msg)}
  function showToast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2300)}
  function isOverdue(t){if(t.done)return false;const now=new Date();const today=fmtDate(now);return t.date<today||(t.date===today&&t.time<`${pad(now.getHours())}:${pad(now.getMinutes())}`)}
  function repeatType(t){return t.repeat||'once'}
  function isRecurring(t){return repeatType(t)!=='once'}
  function repeatLabel(t){const kind=repeatType(t);if(kind==='daily')return'Diariamente';if(kind==='weekdays')return'Lun. a vie.';if(kind==='custom'){if(Array.isArray(t.repeatDates))return `Personalizado (${t.repeatDates.length} fechas)`;const names=['dom','lun','mar','mié','jue','vie','sáb'];return (t.repeatDays||[]).slice().sort((a,b)=>a-b).map(n=>names[n]).join(', ')||'Personalizado'}return'Una vez'}
  function occursOnDate(t,key){if(t.done||key<t.date)return false;const kind=repeatType(t);if(kind==='once')return key===t.date;if(kind==='daily')return true;const weekday=fromDate(key).getDay();if(kind==='weekdays')return weekday>=1&&weekday<=5;if(kind==='custom'){if(Array.isArray(t.repeatDates))return t.repeatDates.includes(key);return Array.isArray(t.repeatDays)&&t.repeatDays.includes(weekday)}return key===t.date}
  function occurrenceDone(t,key){return isRecurring(t)?(Array.isArray(t.completedDates)&&t.completedDates.includes(key)):!!t.done}
  function nextReminderOccurrence(t){
    if(!t||t.done||!t.reminder||!t.date||!t.time)return null;
    const today=fmtDate(new Date()),start=t.date>today?t.date:today;const cursor=fromDate(start);
    for(let i=0;i<370;i++){
      const key=fmtDate(cursor);
      if(occursOnDate({...t,done:false},key)&&!occurrenceDone(t,key)){
        const when=new Date(key+'T'+t.time).getTime();if(Number.isFinite(when)&&when>Date.now())return {date:key,when};
      }
      cursor.setDate(cursor.getDate()+1);
    }
    return null;
  }
  function nativeReminderId(t){const value=Number(t.id);if(Number.isSafeInteger(value)&&value>0)return value;let hash=0;for(const ch of String(t.id||''))hash=(hash*31+ch.charCodeAt(0))&0x7fffffff;return hash||Date.now()}
  function scheduleNativeReminder(t){
    if(!t||!t.reminder||!window.AndroidAI||typeof window.AndroidAI.scheduleReminder!=='function')return;
    const next=nextReminderOccurrence(t);if(!next)return;
    const assigned=t.assignmentLabel||t.lotCode||t.campaignName||'';const title=t.title+(assigned?' · '+(t.assignmentType==='campaign'?'Campaña ':'Lote ')+assigned:'');
    try{window.AndroidAI.scheduleReminder(nativeReminderId(t),title,next.when)}catch(e){}
  }
  function occurrenceFor(t,key,done=occurrenceDone(t,key)){return {...t,date:key,occurrenceDate:key,done,isRepeatOccurrence:isRecurring(t)}}
  function matchesSearchAndCategory(t,q){if(category!=='all'&&t.category!==category)return false;return !q||`${t.title} ${t.note||''} ${t.category} ${t.lotCode||''} ${t.campaignName||''} ${t.assignmentLabel||''} ${t.assignmentCampaign||''}`.toLocaleLowerCase('es').includes(q)}
  function viewTasks(){
    const q=$('searchInput').value.trim().toLocaleLowerCase('es'),today=fmtDate(startOfToday()),result=[];
    for(const t of tasks){
      if(!matchesSearchAndCategory(t,q))continue;
      if(summaryFilter==='pending'){
        if(isRecurring(t)){
          if(t.done)continue;
          let found=null;
          if(repeatType(t)==='custom'&&Array.isArray(t.repeatDates)){const base=t.date<today?today:t.date;found=t.repeatDates.filter(key=>key>=base&&!occurrenceDone(t,key)).sort()[0]||null}
          else {let cursor=fromDate(t.date<today?today:t.date);for(let i=0;i<370;i++){const key=fmtDate(cursor);if(occursOnDate(t,key)&&!occurrenceDone(t,key)){found=key;break}cursor.setDate(cursor.getDate()+1)}}
          if(found)result.push(occurrenceFor(t,found,false));
        }else if(!t.done)result.push({...t,occurrenceDate:t.date,isRepeatOccurrence:false});
        continue;
      }
      if(summaryFilter==='completed'){
        if(isRecurring(t)){(t.completedDates||[]).forEach(key=>result.push(occurrenceFor(t,key,true)))}
        else if(t.done)result.push({...t,occurrenceDate:t.date,isRepeatOccurrence:false});
        continue;
      }
      if(summaryFilter==='overdue'){
        if(!t.done&&isOverdue(t))result.push({...t,occurrenceDate:t.date,isRepeatOccurrence:isRecurring(t)});
        continue;
      }
      if(view==='day'){
        if(isRecurring(t)){if(occursOnDate(t,selectedDate))result.push(occurrenceFor(t,selectedDate))}
        else if(t.date===selectedDate)result.push({...t,occurrenceDate:t.date,isRepeatOccurrence:false});
      }else if(view==='upcoming'){
        if(isRecurring(t)){
          if(t.done)continue;
          if(repeatType(t)==='custom'&&Array.isArray(t.repeatDates)){const base=t.date<today?today:t.date;const found=t.repeatDates.filter(key=>key>=base&&!occurrenceDone(t,key)).sort()[0]||null;if(found)result.push(occurrenceFor(t,found,false));continue}
          let cursor=fromDate(t.date<today?today:t.date),found=null;
          for(let i=0;i<370;i++){const key=fmtDate(cursor);if(occursOnDate(t,key)&&!occurrenceDone(t,key)){found=key;break}cursor.setDate(cursor.getDate()+1)}
          if(found)result.push(occurrenceFor(t,found,false));
        }else if(!t.done&&t.date>=today)result.push({...t,occurrenceDate:t.date,isRepeatOccurrence:false});
      }else if(view==='done'){
        if(isRecurring(t)){(t.completedDates||[]).forEach(key=>result.push(occurrenceFor(t,key,true)))}
        else if(t.done)result.push({...t,occurrenceDate:t.date,isRepeatOccurrence:false});
      }else result.push({...t,occurrenceDate:t.date,isRepeatOccurrence:isRecurring(t)});
    }
    return result.sort((a,b)=>a.date.localeCompare(b.date)||a.time.localeCompare(b.time)||(a.createdAt||0)-(b.createdAt||0));
  }
  function renderTodayProgress(){
    const today=fmtDate(new Date());let total=0,completed=0;
    for(const t of tasks){
      if(repeatType(t)==='once'){
        if(t.date===today){total++;if(t.done)completed++}
        continue;
      }
      const scheduled=occursOnDate({...t,done:false},today)||(Array.isArray(t.completedDates)&&t.completedDates.includes(today));
      if(scheduled){total++;if(occurrenceDone(t,today))completed++}
    }
    const percent=total?Math.round(completed/total*100):0;
    const chart=$('todayProgressChart'),label=$('todayProgressPercent'),ring=$('todayProgressRing');
    label.textContent=`${percent}%`;
    chart.setAttribute('aria-label',`Progreso del día de hoy: ${percent}% (${completed} de ${total} actividades completadas)`);
    const circumference=2*Math.PI*29,target=circumference*(1-percent/100);
    ring.style.strokeDasharray=String(circumference);
    if(!progressInitialized){
      progressInitialized=true;ring.style.strokeDashoffset=String(circumference);
      requestAnimationFrame(()=>{ring.style.strokeDashoffset=String(target)});
    }else ring.style.strokeDashoffset=String(target);
  }
  function renderStats(){const open=tasks.filter(t=>!t.done);$('pendingCount').textContent=open.length;$('doneCount').textContent=tasks.filter(t=>t.done).length;const overdue=open.filter(isOverdue).length;$('overdueCount').textContent=overdue;const highPriorityOverdue=open.some(t=>t.priority==='high'&&isOverdue(t));$('overdueStat').classList.toggle('has-overdue',highPriorityOverdue);renderTodayProgress()}
  const weekdayShort=['dom','lun','mar','mié','jue','vie','sáb'];
  const monthText=d=>new Intl.DateTimeFormat('es-PE',{month:'long',year:'numeric'}).format(d);
  function updateMonthLabel(){const text=monthText(monthFocusDate);$('monthLabel').textContent=text;$('monthLabel').setAttribute('aria-label',`Elegir fecha. Mes visible: ${text}`)}
  function makeDayButton(date){
    const d=fromDate(fmtDate(date)),key=fmtDate(d),btn=document.createElement('button');
    btn.type='button';btn.className='dayBtn';btn.dataset.date=key;
    btn.innerHTML=`<span class="dayName">${weekdayShort[d.getDay()]}</span><span class="dayNum">${d.getDate()}</span><span class="dayDot"></span>`;
    btn.setAttribute('aria-label',dateLong(d));btn.addEventListener('click',()=>{
      if(Date.now()<suppressDateClickUntil)return;
      selectedDate=btn.dataset.date;monthFocusDate=fromDate(selectedDate);summaryFilter=null;view='day';syncViewButtons();render();
    });
    return btn;
  }
  function updateDayButtons(){
    const today=fmtDate(new Date());
    $('weekStrip').querySelectorAll('.dayBtn').forEach(btn=>{
      const key=btn.dataset.date;btn.classList.toggle('selected',key===selectedDate);btn.classList.toggle('today',key===today);btn.classList.toggle('hasTasks',tasks.some(t=>occursOnDate(t,key)&&!occurrenceDone(t,key)));btn.setAttribute('aria-pressed',String(key===selectedDate));
    });
  }
  function appendDates(count=21){
    let last=fromDate($('weekStrip').lastElementChild.dataset.date);const fragment=document.createDocumentFragment();
    for(let i=0;i<count;i++){last.setDate(last.getDate()+1);fragment.appendChild(makeDayButton(last))}
    $('weekStrip').appendChild(fragment);
  }
  function prependDates(count=21){
    const strip=$('weekStrip');let first=fromDate(strip.firstElementChild.dataset.date);const oldWidth=strip.scrollWidth,oldLeft=$('weekCarousel').scrollLeft,fragment=document.createDocumentFragment();
    for(let i=count;i>=1;i--){const d=fromDate(fmtDate(first));d.setDate(d.getDate()-i);fragment.appendChild(makeDayButton(d))}
    adjustingStrip=true;strip.insertBefore(fragment,strip.firstChild);const addedWidth=strip.scrollWidth-oldWidth;$('weekCarousel').scrollLeft=oldLeft+addedWidth;
    requestAnimationFrame(()=>{adjustingStrip=false});
  }
  function ensureDateInStrip(key){
    const strip=$('weekStrip');if(!strip.firstElementChild)return;
    let guard=0;while(key<strip.firstElementChild.dataset.date&&guard++<200)prependDates(21);
    guard=0;while(key>strip.lastElementChild.dataset.date&&guard++<200)appendDates(21);
  }
  function scrollDateIntoView(key,behavior='smooth',center=false){
    ensureDateInStrip(key);const strip=$('weekStrip'),viewport=$('weekCarousel'),btn=strip.querySelector(`[data-date="${key}"]`);if(!btn)return;
    const v=viewport.getBoundingClientRect(),b=btn.getBoundingClientRect();let target=viewport.scrollLeft;
    if(center)target+=b.left-v.left-(viewport.clientWidth-btn.offsetWidth)/2;
    else if(b.left<v.left+8)target+=b.left-v.left-8;
    else if(b.right>v.right-8)target+=b.right-v.right+8;
    if(behavior==='auto')viewport.scrollLeft=Math.max(0,target);else viewport.scrollTo({left:Math.max(0,target),behavior});
  }
  function initializeDateStrip(){
    const strip=$('weekStrip');let start=fromDate(selectedDate);start.setDate(start.getDate()-21);const fragment=document.createDocumentFragment();
    for(let i=0;i<43;i++){fragment.appendChild(makeDayButton(start));start.setDate(start.getDate()+1)}
    strip.appendChild(fragment);stripInitialized=true;updateDayButtons();updateMonthLabel();
    requestAnimationFrame(()=>{scrollDateIntoView(selectedDate,'auto',true);stripReady=true});
  }
  function renderWeek(){if(!stripInitialized)initializeDateStrip();else{updateDayButtons();updateMonthLabel()}}
  function extendDateStripIfNeeded(){
    if(!stripReady||adjustingStrip)return;const viewport=$('weekCarousel'),strip=$('weekStrip');
    if(viewport.scrollLeft<170)prependDates(21);
    else if(strip.scrollWidth-(viewport.scrollLeft+viewport.clientWidth)<360)appendDates(21);
  }
  function syncMonthToViewport(){
    const viewport=$('weekCarousel'),strip=$('weekStrip'),center=viewport.getBoundingClientRect().left+viewport.clientWidth/2;let best=null,bestDistance=Infinity;
    strip.querySelectorAll('.dayBtn').forEach(btn=>{const r=btn.getBoundingClientRect(),centerOfButton=r.left+r.width/2;const distance=Math.abs(centerOfButton-center);if(distance<bestDistance){best=btn;bestDistance=distance}});
    if(best){monthFocusDate=fromDate(best.dataset.date);updateMonthLabel()}
  }
  function handleDateStripScroll(){
    extendDateStripIfNeeded();if(monthUpdateFrame)return;monthUpdateFrame=requestAnimationFrame(()=>{monthUpdateFrame=0;syncMonthToViewport()});
  }
  function renderMonthPicker(){
    const title=monthText(monthPickerCursor),capitalized=title.charAt(0).toLocaleUpperCase('es-PE')+title.slice(1);$('monthPickerTitle').textContent=capitalized;$('monthPickerMonthLabel').textContent=title;
    const grid=$('monthDays');grid.innerHTML='';const first=new Date(monthPickerCursor.getFullYear(),monthPickerCursor.getMonth(),1,12);const start=new Date(first);start.setDate(1-first.getDay());const today=fmtDate(new Date());
    for(let i=0;i<42;i++){
      const d=new Date(start);d.setDate(start.getDate()+i);const key=fmtDate(d),button=document.createElement('button');button.type='button';button.className='monthDay'+(d.getMonth()!==monthPickerCursor.getMonth()?' otherMonth':'')+(key===selectedDate?' selected':'')+(key===today?' today':'')+(tasks.some(t=>occursOnDate(t,key)&&!occurrenceDone(t,key)?true:(t.date===key&&!t.done&&!isRecurring(t)))?' hasTasks':'');button.textContent=d.getDate();button.setAttribute('role','gridcell');button.setAttribute('aria-label',dateLong(d));button.setAttribute('aria-selected',String(key===selectedDate));
      button.addEventListener('click',()=>chooseMonthDate(key));grid.appendChild(button);
    }
  }
  function openMonthPicker(){monthPickerCursor=new Date(monthFocusDate.getFullYear(),monthFocusDate.getMonth(),1,12);renderMonthPicker();$('monthPickerBackdrop').classList.add('open');$('monthPickerBackdrop').setAttribute('aria-hidden','false');document.body.style.overflow='hidden'}
  function closeMonthPicker(){const overlay=$('monthPickerBackdrop');overlay.classList.remove('open');overlay.setAttribute('aria-hidden','true');document.body.style.overflow=''}
  function chooseMonthDate(key){selectedDate=key;monthFocusDate=fromDate(key);summaryFilter=null;view='day';closeMonthPicker();syncViewButtons();render();scrollDateIntoView(key,'smooth',true)}
  function renderAgendaHeading(items){
    let title,sub;
    if(summaryFilter==='pending'){title='Actividades pendientes';sub='Todas las actividades por completar'}
    else if(summaryFilter==='completed'){title='Actividades completadas';sub='Todas las actividades ya completadas'}
    else if(summaryFilter==='overdue'){title='Actividades vencidas';sub='Pendientes que superaron su fecha u hora'}
    else if(view==='day'){title=selectedDate===fmtDate(new Date())?'Agenda de hoy':`Agenda del ${dateLong(fromDate(selectedDate))}`;sub=selectedDate===fmtDate(new Date())?'Tus actividades para hoy':'Actividades del día seleccionado'}
    else if(view==='upcoming'){title='Próximas actividades';sub='Pendientes desde hoy en adelante'}
    else if(view==='done'){title='Actividades completadas';sub='Revisa lo que ya has logrado'}
    else{title='Todas las actividades';sub='Tu lista completa de actividades'}
    $('agendaTitle').textContent=title;$('agendaSub').textContent=sub;$('resultsLabel').textContent=`${items.length} ${items.length===1?'actividad':'actividades'}`;
  }
  function el(tag,cls,html){const node=document.createElement(tag);if(cls)node.className=cls;if(html!==undefined)node.innerHTML=html;return node}
  function renderTasks(){
    const container=$('taskList');container.innerHTML='';const items=viewTasks();renderAgendaHeading(items);
    if(!items.length){container.appendChild(el('div','empty',`<div class="emptyIcon">🗓️</div><b>No hay actividades para mostrar</b><p>Prueba otra fecha o categoría, o pulsa <strong>Nueva</strong> para crear tu primera actividad.</p>`));return}
    for(const t of items){
      const meta=categoryMeta[t.category]||categoryMeta.Otro;const card=el('article','task'+(t.done?' completed':'')+(isOverdue(t)?' overdue':''));card.style.setProperty('--catcolor',meta.color);
      const line=el('div','taskLine');card.appendChild(line);
      const time=el('div','taskTime',`<strong>${timeLabel(t.time)}</strong><span>${t.date===fmtDate(new Date())?'HOY':dateShort(fromDate(t.date)).toUpperCase()}</span>`);if(isOverdue(t))time.classList.add('overdueLabel');card.appendChild(time);
      const content=el('div','taskContent');const pill=el('div','taskCategory',`${meta.emoji} ${escapeHtml(t.category)}`);pill.style.background=meta.bg;pill.style.color=meta.ink;content.appendChild(pill);
      content.appendChild(el('div','taskTitle',escapeHtml(t.title)));
      if(t.note)content.appendChild(el('div','taskNote',escapeHtml(t.note)));
      const tags=el('div','taskMeta');let priorityText=t.priority==='high'?'▲ Prioridad alta':t.priority==='low'?'▽ Prioridad baja':'• Prioridad normal';tags.appendChild(el('span',`priority ${t.priority}`,priorityText));const assignedLabel=t.assignmentLabel||t.campaignName||t.lotCode||'';if(assignedLabel)tags.appendChild(el('span','lotAssignmentTag',`${(t.assignmentType==='campaign'||t.campaignName)?'◉ Campaña:':'🐟 Lote:'} ${escapeHtml(assignedLabel)}`));if(t.reminder)tags.appendChild(el('span','reminderMark','◷ Recordatorio'));if(isRecurring(t))tags.appendChild(el('span','reminderMark',`↻ ${escapeHtml(repeatLabel(t))}`));if(isOverdue(t))tags.appendChild(el('span','priority high','! Vencida'));content.appendChild(tags);card.appendChild(content);
      const actions=el('div','taskActions');const check=el('button','checkTask'+(t.done?' done':''),t.done?'✓':'');check.type='button';check.setAttribute('aria-label',t.done?'Marcar como pendiente':'Marcar como completada');check.addEventListener('click',e=>{e.stopPropagation();const source=tasks.find(x=>x.id===t.id)||t;if(isRecurring(source)){const key=t.occurrenceDate||t.date;const completed=new Set(source.completedDates||[]);if(completed.has(key))completed.delete(key);else completed.add(key);source.completedDates=Array.from(completed).sort()}else source.done=!source.done;save();scheduleNativeReminder(source);render();toast(t.done?'Actividad reabierta':'Actividad completada')});actions.appendChild(check);
      const edit=el('button','tinyAction','✎');edit.type='button';edit.setAttribute('aria-label','Editar actividad');edit.addEventListener('click',e=>{e.stopPropagation();openModal(t.id)});actions.appendChild(edit);card.appendChild(actions);
      card.addEventListener('click',()=>openModal(t.id));container.appendChild(card);
    }
  }
  function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
  function syncViewButtons(){$$('.viewBtn').forEach(b=>b.classList.toggle('active',!summaryFilter&&b.dataset.view===view));}
  function syncSummaryCards(){$$('.stat[data-summary-filter]').forEach(card=>{const active=card.dataset.summaryFilter===summaryFilter;card.classList.toggle('active',active);card.setAttribute('aria-pressed',String(active))})}
  function selectSummaryFilter(kind){summaryFilter=summaryFilter===kind?null:kind;if(!summaryFilter)view='day';render();requestAnimationFrame(()=>{$('agendaSection').scrollIntoView({behavior:'smooth',block:'start'})})}
  function $$(s){return Array.from(agendaRoot.querySelectorAll(s))}
  function syncCategoryButtons(){$$('.catBtn').forEach(b=>b.classList.toggle('active',b.dataset.category===category))}
  function render(){renderStats();renderWeek();renderTasks();$('heroDate').textContent=new Intl.DateTimeFormat('es-PE',{weekday:'long',day:'numeric',month:'long'}).format(new Date());syncViewButtons();syncSummaryCards();syncCategoryButtons()}
  function selectedRepeatDates(){return Array.from(repeatDatesSelected).sort()}
  function renderRepeatCalendar(){
    const label=monthText(repeatCalendarCursor),title=label.charAt(0).toLocaleUpperCase('es-PE')+label.slice(1);$('repeatCalendarMonth').textContent=title;
    const grid=$('repeatCalendarDays');grid.innerHTML='';const first=new Date(repeatCalendarCursor.getFullYear(),repeatCalendarCursor.getMonth(),1,12);const start=new Date(first);start.setDate(1-first.getDay());const today=fmtDate(new Date());const minDate=$('taskDate').value||selectedDate;
    for(let i=0;i<42;i++){const d=new Date(start);d.setDate(start.getDate()+i);const key=fmtDate(d),button=document.createElement('button');button.type='button';button.className='repeatCalDay'+(d.getMonth()!==repeatCalendarCursor.getMonth()?' otherMonth':'')+(repeatDatesSelected.has(key)?' selected':'')+(key===today?' today':'');button.textContent=d.getDate();button.setAttribute('role','gridcell');button.setAttribute('aria-label',dateLong(d));button.setAttribute('aria-pressed',String(repeatDatesSelected.has(key)));button.disabled=key<minDate;button.addEventListener('click',()=>{if(repeatDatesSelected.has(key))repeatDatesSelected.delete(key);else repeatDatesSelected.add(key);if(d.getMonth()!==repeatCalendarCursor.getMonth())repeatCalendarCursor=new Date(d.getFullYear(),d.getMonth(),1,12);renderRepeatCalendar()});grid.appendChild(button)}
    const dates=selectedRepeatDates();$('repeatCalendarSummary').textContent=dates.length?`${dates.length} fecha${dates.length===1?'':'s'}: ${dates.slice(0,4).map(key=>dateShort(fromDate(key))).join(', ')}${dates.length>4?'…':''}`:'Selecciona una o varias fechas.';
  }
  function updateRepeatDaysVisibility(){const custom=$('taskRepeat').value==='custom';$('repeatCalendarField').hidden=!custom;if(custom)renderRepeatCalendar()}
  function openModal(id=null){
    editingId=id;const t=id?tasks.find(x=>x.id===id):null;
    $('modalTitle').textContent=t?'Editar actividad':'Nueva actividad';$('taskTitleInput').value=t?.title||'';$('taskDate').value=t?.date||selectedDate;$('taskTime').value=t?.time||'09:00';$('taskCategory').value=t?.category||'Producción';$('taskPriority').value=t?.priority||'normal';$('taskNote').value=t?.note||'';$('taskReminder').checked=t?.reminder??true;$('taskRepeat').value=t?.repeat||'once';$('lotSearchInput').value='';$('lotResults').hidden=true;restoreAssignment(t);
    repeatDatesSelected=new Set(t?.repeat==='custom'&&Array.isArray(t?.repeatDates)?t.repeatDates:[]);repeatCalendarInitialized=!!(t?.repeat==='custom'&&Array.isArray(t?.repeatDates));const startDate=t?.date||selectedDate;repeatCalendarCursor=new Date(fromDate(startDate).getFullYear(),fromDate(startDate).getMonth(),1,12);if(t?.repeat==='custom'&&!Array.isArray(t?.repeatDates)){repeatDatesSelected.add(startDate);repeatCalendarInitialized=true}updateRepeatDaysVisibility();
    $('deleteTaskBtn').classList.toggle('visible',!!t);$('modalBackdrop').classList.add('open');document.body.style.overflow='hidden';setTimeout(()=>$('taskTitleInput').focus({preventScroll:true}),60)
  }
  function closeModal(){$('modalBackdrop').classList.remove('open');document.body.style.overflow='';editingId=null}

  $('welcomeClose').addEventListener('click',closeWelcome);
  $('welcomeStart').addEventListener('click',closeWelcome);
  $('welcomeBackdrop').addEventListener('click',e=>{if(e.target===$('welcomeBackdrop'))closeWelcome()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('welcomeBackdrop').classList.contains('open'))closeWelcome()});
    $('addTaskBtn').addEventListener('click',()=>openModal());$('closeModal').addEventListener('click',closeModal);$('cancelModal').addEventListener('click',closeModal);$('modalBackdrop').addEventListener('click',e=>{if(e.target===$('modalBackdrop'))closeModal()});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('modalBackdrop').classList.contains('open'))closeModal()});
  $('taskRepeat').addEventListener('change',()=>{if($('taskRepeat').value==='custom'&&!repeatCalendarInitialized){const start=$('taskDate').value||selectedDate;repeatDatesSelected.add(start);const d=fromDate(start);repeatCalendarCursor=new Date(d.getFullYear(),d.getMonth(),1,12);repeatCalendarInitialized=true}updateRepeatDaysVisibility()});
  $('taskDate').addEventListener('change',()=>{const start=$('taskDate').value;if(!start)return;const d=fromDate(start);repeatCalendarCursor=new Date(d.getFullYear(),d.getMonth(),1,12);repeatDatesSelected=new Set(Array.from(repeatDatesSelected).filter(key=>key>=start));if($('taskRepeat').value==='custom')renderRepeatCalendar()});
  $('repeatCalendarPrev').addEventListener('click',()=>{repeatCalendarCursor.setMonth(repeatCalendarCursor.getMonth()-1);renderRepeatCalendar()});
  $('repeatCalendarNext').addEventListener('click',()=>{repeatCalendarCursor.setMonth(repeatCalendarCursor.getMonth()+1);renderRepeatCalendar()});
  $('clearRepeatDates').addEventListener('click',()=>{repeatDatesSelected.clear();renderRepeatCalendar()});
  $('lotSearchInput').addEventListener('focus',renderAssignmentResults);$('lotSearchInput').addEventListener('input',renderAssignmentResults);
  $('clearLotAssignment').addEventListener('click',()=>{setAssignment(null);$('lotResults').hidden=true;$('lotSearchInput').value='';});
  document.addEventListener('click',e=>{if(!$('lotResults').hidden&&!e.target.closest('.lotAssignField'))$('lotResults').hidden=true});
  $('taskForm').addEventListener('submit',e=>{
    e.preventDefault();const title=$('taskTitleInput').value.trim();if(!title){$('taskTitleInput').focus();return}
    const repeat=$('taskRepeat').value,repeatDates=repeat==='custom'?selectedRepeatDates():[],repeatDays=[];
    if(repeat==='custom'&&!repeatDates.length){toast('Selecciona al menos una fecha en el calendario');$('repeatCalendarField').scrollIntoView({behavior:'smooth',block:'center'});return}
    const existing=editingId?tasks.find(x=>x.id===editingId):null;
    const assignmentType=$('taskAssignmentType').value,assignmentId=$('taskAssignmentId').value,assignmentLabel=$('taskAssignmentLabel').value,assignmentSubtitle=$('taskAssignmentSubtitle').value,assignmentCampaign=$('taskAssignmentCampaign').value;const data={title,date:$('taskDate').value,time:$('taskTime').value,category:$('taskCategory').value,priority:$('taskPriority').value,note:$('taskNote').value.trim(),reminder:$('taskReminder').checked,repeat,repeatDays,repeatDates,completedDates:repeat==='once'?[]:(existing?.completedDates||[]),assignmentId,assignmentType,assignmentLabel,assignmentSubtitle,assignmentCampaign,lotId:assignmentType==='lot'?assignmentId:'',lotCode:assignmentType==='lot'?assignmentLabel:'',lotCampaign:assignmentType==='lot'?assignmentCampaign:'',campaignId:assignmentType==='campaign'?assignmentId:'',campaignName:assignmentType==='campaign'?assignmentLabel:''};if(!data.date||!data.time){toast('Completa la fecha y hora');return}
    let savedTask;if(editingId){const index=tasks.findIndex(x=>String(x.id)===String(editingId));if(index>=0){tasks[index]={...tasks[index],...data};savedTask=tasks[index]}toast('Actividad actualizada')}else{savedTask={id:cryptoId(),...data,done:false,createdAt:Date.now()};tasks.push(savedTask);toast('Actividad guardada')}
    selectedDate=data.date;monthFocusDate=fromDate(selectedDate);summaryFilter=null;view='day';save();scheduleNativeReminder(savedTask);closeModal();render();scrollDateIntoView(selectedDate,'smooth',true)
  });
  $('deleteTaskBtn').addEventListener('click',()=>{if(!editingId)return;const t=tasks.find(x=>x.id===editingId);if(!t)return;if(confirm(`¿Eliminar “${t.title}”?`)){tasks=tasks.filter(x=>x.id!==editingId);save();closeModal();render();toast('Actividad eliminada')}});
  const weekCarousel=$('weekCarousel');
  $('prevWeek').addEventListener('click',()=>{const d=fromDate(selectedDate);d.setDate(d.getDate()-7);selectedDate=fmtDate(d);monthFocusDate=fromDate(selectedDate);summaryFilter=null;view='day';render();scrollDateIntoView(selectedDate,'smooth',true)});
  $('nextWeek').addEventListener('click',()=>{const d=fromDate(selectedDate);d.setDate(d.getDate()+7);selectedDate=fmtDate(d);monthFocusDate=fromDate(selectedDate);summaryFilter=null;view='day';render();scrollDateIntoView(selectedDate,'smooth',true)});
  $('monthLabel').addEventListener('click',openMonthPicker);
  $('closeMonthPicker').addEventListener('click',closeMonthPicker);$('monthPickerCancel').addEventListener('click',closeMonthPicker);
  $('monthPickerBackdrop').addEventListener('click',e=>{if(e.target===$('monthPickerBackdrop'))closeMonthPicker()});
  $('monthPickerPrev').addEventListener('click',()=>{monthPickerCursor.setMonth(monthPickerCursor.getMonth()-1);renderMonthPicker()});
  $('monthPickerNext').addEventListener('click',()=>{monthPickerCursor.setMonth(monthPickerCursor.getMonth()+1);renderMonthPicker()});
  $('monthGoToday').addEventListener('click',()=>chooseMonthDate(fmtDate(new Date())));
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('monthPickerBackdrop').classList.contains('open'))closeMonthPicker()});
  weekCarousel.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button!==0)return;stripPointer={id:e.pointerId,x:e.clientX,y:e.clientY,scrollLeft:weekCarousel.scrollLeft,moved:false}});
  weekCarousel.addEventListener('pointermove',e=>{if(!stripPointer||stripPointer.id!==e.pointerId)return;if(Math.abs(e.clientX-stripPointer.x)>8&&Math.abs(e.clientX-stripPointer.x)>Math.abs(e.clientY-stripPointer.y))stripPointer.moved=true},{passive:true});
  function finishStripPointer(e){if(!stripPointer||stripPointer.id!==e.pointerId)return;if(stripPointer.moved||Math.abs(weekCarousel.scrollLeft-stripPointer.scrollLeft)>8)suppressDateClickUntil=Date.now()+260;stripPointer=null}
  weekCarousel.addEventListener('pointerup',finishStripPointer);weekCarousel.addEventListener('pointercancel',finishStripPointer);
  weekCarousel.addEventListener('scroll',handleDateStripScroll,{passive:true});
  $$('.viewBtn').forEach(b=>b.addEventListener('click',()=>{summaryFilter=null;view=b.dataset.view;render()}));$$('.catBtn').forEach(b=>b.addEventListener('click',()=>{category=b.dataset.category;render()}));$('searchInput').addEventListener('input',renderTasks);
  $$('.stat[data-summary-filter]').forEach(card=>{card.addEventListener('click',()=>selectSummaryFilter(card.dataset.summaryFilter));card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectSummaryFilter(card.dataset.summaryFilter)}})});
  save();render();showWelcome();refreshAssignmentPicker();
  window.TruchAppAgendaRender=function(){tasks=loadTasks();render();refreshAssignmentPicker()};
})();