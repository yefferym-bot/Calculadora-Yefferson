/* Agenda: datos reales y enlace transaccional con las API existentes de Lotes/Almacén. */
(function(){
 'use strict';
 const BOOK='truchapp_agenda_workbook_v1',ACTS='activities',LOTS='truchapp_lotes_v1',WATER='truchapp_lotes_water_quality_v1',JOURNAL='truchapp_agenda_transaction_v1';
 const copy=v=>JSON.parse(JSON.stringify(v)),native=()=>window.AndroidAI||null;
 const parse=(text,fallback)=>{if(text===null)return fallback;try{return JSON.parse(text)}catch(_){throw new Error('No se pudieron leer los datos de Agenda. Conserva tu respaldo.')}};
 const read=(key,fallback)=>parse(localStorage.getItem(key),fallback),same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 const num=v=>v===null||v===undefined||v===''?null:Number.isFinite(Number(v))?Number(v):null;
 let expectedActivities,expectedBook,loadError=null;
 function restore(backup){
  for(const [key,value] of Object.entries(backup.local))value===null?localStorage.removeItem(key):localStorage.setItem(key,value);
  if(backup.nativeLots!==null&&native()?.saveLots)native().saveLots(backup.nativeLots);
  if(backup.nativeActivities!==null&&native()?.saveActivities)native().saveActivities(backup.nativeActivities);
 }
 try{const journal=read(JOURNAL,null);if(journal){restore(journal);localStorage.removeItem(JOURNAL)}}catch(e){loadError=e}
 function activities(){
  if(loadError)throw loadError;const raw=localStorage.getItem(ACTS);
  const rows=raw!==null?parse(raw,[]):native()?.getActivities?parse(native().getActivities(),[]):[];
  if(!Array.isArray(rows))throw new Error('La agenda guardada no tiene un formato válido.');return rows;
 }
 function load(){
  const rows=activities(),book=read(BOOK,null);
  if(book&&(book.schema!==2||!Array.isArray(book.records)))throw new Error('No se reconoce el formato de los resultados de Agenda.');
  expectedActivities=localStorage.getItem(ACTS);expectedBook=localStorage.getItem(BOOK);
  return {...(book||{}),schema:2,tasks:rows,records:book?.records||[],limits:book?.limits||{},scope:book?.scope||{center:'all',lot:'all'}};
 }
 function farmList(){
  const result=new Map((read('truchapp_lotes_water_farms_v1',[])||[]).map(f=>[String(f.id),{id:String(f.id),name:String(f.name||'Centro')} ]));
  (read(WATER,[])||[]).forEach(r=>{if(r.farmId&&r.farmId!=='__unassigned__'&&!result.has(String(r.farmId)))result.set(String(r.farmId),{id:String(r.farmId),name:String(r.farmName||'Centro sin ficha')})});return [...result.values()];
 }
 function catalog(){
  const rows=window.TruchAppData?.getLots?.()||[],farms=farmList(),names=new Map(farms.map(f=>[f.id,f.name])),settings=read('truchapp_inicio_control_v1',{}),water=read(WATER,[]);
  return rows.map(l=>{let center=settings.assignments?.[String(l.id)];if(center===undefined){const ids=[...new Set(water.filter(r=>String(r.lotId||'')===String(l.id)&&r.farmId&&r.farmId!=='__unassigned__').map(r=>String(r.farmId)))];center=ids.length===1?ids[0]:''}center=names.has(String(center))?String(center):'unlinked';return {...l,id:String(l.id),code:String(l.code),centerId:center,centerName:names.get(center)||'Sin centro asignado',initialFish:Number(l.initialN)||0}});
 }
 function centers(){const farms=farmList();if(catalog().some(l=>l.centerId==='unlinked'))farms.push({id:'unlinked',name:'Sin centro asignado'});return farms}
 function products(){
  const source=window.TruchAppFeeding?.snapshot?.();if(!source)return [];
  const E=window.TruchAppFeedingData;
  return source.items.filter(E.feedItem).map(p=>{const balances=E.batchBalances(source.movements,p.id),factor=E.unitKg(p),qty=balances.reduce((s,b)=>s+b.qty,0),value=balances.reduce((s,b)=>s+b.value,0);return {...p,unitCost:qty>0?value/qty/factor:null,openingStock:qty*factor}});
 }
 function stock(id,excludedRecord){const p=products().find(p=>p.id===id);if(!p)return null;const old=read(BOOK,null)?.records?.find(r=>r.id===excludedRecord&&r.kind==='feeding'&&r.values.productId===id);return p.openingStock+(old?.values.quantity||0)}
 function fish(id,excludedRecord){const lot=window.TruchAppData?.getLot?.(id);if(!lot)return 0;const old=read(BOOK,null)?.records?.find(r=>r.id===excludedRecord&&r.kind==='losses'&&String(r.lotId)===String(id));return Number(lot.fish||0)+(old?old.values.mortality+old.values.discard:0)}
 function waterControls(){
  return read(WATER,[]).map(r=>{const value=param=>num(r.params?.[param]?.value??r.params?.[param]);const temperature=value('temperature'),oxygen=value('oxygen');return {id:String(r.id),kind:'water',taskId:String(r.agendaTaskId||''),occurrenceDate:r.agendaOccurrenceDate||r.date,lotId:String(r.lotId||''),centerId:String(r.farmId||''),measuredDate:r.date,time:r.time||'00:00',values:{temperature,oxygen},complete:temperature!==null&&oxygen!==null,savedAt:r.savedAt||r.date+'T'+(r.time||'00:00'),note:r.note||''}}).filter(r=>r.values.temperature!==null||r.values.oxygen!==null);
 }
 function sourceId(record){return 'agenda:'+record.id}
 function rawInventory(){const data=read('truchapp_almacen_kardex_v1',{items:[],movements:[]});if(!Array.isArray(data.items)||!Array.isArray(data.movements))throw new Error('Revisa el formato del almacén.');return data}
 function contribute(data,record,remove){
  let day=data.daily.find(d=>d.date===record.measuredDate);const key=sourceId(record),kind=record.kind;
  if(!day){if(remove)throw new Error('El registro diario vinculado cambió en Lotes. Revisa ese día antes de corregir la tarea.');day={id:'DAY-'+data.lot.id+'-'+record.measuredDate,date:record.measuredDate,time:record.time,feed:null,mortality:null,discard:null,appetite:'',note:'',agendaEntries:{}};data.daily.push(day)}
  day.agendaEntries=day.agendaEntries||{};day.agendaBase=day.agendaBase||{};const previous=day.agendaEntries[key];
  if(remove&&!previous)throw new Error('El registro vinculado fue modificado desde Lotes. Revísalo antes de corregirlo desde Agenda.');
  const fields=kind==='losses'?['mortality','discard']:['feed'];
  for(const field of fields){
   const amount=kind==='feeding'?record.values.quantity:record.values[field],before=previous?.[field]??0,total=day[field]??0;
   if(!Object.prototype.hasOwnProperty.call(day.agendaBase,field))day.agendaBase[field]=day[field]===null||day[field]===undefined?null:Math.max(0,total-Object.values(day.agendaEntries).reduce((sum,entry)=>sum+(entry[field]??0),0));
   if(before>total+1e-6)throw new Error('Los totales del día cambiaron en Lotes. Revisa el registro antes de editarlo.');
   const remaining=Math.max(0,total-before)+(remove?0:amount),hasOther=Object.entries(day.agendaEntries).some(([id,entry])=>id!==key&&entry[field]!==undefined);
   day[field]=remove&&remaining<1e-9&&!hasOther&&day.agendaBase[field]===null?null:remaining;
  }
  if(kind==='feeding'){
   const oldLines=day.feedStock?.lines||[];day.feedStock={version:1,lines:oldLines.filter(l=>l.agendaRecordId!==record.id&&!String(l.id).startsWith(key+':'))};
   if(!remove&&record.values.quantity>0){
    const E=window.TruchAppFeedingData,inventory=rawInventory(),item=inventory.items.find(p=>p.id===record.values.productId);
    if(!item||!E.feedItem(item))throw new Error('Selecciona un alimento válido del almacén.');
    const lots=window.TruchAppData.getLots().map(l=>String(l.id)===String(data.lot.id)?{...l,detailState:data}:l);
    const movements=E.combinedMovements(inventory,lots),factor=E.unitKg(item),balances=E.batchBalances(movements,item.id,record.measuredDate).filter(b=>b.qty>1e-6&&(!b.expiry||b.expiry>=record.measuredDate)).sort((a,b)=>(a.expiry||'9999').localeCompare(b.expiry||'9999')||a.firstDate.localeCompare(b.firstDate)||a.batch.localeCompare(b.batch));
    let remaining=record.values.quantity,index=0,cost=0;
    for(const b of balances){const kg=Math.min(remaining,b.qty*factor);if(kg<=1e-6)continue;day.feedStock.lines.push({id:key+':'+index++,agendaRecordId:record.id,itemId:item.id,itemName:item.name,itemCode:item.code||'',unit:item.unit,kgPerUnit:factor,batch:b.batch,expiry:b.expiry||'',kg,unitCost:b.cost,issuedAt:Date.now()});cost+=kg/factor*b.cost;remaining-=kg;if(remaining<1e-6)break}
    if(remaining>1e-6)throw new Error('Stock insuficiente o alimento vencido para la fecha del control. Revisa las entradas del almacén.');record.values.unitCost=cost/record.values.quantity;
   }
   const linked=day.feedStock.lines.reduce((s,l)=>s+l.kg,0);if(Math.abs(linked-day.feed)>1e-6)throw new Error('Ese día contiene alimento sin desglose de almacén. Revisa su registro en Lotes antes de añadir una entrega desde Agenda.');
  }
  if(remove){delete day.agendaEntries[key]}else{day.agendaEntries[key]={kind,...Object.fromEntries(fields.map(field=>[field,kind==='feeding'?record.values.quantity:record.values[field]]))};day.time=record.time;}
 }
 function project(record,previous){
  if(!['water','losses','feeding','biometry'].includes(record.kind))return;
  const api=window.TruchAppData,id=String(record.lotId),current=api.readLotDetail(id);if(!current)throw new Error('El lote de la tarea ya no está disponible.');const data=copy(current),key=sourceId(record);
  if(previous&&String(previous.lotId)!==id)throw new Error('Conserva el lote del resultado ya registrado.');
  if(record.kind==='feeding'||record.kind==='losses'){
   if(previous)contribute(data,previous,true);contribute(data,record,false);
  }else if(record.kind==='biometry'){
   const old=data.samples.find(s=>s.id===key);if(previous&&!old)throw new Error('La biometría vinculada cambió en Lotes. Revísala antes de corregirla.');
   data.samples=data.samples.filter(s=>s.id!==key);data.samples.push({id:key,agendaRecordId:record.id,initial:false,legacyPeriod:false,date:record.measuredDate,time:record.time,weight:record.values.weight,length:record.values.length,pellet:old?.pellet??null,individualWeights:[],sampleSize:record.values.sample,mortality:0,discard:0,feed:null,note:record.note||''});
  }else{
   data.water=data.water.filter(r=>String(r.sourceReadingId||r.id)!==key);
   for(const param of ['temperature','oxygen'])if(record.values[param]!==null)data.water.push({id:key+'::'+param,sourceReadingId:key,lotId:id,param,value:record.values[param],unit:param==='temperature'?'°C':'mg/L',date:record.measuredDate,time:record.time,point:data.lot.unit,note:record.note||''});
   // La API de Lotes conserva las lecturas existentes: retirar solo esta lectura propia permite reemplazarla por el mismo id.
   localStorage.setItem(WATER,JSON.stringify(read(WATER,[]).filter(r=>String(r.id)!==key)));
  }
  api.saveLotDetail(id,data);
  if(record.kind==='water'){
   const rows=read(WATER,[]),row=rows.find(r=>String(r.id)===key);
   if(row){
    // Cada control comparte un id; la API de Lotes crea la lectura con el primer parámetro.
    // Completar aquí sus parámetros mantiene ambos valores en el registro común de agua.
    row.params=Object.fromEntries(['temperature','oxygen'].filter(param=>num(record.values[param])!==null).map(param=>[param,{value:num(record.values[param]),unit:param==='temperature'?'°C':'mg/L'}]));
    Object.assign(row,{farmId:record.centerId==='unlinked'?'':record.centerId,farmName:catalog().find(l=>l.id===id)?.centerName||'',agendaTaskId:record.taskId,agendaOccurrenceDate:record.occurrenceDate,savedAt:record.savedAt});localStorage.setItem(WATER,JSON.stringify(rows));
   }
  }
 }
 function notify(){try{window.dispatchEvent(new CustomEvent('truchapp-agenda-updated'));window.renderActivities?.();window.renderMemory?.();}catch(_){}}
 function commit(next){
  if(loadError)throw loadError;
  if(localStorage.getItem(ACTS)!==expectedActivities||localStorage.getItem(BOOK)!==expectedBook)throw new Error('La agenda cambió fuera de esta ventana. Ciérrala y vuelve a abrirla antes de guardar.');
  const old=read(BOOK,null),changed=next.records.filter(r=>!same(r,old?.records?.find(v=>v.id===r.id)));
  const backup={local:Object.fromEntries([ACTS,BOOK,LOTS,WATER].map(k=>[k,localStorage.getItem(k)])),nativeLots:native()?.getLots?native().getLots():null,nativeActivities:native()?.getActivities?native().getActivities():null};
  try{
   localStorage.setItem(JOURNAL,JSON.stringify(backup));
   for(const record of changed)project(record,old?.records?.find(r=>r.id===record.id));
   const payload=JSON.stringify(next.tasks),book=JSON.stringify({...next,schema:2,tasks:undefined});
   localStorage.setItem(ACTS,payload);localStorage.setItem(BOOK,book);
   if(native()?.saveActivities){native().saveActivities(payload);if(native().getActivities&&native().getActivities()!==payload)throw new Error('Android no confirmó el guardado de la agenda.');}
   if(localStorage.getItem(ACTS)!==payload||localStorage.getItem(BOOK)!==book)throw new Error('El dispositivo no confirmó el guardado.');
   localStorage.removeItem(JOURNAL);expectedActivities=payload;expectedBook=book;notify();return true;
  }catch(error){try{restore(backup);localStorage.removeItem(JOURNAL)}catch(_){loadError=new Error('No se pudo completar la recuperación de Agenda. Reinicia la aplicación antes de continuar.');}throw loadError||error}
 }
 window.TruchAppAgendaStore={BOOK,load,activities,catalog,centers,products,stock,fish,waterControls,commit};
})();
