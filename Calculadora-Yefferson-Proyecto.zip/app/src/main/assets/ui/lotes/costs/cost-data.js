/* Financial inputs belong to the lot; quantities remain authoritative production data. */
(function(root,factory){const F=typeof module==='object'&&module.exports?require('../../feeding/feeding-data.js'):root.TruchAppFeedingData;const api=factory(F,typeof module==='object'&&module.exports?require('./cost-ledger.js'):root.TruchAppCostLedger);if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.TruchAppLotCosts=api;})(typeof window==='object'?window:null,function(Feeding,Ledger){
 'use strict';
 const finite=v=>typeof v==='number'&&Number.isFinite(v),copy=v=>JSON.parse(JSON.stringify(v));
 const categories=[{id:'alevines',label:'Alevines',note:'Costo de la semilla de este lote',color:'#155551'},{id:'sanidad',label:'Sanidad',note:'Desinfectantes, tratamientos y materiales',color:'#368e80'},{id:'mano',label:'Mano de obra',note:'Jornales y horas dedicadas al lote',color:'#72b4a0'},{id:'energia',label:'Energía y oxígeno',note:'Luz, combustible y oxígeno',color:'#467c92'},{id:'otros',label:'Transporte y otros',note:'Fletes, hielo, empaque e imprevistos',color:'#8baeb2'},{id:'fijos',label:'Costos fijos prorrateados',note:'Solo la parte de jaulas, redes y permisos del lote',color:'#9cbaab'}];
 const metricIds=['foodCost','lotExpenses','costTotal','costFish','costBiomass','margin','economicLoss'];
 function empty(){return{version:2,seedMode:'unit',foodPrice:null,expenses:Object.fromEntries(categories.map(c=>[c.id,null])),projection:{weight:null,survival:null,futureCost:null,salePrice:null},weighted:{stockKg:null,stockPrice:null,newKg:null,newPrice:null}};}
 function validate(value){
  if(value===undefined)return;
  if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('Datos económicos del lote no válidos.');
  const validObject=v=>v&&typeof v==='object'&&!Array.isArray(v),shape=(v,keys)=>validObject(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
  if(!shape(value,value.version===2?['version','seedMode','foodPrice','expenses','projection','weighted']:['version','foodPrice','expenses','projection','weighted'])||![1,2].includes(value.version)||value.version===2&&!['unit','total'].includes(value.seedMode)||!shape(value.expenses,categories.map(c=>c.id))||!shape(value.projection,['weight','survival','futureCost','salePrice'])||!shape(value.weighted,['stockKg','stockPrice','newKg','newPrice']))throw new Error('Datos económicos del lote no válidos.');
  const amount=v=>v===null||finite(v)&&v>=0&&v<=1e12;
  if(![value.foodPrice,...Object.values(value.expenses),...Object.values(value.projection),...Object.values(value.weighted)].every(amount)||value.projection.survival!==null&&value.projection.survival>100||value.projection.weight!==null&&value.projection.weight<=0)throw new Error('Revisa los importes, el peso de cosecha y la supervivencia (0 a 100 %).');
  return value;
 }
 function read(value){if(value===undefined)return empty();validate(value);const next=copy(value);if(next.version===1){next.version=2;next.seedMode='total';}return next;}
 function average(w){
  if(!finite(w.stockKg)||!finite(w.newKg)||w.stockKg+w.newKg<=0||w.stockKg>0&&!finite(w.stockPrice)||w.newKg>0&&!finite(w.newPrice))return null;
  return(w.stockKg*(w.stockPrice??0)+w.newKg*(w.newPrice??0))/(w.stockKg+w.newKg);
 }
 function report(data,summary,movements=null,inputs=data.economics,feedOverride=null){
  const values=read(inputs),feed=feedOverride||Feeding.costReport(data,summary,movements),manualKg=feed.unpricedKg,manualKnown=manualKg>Feeding.EPS&&finite(values.foodPrice),manualCost=manualKnown?manualKg*values.foodPrice:0;
  const foodKnown=(feed.allocation?.kg>0)||feed.hasRecords&&(feed.linkedKg>Feeding.EPS||manualKnown||feed.recordedKg===0),foodCost=foodKnown?feed.cost-(feed.allocatedConsumedCost||0)+(feed.allocation?.cost||0)+manualCost:null,unpricedKg=manualKnown?0:manualKg;
  const seedTotal=finite(values.expenses.alevines)?Math.round(values.expenses.alevines*(values.seedMode==='unit'?data.lot.initialN:1)*100)/100:null,ledger=Ledger.trace(data,seedTotal,values.foodPrice,movements);
  const expenses=categories.map(c=>({...c,value:c.id==='alevines'?seedTotal:values.expenses[c.id]})),known=expenses.filter(c=>finite(c.value)),expenseTotal=known.length?known.reduce((n,c)=>n+c.value,0):null;
  const total=foodCost!==null||expenseTotal!==null?(foodCost??0)+(expenseTotal??0):null,complete=feed.hasRecords&&unpricedKg<Feeding.EPS&&known.length===categories.length;
  const fish=summary.fish,biomass=summary.biomass,weight=values.projection.weight??data.lot.targetWeight,survival=values.projection.survival;
  const harvestFish=finite(survival)?fish*survival/100:null,harvestBiomass=harvestFish!==null&&finite(weight)&&weight>0?harvestFish*weight/1000:null;
  const projectedCost=total!==null&&finite(values.projection.futureCost)?total+values.projection.futureCost:null,revenue=harvestBiomass!==null&&finite(values.projection.salePrice)?harvestBiomass*values.projection.salePrice:null,margin=projectedCost!==null&&revenue!==null?revenue-projectedCost:null;
  return{values,feed,seedTotal,ledger,legacySeed:inputs?.version===1&&finite(inputs.expenses?.alevines),manualKg,manualCost,manualKnown,foodCost,unpricedKg,expenses,expenseTotal,total,complete,knownCategories:known.length,fish,biomass,fcr:summary.fcr??null,costFish:ledger.unitCost,costBiomass:total!==null&&biomass>0?total/biomass:null,weight,survival,harvestFish,harvestBiomass,projectedCost,revenue,margin,marginPct:margin!==null&&revenue>0?margin/revenue*100:null,breakEven:projectedCost!==null&&harvestBiomass>0?projectedCost/harvestBiomass:null,average:average(values.weighted),pricing:movements?'Promedio del almacén por fecha':'Costos conservados en las entregas'};
 }
 const money=(v,d=2)=>finite(v)?'S/ '+v.toLocaleString('es-PE',{minimumFractionDigits:d,maximumFractionDigits:d}):'S/ —';
 function cards(r){return[
  {id:'foodCost',label:'Costo de alimentación',short:'Costo alimento',raw:r.foodCost,note:r.unpricedKg>Feeding.EPS?'Valoración parcial':r.feed.hasRecords?'Alimento valorizado':'Sin alimentación registrada'},
  {id:'lotExpenses',label:'Gastos del lote',short:'Gastos del lote',raw:r.expenseTotal,note:r.knownCategories+'/6 categorías · sin alimento'},
  {id:'costTotal',label:'Costo total del lote',short:'Costo total',raw:r.total,note:r.total===null?'Añadir costos y gastos':r.complete?'Según importes registrados':'Costo parcial · por completar'},
  {id:'costFish',label:'Valor por alevino vivo',short:'Valor / pez',raw:r.costFish,note:r.fish>0?(r.ledger.partial?'Base parcial · compra + alimento':'Compra + alimento asignado'):'Sin peces vivos'},
  {id:'costBiomass',label:'Costo por kg de biomasa',short:'Costo / kg',raw:r.costBiomass,note:r.biomass>0?(r.complete?'Biomasa actual estimada':'Parcial / biomasa actual'):'Sin biomasa disponible'},
  {id:'economicLoss',label:'Pérdida económica total',short:'Pérdida económica',raw:r.ledger.totalLoss,note:r.ledger.partial?'Estimación parcial de bajas':'Bajas · compra + alimento asignado'},
  {id:'margin',label:'Margen estimado',short:'Margen estimado',raw:r.margin,note:r.margin===null?'Completar la proyección':r.complete?'Escenario de cosecha':'Escenario con costos parciales'}
 ].map(c=>({...c,value:money(c.raw,c.id==='costFish'?(c.raw>0&&c.raw<.0001?6:4):2)}));}
 return{categories,metricIds,empty,validate,read,average,report,cards,money};
});
