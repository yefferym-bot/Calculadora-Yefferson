/* Dated purchase+food capital. Losses remove their share; future allocations never reprice past deaths. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.TruchAppCostLedger=api;})(typeof window==='object'?window:null,function(){
 'use strict';const finite=v=>typeof v==='number'&&Number.isFinite(v),stamp=r=>r.date+'T'+(r.time||'00:00');
 function trace(data,seedTotal,manualPrice,movements=null){
  const events=[],prices=new Map((movements||[]).map(m=>[m.id,m])),lotId=String(data.lot.id);let unknownFood=0,legacyTiming=false;
  for(const a of data.feedAllocations||[])events.push({id:'allocation:'+a.id,date:a.date,time:a.time,phase:0,kind:'allocation',label:'Alimento asignado · '+a.itemName,add:a.kg*a.unitCost/a.kgPerUnit,kg:a.kg});
  const rows=[...(data.samples||[]).filter(r=>r.legacyPeriod).map(r=>({...r,old:true})),...(data.openingBalance?[{...data.openingBalance,id:'opening-balance',old:true}]:[]),...(data.daily||[]).flatMap(d=>d.entriesVersion===1?d.entries:[d])];
  for(const r of rows){let add=0,known=false,linkedKg=0;for(const l of r.feedStock?.lines||[]){linkedKg+=l.kg;if(l.allocationId)continue;const m=prices.get('feed:'+lotId+':'+r.date+':'+l.id);add+=m?m.qty*m.unitCost:l.kg*l.unitCost/l.kgPerUnit;known=true;}
   const manual=finite(r.feed)?Math.max(0,r.feed-linkedKg):0,missing=manual>1e-6&&!finite(manualPrice);if(missing)unknownFood+=manual;else if(manual>0){add+=manual*manualPrice;known=true;}
   if(known||missing)events.push({id:'food:'+r.id,date:r.date,time:r.time||'23:59',phase:0,kind:'food',label:r.old?'Alimento anterior sin desglose':'Alimento registrado',add:known?add:null,unknown:missing,kg:manual,legacy:!!r.old});
   const mortality=Number(r.mortality)||0,discard=Number(r.discard)||0,adjustment=Number(r.stockAdjustment)||0;
   if(mortality||discard||adjustment){if(r.old)legacyTiming=true;events.push({id:'loss:'+r.id,date:r.date,time:r.time||'23:59',phase:1,kind:'loss',label:r.old?'Bajas anteriores sin desglose':'Bajas registradas',mortality,discard,adjustment,legacy:!!r.old});}
  }
  events.sort((a,b)=>stamp(a).localeCompare(stamp(b))||a.phase-b.phase||String(a.id).localeCompare(String(b.id)));
  let fish=data.lot.initialN,basis=finite(seedTotal)?seedTotal:0,known=finite(seedTotal),partial=!known,loss=0,mortalityLoss=0,discardLoss=0,unknownLoss=0,unknownMortality=0,unknownDiscard=0,pricedLoss=0,pricedMortality=0,pricedDiscard=0,adjustmentValue=0;const history=[];
  for(const e of events){const before=fish,unit=known&&fish>0?basis/fish:null;
   if(e.kind!=='loss'){if(e.unknown)partial=true;if(finite(e.add)){basis+=e.add;known=true;}history.push({...e,fishBefore:before,fishAfter:fish,unitAfter:known&&fish>0?basis/fish:null,basisAfter:basis,partial});continue;}
   const removed=e.mortality+e.discard+e.adjustment;if(removed>fish)throw Error('Las bajas superan el conteo disponible para valorar la pérdida.');
   const mortalityCost=unit===null?null:e.mortality*unit,discardCost=unit===null?null:e.discard*unit,amount=unit===null?null:(e.mortality+e.discard)*unit;
   if(amount===null){unknownLoss+=e.mortality+e.discard;unknownMortality+=e.mortality;unknownDiscard+=e.discard;}else{loss+=amount;mortalityLoss+=mortalityCost;discardLoss+=discardCost;pricedLoss+=e.mortality+e.discard;pricedMortality+=e.mortality;pricedDiscard+=e.discard;}
   if(unit!==null){basis=Math.max(0,basis-removed*unit);adjustmentValue+=e.adjustment*unit;}fish-=removed;
   history.push({...e,fishBefore:before,fishAfter:fish,unitBefore:unit,amount,mortalityCost,discardCost,basisAfter:basis,partial:partial||!!e.legacy||e.adjustment>0});if(e.adjustment)partial=true;
  }
  return{seedTotal,fish,basis:known?basis:null,unitCost:known&&fish>0?basis/fish:null,totalLoss:unknownLoss>0&&!pricedLoss?null:loss,mortalityLoss:unknownMortality>0&&!pricedMortality?null:mortalityLoss,discardLoss:unknownDiscard>0&&!pricedDiscard?null:discardLoss,unknownLoss,unknownFood,adjustmentValue,partial:partial||legacyTiming||unknownLoss>0,legacyTiming,history:history.reverse(),policy:'purchase-and-assigned-food-v1'};
 }
 return{trace};
});
