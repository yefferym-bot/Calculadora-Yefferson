/* Detalle como página de Lotes: conserva la sesión y el guardado existentes. */
(function(){
 'use strict';
 let active=null,view=null;
 const LOAD_TIMEOUT=18000;
 const loadingArt=`<div class="lotLoadingScene" aria-hidden="true"><svg viewBox="0 0 112 112" fill="none"><defs><clipPath id="lotLoadingClip"><circle cx="56" cy="56" r="45"/></clipPath></defs><circle cx="56" cy="56" r="48" class="lotLoadingRim"/><g clip-path="url(#lotLoadingClip)"><circle cx="56" cy="56" r="45" fill="#eef9f4"/><g class="lotLoadingWater lotLoadingWaterBack"><path d="M-112 63Q-84 50-56 63T0 63T56 63T112 63T168 63T224 63V112H-112Z" fill="#c7e9df"/></g><g class="lotLoadingWater lotLoadingWaterFront"><path d="M-112 72Q-84 61-56 72T0 72T56 72T112 72T168 72T224 72V112H-112Z" fill="#9ad9ca"/></g><g class="lotLoadingFish"><path d="M36 56c10-15 30-15 42 0-12 15-32 15-42 0Z" fill="#168f86"/><path d="m36 56-13-10 3 10-3 10 13-10Z" fill="#168f86"/><path d="m50 47 7-8 9 9M50 66l8 7 7-7" fill="#168f86"/><path d="M41 57c9 5 20 6 30 1" stroke="#9ce1d2" stroke-width="2" stroke-linecap="round"/><circle cx="69" cy="53" r="2" fill="#f5fffb"/><circle cx="69.5" cy="53" r=".9" fill="#19453d"/><path d="M63 49c-3 4-3 10 0 14" stroke="#106e69" stroke-width="1.5" stroke-linecap="round"/></g><circle class="lotLoadingBubble lotLoadingBubbleOne" cx="80" cy="72" r="2.8" stroke="#4eaa9d" stroke-width="1.5"/><circle class="lotLoadingBubble lotLoadingBubbleTwo" cx="34" cy="86" r="2" stroke="#6dbbab" stroke-width="1.5"/></g></svg></div>`;
 function send(message,current=active){current?.frame.contentWindow?.postMessage({...message,session:current.token},'*');}
 function clearOpening(current){clearTimeout(current.timeout);cancelAnimationFrame(current.raf);}
 function createFrame(){const frame=document.createElement('iframe');frame.title='Detalle del lote';frame.className='approvedLotFrame';frame.inert=true;frame.setAttribute('aria-hidden','true');frame.addEventListener('error',()=>{if(active?.frame===frame)fail(active);});frame.src='ui/lotes/detail/index.html';return frame;}
 function syncNavigationSpace(){
  if(!active)return;const nav=document.getElementById('bottomNav'),height=nav?.getBoundingClientRect().height;
  if(height>0)active.content.style.setProperty('--lot-detail-navigation-height',height+'px');
 }
 function setShellBusy(current,value){
  if(value){current.shellInert=[document.querySelector('.tn-main-header'),document.getElementById('bottomNav')].filter(Boolean).map(element=>[element,element.inert]);for(const [element]of current.shellInert)element.inert=true;}
  else{for(const [element,inert]of current.shellInert||[])if(element.isConnected)element.inert=inert;current.shellInert=[];}
 }
 function ensureView(){
  if(view)return view;
  const screen=document.getElementById('lotes'),content=document.querySelector('.phone>.content'),list=document.getElementById('lotesRoot');
  const overlay=document.createElement('div');overlay.className='approvedLotPage';overlay.hidden=true;overlay.inert=true;overlay.setAttribute('role','region');overlay.setAttribute('aria-label','Detalle del lote');
  overlay.innerHTML=`<section class="lotLoading" aria-label="Carga del lote"><button type="button" class="lotLoadingClose" aria-label="Volver a lotes">←</button><div class="lotLoadingCard">${loadingArt}<div role="status" aria-live="polite" aria-atomic="true"><h2 class="lotLoadingTitle">Cargando lote…</h2><p class="lotLoadingCaption">Preparando tus registros</p></div><div class="lotLoadingProgress" aria-hidden="true"><span></span></div><button type="button" class="lotLoadingRetry" hidden>Volver a intentar</button></div></section>`;
  const frame=createFrame();overlay.append(frame);screen.append(overlay);view={overlay,frame,content,screen,list,ready:false};
  if(typeof ResizeObserver==='function'){view.resizeObserver=new ResizeObserver(syncNavigationSpace);const nav=document.getElementById('bottomNav');if(nav)view.resizeObserver.observe(nav);}
  overlay.querySelector('.lotLoadingClose').addEventListener('click',close);
  overlay.querySelector('.lotLoadingRetry').addEventListener('click',()=>{if(!active||active.busy)return;const id=active.id;view.frame.remove();view.frame=createFrame();view.ready=false;view.overlay.append(view.frame);open(id);});
  return view;
 }
 function close(options={}){
  if(!active)return true;if(active.busy)return false;const current=active;clearOpening(current);send({type:'truchapp-detail-suspend'},current);active=null;current.overlay.hidden=true;current.overlay.inert=true;current.frame.inert=true;
  current.content.classList.remove('lot-detail-page-open');current.screen.classList.remove('lot-detail-active');current.list.inert=current.listInert;
  if(current.navigationHeight)current.content.style.setProperty('--lot-detail-navigation-height',current.navigationHeight);else current.content.style.removeProperty('--lot-detail-navigation-height');
  current.content.scrollTop=current.scrollTop;
  if(options.restoreFocus!==false)(current.focus?.isConnected?current.focus:document.querySelector('[data-target="lotes"]'))?.focus?.({preventScroll:true});
  return true;
 }
 function fail(current){
  if(active!==current||!current.loading)return;clearOpening(current);current.failed=true;current.overlay.classList.add('is-error');current.overlay.setAttribute('aria-busy','false');current.overlay.querySelector('.lotLoadingTitle').textContent='No se pudo abrir el lote';current.overlay.querySelector('.lotLoadingCaption').textContent='Vuelve a intentarlo para cargar tus registros.';current.overlay.querySelector('.lotLoadingRetry').hidden=false;
 }
 function feedingSnapshot(){try{return window.TruchAppFeeding.snapshot();}catch(error){return{items:[],movements:[],error:error.message};}}
 function bootWhenReady(current){if(active!==current||current.failed||current.bootSent||!current.state||!view.ready)return;current.bootSent=true;send({type:'truchapp-detail-boot',state:current.state,feeding:feedingSnapshot(),revision:current.revision},current);}
 function open(id){
  if(active?.busy)return;close();const cache=ensureView(),{overlay,frame}=cache,focus=document.activeElement;
  const {content,screen,list}=cache;
  const current={id:String(id),token:'detail-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2),frame,overlay,content,screen,list,state:null,focus,scrollTop:content.scrollTop,listInert:list.inert,navigationHeight:content.style.getPropertyValue('--lot-detail-navigation-height'),busy:false,loading:true,failed:false,bootSent:false,revision:0};active=current;
  list.inert=true;content.classList.add('lot-detail-page-open');screen.classList.add('lot-detail-active');syncNavigationSpace();
  overlay.classList.remove('is-loaded','is-error');overlay.querySelector('.lotLoadingTitle').textContent='Cargando lote…';overlay.querySelector('.lotLoadingCaption').textContent='Preparando tus registros';overlay.querySelector('.lotLoadingRetry').hidden=true;overlay.setAttribute('aria-busy','true');overlay.querySelector('.lotLoading').inert=false;overlay.querySelector('.lotLoading').removeAttribute('aria-hidden');frame.inert=true;frame.setAttribute('aria-hidden','true');overlay.hidden=false;overlay.inert=false;overlay.querySelector('.lotLoadingClose').focus({preventScroll:true});
  current.timeout=setTimeout(()=>fail(current),LOAD_TIMEOUT);
  // Permitir que la animación se pinte antes de leer y preparar los registros locales.
  current.raf=requestAnimationFrame(()=>{current.raf=requestAnimationFrame(()=>{if(active!==current||current.failed)return;try{current.state=window.TruchAppData?.readLotDetail?.(current.id);if(!current.state)throw new Error('Lote no disponible');frame.title='Detalle del lote '+current.state.lot.code;bootWhenReady(current);}catch(_){fail(current);}});});
 }
 window.addEventListener('message',async event=>{
  if(!view||event.source!==view.frame.contentWindow)return;const m=event.data;if(!m||typeof m!=='object')return;
  if(m.type==='truchapp-detail-ready'){view.ready=true;if(active)bootWhenReady(active);return;}
  if(!active||m.session!==active.token||active.failed)return;
  if(m.type==='truchapp-detail-rendered'){if(!active.loading)return;clearOpening(active);active.loading=false;active.overlay.classList.add('is-loaded');active.overlay.setAttribute('aria-busy','false');active.overlay.querySelector('.lotLoading').inert=true;active.overlay.querySelector('.lotLoading').setAttribute('aria-hidden','true');active.frame.inert=false;active.frame.removeAttribute('aria-hidden');active.frame.focus();send({type:'truchapp-detail-focus'});return;}
  if(m.type==='truchapp-detail-load-failed'){fail(active);return;}
  if(m.type==='truchapp-detail-open-stock'){if(!active.busy&&!active.loading){close();document.querySelector('.nav[data-target="almacen"]')?.click();}return;}
  if(m.type==='truchapp-detail-close'){close();return;}
  if(m.type==='truchapp-detail-delete'){if(!active.busy&&!active.loading&&window.deleteLote)window.deleteLote();return;}
  if(m.type!=='truchapp-detail-save'||active.busy||active.loading)return;
  const current=active;current.busy=true;setShellBusy(current,true);
  try{
   if(m.baseRevision!==current.revision)throw new Error('No coincide la versión del lote. Cierra la ficha y vuelve a abrirla.');
   const save=()=>window.TruchAppData.saveLotDetail(current.id,m.state);const saved=window.TruchAppStorage?await window.TruchAppStorage.runAsync('Guardar datos del lote',save):save();current.state=saved;current.revision++;
   send({type:'truchapp-detail-saved',request:m.request,revision:current.revision,state:saved,feeding:feedingSnapshot()},current);
  }catch(error){
   send({type:'truchapp-detail-failed',request:m.request,error:String(error.message||'No se pudo guardar el registro.'),feeding:feedingSnapshot()},current);
  }finally{setShellBusy(current,false);current.busy=false;}
 });
 document.addEventListener('click',event=>{if(!active||!event.target.closest('.nav[data-target]'))return;if(active.busy){event.preventDefault();event.stopImmediatePropagation();return;}close({restoreFocus:false});},true);
 document.addEventListener('keydown',event=>{if(active&&event.key==='Escape'&&!active.busy&&!document.querySelector('.tn-menu-layer.tn-open')&&!document.querySelector('dialog[open]')){event.preventDefault();close();}});
 window.addEventListener('resize',syncNavigationSpace);
 window.TruchAppLotDetailHost={open,close,isOpen:()=>!!active};
})();
