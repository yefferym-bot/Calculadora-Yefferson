/* Ventana aislada del detalle aprobado. Mensajes limitados al documento y lote abiertos. */
(function(){
 'use strict';
 let active=null;
 function send(message){active?.frame.contentWindow?.postMessage({...message,session:active.token},'*');}
 function close(){if(!active)return;const current=active;active=null;current.overlay.remove();document.body.style.overflow=current.overflow;for(const [element,inert]of current.inert)element.inert=inert;(current.focus?.isConnected?current.focus:document.querySelector('[data-target="lotes"]'))?.focus?.({preventScroll:true});}
 function open(id){close();const api=window.TruchAppData,lot=api?.readLotDetail?.(id);if(!lot)return;
  const overlay=document.createElement('div');overlay.className='approvedLotOverlay';const frame=document.createElement('iframe');frame.title='Detalle del lote '+lot.lot.code;frame.className='approvedLotFrame';frame.src='ui/lotes/detail/index.html';overlay.append(frame);
  const focus=document.activeElement;const inert=[...document.body.children].filter(e=>!['SCRIPT','STYLE','LINK'].includes(e.tagName)).map(e=>[e,e.inert]);for(const [e]of inert)e.inert=true;
  active={id:String(id),token:'detail-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2),frame,overlay,state:lot,focus,overflow:document.body.style.overflow,inert,busy:false,revision:0};document.body.style.overflow='hidden';document.body.append(overlay);frame.focus();
 }
 window.addEventListener('message',event=>{
  if(!active||event.source!==active.frame.contentWindow)return;const m=event.data;if(!m||typeof m!=='object')return;
  if(m.type==='truchapp-detail-ready'){send({type:'truchapp-detail-boot',state:active.state,revision:active.revision});return;}
  if(m.session!==active.token)return;
  if(m.type==='truchapp-detail-close'){if(!active.busy)close();return;}
  if(m.type==='truchapp-detail-delete'){if(!active.busy&&window.deleteLote)window.deleteLote();return;}
  if(m.type!=='truchapp-detail-save'||active.busy)return;
  active.busy=true;try{if(m.baseRevision!==active.revision)throw new Error('No coincide la versión del lote. Cierra la ficha y vuelve a abrirla.');window.TruchAppData.saveLotDetail(active.id,m.state);active.state=m.state;active.revision++;send({type:'truchapp-detail-saved',request:m.request,revision:active.revision});}catch(error){send({type:'truchapp-detail-failed',request:m.request,error:String(error.message||'No se pudo guardar el registro.')});}finally{if(active)active.busy=false;}
 });
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&active&&!active.busy){event.preventDefault();close();}});
 window.TruchAppLotDetailHost={open,close,isOpen:()=>!!active};
})();
