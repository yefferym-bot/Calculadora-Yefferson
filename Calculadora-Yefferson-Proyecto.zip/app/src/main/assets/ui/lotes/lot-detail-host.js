/* Apertura del detalle: carga visible, una vista reutilizable y datos nuevos en cada sesión. */
(function(){
 'use strict';
 let active=null,view=null;
 const LOAD_TIMEOUT=18000;
 const loadingArt=`<div class="lotLoadingScene" aria-hidden="true"><svg viewBox="0 0 112 112" fill="none"><defs><clipPath id="lotLoadingClip"><circle cx="56" cy="56" r="45"/></clipPath></defs><circle cx="56" cy="56" r="48" class="lotLoadingRim"/><g clip-path="url(#lotLoadingClip)"><circle cx="56" cy="56" r="45" fill="#eef9f4"/><g class="lotLoadingWater lotLoadingWaterBack"><path d="M-112 63Q-84 50-56 63T0 63T56 63T112 63T168 63T224 63V112H-112Z" fill="#c7e9df"/></g><g class="lotLoadingWater lotLoadingWaterFront"><path d="M-112 72Q-84 61-56 72T0 72T56 72T112 72T168 72T224 72V112H-112Z" fill="#9ad9ca"/></g><g class="lotLoadingFish"><path d="M36 56c10-15 30-15 42 0-12 15-32 15-42 0Z" fill="#168f86"/><path d="m36 56-13-10 3 10-3 10 13-10Z" fill="#168f86"/><path d="m50 47 7-8 9 9M50 66l8 7 7-7" fill="#168f86"/><path d="M41 57c9 5 20 6 30 1" stroke="#9ce1d2" stroke-width="2" stroke-linecap="round"/><circle cx="69" cy="53" r="2" fill="#f5fffb"/><circle cx="69.5" cy="53" r=".9" fill="#19453d"/><path d="M63 49c-3 4-3 10 0 14" stroke="#106e69" stroke-width="1.5" stroke-linecap="round"/></g><circle class="lotLoadingBubble lotLoadingBubbleOne" cx="80" cy="72" r="2.8" stroke="#4eaa9d" stroke-width="1.5"/><circle class="lotLoadingBubble lotLoadingBubbleTwo" cx="34" cy="86" r="2" stroke="#6dbbab" stroke-width="1.5"/></g></svg></div>`;
 function send(message,current=active){current?.frame.contentWindow?.postMessage({...message,session:current.token},'*');}
 function clearOpening(current){clearTimeout(current.timeout);cancelAnimationFrame(current.raf);}
 function createFrame(){const frame=document.createElement('iframe');frame.title='Detalle del lote';frame.className='approvedLotFrame';frame.inert=true;frame.setAttribute('aria-hidden','true');frame.addEventListener('error',()=>{if(active?.frame===frame)fail(active);});frame.src='ui/lotes/detail/index.html';return frame;}
 function ensureView(){
  if(view)return view;
  const overlay=document.createElement('div');overlay.className='approvedLotOverlay';overlay.hidden=true;overlay.inert=true;overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Detalle del lote');
  overlay.innerHTML=`<section class="lotLoading" aria-label="Carga del lote"><button type="button" class="lotLoadingClose" aria-label="Cerrar detalle del lote">×</button><div class="lotLoadingCard">${loadingArt}<div role="status" aria-live="polite" aria-atomic="true"><h2 class="lotLoadingTitle">Cargando lote…</h2><p class="lotLoadingCaption">Preparando tus registros</p></div><div class="lotLoadingProgress" aria-hidden="true"><span></span></div><button type="button" class="lotLoadingRetry" hidden>Volver a intentar</button></div></section>`;
  const frame=createFrame();overlay.append(frame);document.body.append(overlay);view={overlay,frame,ready:false};
  overlay.querySelector('.lotLoadingClose').addEventListener('click',close);
  overlay.querySelector('.lotLoadingRetry').addEventListener('click',()=>{if(!active||active.busy)return;const id=active.id;view.frame.remove();view.frame=createFrame();view.ready=false;view.overlay.append(view.frame);open(id);});
  return view;
 }
 function close(){
  if(!active||active.busy)return;const current=active;clearOpening(current);send({type:'truchapp-detail-suspend'},current);active=null;current.overlay.hidden=true;current.overlay.inert=true;current.frame.inert=true;document.body.style.overflow=current.overflow;
  for(const [element,inert]of current.inert)if(element.isConnected)element.inert=inert;
  (current.focus?.isConnected?current.focus:document.querySelector('[data-target="lotes"]'))?.focus?.({preventScroll:true});
 }
 function fail(current){
  if(active!==current||!current.loading)return;clearOpening(current);current.failed=true;current.overlay.classList.add('is-error');current.overlay.setAttribute('aria-busy','false');current.overlay.querySelector('.lotLoadingTitle').textContent='No se pudo abrir el lote';current.overlay.querySelector('.lotLoadingCaption').textContent='Vuelve a intentarlo para cargar tus registros.';current.overlay.querySelector('.lotLoadingRetry').hidden=false;
 }
 function feedingSnapshot(){try{return window.TruchAppFeeding.snapshot();}catch(error){return{items:[],movements:[],error:error.message};}}
 function bootWhenReady(current){if(active!==current||current.failed||current.bootSent||!current.state||!view.ready)return;current.bootSent=true;send({type:'truchapp-detail-boot',state:current.state,feeding:feedingSnapshot(),revision:current.revision},current);}
 function open(id){
  if(active?.busy)return;close();const cache=ensureView(),{overlay,frame}=cache,focus=document.activeElement;
  const inert=[...document.body.children].filter(e=>e!==overlay&&!['SCRIPT','STYLE','LINK'].includes(e.tagName)).map(e=>[e,e.inert]);for(const [e]of inert)e.inert=true;
  const current={id:String(id),token:'detail-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2),frame,overlay,state:null,focus,overflow:document.body.style.overflow,inert,busy:false,loading:true,failed:false,bootSent:false,revision:0};active=current;
  overlay.classList.remove('is-loaded','is-error');overlay.querySelector('.lotLoadingTitle').textContent='Cargando lote…';overlay.querySelector('.lotLoadingCaption').textContent='Preparando tus registros';overlay.querySelector('.lotLoadingRetry').hidden=true;overlay.setAttribute('aria-busy','true');overlay.querySelector('.lotLoading').inert=false;overlay.querySelector('.lotLoading').removeAttribute('aria-hidden');frame.inert=true;frame.setAttribute('aria-hidden','true');overlay.hidden=false;overlay.inert=false;document.body.style.overflow='hidden';overlay.querySelector('.lotLoadingClose').focus({preventScroll:true});
  current.timeout=setTimeout(()=>fail(current),LOAD_TIMEOUT);
  // Permitir que la animación se pinte antes de leer y preparar los registros locales.
  current.raf=requestAnimationFrame(()=>{current.raf=requestAnimationFrame(()=>{if(active!==current||current.failed)return;try{current.state=window.TruchAppData?.readLotDetail?.(current.id);if(!current.state)throw new Error('Lote no disponible');frame.title='Detalle del lote '+current.state.lot.code;bootWhenReady(current);}catch(_){fail(current);}});});
 }
 window.addEventListener('message',async event=>{
  if(!view||event.source!==view.frame.contentWindow)return;const m=event.data;if(!m||typeof m!=='object')return;
  if(m.type==='truchapp-detail-ready'){view.ready=true;if(active)bootWhenReady(active);return;}
  if(!active||m.session!==active.token||active.failed)return;
  if(m.type==='truchapp-detail-rendered'){if(!active.loading)return;clearOpening(active);active.loading=false;active.overlay.classList.add('is-loaded');active.overlay.setAttribute('aria-busy','false');active.overlay.querySelector('.lotLoading').inert=true;active.overlay.querySelector('.lotLoading').setAttribute('aria-hidden','true');active.frame.inert=false;active.frame.removeAttribute('aria-hidden');active.frame.focus();send({type:'truchapp-detail-focus'});return;}
  if(m.type==='truchapp-detail-load-failed'){fail(active);return;}
  if(m.type==='truchapp-detail-open-stock'){if(!active.busy&&!active.loading){close();document.querySelector('.nav[data-target="almacen"]')?.click();}return;}
  if(m.type==='truchapp-detail-close'){close();return;}
  if(m.type==='truchapp-detail-delete'){if(!active.busy&&!active.loading&&window.deleteLote)window.deleteLote();return;}
  if(m.type!=='truchapp-detail-save'||active.busy||active.loading)return;
  active.busy=true;
  try{
   if(m.baseRevision!==active.revision)throw new Error('No coincide la versión del lote. Cierra la ficha y vuelve a abrirla.');
   const save=()=>window.TruchAppData.saveLotDetail(active.id,m.state);const saved=window.TruchAppStorage?await window.TruchAppStorage.runAsync('Guardar datos del lote',save):save();active.state=saved;active.revision++;
   send({type:'truchapp-detail-saved',request:m.request,revision:active.revision,state:saved,feeding:feedingSnapshot()});
  }catch(error){
   send({type:'truchapp-detail-failed',request:m.request,error:String(error.message||'No se pudo guardar el registro.'),feeding:feedingSnapshot()});
  }finally{if(active)active.busy=false;}
 });
 document.addEventListener('keydown',event=>{if(!active)return;if(event.key==='Escape'&&!active.busy){event.preventDefault();close();}else if(event.key==='Tab'&&active.loading){const nodes=[...active.overlay.querySelectorAll('.lotLoading button')].filter(n=>!n.hidden),first=nodes[0],last=nodes.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}});
 window.TruchAppLotDetailHost={open,close,isOpen:()=>!!active};
})();
