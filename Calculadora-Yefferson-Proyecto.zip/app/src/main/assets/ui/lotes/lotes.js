/* TruchApp — módulo Lotes integrado con almacenamiento local compartido. */
(function () {
  'use strict';

  const KEY = 'truchapp_lotes_v1';
  const TUTORIAL_KEY = 'truchapp_lotes_preview_tutorial';
  const rootId = 'lotesRoot';
  const $ = id => document.getElementById(id);
  let activeLoteId = null;
  let rendering = false;
  let tutorialChecked = false;

  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[c]);
  const escAttr = value => esc(value).replace(/`/g, '&#96;');
  const nfmt = (value, digits = 1) => Number(value || 0).toLocaleString('es-PE', {
    minimumFractionDigits: digits, maximumFractionDigits: digits
  });
  const whole = value => Number(value || 0).toLocaleString('es-PE', { maximumFractionDigits: 0 });
  const optionalNumber = value => value === '' || value === null || value === undefined || !Number.isFinite(Number(value))
    ? null : Math.max(0, Number(value));
  const today = () => new Date().toISOString().slice(0, 10);
  const isAndroid = () => typeof window.AndroidAI !== 'undefined';

  function newId() { return 'LOTE-' + Date.now().toString(36).toUpperCase(); }
  function stageLabel(stage) {
    const aliases = {
      ovas: 'Ovas', alevinaje: 'Alevinaje', juvenil: 'Juvenil', engorde: 'Engorde',
      reproductores: 'Reproductores', 'alevín': 'Alevinaje'
    };
    const value = String(stage || 'Producción');
    return aliases[value.toLowerCase()] || value;
  }
  function slugStage(stage) {
    const value = stageLabel(stage).toLowerCase();
    return ({ ovas: 'ovas', alevinaje: 'alevinaje', juvenil: 'juvenil', engorde: 'engorde', reproductores: 'reproductores' })[value] || 'alevinaje';
  }
  function historyItem(h, lot) {
    h = h || {};
    return {
      d: String(h.d || h.date || lot.date || today()),
      w: Math.max(0, Number(h.w ?? h.currentWeight ?? lot.w) || 0),
      l: optionalNumber(h.l ?? h.length),
      m: Math.max(0, Number(h.m ?? h.mortality) || 0),
      discard: Math.max(0, Number(h.discard ?? h.discarded) || 0),
      feedKg: optionalNumber(h.feedKg ?? h.alimentoConsumido),
      pelletCalibre: optionalNumber(h.pelletCalibre),
      fcr: optionalNumber(h.fcr),
      x: String(h.x || h.note || '')
    };
  }
  function normalizeLot(source) {
    const src = source || {};
    const id = String(src.id || src.code || newId());
    const code = String(src.code || src.id || id);
    const n = Math.max(0, Math.floor(Number(src.n ?? src.currentCount ?? src.initialCount) || 0));
    const w = Math.max(0, Number(src.w ?? src.currentWeight ?? src.initialWeight) || 0);
    const mortalitySpecified = src.m !== undefined || src.mortality !== undefined;
    const discarded = Math.max(0, Math.floor(Number(src.discarded ?? src.discard ?? 0) || 0));
    let initialN = Math.max(0, Math.floor(Number(src.initialN ?? src.initialCount) || 0));
    if (!initialN) initialN = n + discarded + (mortalitySpecified ? Math.max(0, Math.floor(Number(src.m ?? src.mortality) || 0)) : 0);
    const m = Math.max(0, Math.floor(mortalitySpecified ? (Number(src.m ?? src.mortality) || 0) : initialN - n - discarded));
    initialN = Math.max(initialN, n + m + discarded);
    const initialWeight = Math.max(0, Number(src.w0 ?? src.initialWeight ?? src.w ?? src.currentWeight) || 0);
    const base = {
      id, code,
      stage: stageLabel(src.stage),
      unit: String(src.unit || 'Sin indicar'),
      origin: String(src.origin || 'Sin indicar'),
      date: String(src.date || today()),
      initialN,
      initialWeight,
      n, w,
      l: optionalNumber(src.l ?? src.length),
      pelletCalibre: optionalNumber(src.pelletCalibre ?? src.pelletSize),
      alimentoConsumido: optionalNumber(src.alimentoConsumido ?? src.feedKg),
      fcr: optionalNumber(src.fcr),
      m,
      discarded,
      targetWeight: Math.max(1, Number(src.targetWeight) || 210),
      harvestKg: Math.max(0, Number(src.harvestKg) || 0),
      history: []
    };
    const rawHistory = Array.isArray(src.history) ? src.history : [];
    base.history = rawHistory.map(h => historyItem(h, base));
    if (!base.history.length) {
      base.history.push({ d: base.date, w: base.w, l: base.l, m: 0, discard: 0, feedKg: null, pelletCalibre: base.pelletCalibre, fcr: base.fcr, x: 'Lote registrado' });
    }
    return base;
  }
  function parseLots(raw) {
    try {
      const value = JSON.parse(raw || '[]');
      return Array.isArray(value) ? value.map(normalizeLot) : [];
    } catch (_) { return []; }
  }
  function localLots() {
    try { return parseLots(localStorage.getItem(KEY)); } catch (_) { return []; }
  }
  function nativeLots() {
    if (!isAndroid() || typeof AndroidAI.getLots !== 'function') return null;
    try {
      const parsed = JSON.parse(AndroidAI.getLots());
      return Array.isArray(parsed) ? parsed.map(normalizeLot) : null;
    } catch (_) { return null; }
  }
  function saveLocal(lots) {
    try { localStorage.setItem(KEY, JSON.stringify(lots)); } catch (_) {}
  }
  function saveNative(lots) {
    if (!isAndroid() || typeof AndroidAI.saveLots !== 'function') return;
    try { AndroidAI.saveLots(JSON.stringify(lots)); } catch (_) {}
  }
  function getLots() {
    const local = localLots();
    const native = nativeLots();
    // If this is an existing installation, migrate WebView localStorage lots before relying on
    // the new native preference key, which did not exist in older versions.
    if (local.length && (!native || native.length === 0)) {
      saveNative(local);
      return local;
    }
    if (native && native.length) {
      saveLocal(native);
      return native;
    }
    return local;
  }
  function survival(lot) {
    const initial = Math.max(Number(lot.initialN) || 0, (Number(lot.n) || 0) + (Number(lot.m) || 0) + (Number(lot.discarded) || 0));
    return initial > 0 ? Math.max(0, Number(lot.n) || 0) / initial * 100 : 0;
  }
  function biomass(lot) { return Math.max(0, Number(lot.n) || 0) * Math.max(0, Number(lot.w) || 0) / 1000; }
  function health(lot) {
    const count = Number(lot.n), weight = Number(lot.w), surv = survival(lot);
    if (!Number.isFinite(count) || count <= 0 || !Number.isFinite(weight) || weight <= 0) return { level: 'critical', label: 'Crítico', survival: surv };
    if (surv < 90) return { level: 'critical', label: 'Crítico', survival: surv };
    if (surv < 95) return { level: 'regular', label: 'Regular', survival: surv };
    return { level: 'good', label: 'Bueno', survival: surv };
  }
  function currentDataSummary(lot) {
    const hs = lot.history && lot.history[0];
    return {
      id: lot.id, code: lot.code, stage: lot.stage, date: lot.date, unit: lot.unit, origin: lot.origin,
      initialN: lot.initialN, initialWeight: lot.initialWeight,
      fish: lot.n, weightG: lot.w, lengthCm: lot.l, biomassKg: biomass(lot), survivalPct: survival(lot),
      pelletCalibreMm: lot.pelletCalibre, feedConsumedKg: lot.alimentoConsumido, fcr: lot.fcr,
      mortalityTotal: lot.m, discardTotal: lot.discarded, harvestKg: lot.harvestKg,
      lastSample: hs ? Object.assign({}, hs) : null,
      history: (lot.history || []).map(h => Object.assign({}, h))
    };
  }
  function notifySharedDataChanged() {
    try { window.dispatchEvent(new CustomEvent('truchapp-lots-updated')); } catch (_) {}
    if (typeof window.refreshAgendaLotOptions === 'function') window.refreshAgendaLotOptions();
    if (typeof window.renderMemory === 'function') window.renderMemory();
    if (typeof window.updateFinanceLotOptions === 'function') window.updateFinanceLotOptions();
  }
  function persistLots(lots) {
    const normalized = (Array.isArray(lots) ? lots : []).map(normalizeLot);
    saveLocal(normalized);
    saveNative(normalized);
    notifySharedDataChanged();
  }
  function apiGetLots() { return getLots().map(currentDataSummary); }
  function apiGetLot(id) {
    const lot = getLots().find(x => x.id === String(id) || x.code === String(id));
    return lot ? currentDataSummary(lot) : null;
  }
  function apiSummary() {
    const lots = getLots();
    return {
      lotCount: lots.length,
      fishCount: lots.reduce((sum, lot) => sum + lot.n, 0),
      biomassKg: lots.reduce((sum, lot) => sum + biomass(lot), 0),
      mortalityTotal: lots.reduce((sum, lot) => sum + lot.m, 0),
      discardTotal: lots.reduce((sum, lot) => sum + lot.discarded, 0),
      lots: lots.map(currentDataSummary)
    };
  }
  window.TruchAppData = Object.assign(window.TruchAppData || {}, {
    getLots: apiGetLots,
    getLot: apiGetLot,
    getLotSummary: apiSummary
  });

  function fishSvg() {
    return `<svg class="lotesFish" viewBox="0 0 120 80" aria-hidden="true"><path d="M6 40C20 19 55 16 82 29L112 12 104 40 112 68 82 51C55 64 20 61 6 40Z" fill="#0d9488"/><path d="M18 41Q50 31 91 40" stroke="#f0734f" stroke-width="5" fill="none" stroke-linecap="round"/><circle cx="21" cy="35" r="4" fill="#0b3b3a"/><path d="M62 23C71 12 77 7 84 4 86 12 90 19 96 25" fill="#159f90"/></svg>`;
  }
  function render() {
    const root = $(rootId);
    if (!root || rendering) return;
    rendering = true;
    const lots = getLots();
    const totalFish = lots.reduce((sum, lot) => sum + lot.n, 0);
    const totalBiomass = lots.reduce((sum, lot) => sum + biomass(lot), 0);
    root.innerHTML = `
      <div class="lotesModule">
        <div class="lotesHead"><div><h2>Lotes</h2><p>Seguimiento de existencias, biometrías, alimentación, mortalidad y cosecha por lote.</p></div><div class="lotesBadge">${fishSvg()} Trucha arcoíris</div></div>
        <div class="lotesKpis"><div class="lotesKpi"><b id="kpiLotes">${whole(lots.length)}</b><span>Lotes activos</span></div><div class="lotesKpi"><b id="kpiPeces">${whole(totalFish)}</b><span>Peces en existencia</span></div><div class="lotesKpi"><b id="kpiBiomasa">${nfmt(totalBiomass, 1)} kg</b><span>Biomasa estimada</span></div></div>
        <button class="createLoteTrigger" id="createLoteTrigger" type="button">＋ Crear nuevo lote</button>
        <div class="lotesCard"><div class="lotesHead innerHead"><div><div class="lotesLabel">Mis lotes</div><div class="lotesHint" style="margin:0">Una ficha por lote para seguir el ciclo productivo.</div></div><span class="lotesStage">🐟 seguimiento local</span></div><div class="lotesCards" id="lotesList" style="margin-top:9px"></div></div>
        <div class="lotesCard"><div class="lotesLabel">Qué conviene registrar</div><p class="lotesHint" style="font-size:12px">Existencias, mortalidad, biometrías, alimentación, movimientos y cosecha. El historial permite comparar crecimiento, supervivencia y manejo.</p><p class="lotesSource"><b>Referencias técnicas:</b> FAO, <i>Small-scale rainbow trout farming</i> (Technical Paper 561, 2011); la NTP 032.103:2024 describe un método para determinar el factor de conversión alimenticia de trucha arcoíris en Perú.</p></div>
        <button class="lotesBtn secondary alt" id="showTutorialAgain" type="button">Ver tutorial otra vez</button>

        <div id="loteModal" class="lotesOverlay" aria-modal="true" role="dialog" aria-labelledby="lmTitle">
          <div class="lotesModal" id="lotePanel" role="document">
            <button class="lotesClose" id="closeLoteBtn" aria-label="Cerrar">×</button><div class="lotesModalIcon">🐟</div>
            <h3 id="lmTitle">Lote</h3><p id="lmSubtitle" class="lotesModalSubtitle"></p>
            <div class="lotesStatGrid" style="margin:8px 0 12px">
              <div class="lotesStat"><b id="lmFish">0</b><span>Peces</span></div><div class="lotesStat"><b id="lmWeightStat">0,0 g</b><span>Peso prom.</span></div><div class="lotesStat"><b id="lmBiomass">0,0 kg</b><span>Biomasa</span></div><div class="lotesStat"><b id="lmSurvival">0,0%</b><span>Supervivencia</span></div>
            </div>
            <div class="lotesStatGrid detailExtraGrid" style="margin:0 0 12px">
              <div class="lotesStat"><b id="lmLengthStat">— cm</b><span>Talla</span></div><div class="lotesStat"><b id="lmPellet">— mm</b><span>Pellet calibre</span></div><div class="lotesStat"><b id="lmFeedConsumed">— kg</b><span>Alimento consumido</span></div><div class="lotesStat"><b id="lmFcr">—</b><span>FCR</span></div>
            </div>
            <section class="sampleUpdatePanel" aria-label="Nuevo muestreo o actualización de datos">
              <div class="sampleUpdateHeading"><span class="editMark" aria-hidden="true">✎</span><span>Nuevo muestreo / actualizar</span></div>
              <div class="lotesGrid2">
                <div class="lotesField"><label for="lmWeight">Peso promedio (g)</label><input class="lotesInput" id="lmWeight" type="number" min="0.1" step="0.1"></div>
                <div class="lotesField"><label for="lmLength">Talla promedio (cm)</label><input class="lotesInput" id="lmLength" type="number" min="0.1" step="0.1" placeholder="Ej. 15,5"></div>
                <div class="lotesField"><label for="lmMort">Mortalidad de hoy (u.)</label><input class="lotesInput" id="lmMort" type="number" min="0" step="1" value="0"></div>
                <div class="lotesField discardField"><label for="lmDiscard">Descarte (malformaciones)</label><input class="lotesInput" id="lmDiscard" type="number" min="0" step="1" value="0" placeholder="0"></div>
                <div class="lotesField"><label for="lmPelletInput">Pellet calibre (mm)</label><input class="lotesInput" id="lmPelletInput" type="number" min="0.1" step="0.1" placeholder="Ej. 3,0"></div>
                <div class="lotesField"><label for="lmFeedInput">Alimento consumido (kg)</label><input class="lotesInput" id="lmFeedInput" type="number" min="0" step="0.01" placeholder="En este periodo"></div>
              </div>
              <div class="lotesHint" style="margin-top:8px">El descarte se registra por separado de la mortalidad. El alimento ingresado corresponde a este periodo y se suma al acumulado; el FCR se estima cuando existe ganancia positiva de peso.</div>
              <div class="lotesField" style="margin-top:9px"><label for="lmObs">Observaciones sanitarias</label><textarea class="lotesInput" id="lmObs" rows="3" placeholder="Agallas limpias, buen apetito, comportamiento normal…"></textarea></div>
            </section>
            <div class="lotesActions" style="margin-top:12px"><button class="lotesBtn primary" id="saveLoteBtn" type="button">Guardar muestreo</button></div>
            <button class="lotesBtn dangerBtn" style="margin-top:8px" id="deleteLoteBtn" type="button">Eliminar este lote</button>
            <div style="margin-top:12px;text-align:left"><div class="lotesLabel" style="font-size:10px;letter-spacing:.07em;margin-bottom:6px">ÚLTIMOS REGISTROS</div><div id="lmHistory"></div></div>
          </div>
        </div>

        <div id="createModal" class="lotesOverlay createModal" aria-modal="true" role="dialog" aria-labelledby="createTitle">
          <div class="lotesModal" id="createPanel" role="document">
            <button class="lotesClose" id="closeCreateBtn" aria-label="Cerrar">×</button><div class="lotesModalIcon">🐟</div>
            <h3 id="createTitle">Crear nuevo lote</h3><p class="lotesSubhead">Registra los datos iniciales del lote para comenzar su seguimiento productivo.</p>
            <div class="lotesGrid2">
              <div class="lotesField"><label for="crCode">Código del lote</label><input class="lotesInput" id="crCode" placeholder="TR-2026-03" maxlength="48"></div>
              <div class="lotesField"><label for="crStage">Etapa</label><select class="lotesInput" id="crStage"><option>Alevinaje</option><option>Juvenil</option><option>Engorde</option><option>Reproductores</option><option>Ovas</option></select></div>
              <div class="lotesField"><label for="crDate">Fecha de siembra / ingreso</label><input class="lotesInput" id="crDate" type="date"></div>
              <div class="lotesField"><label for="crOrigin">Origen</label><input class="lotesInput" id="crOrigin" placeholder="Centro / proveedor"></div>
              <div class="lotesField"><label for="crUnit">Unidad de cultivo</label><input class="lotesInput" id="crUnit" placeholder="Estanque / jaula / tanque"></div>
              <div class="lotesField"><label for="crFish">Peces iniciales</label><input class="lotesInput" id="crFish" type="number" min="1" step="1" placeholder="10000"></div>
              <div class="lotesField"><label for="crW0">Peso inicial (g)</label><input class="lotesInput" id="crW0" type="number" min="0.1" step="0.1" placeholder="20"></div>
              <div class="lotesField"><label for="crW">Peso actual (g)</label><input class="lotesInput" id="crW" type="number" min="0.1" step="0.1" placeholder="20"></div>
            </div>
            <div id="createModalMsg" class="lotesHint createModalMsg" style="display:none;margin-top:8px"></div>
            <div class="lotesActions" style="margin-top:12px"><button class="lotesBtn primary" id="createLoteBtn" type="button">＋ Crear lote</button></div>
          </div>
        </div>

        <div id="lotesTutorial" class="lotesOverlay" aria-modal="true" role="dialog" aria-labelledby="lotesTutorialTitle">
          <div class="lotesModal" role="document"><button class="lotesClose" id="closeTutorialBtn" aria-label="Cerrar">×</button><div class="lotesModalIcon">🐟</div>
            <h3 id="lotesTutorialTitle">Controla el ciclo de cada lote</h3><p>Registra siembra, población, biometrías, mortalidad, alimentación, movimientos y cosecha. El historial ayuda a comparar crecimiento, supervivencia y manejo.</p><small>Primera visita · puedes cerrarlo con × o tocando fuera.</small>
          </div>
        </div>
      </div>`;

    bindEvents();
    renderKpis();
    renderList();
    rendering = false;
    notifySharedDataChanged();
  }
  function bindEvents() {
    $('createLoteTrigger')?.addEventListener('click', openCreateLote);
    $('createLoteBtn')?.addEventListener('click', createLoteFromModal);
    $('closeCreateBtn')?.addEventListener('click', closeCreateLote);
    $('closeLoteBtn')?.addEventListener('click', closeLote);
    $('saveLoteBtn')?.addEventListener('click', saveLote);
    $('deleteLoteBtn')?.addEventListener('click', deleteLote);
    $('showTutorialAgain')?.addEventListener('click', () => $('lotesTutorial')?.classList.add('open'));
    $('closeTutorialBtn')?.addEventListener('click', closeTutorial);
    $('loteModal')?.addEventListener('click', closeLote);
    $('createModal')?.addEventListener('click', closeCreateLote);
    $('lotesTutorial')?.addEventListener('click', closeTutorial);
    ['lotePanel', 'createPanel'].forEach(id => $(id)?.addEventListener('click', ev => ev.stopPropagation()));
  }
  function setupTutorial() {
    const modal = $('lotesTutorial');
    if (!modal || tutorialChecked) return;
    tutorialChecked = true;
    let seen = false;
    try { seen = localStorage.getItem(TUTORIAL_KEY) === '1' || localStorage.getItem('truchapp_lotes_tutorial_seen_v1') === '1'; } catch (_) {}
    if (!seen) modal.classList.add('open'); else modal.classList.remove('open');
  }
  function closeTutorial() {
    tutorialChecked = true;
    $('lotesTutorial')?.classList.remove('open');
    try { localStorage.setItem(TUTORIAL_KEY, '1'); localStorage.setItem('truchapp_lotes_tutorial_seen_v1', '1'); } catch (_) {}
  }
  function renderKpis() {
    const root = $(rootId); if (!root) return;
    const lots = getLots();
    const count = lots.reduce((sum, lot) => sum + lot.n, 0);
    const bio = lots.reduce((sum, lot) => sum + biomass(lot), 0);
    const lotCount = root.querySelector('#kpiLotes'), fishCount = root.querySelector('#kpiPeces'), bioCount = root.querySelector('#kpiBiomasa');
    if (lotCount) lotCount.textContent = whole(lots.length);
    if (fishCount) fishCount.textContent = whole(count);
    if (bioCount) bioCount.textContent = nfmt(bio, 1) + ' kg';
  }
  function renderList() {
    const box = $('lotesList');
    if (!box) return;
    const lots = getLots();
    if (!lots.length) {
      box.innerHTML = '<div class="lotesEmpty">Aún no tienes lotes registrados. Pulsa “Crear nuevo lote” para ingresar el primero.</div>';
      return;
    }
    box.innerHTML = lots.map(l => {
      const surv = survival(l), bio = biomass(l), target = Number(l.targetWeight) || 210;
      const progress = Math.max(0, Math.min(100, (Number(l.w) || 0) / target * 100));
      const state = health(l);
      return `<div class="lotesLote" data-lote="${escAttr(l.id)}">
        <div class="lotesLoteTop"><div><div class="lotesCode">${esc(l.code)}</div><div class="lotesMeta">${esc(stageLabel(l.stage))} · ingreso ${esc(l.date)} · ${esc(l.unit)}${l.origin && l.origin !== 'Sin indicar' ? ' · ' + esc(l.origin) : ''}</div></div><div class="lotesHealth"><span class="lotesStage">Estado</span><span class="healthLight ${state.level}" title="Estado ${state.label} · Supervivencia ${nfmt(surv)}%" role="img" aria-label="Estado ${state.label}. Supervivencia ${nfmt(surv)} por ciento."></span></div></div>
        <div class="lotesStatGrid"><div class="lotesStat"><b>${whole(l.n)}</b><span>Peces</span></div><div class="lotesStat"><b>${nfmt(l.w)} g</b><span>Peso prom.</span></div><div class="lotesStat"><b>${nfmt(bio)} kg</b><span>Biomasa</span></div><div class="lotesStat"><b>${nfmt(surv)}%</b><span>Supervivencia</span></div></div>
        <div class="lotesProgress"><i style="width:${progress}%"></i></div><div class="lotesNote">Progreso hacia ${whole(target)} g: ${nfmt(progress)}% · Mortalidad: ${whole(l.m)} · Descarte: ${whole(l.discarded)}</div>
        <div class="lotesActions"><button class="lotesBtn secondary openLoteBtn" data-lote-id="${escAttr(l.id)}" type="button">Ver / actualizar lote</button></div>
      </div>`;
    }).join('');
    box.querySelectorAll('.openLoteBtn').forEach(btn => btn.addEventListener('click', () => openLote(btn.dataset.loteId)));
  }
  function openCreateLote() {
    const date = $('crDate'); if (date && !date.value) date.value = today();
    const msg = $('createModalMsg'); if (msg) { msg.style.display = 'none'; msg.textContent = ''; }
    $('createModal')?.classList.add('open');
  }
  function closeCreateLote() { $('createModal')?.classList.remove('open'); }
  function createLoteFromModal() {
    const code = $('crCode').value.trim();
    const stage = $('crStage').value;
    const date = $('crDate').value || today();
    const origin = $('crOrigin').value.trim() || 'Sin indicar';
    const unit = $('crUnit').value.trim() || 'Sin indicar';
    const initialN = Math.max(0, Math.floor(Number($('crFish').value) || 0));
    const initialWeight = Math.max(0, Number($('crW0').value) || 0);
    const weight = Math.max(0, Number($('crW').value) || initialWeight);
    const msg = $('createModalMsg');
    const fail = text => { msg.textContent = text; msg.style.display = 'block'; msg.classList.add('error'); };
    msg.classList.remove('error');
    if (!code || initialN <= 0 || initialWeight <= 0 || weight <= 0) { fail('Completa código, peces iniciales, peso inicial y peso actual con valores válidos.'); return; }
    const lots = getLots();
    if (lots.some(l => l.code.toLowerCase() === code.toLowerCase() || l.id.toLowerCase() === code.toLowerCase())) { fail('Ya existe un lote con ese código.'); return; }
    const lot = normalizeLot({ id: code, code, stage, unit, date, origin, initialN, initialWeight, n: initialN, w: weight, l: null, pelletCalibre: null, alimentoConsumido: null, fcr: null, m: 0, discarded: 0, harvestKg: 0, history: [{ d: date, w: weight, l: null, m: 0, discard: 0, feedKg: null, pelletCalibre: null, fcr: null, x: 'Lote creado' }] });
    persistLots([lot, ...lots]);
    closeCreateLote();
    render();
    const card = Array.from(document.querySelectorAll('.lotesLote')).find(el => el.dataset.lote === lot.id);
    if (card) { card.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); card.classList.add('createdPulse'); setTimeout(() => card.classList.remove('createdPulse'), 1000); }
  }
  function openLote(id) {
    const lot = getLots().find(l => l.id === String(id) || l.code === String(id));
    if (!lot) return;
    activeLoteId = lot.id;
    $('lmTitle').textContent = lot.code + ' · ' + stageLabel(lot.stage);
    $('lmSubtitle').textContent = lot.unit + ' · ingreso ' + lot.date + (lot.origin && lot.origin !== 'Sin indicar' ? ' · origen ' + lot.origin : '');
    $('lmFish').textContent = whole(lot.n);
    $('lmWeightStat').textContent = nfmt(lot.w) + ' g';
    $('lmBiomass').textContent = nfmt(biomass(lot)) + ' kg';
    $('lmSurvival').textContent = nfmt(survival(lot)) + '%';
    $('lmLengthStat').textContent = lot.l == null ? '— cm' : nfmt(lot.l) + ' cm';
    $('lmPellet').textContent = lot.pelletCalibre == null ? '— mm' : nfmt(lot.pelletCalibre) + ' mm';
    $('lmFeedConsumed').textContent = lot.alimentoConsumido == null ? '— kg' : nfmt(lot.alimentoConsumido, 2) + ' kg';
    $('lmFcr').textContent = lot.fcr == null ? '—' : nfmt(lot.fcr, 2);
    $('lmWeight').value = lot.w;
    $('lmLength').value = lot.l == null ? '' : lot.l;
    $('lmMort').value = '0';
    $('lmDiscard').value = '0';
    $('lmPelletInput').value = lot.pelletCalibre == null ? '' : lot.pelletCalibre;
    $('lmFeedInput').value = '';
    $('lmObs').value = '';
    $('lmHistory').innerHTML = (lot.history || []).slice(0, 5).map(h => {
      const details = [];
      if (h.l != null) details.push('talla ' + nfmt(h.l) + ' cm');
      details.push('mortalidad ' + whole(h.m));
      if (Number(h.discard) > 0) details.push('descarte ' + whole(h.discard));
      if (h.feedKg != null) details.push('alimento ' + nfmt(h.feedKg, 2) + ' kg');
      if (h.fcr != null) details.push('FCR ' + nfmt(h.fcr, 2));
      return `<div class="lotesHistoryItem"><b>${esc(h.d)}</b> · ${nfmt(h.w)} g · ${details.join(' · ')}<br><span>${esc(h.x || '')}</span></div>`;
    }).join('') || '<div class="lotesHint">Sin registros.</div>';
    $('loteModal').classList.add('open');
  }
  function closeLote() { $('loteModal')?.classList.remove('open'); activeLoteId = null; }
  function saveLote() {
    if (!activeLoteId) return;
    const lots = getLots();
    const lot = lots.find(item => item.id === activeLoteId);
    if (!lot) return;
    const weightRaw = $('lmWeight').value;
    const weight = weightRaw === '' ? lot.w : Number(weightRaw);
    const lengthRaw = $('lmLength').value;
    const length = lengthRaw === '' ? null : Number(lengthRaw);
    const mortality = Math.max(0, Number($('lmMort').value) || 0);
    const discarded = Math.max(0, Number($('lmDiscard').value) || 0);
    const pelletRaw = $('lmPelletInput').value;
    const pellet = pelletRaw === '' ? null : Number(pelletRaw);
    const feedRaw = $('lmFeedInput').value;
    const feedPeriod = feedRaw === '' ? null : Number(feedRaw);
    if (!Number.isFinite(weight) || weight <= 0) { alert('Ingresa un peso promedio válido mayor que cero.'); return; }
    if (lengthRaw !== '' && (!Number.isFinite(length) || length <= 0)) { alert('Ingresa una talla válida mayor que cero o deja el campo vacío.'); return; }
    if (!Number.isInteger(mortality) || !Number.isInteger(discarded) || mortality < 0 || discarded < 0) { alert('La mortalidad y el descarte deben ser números enteros no negativos.'); return; }
    if (mortality + discarded > lot.n) { alert('La mortalidad y el descarte no pueden superar la cantidad de peces del lote.'); return; }
    if (pelletRaw !== '' && (!Number.isFinite(pellet) || pellet <= 0)) { alert('Ingresa un calibre de pellet válido mayor que cero.'); return; }
    if (feedRaw !== '' && (!Number.isFinite(feedPeriod) || feedPeriod < 0)) { alert('Ingresa una cantidad de alimento válida no negativa.'); return; }

    const previousN = lot.n, previousWeight = lot.w;
    const remainingN = Math.max(0, previousN - mortality - discarded);
    const gainKg = Math.max(0, (weight - previousWeight) * ((previousN + remainingN) / 2) / 1000);
    lot.w = weight;
    if (length !== null) lot.l = length;
    if (pellet !== null) lot.pelletCalibre = pellet;
    lot.n = remainingN;
    lot.m += mortality;
    lot.discarded += discarded;
    let sampleFcr = null;
    if (feedPeriod !== null) {
      lot.alimentoConsumido = (Number(lot.alimentoConsumido) || 0) + feedPeriod;
      if (feedPeriod > 0 && gainKg > 0) { sampleFcr = feedPeriod / gainKg; lot.fcr = sampleFcr; }
    }
    const history = {
      d: today(), w: lot.w, l: lot.l, m: mortality, discard: discarded,
      feedKg: feedPeriod, pelletCalibre: lot.pelletCalibre, fcr: sampleFcr,
      x: $('lmObs').value.trim()
    };
    lot.history.unshift(history);
    persistLots(lots);
    closeLote();
    render();
    if (feedPeriod !== null && feedPeriod > 0 && gainKg <= 0) {
      alert('Muestreo guardado. El FCR no se actualizó porque no se registró ganancia positiva de peso en este periodo.');
    } else {
      alert('Muestreo guardado en la memoria local de TruchApp. Los demás módulos ya pueden consultar este lote.');
    }
  }
  function deleteLote() {
    if (!activeLoteId) return;
    const lot = getLots().find(item => item.id === activeLoteId);
    if (!lot || !confirm('¿Eliminar ' + lot.code + ' y todo su historial? Esta acción no se puede deshacer.')) return;
    persistLots(getLots().filter(item => item.id !== activeLoteId));
    closeLote();
    render();
  }
  function showTutorial() { $('lotesTutorial')?.classList.add('open'); }

  window.openLote = openLote;
  window.saveLote = saveLote;
  window.deleteLote = deleteLote;
  window.closeLote = closeLote;
  window.lotesShowTutorial = showTutorial;
  window.lotesOnEnter = setupTutorial;
  window.renderLots = render;
  window.renderLotsForSharedViews = notifySharedDataChanged;

  function init() { render(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
