/* TruchApp — módulo Lotes integrado con almacenamiento local compartido. */
(function () {
  'use strict';

  const KEY = 'truchapp_lotes_v1';
  const TUTORIAL_KEY = 'truchapp_lotes_tutorial_v2';
  // Respaldo local por si el WebView restringe temporalmente el acceso a localStorage.
  const lotesMemoryFallback = new Map();
  function readLotesStorage(key) {
    try { const value = localStorage.getItem(key); if (value !== null) return value; } catch (_) {}
    return lotesMemoryFallback.has(key) ? lotesMemoryFallback.get(key) : null;
  }
  function writeLotesStorage(key, value) {
    const text = String(value);
    lotesMemoryFallback.set(key, text);
    try { localStorage.setItem(key, text); } catch (_) {}
  }
  const rootId = 'lotesRoot';
  const $ = id => document.getElementById(id);
  let activeLoteId = null;
  let rendering = false;
  let tutorialChecked = false;
  let tutorialStepIndex = 0;
  const TUTORIAL_STEPS = [
    {heading:'Conoce el resumen',text:'Los indicadores superiores muestran cuántos lotes tienes registrados, la cantidad de peces en existencia y la biomasa estimada del conjunto.',tipHeading:'Consejo práctico',tipText:'Revisa el resumen después de crear un lote o guardar un nuevo muestreo.'},
    {heading:'Registra un nuevo lote',text:'Pulsa “Crear nuevo lote” e ingresa un código único, etapa productiva, fecha de ingreso, origen, unidad de cultivo, cantidad inicial, peso inicial y objetivo comercial. Comprueba los datos antes de guardar.',tipHeading:'Antes de guardar',tipText:'Utiliza códigos distintos para cada lote, registra el peso medido en campo y define tu objetivo comercial.'},
    {heading:'Actualiza el muestreo',text:'Abre la ficha de un lote y registra peso y talla promedio, mortalidad del periodo, descarte, calibre del pellet, alimento consumido y observaciones sanitarias.',tipHeading:'Para mantener un buen historial',tipText:'Anota el alimento correspondiente al periodo que estás registrando, no una cifra aproximada de todo el ciclo.'},
    {heading:'Interpreta los indicadores',text:'La ficha resume peces actuales, peso promedio, biomasa, supervivencia, talla, alimento acumulado y FCR estimado. Estos indicadores dependen de la calidad de los datos introducidos.',tipHeading:'Recuerda',tipText:'Mortalidad y descarte se registran por separado: el descarte no debe contarse como mortalidad.'},
    {heading:'Consulta la evolución',text:'Los últimos registros permiten comparar crecimiento y manejo a lo largo del tiempo. Abre cada ficha para revisar el historial y actualiza los datos cuando realices nuevos controles.',tipHeading:'Cuidado con los datos',tipText:'Elimina un lote solo cuando corresponda; al hacerlo, también se elimina su historial en la aplicación.'}
  ];

  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[c]);
  const escAttr = value => esc(value).replace(/`/g, '&#96;');

  const WATER_KEY = 'truchapp_lotes_water_quality_v1';
  const WATER_FARMS_KEY = 'truchapp_lotes_water_farms_v1';
  const WATER_ACTIVE_FARM_KEY = 'truchapp_lotes_water_active_farm_v1';
  let activeWaterParamId = null;
  let activeWaterCustom = null;
  let waterEntryLotId = null;
  let activeWaterFarmId = null;
  let editingWaterFarmId = null;
  const WATER_GROUPS = [
    {id:'physical', number:'01', title:'Parámetros físicos y de circulación', intro:'Mediciones de campo y características visibles del agua.', params:[
      {id:'temperature', label:'Temperatura del agua', unit:'°C', step:'0.1', ref:'En trucha, el objetivo depende de etapa y sistema; FAO cita 14–17 °C como intervalo óptimo de crecimiento.'},
      {id:'turbidity', label:'Turbidez', unit:'NTU', step:'0.1', ref:'Valores bajos suelen ser preferibles; interpreta según fuente y método.'},
      {id:'suspendedSolids', label:'Sólidos suspendidos totales (SST)', unit:'mg/L', step:'0.1'},
      {id:'transparency', label:'Transparencia', unit:'cm', step:'0.1', ref:'Útil sobre todo en estanques; no sustituye la turbidez instrumental.'},
      {id:'waterColor', label:'Color aparente', unit:'descripción', kind:'text', placeholder:'Ej. claro, verdoso, marrón'},
      {id:'waterOdor', label:'Olor del agua', unit:'descripción', kind:'text', placeholder:'Ej. sin olor, terroso, sulfuroso'},
      {id:'flow', label:'Caudal de entrada', unit:'L/s', step:'0.1'},
      {id:'velocity', label:'Velocidad de corriente', unit:'m/s', step:'0.01'}
    ]},
    {id:'core', number:'02', title:'Parámetros químicos principales', intro:'Indicadores esenciales para controlar el ambiente de las truchas.', params:[
      {id:'oxygen', label:'Oxígeno disuelto', unit:'mg/L', step:'0.1', ref:'FAO indica cerca de saturación como condición favorable; alrededor de 5,5 mg/L es un mínimo general descrito para crecimiento, no una meta de manejo.'},
      {id:'oxygenSaturation', label:'Saturación de oxígeno', unit:'%', step:'0.1', ref:'Interprétala junto al valor en mg/L, temperatura y altitud.'},
      {id:'ph', label:'pH', unit:'unidades', step:'0.01', ref:'Referencia general FAO para trucha: pH 6,5–8,5; ajustar por etapa y fuente.'},
      {id:'carbonDioxide', label:'Dióxido de carbono (CO₂)', unit:'mg/L', step:'0.01', ref:'La ficha FAO para trucha cita CO₂ menor de 2 mg/L como criterio de calidad.'},
      {id:'conductivity', label:'Conductividad eléctrica', unit:'µS/cm', step:'1'},
      {id:'tds', label:'Sólidos disueltos totales (TDS)', unit:'mg/L', step:'1'},
      {id:'salinity', label:'Salinidad', unit:'ppt', step:'0.01'},
      {id:'alkalinity', label:'Alcalinidad total (como CaCO₃)', unit:'mg/L', step:'1', ref:'La referencia FAO es amplia (10–400 mg/L como CaCO₃); el valor conveniente depende del origen y del sistema.'},
      {id:'hardness', label:'Dureza total (como CaCO₃)', unit:'mg/L', step:'1'},
      {id:'orp', label:'Potencial óxido-reducción (ORP)', unit:'mV', step:'1'}
    ]},
    {id:'nitrogen', number:'03', title:'Nutrientes, nitrógeno y sales', intro:'Parámetros relacionados con residuos del alimento, metabolismo y composición del agua.', params:[
      {id:'tan', label:'Amoniaco + amonio total (TAN)', unit:'mg/L como N', step:'0.001', ref:'Debe interpretarse con el pH y la temperatura; confirma si el kit expresa el resultado como N o como NH₃/NH₄⁺.'},
      {id:'ammonia', label:'Amoniaco no ionizado (NH₃)', unit:'mg/L', step:'0.001', ref:'Es la forma más tóxica; mantenerla lo más baja posible. Su proporción aumenta con pH y temperatura.'},
      {id:'ammonium', label:'Ion amonio (NH₄⁺)', unit:'mg/L', step:'0.001'},
      {id:'nitrite', label:'Nitrito (NO₂⁻)', unit:'mg/L', step:'0.001', ref:'La toxicidad depende de la etapa y la concentración de cloruros; conserva las unidades del método.'},
      {id:'nitrate', label:'Nitrato (NO₃⁻)', unit:'mg/L', step:'0.1'},
      {id:'totalNitrogen', label:'Nitrógeno total', unit:'mg/L como N', step:'0.1'},
      {id:'phosphate', label:'Fosfato (PO₄³⁻)', unit:'mg/L', step:'0.01'},
      {id:'totalPhosphorus', label:'Fósforo total', unit:'mg/L como P', step:'0.01'},
      {id:'chloride', label:'Cloruros (Cl⁻)', unit:'mg/L', step:'0.1'},
      {id:'sulfate', label:'Sulfatos (SO₄²⁻)', unit:'mg/L', step:'0.1'},
      {id:'sulfide', label:'Sulfuro / ácido sulfhídrico (H₂S)', unit:'mg/L', step:'0.001'},
      {id:'freeChlorine', label:'Cloro libre', unit:'mg/L', step:'0.01'},
      {id:'totalChlorine', label:'Cloro total', unit:'mg/L', step:'0.01'},
      {id:'organicMatter', label:'Materia orgánica', unit:'mg/L', step:'0.1'},
      {id:'bod', label:'Demanda bioquímica de oxígeno (DBO₅)', unit:'mg/L', step:'0.1'},
      {id:'cod', label:'Demanda química de oxígeno (DQO)', unit:'mg/L', step:'0.1'},
      {id:'organicCarbon', label:'Carbono orgánico total (COT)', unit:'mg/L', step:'0.1'}
    ]},
    {id:'metals', number:'04', title:'Metales y contaminantes', intro:'Análisis complementarios según la fuente, sospecha de contaminación o control de laboratorio.', params:[
      {id:'iron', label:'Hierro (Fe)', unit:'mg/L', step:'0.001', ref:'La ficha FAO para trucha cita menos de 1 mg/L; algunos sistemas requieren límites más estrictos.'},
      {id:'manganese', label:'Manganeso (Mn)', unit:'mg/L', step:'0.001', ref:'La ficha FAO para trucha cita menos de 0,01 mg/L.'},
      {id:'copper', label:'Cobre (Cu)', unit:'mg/L', step:'0.0001', ref:'La toxicidad depende de la dureza, alcalinidad y química del agua.'},
      {id:'zinc', label:'Zinc (Zn)', unit:'mg/L', step:'0.001', ref:'La ficha FAO para trucha cita menos de 0,05 mg/L.'},
      {id:'aluminum', label:'Aluminio (Al)', unit:'mg/L', step:'0.001'},
      {id:'arsenic', label:'Arsénico (As)', unit:'mg/L', step:'0.0001'},
      {id:'lead', label:'Plomo (Pb)', unit:'mg/L', step:'0.0001'},
      {id:'cadmium', label:'Cadmio (Cd)', unit:'mg/L', step:'0.0001'},
      {id:'mercury', label:'Mercurio (Hg)', unit:'mg/L', step:'0.0001'},
      {id:'chromium', label:'Cromo (Cr)', unit:'mg/L', step:'0.0001'},
      {id:'nickel', label:'Níquel (Ni)', unit:'mg/L', step:'0.0001'}
    ]}
  ];
  const WATER_PARAM_LOOKUP = WATER_GROUPS.reduce((all, group) => {
    group.params.forEach(param => { all[param.id] = param; });
    return all;
  }, {});
  // Se reutiliza una sola lectura del historial durante la generación de las 46 tarjetas.
  // No es caché persistente: las mediciones guardadas siempre se vuelven a consultar.
  let waterCardsReadingsSnapshot = null;
  let waterDrawerRenderTimer = null;
  let waterDrawerOpenFrame = null;
  let waterDrawerGeneration = 0;
  let renderedWaterFarmId = null;
  function currentWaterCardReadings() {
    return waterCardsReadingsSnapshot === null ? currentWaterReadings() : waterCardsReadingsSnapshot;
  }
  function currentWaterReadings() {
    if (!activeWaterFarmId) return [];
    const readings = readWaterReadings();
    if (String(activeWaterFarmId) === '__unassigned__') return readings.filter(reading => !reading.farmId || String(reading.farmId) === '__unassigned__');
    return readings.filter(reading => String(reading.farmId || '') === String(activeWaterFarmId));
  }
  function latestWaterParameterReading(paramId, readings = currentWaterCardReadings()) {
    for (const reading of readings) {
      const item = reading.params && reading.params[paramId];
      if (item !== undefined && item !== null && String(item.value ?? item).trim() !== '') {
        return {reading, item: typeof item === 'object' ? item : {value:item, unit:(WATER_PARAM_LOOKUP[paramId] || {}).unit || ''}};
      }
    }
    return null;
  }
  function latestCustomWaterReading(name) {
    const key = String(name || '').trim().toLocaleLowerCase('es-PE');
    for (const reading of currentWaterCardReadings()) {
      if (reading.custom && String(reading.custom.name || '').trim().toLocaleLowerCase('es-PE') === key) return {reading, item:reading.custom};
    }
    return null;
  }
  function waterRelativeDate(value) {
    if (!value) return 'Sin fecha';
    const target = new Date(`${value}T12:00:00`);
    if (Number.isNaN(target.getTime())) return formatWaterDate(value);
    const todayDate = new Date(); todayDate.setHours(12,0,0,0);
    target.setHours(12,0,0,0);
    const diff = Math.round((todayDate - target) / 86400000);
    if (diff === 0) return 'hoy';
    if (diff === 1) return 'hace un día';
    if (diff > 1 && diff < 7) return `hace ${diff} días`;
    return formatWaterDate(value);
  }
  function waterParameterStatus(param, rawValue) {
    const value = Number(rawValue);
    if (!Number.isFinite(value) || param.kind === 'text') return {label:'Registrado', state:'recorded'};
    if (param.id === 'ph') return value >= 6.5 && value <= 8.5 ? {label:'En rango orientativo',state:'good'} : {label:'Revisar valor',state:'review'};
    if (param.id === 'oxygen') return value >= 5.5 ? {label:'Valor registrado',state:'recorded'} : {label:'Revisar oxígeno',state:'review'};
    if (param.id === 'carbonDioxide') return value < 2 ? {label:'Bajo',state:'good'} : {label:'Revisar CO₂',state:'review'};
    if (param.id === 'temperature') return value >= 14 && value <= 17 ? {label:'Referencia 14–17 °C',state:'good'} : {label:'Verificar etapa/sistema',state:'recorded'};
    return {label:'Registrado',state:'recorded'};
  }
  function displayWaterCardValue(value) {
    if (value === undefined || value === null || String(value).trim() === '') return '—';
    if (typeof value === 'number' || (String(value).trim() !== '' && Number.isFinite(Number(value)))) {
      return Number(value).toLocaleString('es-PE', {maximumFractionDigits:4});
    }
    return String(value);
  }
  function waterParameterCard(param, readings = currentWaterCardReadings()) {
    const latest = latestWaterParameterReading(param.id, readings);
    const hasValue = !!latest;
    const value = hasValue ? (latest.item.value ?? latest.item) : '—';
    const status = hasValue ? waterParameterStatus(param, value) : {label:'＋ Registrar medición',state:'pending'};
    const unit = hasValue && latest.item.unit ? latest.item.unit : param.unit;
    const date = hasValue ? waterRelativeDate(latest.reading.date) : 'Sin medición registrada';
    const valueClass = String(value).length > 12 ? ' waterParamCardValueLong' : '';
    return `<button class="waterParamCard" type="button" data-water-card="${escAttr(param.id)}" aria-label="${escAttr(param.label)}: ${escAttr(displayWaterCardValue(value))} ${escAttr(unit)}. ${hasValue ? 'Abrir registro' : 'Registrar medición'}"><span class="waterParamCardName">${esc(param.label)}</span><strong class="waterParamCardValue${valueClass}">${esc(displayWaterCardValue(value))}</strong><span class="waterParamCardUnit">${esc(unit)}</span><span class="waterParamCardStatus ${status.state}">${esc(status.label)}</span><span class="waterParamCardDate">${esc(date)}</span></button>`;
  }
  function waterCustomCard(name, unit) {
    const latest = latestCustomWaterReading(name);
    const hasValue = !!latest;
    const value = hasValue ? latest.item.value : '—';
    const latestUnit = hasValue && latest.item.unit ? latest.item.unit : (unit || 'unidad por indicar');
    const status = hasValue ? {label:'Registrado',state:'recorded'} : {label:'＋ Registrar medición',state:'pending'};
    return `<button class="waterParamCard" type="button" data-water-custom-name="${escAttr(name)}" data-water-custom-unit="${escAttr(latestUnit)}" aria-label="${escAttr(name)}: ${escAttr(value)} ${escAttr(latestUnit)}"><span class="waterParamCardName">${esc(name)}</span><strong class="waterParamCardValue${String(value).length > 12 ? ' waterParamCardValueLong' : ''}">${esc(displayWaterCardValue(value))}</strong><span class="waterParamCardUnit">${esc(latestUnit)}</span><span class="waterParamCardStatus ${status.state}">${status.label}</span><span class="waterParamCardDate">${esc(hasValue ? waterRelativeDate(latest.reading.date) : 'Sin medición registrada')}</span></button>`;
  }
  function renderWaterParameterGroups() {
    waterCardsReadingsSnapshot = currentWaterReadings();
    try {
    const groups = WATER_GROUPS.map(group => `<section class="waterParameterSection" aria-labelledby="waterGroup_${group.id}"><div class="waterSectionHeading"><span>${group.number}</span><div><h4 id="waterGroup_${group.id}">${group.title}</h4><p>${group.intro}</p></div></div><div class="waterParameterGrid">${group.params.map(param => waterParameterCard(param)).join('')}</div></section>`).join('');
    const customMap = new Map();
    waterCardsReadingsSnapshot.forEach(reading => {
      if (!reading.custom || !String(reading.custom.name || '').trim()) return;
      const name = String(reading.custom.name).trim();
      const key = name.toLocaleLowerCase('es-PE');
      if (!customMap.has(key)) customMap.set(key, {name,unit:reading.custom.unit || ''});
    });
    const customCards = [...customMap.values()].map(item => waterCustomCard(item.name,item.unit)).join('');
    const additional = `<section class="waterParameterSection waterAdditionalSection" aria-labelledby="waterAdditionalTitle"><div class="waterSectionHeading"><span>05</span><div><h4 id="waterAdditionalTitle">Otros análisis y observaciones</h4><p>Agrega un parámetro que no figure en la lista o un resultado informado por laboratorio.</p></div></div><div class="waterParameterGrid">${customCards}<button class="waterParamCard waterParamAddCard" type="button" data-water-custom-add="true"><span class="waterParamAddIcon">＋</span><strong>Añadir parámetro</strong><span class="waterParamAddDescription">Nombre, resultado y unidad personalizados</span></button></div><div class="waterAdditionalNotes"><label for="wqNotes">Observaciones generales de campo / método</label><textarea class="lotesInput" id="wqNotes" rows="2" placeholder="Equipo o kit utilizado, condiciones, color anormal o cambios de caudal…"></textarea></div></section>`;
    return groups + additional;
    } finally {
      waterCardsReadingsSnapshot = null;
    }
  }
  const LOT_WATER_PREVIEW = ['temperature', 'turbidity', 'suspendedSolids', 'transparency'];
  function waterReadingsForLot(lot) {
    if (!lot) return [];
    return readWaterReadings().filter(reading => String(reading.lotId || '') === String(lot.id)
      || (!reading.lotId && reading.lotCode && String(reading.lotCode) === String(lot.code)))
      .sort((a, b) => `${b.date || ''}T${b.time || '00:00'}`.localeCompare(`${a.date || ''}T${a.time || '00:00'}`));
  }
  function renderLotWaterMore(lot, readings) {
    const host = $('lotWaterMoreGroups');
    if (!host || !$('lotWaterMore')?.open) return;
    host.innerHTML = WATER_GROUPS.map(group => {
      const params = group.params.filter(param => !LOT_WATER_PREVIEW.includes(param.id));
      return `<section class="lotWaterGroup"><h5>${esc(group.title)}</h5><div class="waterParameterGrid">${params.map(param => waterParameterCard(param, readings)).join('')}</div></section>`;
    }).join('');
  }
  function renderLotWaterSection() {
    const lot = getLots().find(item => item.id === activeLoteId);
    const host = $('lotWaterCards');
    if (!lot || !host) return;
    const readings = waterReadingsForLot(lot);
    host.innerHTML = LOT_WATER_PREVIEW.map(id => waterParameterCard(WATER_PARAM_LOOKUP[id], readings)).join('');
    renderLotWaterMore(lot, readings);
    renderWaterHistory('lotWaterHistoryList', 'lotWaterHistoryCount', readings);
  }
  function lotWaterEntryFields(lot) {
    if (!lot) return '';
    return `<div class="waterEntryLotContext"><span>Medición para el lote</span><strong>${esc(lot.code)} · ${esc(stageLabel(lot.stage))}</strong></div><div class="waterEntryGrid"><div class="waterEntryField"><label for="lotWaterEntryDate">Fecha</label><input class="lotesInput" id="lotWaterEntryDate" type="date" value="${localDateValue()}"></div><div class="waterEntryField"><label for="lotWaterEntryTime">Hora</label><input class="lotesInput" id="lotWaterEntryTime" type="time" value="${localTimeValue()}"></div></div><div class="waterEntryField"><label for="lotWaterEntryPoint">Punto de medición</label><input class="lotesInput" id="lotWaterEntryPoint" maxlength="100" value="${escAttr(lot.unit)}" placeholder="Estanque, jaula o punto de control"></div>`;
  }
  function openWaterParamEntry(paramId, lotId = null) {
    const param = WATER_PARAM_LOOKUP[paramId];
    if (!param) return;
    const lot = lotId === null ? null : getLots().find(item => item.id === String(lotId));
    if (lotId !== null && !lot) return;
    waterEntryLotId = lot ? lot.id : null;
    activeWaterParamId = paramId;
    activeWaterCustom = null;
    const latest = latestWaterParameterReading(paramId, lot ? waterReadingsForLot(lot) : currentWaterCardReadings());
    const valueType = param.kind === 'text' ? 'text' : 'number';
    const step = valueType === 'number' ? ` step="${escAttr(param.step || 'any')}"` : '';
    const phLimit = param.id === 'ph' ? ' min="0" max="14"' : '';
    const ref = param.ref ? `<div class="waterEntryReference"><b>Referencia</b><span>${esc(param.ref)}</span></div>` : '';
    const latestText = latest ? `<div class="waterEntryLast"><span>Último valor registrado</span><strong>${esc(displayWaterCardValue(latest.item.value ?? latest.item))} ${esc(latest.item.unit || param.unit)}</strong><small>${esc(formatWaterDate(latest.reading.date))} · ${esc(latest.reading.time || 'Hora sin indicar')}</small></div>` : '';
    $('waterParamEntryContent').innerHTML = `${lotWaterEntryFields(lot)}${latestText}<div class="waterEntryField"><label for="waterEntryValue">Nueva medición <span>${esc(param.unit)}</span></label><input class="lotesInput" id="waterEntryValue" type="${valueType}"${step}${phLimit} placeholder="${escAttr(param.placeholder || 'Ingresa el valor medido')}" autocomplete="off" required></div><div class="waterEntryField"><label for="waterEntryNote">Observación de esta medición (opcional)</label><textarea class="lotesInput" id="waterEntryNote" rows="2" placeholder="Método, equipo, condición observada…"></textarea></div>${ref}`;
    $('waterParamEntryTitle').textContent = param.label;
    $('waterParamEntryUnit').textContent = param.unit;
    $('waterParamEntryModal')?.classList.add('open');
    setTimeout(() => $('waterEntryValue')?.focus(), 40);
  }
  function openCustomWaterParamEntry(name = '', unit = '') {
    waterEntryLotId = null;
    activeWaterParamId = null;
    activeWaterCustom = {name:String(name || '').trim(),unit:String(unit || '').trim()};
    const latest = activeWaterCustom.name ? latestCustomWaterReading(activeWaterCustom.name) : null;
    const latestText = latest ? `<div class="waterEntryLast"><span>Último valor registrado</span><strong>${esc(latest.item.value)} ${esc(latest.item.unit || '')}</strong><small>${esc(formatWaterDate(latest.reading.date))} · ${esc(latest.reading.time || 'Hora sin indicar')}</small></div>` : '';
    $('waterParamEntryTitle').textContent = activeWaterCustom.name || 'Añadir parámetro';
    $('waterParamEntryUnit').textContent = 'Personalizado';
    $('waterParamEntryContent').innerHTML = `${latestText}<div class="waterEntryField"><label for="waterEntryName">Nombre del parámetro</label><input class="lotesInput" id="waterEntryName" value="${escAttr(activeWaterCustom.name)}" placeholder="Ej. calcio, fosfato reactivo…" autocomplete="off" required></div><div class="waterEntryGrid"><div class="waterEntryField"><label for="waterEntryValue">Resultado medido</label><input class="lotesInput" id="waterEntryValue" type="text" placeholder="Ej. 12,5" autocomplete="off" required></div><div class="waterEntryField"><label for="waterEntryUnit">Unidad</label><input class="lotesInput" id="waterEntryUnit" value="${escAttr(activeWaterCustom.unit)}" placeholder="Ej. mg/L" autocomplete="off"></div></div><div class="waterEntryField"><label for="waterEntryNote">Observaciones (opcional)</label><textarea class="lotesInput" id="waterEntryNote" rows="2" placeholder="Método, equipo, laboratorio…"></textarea></div>`;
    $('waterParamEntryModal')?.classList.add('open');
    setTimeout(() => $('waterEntryName')?.focus(), 40);
  }
  function closeWaterParamEntry() {
    $('waterParamEntryModal')?.classList.remove('open');
    waterEntryLotId = null;
    activeWaterParamId = null;
    activeWaterCustom = null;
  }
  function saveWaterParamMeasurement() {
    if (!activeWaterParamId && !activeWaterCustom) return;
    const lotEntry = waterEntryLotId !== null;
    const date = (lotEntry ? $('lotWaterEntryDate')?.value : $('wqDate')?.value) || localDateValue();
    const time = (lotEntry ? $('lotWaterEntryTime')?.value : $('wqTime')?.value) || localTimeValue();
    const raw = String($('waterEntryValue')?.value || '').trim();
    if (!raw) { window.alert('Ingresa el resultado de la medición antes de guardar.'); $('waterEntryValue')?.focus(); return; }
    let params = {};
    let custom = null;
    if (activeWaterParamId) {
      const spec = WATER_PARAM_LOOKUP[activeWaterParamId];
      if (!spec) return;
      let value = raw;
      if (spec.kind !== 'text') {
        value = Number(raw.replace(',', '.'));
        if (!Number.isFinite(value)) { window.alert('El valor debe ser numérico.'); return; }
        if (spec.id === 'ph' && (value < 0 || value > 14)) { window.alert('El pH debe estar entre 0 y 14. Revisa el dato ingresado.'); return; }
      }
      params[spec.id] = {value,unit:spec.unit};
    } else {
      const name = String($('waterEntryName')?.value || '').trim();
      const value = raw;
      const unit = String($('waterEntryUnit')?.value || '').trim();
      if (!name) { window.alert('Escribe el nombre del parámetro.'); $('waterEntryName')?.focus(); return; }
      custom = {name,value,unit};
    }
    const lotId = lotEntry ? waterEntryLotId : ($('wqLot')?.value || '');
    const lot = getLots().find(item => String(item.id) === String(lotId));
    if (lotEntry && !lot) { window.alert('Este lote ya no está disponible. Cierra la medición y vuelve a abrir su ficha.'); return; }
    const reading = {
      id: 'AGUA-' + Date.now().toString(36).toUpperCase(), date, time,
      point: (lotEntry ? $('lotWaterEntryPoint')?.value.trim() : $('wqPoint')?.value) || 'Punto sin especificar',
      site: lotEntry ? (lot.origin === 'Sin indicar' ? '' : lot.origin) : String($('wqSite')?.value || '').trim(),
      farmId: lotEntry ? '' : activeWaterFarmId,
      farmName: lotEntry ? '' : (getActiveWaterFarm()?.name || ''),
      lotId, lotCode: lot ? lot.code : '', params, custom,
      note: String($('waterEntryNote')?.value || '').trim() || (lotEntry ? '' : String($('wqNotes')?.value || '').trim())
    };
    const records = readWaterReadings();
    records.unshift(reading);
    writeLotesStorage(WATER_KEY, JSON.stringify(records.slice(0, 500)));
    renderWaterFarmManager();
    if (activeLoteId) renderLotWaterSection();
    const saved = $('waterQualitySaved');
    if (saved) { saved.textContent = `Medición guardada: ${date ? formatWaterDate(date) : 'hoy'} a las ${time}.`; saved.classList.add('visible'); }
    if (lotEntry) {
      const message = $('lotWaterSaved');
      if (message) message.textContent = `Medición guardada: ${formatWaterDate(date)} a las ${time}.`;
    } else {
      const nextTime = $('wqTime'); if (nextTime) nextTime.value = localTimeValue();
    }
    notifySharedDataChanged();
    closeWaterParamEntry();
  }
  function readWaterReadings() {
    try { const rows = JSON.parse(readLotesStorage(WATER_KEY) || '[]'); return Array.isArray(rows) ? rows : []; }
    catch (_) { return []; }
  }
  function localDateValue() {
    const date = new Date();
    date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
    return date.toISOString().slice(0, 10);
  }
  function localTimeValue() { return new Date().toTimeString().slice(0, 5); }
  function formatWaterDate(value) {
    const parts = String(value || '').split('-');
    return parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : String(value || 'Fecha sin indicar');
  }
  function renderWaterHistory(hostId = 'waterQualityHistory', counterId = 'waterQualityHistoryCount', readings = currentWaterReadings()) {
    const host = $(hostId);
    const counter = $(counterId);
    if (!host) return;
    if (counter) counter.textContent = `${readings.length} ${readings.length === 1 ? 'registro' : 'registros'}`;
    if (!readings.length) {
      host.innerHTML = '<div class="waterHistoryEmpty">Todavía no hay mediciones guardadas. Registra los parámetros observados para construir el historial de calidad del agua.</div>';
      return;
    }
    host.innerHTML = readings.slice(0, 8).map(reading => {
      const params = reading.params || {};
      const chips = Object.entries(params).map(([id, item]) => {
        const spec = WATER_PARAM_LOOKUP[id];
        const label = spec ? spec.label : id;
        const value = item && typeof item === 'object' ? item.value : item;
        const unit = item && typeof item === 'object' && item.unit ? item.unit : (spec ? spec.unit : '');
        return `<span class="waterResultChip"><b>${esc(label)}:</b> ${esc(value)}${unit ? ` ${esc(unit)}` : ''}</span>`;
      }).join('');
      const custom = reading.custom ? `<span class="waterResultChip"><b>${esc(reading.custom.name)}:</b> ${esc(reading.custom.value)}${reading.custom.unit ? ` ${esc(reading.custom.unit)}` : ''}</span>` : '';
      const count = Object.keys(params).length + (reading.custom ? 1 : 0);
      const point = reading.point || 'Punto sin especificar';
      const lot = reading.lotCode ? ` · Lote ${reading.lotCode}` : '';
      const note = reading.note ? `<p class="waterHistoryNote">${esc(reading.note)}</p>` : '';
      return `<article class="waterHistoryCard"><div class="waterHistoryCardTop"><div><strong>${esc(point)}</strong><small>${esc(formatWaterDate(reading.date))} · ${esc(reading.time || 'Hora sin indicar')}${reading.farmName ? ' · ' + esc(reading.farmName) : ''}</small></div><span class="waterHistoryCountBadge">${count} ${count === 1 ? 'valor' : 'valores'}</span></div><p class="waterHistoryPlace">${esc(reading.site || 'Lugar no especificado')}${esc(lot)}</p><div class="waterResultChips">${chips}${custom}</div>${note}</article>`;
    }).join('');
  }
  function readWaterFarms() {
    try {
      const rows = JSON.parse(readLotesStorage(WATER_FARMS_KEY) || '[]');
      return Array.isArray(rows) ? rows.filter(row => row && row.id && String(row.name || '').trim()) : [];
    } catch (_) { return []; }
  }
  function writeWaterFarms(farms) { writeLotesStorage(WATER_FARMS_KEY, JSON.stringify(farms)); }
  function getActiveWaterFarm() {
    if (String(activeWaterFarmId) === '__unassigned__' && readWaterReadings().some(reading => !reading.farmId || String(reading.farmId) === '__unassigned__')) {
      return {id:'__unassigned__',name:'Mediciones anteriores sin centro asignado',type:'Registros anteriores',location:'Sin asociación original',system:'',waterSource:'Sin especificar',notes:''};
    }
    return readWaterFarms().find(farm => String(farm.id) === String(activeWaterFarmId)) || null;
  }
  function waterFarmReadings(farmId) {
    const rows = readWaterReadings();
    if (String(farmId) === '__unassigned__') return rows.filter(reading => !reading.farmId || String(reading.farmId) === '__unassigned__');
    return rows.filter(reading => String(reading.farmId || '') === String(farmId));
  }
  function newWaterFarmId() { return 'CENTRO-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2,6).toUpperCase(); }
  function renderWaterFarmManager() {
    const list = $('waterFarmList');
    const workspace = $('waterFarmWorkspace');
    if (!list || !workspace) return;
    const farms = readWaterFarms();
    const allRecords = readWaterReadings();
    const legacyRecords = allRecords.filter(reading => !reading.farmId || String(reading.farmId) === '__unassigned__');
    const displayFarms = farms.slice();
    if (legacyRecords.length) displayFarms.push({id:'__unassigned__',name:'Mediciones anteriores sin centro asignado',type:'Registros anteriores',location:'Sin asociación original',system:'',waterSource:'Sin especificar',notes:''});
    if (activeWaterFarmId && !displayFarms.some(farm => String(farm.id) === String(activeWaterFarmId))) activeWaterFarmId = null;
    const active = getActiveWaterFarm();
    const subtitle = $('waterQualitySubtitle');
    if (subtitle) subtitle.textContent = active ? `Registra los parámetros físico-químicos de ${active.name}. Cada medición quedará asociada a este centro.` : 'Crea una granja o centro piscícola y abre su ficha para registrar y consultar los parámetros del agua.';
    if (!displayFarms.length) {
      list.innerHTML = '<div class="waterFarmEmpty"><strong>Empieza registrando tu primera instalación</strong>Crea una granja o centro piscícola. Después podrás guardar las mediciones de agua en su ficha y mantener su historial organizado.</div>';
    } else {
      list.innerHTML = displayFarms.map(farm => {
        const records = String(farm.id) === '__unassigned__'
          ? legacyRecords : allRecords.filter(reading => String(reading.farmId || '') === String(farm.id));
        const last = records[0];
        const isActive = String(farm.id) === String(activeWaterFarmId);
        const isLegacy = String(farm.id) === '__unassigned__';
        const location = [farm.location, farm.system].filter(Boolean).join(' · ') || 'Ubicación / sistema sin especificar';
        const source = farm.waterSource || 'Sin especificar';
        const actionButtons = isLegacy
          ? `<div class="waterFarmActions"><button class="waterFarmOpenBtn" type="button" data-water-farm-select="${escAttr(farm.id)}">${isActive ? 'Historial abierto ✓' : 'Abrir historial →'}</button></div>`
          : `<div class="waterFarmActions"><button class="waterFarmOpenBtn" type="button" data-water-farm-select="${escAttr(farm.id)}">${isActive ? 'Centro abierto ✓' : 'Abrir parámetros →'}</button><button class="waterFarmEditBtn" type="button" data-water-farm-edit="${escAttr(farm.id)}">Editar</button></div>`;
        return `<article class="waterFarmCard${isActive ? ' selected' : ''}" data-water-farm-card="${escAttr(farm.id)}">
          <div class="waterFarmCardTop"><div class="waterFarmTitleWrap"><span class="waterFarmType">${esc(farm.type || 'Centro piscícola')}</span><h5 class="waterFarmName">${esc(farm.name)}</h5><p class="waterFarmPlace">⌖ ${esc(location)}</p></div><span class="waterFarmStatus"><i></i>${isActive ? 'Seleccionado' : isLegacy ? 'Por organizar' : 'Registrado'}</span></div>
          <div class="waterFarmStats"><div class="waterFarmStat"><strong>${whole(records.length)}</strong><span>Registros de agua</span></div><div class="waterFarmStat"><strong>${esc(last ? formatWaterDate(last.date) : '—')}</strong><span>Última medición</span></div></div>
          <p class="waterFarmPlace" style="margin-top:8px">${isLegacy ? 'Estos registros conservan sus datos, pero no tenían una granja asociada.' : 'Abastecimiento: ' + esc(source) + (farm.notes ? ' · ' + esc(farm.notes) : '')}</p>
          ${actionButtons}
        </article>`;
      }).join('');
    }
    workspace.hidden = !active;
    if (active) {
      const title = $('waterFarmWorkspaceName'); if (title) title.textContent = active.name;
      const meta = $('waterFarmWorkspaceMeta');
      if (meta) meta.textContent = [active.type, active.location, active.system, 'Agua: ' + (active.waterSource || 'sin especificar')].filter(Boolean).join(' · ');
      const site = $('wqSite'); if (site && !site.value && active.location && active.id !== '__unassigned__') site.value = active.location;
      $('waterParameterGroups').innerHTML = renderWaterParameterGroups();
      renderWaterHistory();
      renderedWaterFarmId = String(active.id);
    } else {
      const groups = $('waterParameterGroups'); if (groups) groups.innerHTML = '';
      const history = $('waterQualityHistory'); if (history) history.innerHTML = '';
      const counter = $('waterQualityHistoryCount'); if (counter) counter.textContent = '0 registros';
      renderedWaterFarmId = null;
    }
  }
  // Animación desacoplada del render pesado: el panel comienza a deslizarse primero.
  function cancelPendingWaterDrawerWork() {
    ++waterDrawerGeneration;
    if (waterDrawerOpenFrame !== null) {
      cancelAnimationFrame(waterDrawerOpenFrame);
      waterDrawerOpenFrame = null;
    }
    if (waterDrawerRenderTimer !== null) {
      clearTimeout(waterDrawerRenderTimer);
      waterDrawerRenderTimer = null;
    }
  }
  function openWaterFarmDrawer() {
    if (!activeWaterFarmId || !$('waterFarmWorkspace') || $('waterFarmWorkspace').hidden) return;
    const drawer = $('waterFarmDrawer');
    if (!drawer) return;
    drawer.setAttribute('aria-hidden', 'false');
    // Dos cuadros garantizan que WebView pinte primero el panel fuera de pantalla.
    // El cambio a .open sólo mueve una capa GPU: no calcula tarjetas ni historiales.
    waterDrawerOpenFrame = requestAnimationFrame(() => {
      waterDrawerOpenFrame = requestAnimationFrame(() => {
        waterDrawerOpenFrame = null;
        if (drawer.getAttribute('aria-hidden') === 'false') drawer.classList.add('open');
      });
    });
    const panel = $('waterFarmDrawerPanel');
    if (panel) panel.scrollTop = 0;
  }
  function closeWaterFarmDrawer() {
    cancelPendingWaterDrawerWork();
    const drawer = $('waterFarmDrawer');
    if (!drawer) return;
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden', 'true');
    if (drawer.contains(document.activeElement)) {
      const selected = $('waterFarmList')?.querySelector('.waterFarmCard.selected .waterFarmOpenBtn');
      selected?.focus({preventScroll:true});
    }
  }
  function selectWaterFarm(id, openDrawer = true) {
    const isLegacy = String(id) === '__unassigned__';
    const farm = isLegacy
      ? (readWaterReadings().some(reading => !reading.farmId || String(reading.farmId) === '__unassigned__')
          ? {id:'__unassigned__',name:'Mediciones anteriores sin centro asignado',type:'Registros anteriores',location:'Sin asociación original',system:'',waterSource:'Sin especificar'} : null)
      : readWaterFarms().find(item => String(item.id) === String(id));
    if (!farm) return;
    cancelPendingWaterDrawerWork();
    const generation = waterDrawerGeneration;
    activeWaterFarmId = farm.id;
    writeLotesStorage(WATER_ACTIVE_FARM_KEY, activeWaterFarmId);
    if (!openDrawer) { renderWaterFarmManager(); return; }
    // Actualización mínima del encabezado y de las tarjetas; sin reconstruir 46 controles.
    $('waterFarmList')?.querySelectorAll('[data-water-farm-card]').forEach(card => {
      const isSelected = String(card.dataset.waterFarmCard) === String(farm.id);
      card.classList.toggle('selected', isSelected);
      const status = card.querySelector('.waterFarmStatus');
      if (status) status.innerHTML = '<i></i>' + (isSelected ? 'Seleccionado' : String(card.dataset.waterFarmCard) === '__unassigned__' ? 'Por organizar' : 'Registrado');
      const button = card.querySelector('.waterFarmOpenBtn');
      if (button) button.textContent = isSelected ? (isLegacy ? 'Historial abierto ✓' : 'Centro abierto ✓') : (String(card.dataset.waterFarmCard) === '__unassigned__' ? 'Abrir historial →' : 'Abrir parámetros →');
    });
    const subtitle = $('waterQualitySubtitle');
    if (subtitle) subtitle.textContent = `Registra los parámetros físico-químicos de ${farm.name}. Cada medición quedará asociada a este centro.`;
    const workspace = $('waterFarmWorkspace');
    if (!workspace) return;
    workspace.hidden = false;
    const title = $('waterFarmWorkspaceName'); if (title) title.textContent = farm.name;
    const meta = $('waterFarmWorkspaceMeta');
    if (meta) meta.textContent = [farm.type, farm.location, farm.system, 'Agua: ' + (farm.waterSource || 'sin especificar')].filter(Boolean).join(' · ');
    const site = $('wqSite'); if (site && farm.location && !isLegacy && !site.value) site.value = farm.location;
    const needsRender = renderedWaterFarmId !== String(farm.id);
    if (needsRender) {
      // No conservar el id anterior cuando sustituimos las tarjetas por un indicador de carga.
      // Evita mostrar un panel vacío al cambiar de centro antes de acabar la animación.
      renderedWaterFarmId = null;
      const groups = $('waterParameterGroups');
      if (groups) groups.innerHTML = '<div class="waterDrawerLoading" role="status">Preparando parámetros del centro…</div>';
      const history = $('waterQualityHistory');
      if (history) history.innerHTML = '';
      const count = $('waterQualityHistoryCount'); if (count) count.textContent = '…';
    }
    openWaterFarmDrawer();
    if (needsRender) {
      // Esperar a que termine la traslación evita saltos en Android WebView.
      const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      waterDrawerRenderTimer = setTimeout(() => {
        waterDrawerRenderTimer = null;
        if (generation !== waterDrawerGeneration || String(activeWaterFarmId) !== String(farm.id)) return;
        renderWaterFarmManager();
      }, reducedMotion ? 0 : 295);
    }
  }
  function openWaterFarmEditor(farmId = null) {
    editingWaterFarmId = farmId;
    const farm = farmId ? readWaterFarms().find(item => String(item.id) === String(farmId)) : null;
    $('waterFarmEditorTitle').textContent = farm ? 'Editar granja o centro' : 'Crear granja o centro piscícola';
    $('saveWaterFarmBtn').textContent = farm ? 'Guardar cambios' : 'Guardar centro';
    const fill = (id, value) => { const el = $(id); if (el) el.value = value || ''; };
    fill('wfName', farm?.name || '');
    fill('wfType', farm?.type || 'Centro piscícola');
    fill('wfSystem', farm?.system || 'Mixto');
    fill('wfLocation', farm?.location || '');
    fill('wfWaterSource', farm?.waterSource || 'Sin especificar');
    fill('wfNotes', farm?.notes || '');
    const message = $('waterFarmEditorMessage'); if (message) { message.textContent = ''; message.classList.remove('visible'); }
    $('waterFarmEditorModal')?.classList.add('open');
    setTimeout(() => $('wfName')?.focus(), 40);
  }
  function closeWaterFarmEditor() { $('waterFarmEditorModal')?.classList.remove('open'); }
  function saveWaterFarmFromModal() {
    const name = String($('wfName')?.value || '').trim();
    const message = $('waterFarmEditorMessage');
    if (!name) {
      if (message) { message.textContent = 'Escribe un nombre para identificar la granja o el centro piscícola.'; message.classList.add('visible'); }
      $('wfName')?.focus(); return;
    }
    const farms = readWaterFarms();
    const duplicated = farms.some(farm => String(farm.id) !== String(editingWaterFarmId || '') && String(farm.name || '').trim().toLocaleLowerCase('es-PE') === name.toLocaleLowerCase('es-PE'));
    if (duplicated) {
      if (message) { message.textContent = 'Ya existe una ficha con ese nombre. Usa un nombre distinto para diferenciar los centros.'; message.classList.add('visible'); }
      $('wfName')?.focus(); return;
    }
    const previous = editingWaterFarmId ? farms.find(farm => String(farm.id) === String(editingWaterFarmId)) : null;
    const farm = {
      id: previous ? previous.id : newWaterFarmId(),
      name,
      type: String($('wfType')?.value || 'Centro piscícola'),
      system: String($('wfSystem')?.value || 'Mixto'),
      location: String($('wfLocation')?.value || '').trim(),
      waterSource: String($('wfWaterSource')?.value || 'Sin especificar'),
      notes: String($('wfNotes')?.value || '').trim(),
      createdAt: previous?.createdAt || localDateValue(),
      updatedAt: localDateValue()
    };
    const next = previous ? farms.map(item => String(item.id) === String(previous.id) ? farm : item) : [farm, ...farms];
    writeWaterFarms(next);
    activeWaterFarmId = farm.id;
    writeLotesStorage(WATER_ACTIVE_FARM_KEY, farm.id);
    closeWaterFarmEditor();
    renderWaterFarmManager();
    if (previous && $('wqSite') && !$('wqSite').value) $('wqSite').value = farm.location;
    if (!previous) $('wqSite').value = farm.location || '';
    closeWaterFarmDrawer();
    $('waterFarmManagerTitle')?.scrollIntoView({behavior:'smooth', block:'nearest'});
  }
  function openWaterQuality() {
    const date = $('wqDate'); if (date && !date.value) date.value = localDateValue();
    const time = $('wqTime'); if (time && !time.value) time.value = localTimeValue();
    if (!activeWaterFarmId) {
      const savedId = readLotesStorage(WATER_ACTIVE_FARM_KEY);
      const hasSavedFarm = savedId && (readWaterFarms().some(farm => String(farm.id) === String(savedId)) || (String(savedId) === '__unassigned__' && readWaterReadings().some(reading => !reading.farmId || String(reading.farmId) === '__unassigned__')));
      if (hasSavedFarm) activeWaterFarmId = savedId;
    }
    renderWaterFarmManager();
    closeWaterFarmDrawer();
    $('waterQualityModal')?.classList.add('open');
  }
  function closeWaterQuality() { closeWaterFarmDrawer(); $('waterQualityModal')?.classList.remove('open'); closeWaterFarmEditor(); closeWaterParamEntry(); }
  const nfmt = (value, digits = 1) => Number(value || 0).toLocaleString('es-PE', {
    minimumFractionDigits: 0, maximumFractionDigits: digits
  });
  const whole = value => Number(value || 0).toLocaleString('es-PE', { maximumFractionDigits: 0 });
  const optionalNumber = value => value === '' || value === null || value === undefined || !Number.isFinite(Number(value))
    ? null : Math.max(0, Number(value));
  const today = () => new Date().toISOString().slice(0, 10);
  const isAndroid = () => typeof window.AndroidAI !== 'undefined';

  function newId() { return 'LOTE-' + Date.now().toString(36).toUpperCase(); }
  function stageLabel(stage) {
    const aliases = {
      ovas: 'Ovas', alevinaje: 'Alevinaje', juvenil: 'Juvenil', engorde: 'Engorde',
      reproductores: 'Reproductores', 'alevín': 'Alevinaje'
    };
    const value = String(stage || 'Producción');
    return aliases[value.toLowerCase()] || value;
  }
  function slugStage(stage) {
    const value = stageLabel(stage).toLowerCase();
    return ({ ovas: 'ovas', alevinaje: 'alevinaje', juvenil: 'juvenil', engorde: 'engorde', reproductores: 'reproductores' })[value] || 'alevinaje';
  }
  function historyItem(h, lot) {
    h = h || {};
    return {
      d: String(h.d || h.date || lot.date || today()),
      w: Math.max(0, Number(h.w ?? h.currentWeight ?? lot.w) || 0),
      l: optionalNumber(h.l ?? h.length),
      m: Math.max(0, Number(h.m ?? h.mortality) || 0),
      discard: Math.max(0, Number(h.discard ?? h.discarded) || 0),
      feedKg: optionalNumber(h.feedKg ?? h.alimentoConsumido),
      pelletCalibre: optionalNumber(h.pelletCalibre),
      fcr: optionalNumber(h.fcr),
      x: String(h.x || h.note || '')
    };
  }
  function normalizeLot(source) {
    const src = source || {};
    const id = String(src.id || src.code || newId());
    const code = String(src.code || src.id || id);
    const n = Math.max(0, Math.floor(Number(src.n ?? src.currentCount ?? src.initialCount) || 0));
    const w = Math.max(0, Number(src.w ?? src.currentWeight ?? src.initialWeight) || 0);
    const mortalitySpecified = src.m !== undefined || src.mortality !== undefined;
    const discarded = Math.max(0, Math.floor(Number(src.discarded ?? src.discard ?? 0) || 0));
    let initialN = Math.max(0, Math.floor(Number(src.initialN ?? src.initialCount) || 0));
    if (!initialN) initialN = n + discarded + (mortalitySpecified ? Math.max(0, Math.floor(Number(src.m ?? src.mortality) || 0)) : 0);
    const m = Math.max(0, Math.floor(mortalitySpecified ? (Number(src.m ?? src.mortality) || 0) : initialN - n - discarded));
    initialN = Math.max(initialN, n + m + discarded);
    const initialWeight = Math.max(0, Number(src.w0 ?? src.initialWeight ?? src.w ?? src.currentWeight) || 0);
    const base = {
      id, code,
      stage: stageLabel(src.stage),
      unit: String(src.unit || 'Sin indicar'),
      origin: String(src.origin || 'Sin indicar'),
      date: String(src.date || today()),
      initialN,
      initialWeight,
      n, w,
      l: optionalNumber(src.l ?? src.length),
      pelletCalibre: optionalNumber(src.pelletCalibre ?? src.pelletSize),
      alimentoConsumido: optionalNumber(src.alimentoConsumido ?? src.feedKg),
      fcr: optionalNumber(src.fcr),
      m,
      discarded,
      targetWeight: Math.max(1, Number(src.targetWeight) || 210),
      harvestKg: Math.max(0, Number(src.harvestKg) || 0),
      history: []
    };
    const rawHistory = Array.isArray(src.history) ? src.history : [];
    base.history = rawHistory.map(h => historyItem(h, base));
    if (!base.history.length) {
      base.history.push({ d: base.date, w: base.w, l: base.l, m: 0, discard: 0, feedKg: null, pelletCalibre: base.pelletCalibre, fcr: base.fcr, x: 'Lote registrado' });
    }
    return base;
  }
  function parseLots(raw) {
    try {
      const value = JSON.parse(raw || '[]');
      return Array.isArray(value) ? value.map(normalizeLot) : [];
    } catch (_) { return []; }
  }
  function localLots() {
    try { return parseLots(readLotesStorage(KEY)); } catch (_) { return []; }
  }
  function nativeLots() {
    if (!isAndroid() || typeof AndroidAI.getLots !== 'function') return null;
    try {
      const parsed = JSON.parse(AndroidAI.getLots());
      return Array.isArray(parsed) ? parsed.map(normalizeLot) : null;
    } catch (_) { return null; }
  }
  function saveLocal(lots) {
    try { writeLotesStorage(KEY, JSON.stringify(lots)); } catch (_) {}
  }
  function saveNative(lots) {
    if (!isAndroid() || typeof AndroidAI.saveLots !== 'function') return;
    try { AndroidAI.saveLots(JSON.stringify(lots)); } catch (_) {}
  }
  function getLots() {
    const local = localLots();
    const native = nativeLots();
    // If this is an existing installation, migrate WebView localStorage lots before relying on
    // the new native preference key, which did not exist in older versions.
    if (local.length && (!native || native.length === 0)) {
      saveNative(local);
      return local;
    }
    if (native && native.length) {
      saveLocal(native);
      return native;
    }
    return local;
  }
  function survival(lot) {
    const initial = Math.max(Number(lot.initialN) || 0, (Number(lot.n) || 0) + (Number(lot.m) || 0) + (Number(lot.discarded) || 0));
    return initial > 0 ? Math.max(0, Number(lot.n) || 0) / initial * 100 : 0;
  }
  function biomass(lot) { return Math.max(0, Number(lot.n) || 0) * Math.max(0, Number(lot.w) || 0) / 1000; }
  function daysSince(dateValue) {
    if (!dateValue) return 0;
    const start = new Date(String(dateValue).slice(0, 10) + 'T00:00:00Z');
    const end = new Date(today() + 'T00:00:00Z');
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime())) return 0;
    return Math.max(0, Math.floor((end.getTime() - start.getTime()) / 86400000));
  }
  function performanceData(lot) {
    const days = daysSince(lot.date);
    const initialWeight = Number(lot.initialWeight) || 0;
    const weight = Number(lot.w) || 0;
    const sgr = days > 0 && initialWeight > 0 && weight > 0
      ? (Math.log(weight / initialWeight) / days) * 100 : null;
    const fcrValue = lot.fcr !== null && lot.fcr !== undefined && Number.isFinite(Number(lot.fcr)) && Number(lot.fcr) > 0
      ? Number(lot.fcr) : null;
    return {lot, biomass: biomass(lot), weight, survival: survival(lot), sgr, fcr: fcrValue, days};
  }
  function performanceMetricValue(row, key) {
    return key === 'biomass' ? row.biomass : key === 'survival' ? row.survival : key === 'weight' ? row.weight : key === 'sgr' ? row.sgr : row.fcr;
  }
  function performanceMetricText(row, key) {
    const value = performanceMetricValue(row, key);
    if (value === null || value === undefined || !Number.isFinite(value)) return '—';
    if (key === 'biomass') return nfmt(value, 1) + ' kg';
    if (key === 'survival') return nfmt(value, 1) + '%';
    if (key === 'weight') return nfmt(value, 1) + ' g';
    if (key === 'sgr') return nfmt(value, 2) + '%/día';
    return nfmt(value, 2);
  }
  function openPerformance() {
    const sort = $('performanceSort');
    if (sort) sort.value = 'biomass';
    renderPerformanceCompare();
    $('performanceModal')?.classList.add('open');
  }
  function closePerformance() { $('performanceModal')?.classList.remove('open'); }
  function renderPerformanceCompare() {
    const summary = $('performanceSummary');
    const content = $('performanceContent');
    if (!summary || !content) return;
    const lots = getLots();
    const totalFish = lots.reduce((sum, lot) => sum + (Number(lot.n) || 0), 0);
    const totalInitial = lots.reduce((sum, lot) => sum + (Number(lot.initialN) || 0), 0);
    const totalBiomass = lots.reduce((sum, lot) => sum + biomass(lot), 0);
    const overallSurvival = totalInitial > 0 ? totalFish / totalInitial * 100 : null;
    summary.innerHTML = `<div class="performanceSummaryCard"><b>${whole(lots.length)}</b><span>Lotes comparados</span></div><div class="performanceSummaryCard"><b>${nfmt(totalBiomass, 1)} kg</b><span>Biomasa viva</span></div><div class="performanceSummaryCard"><b>${overallSurvival === null ? '—' : nfmt(overallSurvival, 1) + '%'}</b><span>Supervivencia global</span></div>`;
    if (!lots.length) {
      content.innerHTML = '<div class="performanceEmpty">Todavía no hay lotes registrados para comparar. Crea un lote y registra sus primeros datos productivos.</div>';
      return;
    }
    const sortKey = $('performanceSort')?.value || 'biomass';
    const rows = lots.map(performanceData);
    rows.sort((a, b) => {
      const av = performanceMetricValue(a, sortKey), bv = performanceMetricValue(b, sortKey);
      const aMissing = av === null || av === undefined || !Number.isFinite(av);
      const bMissing = bv === null || bv === undefined || !Number.isFinite(bv);
      if (aMissing && bMissing) return String(a.lot.code).localeCompare(String(b.lot.code));
      if (aMissing) return 1;
      if (bMissing) return -1;
      return sortKey === 'fcr' ? av - bv : bv - av;
    });
    const vals = rows.map(row => performanceMetricValue(row, sortKey)).filter(value => value !== null && value !== undefined && Number.isFinite(value));
    const maxValue = vals.length ? Math.max(...vals) : 0;
    const minValue = vals.length ? Math.min(...vals) : 0;
    const labels = {biomass:'Biomasa',survival:'Supervivencia',weight:'Peso promedio',sgr:'Crecimiento específico',fcr:'FCR último registrado'};
    content.innerHTML = rows.map((row, index) => {
      const value = performanceMetricValue(row, sortKey);
      const hasValue = value !== null && value !== undefined && Number.isFinite(value);
      let bar = 0;
      if (hasValue && maxValue > 0) bar = sortKey === 'fcr' ? Math.min(100, minValue / value * 100) : Math.min(100, value / maxValue * 100);
      const stage = esc(stageLabel(row.lot.stage));
      const meta = `${stage} · ${esc(row.lot.unit || 'Sin unidad')} · ${row.days} días desde ingreso`;
      const best = index === 0 && hasValue;
      return `<article class="performanceLot"><div class="performanceLotHead"><div><div class="performanceLotTitle">${esc(row.lot.code)}</div><div class="performanceLotMeta">${meta}</div>${best ? '<span class="performanceBest">Mejor en ' + labels[sortKey].toLowerCase() + '</span>' : ''}</div><span class="performanceRank">${String(index + 1).padStart(2, '0')}</span></div><div class="performanceMetricGrid"><div class="performanceMetric"><b>${nfmt(row.biomass, 1)} kg</b><span>Biomasa</span></div><div class="performanceMetric"><b>${nfmt(row.weight, 1)} g</b><span>Peso promedio</span></div><div class="performanceMetric"><b>${nfmt(row.survival, 1)}%</b><span>Supervivencia</span></div><div class="performanceMetric"><b>${row.sgr === null ? '—' : nfmt(row.sgr, 2) + '%'}</b><span>SGR (%/día)</span></div><div class="performanceMetric"><b>${row.fcr === null ? '—' : nfmt(row.fcr, 2)}</b><span>FCR último registro</span></div><div class="performanceMetric"><b>${row.days}</b><span>Días desde ingreso</span></div></div><div class="performanceBarWrap" role="img" aria-label="${labels[sortKey]} de ${esc(row.lot.code)}: ${performanceMetricText(row, sortKey)}"><div class="performanceBar" style="width:${bar}%"></div></div><div class="performanceLotMeta" style="margin-top:5px">${labels[sortKey]}: <b>${performanceMetricText(row, sortKey)}</b></div></article>`;
    }).join('');
  }

  function health(lot) {
    const count = Number(lot.n), weight = Number(lot.w), surv = survival(lot);
    if (!Number.isFinite(count) || count <= 0 || !Number.isFinite(weight) || weight <= 0) return { level: 'critical', label: 'Crítico', survival: surv };
    if (surv < 90) return { level: 'critical', label: 'Crítico', survival: surv };
    if (surv < 95) return { level: 'regular', label: 'Regular', survival: surv };
    return { level: 'good', label: 'Bueno', survival: surv };
  }
  function currentDataSummary(lot) {
    const hs = lot.history && lot.history[0];
    return {
      id: lot.id, code: lot.code, stage: lot.stage, date: lot.date, unit: lot.unit, origin: lot.origin,
      initialN: lot.initialN, initialWeight: lot.initialWeight,
      fish: lot.n, weightG: lot.w, lengthCm: lot.l, biomassKg: biomass(lot), survivalPct: survival(lot),
      pelletCalibreMm: lot.pelletCalibre, feedConsumedKg: lot.alimentoConsumido, fcr: lot.fcr,
      mortalityTotal: lot.m, discardTotal: lot.discarded, harvestKg: lot.harvestKg,
      lastSample: hs ? Object.assign({}, hs) : null,
      history: (lot.history || []).map(h => Object.assign({}, h))
    };
  }
  function notifySharedDataChanged() {
    try { window.dispatchEvent(new CustomEvent('truchapp-lots-updated')); } catch (_) {}
    if (typeof window.refreshAgendaLotOptions === 'function') window.refreshAgendaLotOptions();
    if (typeof window.renderMemory === 'function') window.renderMemory();
    if (typeof window.updateFinanceLotOptions === 'function') window.updateFinanceLotOptions();
  }
  function persistLots(lots) {
    const normalized = (Array.isArray(lots) ? lots : []).map(normalizeLot);
    saveLocal(normalized);
    saveNative(normalized);
    notifySharedDataChanged();
  }
  function apiGetLots() { return getLots().map(currentDataSummary); }
  function apiGetLot(id) {
    const lot = getLots().find(x => x.id === String(id) || x.code === String(id));
    return lot ? currentDataSummary(lot) : null;
  }
  function apiSummary() {
    const lots = getLots();
    return {
      lotCount: lots.length,
      fishCount: lots.reduce((sum, lot) => sum + lot.n, 0),
      biomassKg: lots.reduce((sum, lot) => sum + biomass(lot), 0),
      mortalityTotal: lots.reduce((sum, lot) => sum + lot.m, 0),
      discardTotal: lots.reduce((sum, lot) => sum + lot.discarded, 0),
      lots: lots.map(currentDataSummary)
    };
  }
  window.TruchAppData = Object.assign(window.TruchAppData || {}, {
    getLots: apiGetLots,
    getLot: apiGetLot,
    getLotSummary: apiSummary
  });

  function fishSvg() {
    // A right-facing, teal-blue rainbow trout. The fish stays in place; only a subtle body float and tail flick animate.
    return `<svg class="lotesFish" viewBox="0 0 140 82" role="img" aria-label="Trucha arcoíris nadando suavemente en su sitio" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="lotFishBodyGradient" x1="0" y1="0" x2="0.12" y2="1"><stop offset="0" stop-color="#0b6574"/><stop offset=".42" stop-color="#159caa"/><stop offset=".78" stop-color="#42c7c2"/><stop offset="1" stop-color="#b9f3e6"/></linearGradient>
        <linearGradient id="lotFishFinGradient" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#167d8e"/><stop offset="1" stop-color="#54d7c9"/></linearGradient>
        <linearGradient id="lotFishBellyGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d9fff4" stop-opacity=".25"/><stop offset="1" stop-color="#e6fff8" stop-opacity=".96"/></linearGradient>
      </defs>
      <g class="lotesFishTail">
        <path d="M31 40 C20 32 12 22 4 17 C7 29 8 37 8 41 C7 49 7 57 4 65 C15 59 24 50 32 43 Z" fill="url(#lotFishFinGradient)" stroke="#0b7180" stroke-width="1.2" stroke-linejoin="round"/>
        <path d="M10 23 Q19 35 29 40 M10 59 Q20 48 29 43" fill="none" stroke="#9ef1e2" stroke-opacity=".8" stroke-width="1.2" stroke-linecap="round"/>
      </g>
      <path d="M28 39 C39 24 61 17 83 21 C99 23 111 27 124 34 Q132 39 124 44 C111 51 99 56 82 58 C59 61 39 53 28 43 Z" fill="url(#lotFishBodyGradient)" stroke="#0c7282" stroke-width="1.2"/>
      <path d="M36 43 C52 51 77 55 100 48 C108 46 115 43 123 40 C111 53 95 57 81 58 C60 60 43 53 36 43 Z" fill="url(#lotFishBellyGradient)"/>
      <path d="M50 23 C55 14 63 9 75 8 C72 16 75 20 82 22 Z" fill="url(#lotFishFinGradient)" stroke="#0b7180" stroke-width="1" stroke-linejoin="round"/>
      <path d="M71 57 C78 60 84 64 91 69 C91 61 89 57 84 55 Z" fill="url(#lotFishFinGradient)" stroke="#0b7180" stroke-width="1" stroke-linejoin="round"/>
      <path d="M86 47 C91 51 95 55 100 58 C101 51 99 47 96 44 Z" fill="#25aeb5" stroke="#0b7180" stroke-width="1" stroke-linejoin="round"/>
      <path d="M38 34 Q61 28 82 32 Q100 34 119 38" fill="none" stroke="#8be5da" stroke-opacity=".75" stroke-width="1.3" stroke-linecap="round"/>
      <g fill="#075b70" opacity=".75">
        <ellipse cx="43" cy="31" rx="1.4" ry="1"/><ellipse cx="51" cy="26" rx="1.2" ry=".9"/><ellipse cx="59" cy="31" rx="1.5" ry="1.1"/><ellipse cx="68" cy="25" rx="1.2" ry=".9"/><ellipse cx="75" cy="30" rx="1.5" ry="1.1"/><ellipse cx="84" cy="26" rx="1.2" ry=".9"/><ellipse cx="93" cy="31" rx="1.4" ry="1"/><ellipse cx="101" cy="34" rx="1.2" ry=".9"/><ellipse cx="64" cy="38" rx="1.1" ry=".8"/><ellipse cx="76" cy="38" rx="1.3" ry=".9"/><ellipse cx="88" cy="39" rx="1.1" ry=".8"/>
      </g>
      <path d="M107 29 Q114 31 121 36" fill="none" stroke="#d7fff5" stroke-width="1.1" stroke-linecap="round"/>
      <path d="M104 28 Q112 25 119 34 Q125 40 118 45 Q111 49 103 46 Q110 40 104 28 Z" fill="#36bfc0" stroke="#0d7787" stroke-width="1.1"/>
      <circle cx="115" cy="34" r="4.2" fill="#e9fffb"/><circle cx="116" cy="34" r="2.8" fill="#063d56"/><circle cx="117" cy="33" r="1" fill="#ffffff"/>
      <path d="M124 41 Q128 42 131 40" fill="none" stroke="#075b70" stroke-width="1.2" stroke-linecap="round"/>
      <path d="M54 23 Q68 20 83 23" fill="none" stroke="#aaf7e9" stroke-opacity=".8" stroke-width="1.1" stroke-linecap="round"/>
    </svg>`;
  }
  function render() {
    const root = $(rootId);
    if (!root || rendering) return;
    rendering = true;
    const lots = getLots();
    const totalFish = lots.reduce((sum, lot) => sum + lot.n, 0);
    const totalBiomass = lots.reduce((sum, lot) => sum + biomass(lot), 0);
    root.innerHTML = `
      <div class="lotesModule">
        <div class="lotesHead"><div><h2>Lotes</h2><p>Seguimiento de existencias, biometrías, alimentación, mortalidad y cosecha por lote.</p></div><div class="lotesBadgeStack"><button class="lotesBadge" id="openPerformanceBtn" type="button" aria-haspopup="dialog" aria-controls="performanceModal" title="Comparar rendimiento de lotes"><span class="lotesFishLane">${fishSvg()}</span><span class="lotesBadgeLabel">Rendimiento de lotes</span></button><button class="lotesBadge waterQualityBadge" id="openWaterQualityBtn" type="button" aria-haspopup="dialog" aria-controls="waterQualityModal" title="Registrar parámetros físico-químicos del agua"><span class="waterBadgeIcon" aria-hidden="true">💧</span><span class="lotesBadgeLabel">Parámetros físico-químicos</span></button></div></div>
        <div class="lotesKpis"><div class="lotesKpi"><b id="kpiLotes">${whole(lots.length)}</b><span>Lotes activos</span></div><div class="lotesKpi"><b id="kpiPeces">${whole(totalFish)}</b><span>Peces en existencia</span></div><div class="lotesKpi"><b id="kpiBiomasa">${nfmt(totalBiomass, 1)} kg</b><span>Biomasa estimada</span></div></div>
        <button class="createLoteTrigger" id="createLoteTrigger" type="button">＋ Crear nuevo lote</button>
        <div class="lotesCard"><div class="lotesHead innerHead"><div><div class="lotesLabel">Mis lotes</div><div class="lotesHint" style="margin:0">Una ficha por lote para seguir el ciclo productivo.</div></div><span class="lotesStage">🐟 seguimiento local</span></div><div class="lotesSearchWrap"><span class="lotesSearchIcon" aria-hidden="true">⌕</span><input class="lotesSearchInput" id="lotesSearch" type="search" autocomplete="off" aria-label="Buscar lotes" placeholder="Buscar por código, etapa, unidad u origen"></div><div class="lotesCards" id="lotesList"></div></div>
        <div class="lotesCard"><div class="lotesLabel">Qué conviene registrar</div><p class="lotesHint" style="font-size:12px">Existencias, mortalidad, biometrías, alimentación, movimientos y cosecha. El historial permite comparar crecimiento, supervivencia y manejo.</p><p class="lotesSource"><b>Referencias técnicas:</b> FAO, <i>Small-scale rainbow trout farming</i> (Technical Paper 561, 2011); la NTP 032.103:2024 describe un método para determinar el factor de conversión alimenticia de trucha arcoíris en Perú.</p></div>
        <button class="lotesBtn secondary alt" id="showTutorialAgain" type="button">Ver tutorial otra vez</button>

        <div id="performanceModal" class="lotesOverlay" aria-modal="true" role="dialog" aria-labelledby="performanceTitle">
          <div class="lotesModal performanceModal" id="performancePanel" role="document">
            <button class="lotesClose" id="closePerformanceBtn" aria-label="Cerrar comparación">×</button>
            <div class="lotesModalIcon">📊</div>
            <h3 id="performanceTitle">Rendimiento de lotes</h3>
            <p class="lotesModalSubtitle">Compara el crecimiento y la eficiencia de los lotes registrados.</p>
            <div class="performanceSummary" id="performanceSummary"></div>
            <div class="lotesField performanceSortField"><label for="performanceSort">Ordenar lotes por indicador</label><select class="lotesInput" id="performanceSort"><option value="biomass">Biomasa (mayor primero)</option><option value="survival">Supervivencia (mayor primero)</option><option value="weight">Peso promedio (mayor primero)</option><option value="sgr">Crecimiento específico (mayor primero)</option><option value="fcr">FCR (menor primero)</option></select></div>
            <div id="performanceContent" class="performanceCompareList"></div>
            <p class="performanceCaveat"><b>Cómo leer los indicadores:</b> biomasa estima los kg de pez vivo; supervivencia compara los peces actuales con los iniciales; crecimiento específico (SGR) estima el aumento porcentual de peso por día; y el FCR muestra el alimento usado por unidad de ganancia de biomasa según el último registro guardado. Para comparar FCR, asegúrate de que los lotes compartan periodos y bases de cálculo comparables.</p>
            <p class="performanceSources">Referencias técnicas: <a href="https://www.fao.org/fishery/docs/CDrom/FAO_Training/FAO_Training/General/x6709e/x6709e10.htm" target="_blank" rel="noopener noreferrer">FAO · relación de conversión alimenticia (FCR)</a> · <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC12153620/" target="_blank" rel="noopener noreferrer">Estudio de trucha arcoíris · SGR, FCR y supervivencia</a>.</p>
          </div>
        </div>

        <div id="waterQualityModal" class="lotesOverlay waterQualityOverlay" aria-modal="true" role="dialog" aria-labelledby="waterQualityTitle" aria-describedby="waterQualitySubtitle">
          <div class="lotesModal waterQualityModal" id="waterQualityPanel" role="document">
            <button class="lotesClose" id="closeWaterQualityBtn" aria-label="Cerrar parámetros físico-químicos">×</button>
            <div class="lotesModalIcon waterQualityModalIcon">💧</div>
            <h3 id="waterQualityTitle">Parámetros físico-químicos</h3>
            <p id="waterQualitySubtitle" class="lotesModalSubtitle">Organiza tus centros piscícolas y registra los parámetros del agua por instalación, conservando un historial independiente para cada una.</p>
            <section class="waterFarmManager" aria-labelledby="waterFarmManagerTitle">
              <div class="waterFarmManagerHead"><div><h4 id="waterFarmManagerTitle" class="waterFarmManagerTitle">Granjas y centros piscícolas</h4><p class="waterFarmManagerIntro">Cada centro tendrá su propia ficha e historial de calidad del agua.</p></div><button class="waterFarmNewBtn" id="createWaterFarmBtn" type="button">＋ Nueva granja</button></div>
              <div id="waterFarmList" class="waterFarmCards"><div class="waterFarmEmpty"><strong>Preparando centros piscícolas…</strong>Las fichas aparecerán aquí.</div></div>
            </section>
          </div>
        </div>

        <!-- Panel lateral del centro: mismos campos, parametros e historial, sin duplicacion. -->
        <div id="waterFarmDrawer" class="waterFarmDrawerOverlay" role="dialog" aria-modal="true" aria-hidden="true" aria-label="Datos y parámetros del centro piscícola">
          <div id="waterFarmDrawerPanel" class="waterFarmDrawerPanel" role="document" tabindex="-1">
            <div class="waterFarmDrawerTop"><span>Centro abierto · Parámetros físico-químicos</span><button id="closeWaterFarmDrawerBtn" type="button" class="waterFarmDrawerClose" aria-label="Cerrar panel del centro">×</button></div>
            <div id="waterFarmWorkspace" hidden>
              <section class="waterFarmWorkspaceHead" aria-live="polite"><button type="button" class="waterFarmWorkspaceBack" id="waterFarmWorkspaceBack">← Volver a las granjas</button><span class="waterFarmWorkspaceEyebrow">Centro seleccionado</span><h4 id="waterFarmWorkspaceName" class="waterFarmWorkspaceName">Centro piscícola</h4><p id="waterFarmWorkspaceMeta" class="waterFarmWorkspaceMeta"></p></section>
            <section class="waterQualityContext">
              <div class="waterQualityContextHeading"><span>⌁</span><b>Datos de la medición</b></div>
              <div class="waterContextGrid">
                <div class="lotesField"><label for="wqDate">Fecha</label><input class="lotesInput" id="wqDate" type="date" value="${localDateValue()}"></div>
                <div class="lotesField"><label for="wqTime">Hora</label><input class="lotesInput" id="wqTime" type="time" value="${localTimeValue()}"></div>
                <div class="lotesField"><label for="wqPoint">Punto de muestreo</label><select class="lotesInput" id="wqPoint"><option>Fuente / pozo</option><option>Entrada de agua</option><option>Estanque / tanque</option><option>Jaula</option><option>Salida de cultivo</option><option>Reservorio</option><option>Otro</option></select></div>
                <div class="lotesField"><label for="wqLot">Asociar a lote (opcional)</label><select class="lotesInput" id="wqLot"><option value="">Sin asociar a un lote</option>${lots.map(lot => `<option value="${escAttr(lot.id)}">${esc(lot.code)} · ${esc(stageLabel(lot.stage))}</option>`).join('')}</select></div>
                <div class="lotesField waterContextFull"><label for="wqSite">Ubicación / unidad de cultivo</label><input class="lotesInput" id="wqSite" placeholder="Ej. entrada principal, estanque 2, jaula C1" autocomplete="off"></div>
              </div>
            </section>
            <div class="waterQualitySaved" id="waterQualitySaved" role="status" aria-live="polite"></div>
            <div id="waterParameterGroups">${renderWaterParameterGroups()}</div>
            <section class="waterQualityHistoryPanel" aria-labelledby="waterHistoryTitle"><div class="waterHistoryHeading"><h4 id="waterHistoryTitle">Historial de mediciones</h4><span id="waterQualityHistoryCount">0 registros</span></div><div id="waterQualityHistory" class="waterQualityHistory"></div></section>
            <p class="waterQualityFootnote">Las mediciones se guardan dentro del centro seleccionado en el almacenamiento local de TruchAPP. Mantén las unidades del equipo o método; por ejemplo, NO₂⁻ y NO₂-N no son expresiones equivalentes al comparar límites.</p>
            </div>
          </div>
        </div>

        <div id="waterFarmEditorModal" class="lotesOverlay waterFarmEditorOverlay" aria-modal="true" role="dialog" aria-labelledby="waterFarmEditorTitle">
          <div class="lotesModal waterFarmEditorModal" id="waterFarmEditorPanel" role="document">
            <button class="lotesClose" id="closeWaterFarmEditorBtn" aria-label="Cerrar formulario de granja">×</button>
            <div class="lotesModalIcon waterQualityModalIcon">⌂</div>
            <h3 id="waterFarmEditorTitle">Crear granja o centro piscícola</h3>
            <p class="lotesSubhead">Registra la instalación una sola vez. Después podrás guardar y consultar sus mediciones de agua por separado.</p>
            <div class="waterFarmEditorGrid">
              <div class="lotesField waterFarmEditorFull"><label for="wfName">Nombre de la granja / centro *</label><input class="lotesInput" id="wfName" maxlength="70" placeholder="Ej. Centro Piscícola Jacha Paru" autocomplete="organization"></div>
              <div class="lotesField"><label for="wfType">Tipo de instalación</label><select class="lotesInput" id="wfType"><option>Centro piscícola</option><option>Granja piscícola</option><option>Estación de producción</option><option>Otro</option></select></div>
              <div class="lotesField"><label for="wfSystem">Sistema de cultivo</label><select class="lotesInput" id="wfSystem"><option>Mixto</option><option>Estanques</option><option>Jaulas</option><option>Tanques</option><option>Incubación / alevinaje</option><option>Recirculación (RAS)</option></select></div>
              <div class="lotesField waterFarmEditorFull"><label for="wfLocation">Ubicación</label><input class="lotesInput" id="wfLocation" maxlength="110" placeholder="Comunidad, distrito, provincia"></div>
              <div class="lotesField waterFarmEditorFull"><label for="wfWaterSource">Fuente / abastecimiento de agua</label><select class="lotesInput" id="wfWaterSource"><option>Sin especificar</option><option>Manantial</option><option>Pozo</option><option>Río</option><option>Lago / laguna</option><option>Canal</option><option>Reservorio</option><option>Recirculación / RAS</option><option>Otra fuente</option></select></div>
              <div class="lotesField waterFarmEditorFull"><label for="wfNotes">Notas de la instalación (opcional)</label><textarea class="lotesInput" id="wfNotes" rows="2" maxlength="300" placeholder="Referencia, número de unidades, observaciones…"></textarea></div>
            </div>
            <div id="waterFarmEditorMessage" class="waterFarmEditorMessage" role="alert"></div>
            <div class="lotesActions" style="margin-top:13px"><button class="lotesBtn secondary" id="cancelWaterFarmEditorBtn" type="button">Cancelar</button><button class="lotesBtn primary" id="saveWaterFarmBtn" type="button">Guardar centro</button></div>
          </div>
        </div>

        <div id="waterParamEntryModal" class="lotesOverlay waterParamEntryOverlay" aria-modal="true" role="dialog" aria-labelledby="waterParamEntryTitle">
          <div class="lotesModal waterParamEntryModal" id="waterParamEntryPanel" role="document">
            <button class="lotesClose" id="closeWaterParamEntryBtn" aria-label="Cerrar registro de parámetro">×</button>
            <div class="lotesModalIcon waterParamEntryIcon">＋</div>
            <h3 id="waterParamEntryTitle">Registrar parámetro</h3>
            <p class="lotesModalSubtitle">Anota el valor medido y conserva la fecha, el punto de muestreo y el lote indicados en la ventana anterior.</p>
            <div class="waterParamEntryUnitPill" id="waterParamEntryUnit">Unidad</div>
            <div id="waterParamEntryContent"></div>
            <div class="lotesActions waterParamEntryActions"><button class="lotesBtn secondary" id="cancelWaterParamEntryBtn" type="button">Cancelar</button><button class="lotesBtn primary" id="saveWaterParamEntryBtn" type="button">Guardar medición</button></div>
          </div>
        </div>

        <div id="loteModal" class="lotesOverlay" aria-modal="true" role="dialog" aria-labelledby="lmTitle">
          <div class="lotesModal" id="lotePanel" role="document">
            <header class="lotDetailHeader"><button class="lotesClose" id="closeLoteBtn" aria-label="Cerrar">×</button><h3 id="lmTitle">Lote</h3><p id="lmSubtitle" class="lotesModalSubtitle"></p></header>
            <div class="lotesStatGrid" style="margin:8px 0 12px">
              <button class="lotesStat lotesStatInteractive" data-metric="fish" type="button" title="Ver historial de peces" aria-haspopup="dialog" aria-controls="metricDetailModal"><b id="lmFish">0</b><span>Peces</span></button><button class="lotesStat lotesStatInteractive" data-metric="weight" type="button" title="Ver historial de peso promedio" aria-haspopup="dialog" aria-controls="metricDetailModal"><b id="lmWeightStat">0 g</b><span>Peso prom.</span></button><button class="lotesStat lotesStatInteractive" data-metric="biomass" type="button" title="Ver historial de biomasa" aria-haspopup="dialog" aria-controls="metricDetailModal"><b id="lmBiomass">0 kg</b><span>Biomasa</span></button><button class="lotesStat lotesStatInteractive" data-metric="survival" type="button" title="Ver historial de supervivencia" aria-haspopup="dialog" aria-controls="metricDetailModal"><b id="lmSurvival">0%</b><span>Supervivencia</span></button>
            </div>
            <div class="lotesStatGrid detailExtraGrid" style="margin:0 0 12px">
              <button class="lotesStat lotesStatInteractive" data-metric="length" type="button" title="Ver historial de talla" aria-haspopup="dialog" aria-controls="metricDetailModal"><b id="lmLengthStat">— cm</b><span>Talla</span></button><button class="lotesStat lotesStatInteractive" data-metric="pellet" type="button" title="Ver historial del calibre de pellet" aria-haspopup="dialog" aria-controls="metricDetailModal"><b id="lmPellet">— mm</b><span>Pellet calibre</span></button><button class="lotesStat lotesStatInteractive" data-metric="feed" type="button" title="Ver historial de alimento consumido" aria-haspopup="dialog" aria-controls="metricDetailModal"><b id="lmFeedConsumed">— kg</b><span>Alimento consumido</span></button><button class="lotesStat lotesStatInteractive" data-metric="fcr" type="button" title="Ver historial del FCR" aria-haspopup="dialog" aria-controls="metricDetailModal"><b id="lmFcr">—</b><span>FCR</span></button>
            </div>
            <section class="lotWaterPanel" id="lotWaterSection" aria-labelledby="lotWaterTitle">
              <div class="lotWaterHeading"><h4 id="lotWaterTitle">Parámetros físicoquímicos</h4><p>Mediciones del agua de este lote. Toca una tarjeta para registrar un valor.</p></div>
              <div class="waterParameterGrid" id="lotWaterCards"></div>
              <details class="lotWaterDetails" id="lotWaterMore"><summary>Ver más parámetros físicos y químicos</summary><div id="lotWaterMoreGroups"></div></details>
              <details class="lotWaterDetails"><summary>Historial de agua <span id="lotWaterHistoryCount">0 registros</span></summary><div id="lotWaterHistoryList"></div></details>
              <div class="lotesHint lotWaterSaved" id="lotWaterSaved" role="status" aria-live="polite"></div>
            </section>
            <section class="sampleUpdatePanel" aria-label="Nuevo muestreo o actualización de datos">
              <div class="sampleUpdateHeading"><span class="editMark" aria-hidden="true">✎</span><span>Nuevo muestreo / actualizar</span></div>
              <div class="lotesGrid2">
                <div class="lotesField"><label for="lmWeight">Peso promedio (g)</label><input class="lotesInput" id="lmWeight" type="number" min="0.1" step="0.1"></div>
                <div class="lotesField"><label for="lmLength">Talla promedio (cm)</label><input class="lotesInput" id="lmLength" type="number" min="0.1" step="0.1" placeholder="Ej. 15,5"></div>
                <div class="lotesField"><label for="lmMort">Mortalidad de hoy (u.)</label><input class="lotesInput" id="lmMort" type="number" min="0" step="1" value="0"></div>
                <div class="lotesField discardField"><label for="lmDiscard">Descarte (malformaciones)</label><input class="lotesInput" id="lmDiscard" type="number" min="0" step="1" value="0" placeholder="0"></div>
                <div class="lotesField"><label for="lmPelletInput">Pellet calibre (mm)</label><input class="lotesInput" id="lmPelletInput" type="number" min="0.1" step="0.1" placeholder="Ej. 3,0"></div>
                <div class="lotesField"><label for="lmFeedInput">Alimento consumido (kg)</label><input class="lotesInput" id="lmFeedInput" type="number" min="0" step="0.01" placeholder="En este periodo"></div>
              </div>
              <div class="lotesHint" style="margin-top:8px">El descarte se registra por separado de la mortalidad. El alimento ingresado corresponde a este periodo y se suma al acumulado; el FCR se estima cuando existe ganancia positiva de peso.</div>
              <div class="lotesField" style="margin-top:9px"><label for="lmObs">Observaciones sanitarias</label><textarea class="lotesInput" id="lmObs" rows="3" placeholder="Agallas limpias, buen apetito, comportamiento normal…"></textarea></div>
            </section>
            <div class="lotesActions" style="margin-top:12px"><button class="lotesBtn primary" id="saveLoteBtn" type="button">Guardar muestreo</button></div>
            <button class="lotesBtn dangerBtn" style="margin-top:8px" id="deleteLoteBtn" type="button">Eliminar este lote</button>
            <div style="margin-top:12px;text-align:left"><div class="lotesLabel" style="font-size:10px;letter-spacing:.07em;margin-bottom:6px">ÚLTIMOS REGISTROS</div><div id="lmHistory"></div></div>
          </div>
        </div>

        <div id="metricDetailModal" class="lotesOverlay metricDetailOverlay" aria-modal="true" role="dialog" aria-labelledby="metricDetailTitle" aria-describedby="metricDetailSubtitle">
          <div class="lotesModal metricDetailModal" id="metricDetailPanel" role="document">
            <button class="lotesClose" id="closeMetricDetailBtn" aria-label="Cerrar detalle del indicador">×</button>
            <div class="lotesModalIcon" id="metricDetailIcon" aria-hidden="true">📈</div>
            <h3 id="metricDetailTitle">Detalle del indicador</h3>
            <p id="metricDetailSubtitle" class="lotesModalSubtitle"></p>
            <section class="metricDetailCurrent" aria-label="Valor actual">
              <span class="metricDetailEyebrow">VALOR ACTUAL</span>
              <strong id="metricDetailValue">—</strong>
              <p id="metricDetailNote"></p>
            </section>
            <section id="fishPopulationPanel" class="fishPopulationPanel" aria-label="Análisis de población del lote" hidden>
              <div class="fishAnalysisHeading">ANÁLISIS DE RENDIMIENTO</div>
              <div id="fishAnalysisGrid" class="fishAnalysisGrid"></div>
              <section class="fishEvolutionCard" aria-label="Gráfica de evolución de la población">
                <div class="fishEvolutionTop"><div><strong>EVOLUCIÓN DE POBLACIÓN</strong><p id="fishChartSubtitle" class="fishEvolutionSubtitle">Según los muestreos registrados</p></div><span aria-hidden="true">📈</span></div>
                <div id="fishPopulationChart"></div>
              </section>
            </section>
            <div class="metricHistoryHeading fishMetricHistoryLabel"><span class="lotesLabel">Historial registrado</span><span id="metricHistoryCount" class="metricHistoryCount">0 registros</span></div>
            <div id="metricDetailHistory" class="metricDetailHistory"></div>
            <p class="metricDetailFootnote">Los valores se muestran a partir de los muestreos guardados en este lote. Los valores derivados, como biomasa y supervivencia, se calculan con los datos registrados.</p>
          </div>
        </div>

        <div id="createModal" class="lotesOverlay createModal" aria-modal="true" role="dialog" aria-labelledby="createTitle">
          <div class="lotesModal" id="createPanel" role="document">
            <button class="lotesClose" id="closeCreateBtn" aria-label="Cerrar">×</button><div class="lotesModalIcon">🐟</div>
            <h3 id="createTitle">Crear nuevo lote</h3><p class="lotesSubhead">Registra los datos iniciales del lote para comenzar su seguimiento productivo.</p>
            <div class="lotesGrid2">
              <div class="lotesField"><label for="crCode">Código del lote</label><input class="lotesInput" id="crCode" placeholder="TR-2026-03" maxlength="48"></div>
              <div class="lotesField"><label for="crStage">Etapa</label><select class="lotesInput" id="crStage"><option>Alevinaje</option><option>Juvenil</option><option>Engorde</option><option>Reproductores</option><option>Ovas</option></select></div>
              <div class="lotesField"><label for="crDate">Fecha de siembra / ingreso</label><input class="lotesInput" id="crDate" type="date"></div>
              <div class="lotesField"><label for="crOrigin">Origen</label><input class="lotesInput" id="crOrigin" placeholder="Centro / proveedor"></div>
              <div class="lotesField"><label for="crUnit">Unidad de cultivo</label><input class="lotesInput" id="crUnit" placeholder="Estanque / jaula / tanque"></div>
              <div class="lotesField"><label for="crFish">Peces iniciales</label><input class="lotesInput" id="crFish" type="number" min="1" step="1" placeholder="10000"></div>
              <div class="lotesField"><label for="crW0">Peso inicial (g)</label><input class="lotesInput" id="crW0" type="number" min="0.1" step="0.1" placeholder="20"></div>
              <div class="lotesField"><label for="crTargetWeight">Objetivo comercial (g)</label><input class="lotesInput" id="crTargetWeight" type="number" min="1" step="0.1" value="210" placeholder="210"></div>
            </div>
            <div id="createModalMsg" class="lotesHint createModalMsg" style="display:none;margin-top:8px"></div>
            <div class="lotesActions" style="margin-top:12px"><button class="lotesBtn primary" id="createLoteBtn" type="button">＋ Crear lote</button></div>
          </div>
        </div>

        <div id="lotesTutorial" class="lotesOverlay" aria-modal="true" role="dialog" aria-labelledby="lotesTutorialTitle">
          <div class="lotesModal lotesTutorialModal" id="lotesTutorialPanel" role="document">
            <button class="lotesClose" id="closeTutorialBtn" aria-label="Cerrar tutorial">×</button>
            <div class="lotesModalIcon">🐟</div>
            <h3 id="lotesTutorialTitle">Aprende a llevar el control de tus lotes</h3>
            <p class="lotesTutorialIntro">Una guía breve para registrar tus datos productivos y entender los indicadores principales.</p>
            <div class="lotesTutorialProgressHeader"><span id="lotesTutorialStepCount">PASO 1 DE 5</span><span>GUÍA DE LOTES</span></div>
            <div class="lotesTutorialTrack" role="progressbar" aria-label="Progreso del tutorial" aria-valuemin="1" aria-valuemax="5" aria-valuenow="1" id="lotesTutorialProgress"><i id="lotesTutorialProgressFill"></i></div>
            <div class="lotesTutorialStepCard">
              <div class="lotesTutorialStepNumber" id="lotesTutorialStepNumber">01</div>
              <div><h4 id="lotesTutorialStepHeading">Conoce el resumen</h4><p id="lotesTutorialStepText">Los indicadores superiores muestran los lotes registrados, los peces que quedan en existencia y la biomasa estimada.</p></div>
            </div>
            <div class="lotesTutorialTip"><b id="lotesTutorialTipHeading">Consejo práctico</b><p id="lotesTutorialTipText">Revisa el resumen después de registrar un lote o guardar un muestreo.</p></div>
            <div class="lotesTutorialDots" id="lotesTutorialDots" aria-label="Pasos del tutorial"></div>
            <div class="lotesTutorialActions"><button class="lotesBtn secondary alt" id="lotesTutorialPrev" type="button" disabled>Anterior</button><button class="lotesBtn primary" id="lotesTutorialNext" type="button">Siguiente →</button></div>
            <small class="lotesTutorialFooter">Puedes cerrar con ×, tocar fuera de la ventana o presionar Escape.</small>
          </div>
        </div>
      </div>`;

    bindEvents();
    renderKpis();
    renderList();
    rendering = false;
    notifySharedDataChanged();
  }
  function bindEvents() {
    $('createLoteTrigger')?.addEventListener('click', openCreateLote);
    $('createLoteBtn')?.addEventListener('click', createLoteFromModal);
    $('closeCreateBtn')?.addEventListener('click', closeCreateLote);
    $('closeLoteBtn')?.addEventListener('click', closeLote);
    $('closeMetricDetailBtn')?.addEventListener('click', closeMetricDetail);
    $('metricDetailModal')?.addEventListener('click', closeMetricDetail);
    $('lotePanel')?.querySelectorAll('[data-metric]').forEach(stat => stat.addEventListener('click', () => openMetricDetail(stat.dataset.metric)));
    $('lotWaterSection')?.addEventListener('click', ev => {
      const card = ev.target.closest('[data-water-card]');
      if (card && activeLoteId) openWaterParamEntry(card.dataset.waterCard, activeLoteId);
    });
    $('lotWaterMore')?.addEventListener('toggle', () => { if ($('lotWaterMore')?.open) renderLotWaterSection(); });
    $('openPerformanceBtn')?.addEventListener('click', openPerformance);
    $('openWaterQualityBtn')?.addEventListener('click', openWaterQuality);
    $('closeWaterQualityBtn')?.addEventListener('click', closeWaterQuality);
    $('createWaterFarmBtn')?.addEventListener('click', () => openWaterFarmEditor());
    $('closeWaterFarmEditorBtn')?.addEventListener('click', closeWaterFarmEditor);
    $('cancelWaterFarmEditorBtn')?.addEventListener('click', closeWaterFarmEditor);
    $('saveWaterFarmBtn')?.addEventListener('click', saveWaterFarmFromModal);
    $('waterFarmWorkspaceBack')?.addEventListener('click', closeWaterFarmDrawer);
    $('closeWaterFarmDrawerBtn')?.addEventListener('click', closeWaterFarmDrawer);
    $('waterFarmDrawer')?.addEventListener('click', ev => { if (ev.target === $('waterFarmDrawer')) closeWaterFarmDrawer(); });
    $('waterFarmList')?.addEventListener('click', ev => {
      const select = ev.target.closest('[data-water-farm-select]');
      const edit = ev.target.closest('[data-water-farm-edit]');
      if (edit) { openWaterFarmEditor(edit.dataset.waterFarmEdit); return; }
      if (select) selectWaterFarm(select.dataset.waterFarmSelect);
    });
    $('waterParameterGroups')?.addEventListener('click', ev => {
      const card = ev.target.closest('[data-water-card]');
      const customCard = ev.target.closest('[data-water-custom-name]');
      if (card) { openWaterParamEntry(card.dataset.waterCard); return; }
      if (customCard) { openCustomWaterParamEntry(customCard.dataset.waterCustomName || '', customCard.dataset.waterCustomUnit || ''); return; }
      if (ev.target.closest('[data-water-custom-add]')) openCustomWaterParamEntry();
    });
    $('closeWaterParamEntryBtn')?.addEventListener('click', closeWaterParamEntry);
    $('cancelWaterParamEntryBtn')?.addEventListener('click', closeWaterParamEntry);
    $('saveWaterParamEntryBtn')?.addEventListener('click', saveWaterParamMeasurement);
    $('waterParamEntryModal')?.addEventListener('click', closeWaterParamEntry);
    $('closePerformanceBtn')?.addEventListener('click', closePerformance);
    $('performanceSort')?.addEventListener('change', renderPerformanceCompare);
    $('saveLoteBtn')?.addEventListener('click', saveLote);
    $('deleteLoteBtn')?.addEventListener('click', deleteLote);
    $('showTutorialAgain')?.addEventListener('click', openTutorial);
    $('lotesSearch')?.addEventListener('input', renderList);
    $('closeTutorialBtn')?.addEventListener('click', closeTutorial);
    $('lotesTutorialPrev')?.addEventListener('click', () => { if (tutorialStepIndex > 0) { tutorialStepIndex--; renderTutorialStep(); } });
    $('lotesTutorialNext')?.addEventListener('click', () => {
      if (tutorialStepIndex < TUTORIAL_STEPS.length - 1) { tutorialStepIndex++; renderTutorialStep(); }
      else closeTutorial();
    });
    $('loteModal')?.addEventListener('click', closeLote);
    $('createModal')?.addEventListener('click', closeCreateLote);
    $('performanceModal')?.addEventListener('click', closePerformance);
    $('waterQualityModal')?.addEventListener('click', closeWaterQuality);
    $('waterFarmEditorModal')?.addEventListener('click', closeWaterFarmEditor);
    $('lotesTutorial')?.addEventListener('click', closeTutorial);
    ['lotePanel', 'metricDetailPanel', 'createPanel', 'performancePanel', 'waterQualityPanel', 'waterFarmDrawerPanel', 'waterFarmEditorPanel', 'waterParamEntryPanel', 'lotesTutorialPanel'].forEach(id => $(id)?.addEventListener('click', ev => ev.stopPropagation()));
  }
  function renderTutorialStep() {
    const step = TUTORIAL_STEPS[tutorialStepIndex];
    if (!step) return;
    const setText = (id, value) => { const el = $(id); if (el) el.textContent = value; };
    setText('lotesTutorialStepCount', `PASO ${tutorialStepIndex + 1} DE ${TUTORIAL_STEPS.length}`);
    setText('lotesTutorialStepNumber', String(tutorialStepIndex + 1).padStart(2, '0'));
    setText('lotesTutorialStepHeading', step.heading);
    setText('lotesTutorialStepText', step.text);
    setText('lotesTutorialTipHeading', step.tipHeading);
    setText('lotesTutorialTipText', step.tipText);
    const fill = $('lotesTutorialProgressFill');
    if (fill) fill.style.width = `${((tutorialStepIndex + 1) / TUTORIAL_STEPS.length) * 100}%`;
    const progress = $('lotesTutorialProgress');
    if (progress) progress.setAttribute('aria-valuenow', String(tutorialStepIndex + 1));
    const prev = $('lotesTutorialPrev');
    if (prev) prev.disabled = tutorialStepIndex === 0;
    const next = $('lotesTutorialNext');
    if (next) next.textContent = tutorialStepIndex === TUTORIAL_STEPS.length - 1 ? 'Entendido, empezar' : 'Siguiente →';
    const dots = $('lotesTutorialDots');
    if (dots) {
      dots.innerHTML = TUTORIAL_STEPS.map((_, i) => `<button type="button" class="lotesTutorialDot${i === tutorialStepIndex ? ' active' : ''}" aria-label="Ir al paso ${i + 1}" aria-current="${i === tutorialStepIndex ? 'step' : 'false'}"></button>`).join('');
      dots.querySelectorAll('button').forEach((dot, i) => dot.addEventListener('click', () => { tutorialStepIndex = i; renderTutorialStep(); }));
    }
  }
  function openTutorial() {
    tutorialStepIndex = 0;
    renderTutorialStep();
    $('lotesTutorial')?.classList.add('open');
  }
  function setupTutorial() {
    const modal = $('lotesTutorial');
    if (!modal || tutorialChecked) return;
    tutorialChecked = true;
    let seen = false;
    try { seen = readLotesStorage(TUTORIAL_KEY) === '1'; } catch (_) {}
    if (!seen) openTutorial(); else modal.classList.remove('open');
  }
  function closeTutorial() {
    tutorialChecked = true;
    $('lotesTutorial')?.classList.remove('open');
    try { writeLotesStorage(TUTORIAL_KEY, '1'); writeLotesStorage('truchapp_lotes_tutorial_seen_v1', '1'); } catch (_) {}
  }
  function renderKpis() {
    const root = $(rootId); if (!root) return;
    const lots = getLots();
    const count = lots.reduce((sum, lot) => sum + lot.n, 0);
    const bio = lots.reduce((sum, lot) => sum + biomass(lot), 0);
    const lotCount = root.querySelector('#kpiLotes'), fishCount = root.querySelector('#kpiPeces'), bioCount = root.querySelector('#kpiBiomasa');
    if (lotCount) lotCount.textContent = whole(lots.length);
    if (fishCount) fishCount.textContent = whole(count);
    if (bioCount) bioCount.textContent = nfmt(bio, 1) + ' kg';
  }
  function renderList() {
    const box = $('lotesList');
    if (!box) return;
    const lots = getLots();
    const searchValue = ($('lotesSearch')?.value || '').trim().toLocaleLowerCase('es');
    if (!lots.length) {
      box.innerHTML = '<div class="lotesEmpty">Aún no tienes lotes registrados. Pulsa “Crear nuevo lote” para ingresar el primero.</div>';
      return;
    }
    const filteredLots = searchValue ? lots.filter(l => [l.code, l.id, stageLabel(l.stage), l.stage, l.unit, l.origin, l.date].filter(value => value != null).join(' ').toLocaleLowerCase('es').includes(searchValue)) : lots;
    if (!filteredLots.length) {
      box.innerHTML = '<div class="lotesEmpty">No se encontraron lotes con esa búsqueda. Prueba con otro código, etapa, unidad u origen.</div>';
      return;
    }
    box.innerHTML = filteredLots.map(l => {
      const surv = survival(l), bio = biomass(l), target = Number(l.targetWeight) || 210;
      const progress = Math.max(0, Math.min(100, (Number(l.w) || 0) / target * 100));
      const state = health(l);
      return `<div class="lotesLote" data-lote="${escAttr(l.id)}">
        <div class="lotesLoteTop"><div><div class="lotesCode">${esc(l.code)}</div><div class="lotesMeta">${esc(stageLabel(l.stage))} · ingreso ${esc(l.date)} · ${esc(l.unit)}${l.origin && l.origin !== 'Sin indicar' ? ' · ' + esc(l.origin) : ''}</div></div><div class="lotesHealth"><span class="lotesStage">Estado</span><span class="healthLight ${state.level}" title="Estado ${state.label} · Supervivencia ${nfmt(surv)}%" role="img" aria-label="Estado ${state.label}. Supervivencia ${nfmt(surv)} por ciento."></span></div></div>
        <div class="lotesStatGrid"><div class="lotesStat"><b>${whole(l.n)}</b><span>Peces</span></div><div class="lotesStat"><b>${nfmt(l.w)} g</b><span>Peso prom.</span></div><div class="lotesStat"><b>${nfmt(bio)} kg</b><span>Biomasa</span></div><div class="lotesStat"><b>${nfmt(surv)}%</b><span>Supervivencia</span></div></div>
        <div class="lotesProgress"><i style="width:${progress}%"></i></div><div class="lotesNote">Progreso hacia ${nfmt(target)} g: ${nfmt(progress)}% · Mortalidad: ${whole(l.m)} · Descarte: ${whole(l.discarded)}</div>
        <div class="lotesActions"><button class="lotesBtn secondary openLoteBtn" data-lote-id="${escAttr(l.id)}" type="button">Ver / actualizar lote</button></div>
      </div>`;
    }).join('');
    box.querySelectorAll('.openLoteBtn').forEach(btn => btn.addEventListener('click', () => openLote(btn.dataset.loteId)));
  }
  function openCreateLote() {
    const date = $('crDate'); if (date && !date.value) date.value = today();
    const msg = $('createModalMsg'); if (msg) { msg.style.display = 'none'; msg.textContent = ''; }
    $('createModal')?.classList.add('open');
  }
  function closeCreateLote() { $('createModal')?.classList.remove('open'); }
  function createLoteFromModal() {
    const code = $('crCode').value.trim();
    const stage = $('crStage').value;
    const date = $('crDate').value || today();
    const origin = $('crOrigin').value.trim() || 'Sin indicar';
    const unit = $('crUnit').value.trim() || 'Sin indicar';
    const initialN = Math.max(0, Math.floor(Number($('crFish').value) || 0));
    const initialWeight = Math.max(0, Number($('crW0').value) || 0);
    const weight = initialWeight;
    const targetWeight = Number($('crTargetWeight').value);
    const msg = $('createModalMsg');
    const fail = text => { msg.textContent = text; msg.style.display = 'block'; msg.classList.add('error'); };
    msg.classList.remove('error');
    if (!code || initialN <= 0 || initialWeight <= 0 || !Number.isFinite(targetWeight) || targetWeight < 1) { fail('Completa código, peces iniciales, peso inicial y objetivo comercial con valores válidos.'); return; }
    const lots = getLots();
    if (lots.some(l => l.code.toLowerCase() === code.toLowerCase() || l.id.toLowerCase() === code.toLowerCase())) { fail('Ya existe un lote con ese código.'); return; }
    const lot = normalizeLot({ id: code, code, stage, unit, date, origin, initialN, initialWeight, targetWeight, n: initialN, w: weight, l: null, pelletCalibre: null, alimentoConsumido: null, fcr: null, m: 0, discarded: 0, harvestKg: 0, history: [{ d: date, w: weight, l: null, m: 0, discard: 0, feedKg: null, pelletCalibre: null, fcr: null, x: 'Lote creado' }] });
    persistLots([lot, ...lots]);
    closeCreateLote();
    render();
    const card = Array.from(document.querySelectorAll('.lotesLote')).find(el => el.dataset.lote === lot.id);
    if (card) { card.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); card.classList.add('createdPulse'); setTimeout(() => card.classList.remove('createdPulse'), 1000); }
  }
  function openLote(id) {
    const lot = getLots().find(l => l.id === String(id) || l.code === String(id));
    if (!lot) return;
    if (waterEntryLotId !== null) closeWaterParamEntry();
    activeLoteId = lot.id;
    $('lmTitle').textContent = lot.code + ' · ' + stageLabel(lot.stage);
    $('lmSubtitle').textContent = lot.unit + ' · ingreso ' + lot.date + (lot.origin && lot.origin !== 'Sin indicar' ? ' · origen ' + lot.origin : '');
    $('lmFish').textContent = whole(lot.n);
    $('lmWeightStat').textContent = nfmt(lot.w) + ' g';
    $('lmBiomass').textContent = nfmt(biomass(lot)) + ' kg';
    $('lmSurvival').textContent = nfmt(survival(lot)) + '%';
    $('lmLengthStat').textContent = lot.l == null ? '— cm' : nfmt(lot.l) + ' cm';
    $('lmPellet').textContent = lot.pelletCalibre == null ? '— mm' : nfmt(lot.pelletCalibre) + ' mm';
    $('lmFeedConsumed').textContent = lot.alimentoConsumido == null ? '— kg' : nfmt(lot.alimentoConsumido, 2) + ' kg';
    $('lmFcr').textContent = lot.fcr == null ? '—' : nfmt(lot.fcr, 2);
    $('lmWeight').value = lot.w;
    $('lmLength').value = lot.l == null ? '' : lot.l;
    $('lmMort').value = '0';
    $('lmDiscard').value = '0';
    $('lmPelletInput').value = lot.pelletCalibre == null ? '' : lot.pelletCalibre;
    $('lmFeedInput').value = '';
    $('lmObs').value = '';
    const waterMore = $('lotWaterMore'); if (waterMore) waterMore.open = false;
    const waterMoreGroups = $('lotWaterMoreGroups'); if (waterMoreGroups) waterMoreGroups.innerHTML = '';
    const waterMessage = $('lotWaterSaved'); if (waterMessage) waterMessage.textContent = '';
    renderLotWaterSection();
    $('lmHistory').innerHTML = (lot.history || []).slice(0, 5).map(h => {
      const details = [];
      if (h.l != null) details.push('talla ' + nfmt(h.l) + ' cm');
      details.push('mortalidad ' + whole(h.m));
      if (Number(h.discard) > 0) details.push('descarte ' + whole(h.discard));
      if (h.feedKg != null) details.push('alimento ' + nfmt(h.feedKg, 2) + ' kg');
      if (h.fcr != null) details.push('FCR ' + nfmt(h.fcr, 2));
      return `<div class="lotesHistoryItem"><b>${esc(h.d)}</b> · ${nfmt(h.w)} g · ${details.join(' · ')}<br><span>${esc(h.x || '')}</span></div>`;
    }).join('') || '<div class="lotesHint">Sin registros.</div>';
    $('loteModal').classList.add('open');
    const panel = $('lotePanel'); if (panel) panel.scrollTop = 0;
  }
  const METRIC_DETAILS = {
    fish: {title:'Peces en existencia', icon:'🐟', unit:'peces', note:'Cantidad estimada de peces vivos registrada actualmente. El histórico se reconstruye usando los registros de mortalidad y descarte guardados por periodo.'},
    weight: {title:'Peso promedio', icon:'⚖️', unit:'g', note:'Peso promedio registrado en cada muestreo. Utiliza mediciones representativas de los peces del lote.'},
    biomass: {title:'Biomasa estimada', icon:'📊', unit:'kg', note:'Se calcula como peces en existencia × peso promedio (g) ÷ 1.000. Los valores históricos son estimaciones a partir de los registros guardados.'},
    survival: {title:'Supervivencia', icon:'💧', unit:'%', note:'Porcentaje estimado respecto a los peces iniciales; se descuentan mortalidades y descartes registrados.'},
    length: {title:'Talla promedio', icon:'📏', unit:'cm', note:'Talla promedio registrada en los muestreos. Solo aparecen las fechas en las que se guardó una talla.'},
    pellet: {title:'Calibre del pellet', icon:'🌾', unit:'mm', note:'Tamaño del pellet registrado para la alimentación del lote.'},
    feed: {title:'Alimento consumido', icon:'🌾', unit:'kg', note:'El valor actual representa el acumulado registrado. Cada fila histórica muestra el alimento ingresado en ese periodo.'},
    fcr: {title:'Factor de conversión alimenticia (FCR)', icon:'🧮', unit:'', note:'FCR registrado para un periodo cuando hay consumo de alimento y ganancia positiva de biomasa. Un valor vacío significa que no pudo calcularse en ese registro.'}
  };
  function metricSnapshots(lot) {
    const history = Array.isArray(lot.history) ? lot.history : [];
    const snapshots = new Array(history.length);
    let lostAfterRecord = 0;
    // History is newest-first; add losses from newer entries to reconstruct older fish counts.
    for (let i = 0; i < history.length; i++) {
      const h = history[i] || {};
      const fishAtRecord = Math.max(0, Number(lot.n || 0) + lostAfterRecord);
      const initial = Math.max(Number(lot.initialN) || 0, (Number(lot.n) || 0) + (Number(lot.m) || 0) + (Number(lot.discarded) || 0));
      snapshots[i] = {h, fish:fishAtRecord, biomass:fishAtRecord * Math.max(0, Number(h.w) || 0) / 1000, survival:initial > 0 ? fishAtRecord / initial * 100 : 0, feedCumulative:0};
      lostAfterRecord += Math.max(0, Number(h.m) || 0) + Math.max(0, Number(h.discard) || 0);
    }
    let feedCumulative = 0;
    for (let i = history.length - 1; i >= 0; i--) {
      feedCumulative += Math.max(0, Number(history[i]?.feedKg) || 0);
      snapshots[i].feedCumulative = feedCumulative;
    }
    return snapshots;
  }
  function metricCurrent(lot, metric) {
    if (metric === 'fish') return {value:whole(lot.n), note:'Peces vivos en existencia'};
    if (metric === 'weight') return {value:nfmt(lot.w) + ' g', note:'Último peso promedio guardado'};
    if (metric === 'biomass') return {value:nfmt(biomass(lot), 1) + ' kg', note:'Calculada con las existencias y el peso promedio actual'};
    if (metric === 'survival') return {value:nfmt(survival(lot), 1) + '%', note:'Respecto a ' + whole(lot.initialN) + ' peces iniciales'};
    if (metric === 'length') return {value:lot.l == null ? '— cm' : nfmt(lot.l) + ' cm', note:lot.l == null ? 'Todavía no se ha guardado una talla' : 'Última talla promedio registrada'};
    if (metric === 'pellet') return {value:lot.pelletCalibre == null ? '— mm' : nfmt(lot.pelletCalibre) + ' mm', note:lot.pelletCalibre == null ? 'Todavía no se ha registrado el calibre' : 'Último calibre guardado'};
    if (metric === 'feed') {
      const hasFeedHistory = (lot.history || []).some(h => h.feedKg != null);
      const feedTotal = lot.alimentoConsumido == null && hasFeedHistory ? metricSnapshots(lot).reduce((sum, row) => sum + (Number(row.h.feedKg) || 0), 0) : lot.alimentoConsumido;
      return {value:feedTotal == null ? '— kg' : nfmt(feedTotal, 2) + ' kg', note:feedTotal == null ? 'Todavía no se ha registrado alimento consumido' : 'Alimento acumulado registrado en este lote'};
    }
    if (metric === 'fcr') return {value:lot.fcr == null ? '—' : nfmt(lot.fcr, 2), note:lot.fcr == null ? 'Todavía no hay un FCR calculado' : 'Último FCR válido guardado'};
    return {value:'—', note:''};
  }
  function metricHistoryValue(metric, snapshot) {
    const h = snapshot.h;
    if (metric === 'fish') return whole(snapshot.fish) + ' peces';
    if (metric === 'weight') return nfmt(h.w) + ' g';
    if (metric === 'biomass') return nfmt(snapshot.biomass, 2) + ' kg';
    if (metric === 'survival') return nfmt(snapshot.survival, 1) + '%';
    if (metric === 'length') return h.l == null ? null : nfmt(h.l) + ' cm';
    if (metric === 'pellet') return h.pelletCalibre == null ? null : nfmt(h.pelletCalibre) + ' mm';
    if (metric === 'feed') return h.feedKg == null ? null : nfmt(h.feedKg, 2) + ' kg';
    if (metric === 'fcr') return h.fcr == null ? null : nfmt(h.fcr, 2);
    return null;
  }
  function metricHistoryMeta(metric, snapshot) {
    const h = snapshot.h;
    const parts = [];
    if (metric === 'feed') parts.push('consumo del periodo');
    if (metric === 'fcr') parts.push('FCR calculado para este periodo');
    if (metric === 'fish' || metric === 'survival' || metric === 'biomass') {
      parts.push('mortalidad ' + whole(h.m));
      if (Number(h.discard) > 0) parts.push('descarte ' + whole(h.discard));
    }
    if (h.x) parts.push(h.x);
    return parts.join(' · ');
  }
  function fishEvolutionPoints(lot, snapshots) {
    const hist = Array.isArray(lot.history) ? lot.history : [];
    const historicMortality = hist.reduce((sum, item) => sum + Math.max(0, Number(item?.m) || 0), 0);
    const historicDiscard = hist.reduce((sum, item) => sum + Math.max(0, Number(item?.discard) || 0), 0);
    const totalMortality = Math.max(Number(lot.m) || 0, historicMortality);
    const totalDiscard = Math.max(Number(lot.discarded) || 0, historicDiscard);
    const initial = Math.max(0, Number(lot.initialN) || 0, (Number(lot.n) || 0) + totalMortality + totalDiscard);
    let points = (snapshots || []).map(row => ({
      date: String(row.h?.d || lot.date || '').slice(0, 10),
      fish: Math.max(0, Number(row.fish) || 0),
      note: String(row.h?.x || '')
    })).filter(point => /^\d{4}-\d{2}-\d{2}$/.test(point.date));
    points.reverse();
    const hasInitialPoint = points.some(point =>
      /lote (creado|registrado)/i.test(point.note) ||
      (point.date === String(lot.date || '').slice(0, 10) && Math.abs(point.fish - initial) < 0.5)
    );
    if (initial > 0 && lot.date && !hasInitialPoint) {
      points.unshift({date:String(lot.date).slice(0, 10), fish:initial, note:'Población inicial'});
    }
    points.sort((a, b) => a.date.localeCompare(b.date));
    // If legacy records contain the same date several times, keep each sample in saved order;
    // they represent independent records even when entered on one day.
    if (!points.length && initial > 0) points = [{date:String(lot.date || today()).slice(0, 10), fish:initial, note:'Población inicial'}];
    return points;
  }

  function fishChartDateLabel(date) {
    const parts = String(date || '').split('-');
    return parts.length === 3 ? parts[2] + '/' + parts[1] : String(date || '');
  }

  function makeFishEvolutionSvg(points) {
    if (!points || !points.length) return '<div class="fishChartEmpty">Todavía no hay registros suficientes para mostrar la evolución de peces.</div>';
    const W = 620, H = 228, left = 58, right = 18, top = 20, bottom = 40;
    const plotW = W - left - right, plotH = H - top - bottom, yBase = top + plotH;
    const values = points.map(point => Math.max(0, Number(point.fish) || 0));
    const dataMin = Math.min(...values), dataMax = Math.max(...values);
    const padding = Math.max((dataMax - dataMin) * 0.18, dataMax * 0.006, 1);
    const minY = Math.max(0, dataMin - padding), maxY = Math.max(dataMax + padding, minY + 1);
    const yAt = value => top + ((maxY - value) / (maxY - minY)) * plotH;
    const xAt = index => points.length < 2 ? left + plotW / 2 : left + (index / (points.length - 1)) * plotW;
    const path = points.map((point, index) => `${index ? 'L' : 'M'}${xAt(index).toFixed(1)},${yAt(point.fish).toFixed(1)}`).join(' ');
    const area = `${path} L${xAt(points.length - 1).toFixed(1)},${yBase} L${xAt(0).toFixed(1)},${yBase} Z`;
    const grid = Array.from({length:5}, (_, index) => {
      const value = maxY - (maxY - minY) * index / 4;
      const y = yAt(value);
      return `<g><line x1="${left}" y1="${y.toFixed(1)}" x2="${W-right}" y2="${y.toFixed(1)}" stroke="#d7e6e5" stroke-width="1"/><text x="${left-8}" y="${(y+3.5).toFixed(1)}" fill="#718984" font-size="10" text-anchor="end">${esc(whole(value))}</text></g>`;
    }).join('');
    const xLabels = points.map((point, index) => {
      // Keep labels readable on a dense history: at most five date labels.
      const show = points.length <= 5 || index === 0 || index === points.length - 1 || index === Math.round((points.length - 1) / 2);
      if (!show) return '';
      return `<text x="${xAt(index).toFixed(1)}" y="${H-18}" fill="#718984" font-size="10" text-anchor="middle">${esc(fishChartDateLabel(point.date))}</text>`;
    }).join('');
    const labelIdx = points.length <= 4 ? points.map((_, i) => i) : Array.from(new Set([Math.floor((points.length-1)/2), points.length-1]));
    const labels = labelIdx.map(index => {
      const x = xAt(index), y = Math.max(2, yAt(points[index].fish) - 27);
      const label = whole(points[index].fish), bw = Math.max(48, label.length * 7 + 14);
      const bx = Math.min(W - bw - 2, Math.max(2, x - bw / 2));
      return `<g><rect x="${bx.toFixed(1)}" y="${y.toFixed(1)}" width="${bw}" height="21" rx="6" fill="#e1f4f1" stroke="#c7e8e2"/><text x="${(bx+bw/2).toFixed(1)}" y="${(y+14).toFixed(1)}" fill="#266e76" font-size="10.5" font-weight="800" text-anchor="middle">${esc(label)}</text></g>`;
    }).join('');
    const dots = points.map((point, index) => `<circle cx="${xAt(index).toFixed(1)}" cy="${yAt(point.fish).toFixed(1)}" r="4.3" fill="#5297b1" stroke="#ffffff" stroke-width="1.7"/>`).join('');
    return `<svg class="fishPopulationChart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Evolución de peces: ${esc(points.map(p => `${p.date}: ${whole(p.fish)} peces`).join('; '))}"><defs><linearGradient id="fishPopulationFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#72bfd0" stop-opacity=".34"/><stop offset="100%" stop-color="#72bfd0" stop-opacity=".02"/></linearGradient></defs>${grid}<path d="${area}" fill="url(#fishPopulationFill)"/><path d="${path}" fill="none" stroke="#5297b1" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>${dots}${labels}${xLabels}<text x="17" y="${top+plotH/2}" fill="#526f69" font-size="10.5" font-weight="700" text-anchor="middle" transform="rotate(-90 17 ${top+plotH/2})">Peces</text><text x="${left+plotW/2}" y="${H-2}" fill="#526f69" font-size="10.5" text-anchor="middle">Fecha de muestreo</text></svg>`;
  }

  function renderFishPopulationPanel(lot, snapshots) {
    const panel = $('fishPopulationPanel');
    const grid = $('fishAnalysisGrid');
    const chart = $('fishPopulationChart');
    const subtitle = $('fishChartSubtitle');
    if (!panel || !grid || !chart || !subtitle) return;
    const mortalityFromHistory = (lot.history || []).reduce((sum, item) => sum + Math.max(0, Number(item?.m) || 0), 0);
    const discardFromHistory = (lot.history || []).reduce((sum, item) => sum + Math.max(0, Number(item?.discard) || 0), 0);
    const mortality = Math.max(Number(lot.m) || 0, mortalityFromHistory);
    const discard = Math.max(Number(lot.discarded) || 0, discardFromHistory);
    const initial = Math.max(0, Number(lot.initialN) || 0, (Number(lot.n) || 0) + mortality + discard);
    const surv = initial > 0 ? Math.min(100, Math.max(0, Number(lot.n) || 0) / initial * 100) : 0;
    const circumference = 2 * Math.PI * 26;
    const dash = circumference * surv / 100;
    const mortalityPct = initial > 0 ? mortality / initial * 100 : 0;
    const discardPct = initial > 0 ? discard / initial * 100 : 0;
    grid.innerHTML = `
      <article class="fishAnalysisCard survival"><div class="fishAnalysisTitle">Supervivencia <span aria-hidden="true" style="color:#2c9d8a">✓</span></div><div class="fishSurvivalRing"><svg viewBox="0 0 64 64" aria-hidden="true"><circle class="ringTrack" cx="32" cy="32" r="26"/><circle class="ringValue" cx="32" cy="32" r="26" stroke-dasharray="${dash.toFixed(2)} ${circumference.toFixed(2)}"/></svg><b>${nfmt(surv,1)}%</b></div><span class="fishAnalysisCaption">de peces iniciales</span></article>
      <article class="fishAnalysisCard mortality"><div class="fishAnalysisTitle"><span class="fishAnalysisIcon" aria-hidden="true" style="color:#4a88a3">🐟̸</span> Mortalidad</div><strong class="fishAnalysisNumber">${whole(mortality)}</strong><span class="fishAnalysisUnit">peces</span><span class="fishAnalysisCaption">${nfmt(mortalityPct,2)}% acumulada</span></article>
      <article class="fishAnalysisCard discard"><div class="fishAnalysisTitle"><span class="fishAnalysisIcon" aria-hidden="true" style="color:#5d7d77">♧</span> Descarte</div><strong class="fishAnalysisNumber">${whole(discard)}</strong><span class="fishAnalysisUnit">peces</span><span class="fishAnalysisCaption">${nfmt(discardPct,2)}% acumulado</span></article>`;
    const allPoints = fishEvolutionPoints(lot, snapshots);
    const todayStart = new Date(`${today()}T00:00:00`);
    const cutoff = new Date(todayStart);
    cutoff.setDate(cutoff.getDate() - 29);
    const cutoffIso = cutoff.toISOString().slice(0,10);
    const recent = allPoints.filter(point => point.date >= cutoffIso && point.date <= today());
    let shown = recent;
    if (recent.length < 2) {
      shown = allPoints.slice(-8);
      subtitle.textContent = allPoints.length > recent.length ? 'Pocos muestreos en los últimos 30 días; se muestra el historial reciente.' : 'Según los muestreos registrados en este lote.';
    } else {
      subtitle.textContent = 'Muestreos registrados en los últimos 30 días.';
    }
    chart.innerHTML = makeFishEvolutionSvg(shown);
    panel.classList.add('active');
    panel.hidden = false;
  }

  function openMetricDetail(metric) {
    if (!activeLoteId) return;
    const lot = getLots().find(item => item.id === activeLoteId);
    const detail = METRIC_DETAILS[metric];
    if (!lot || !detail) return;
    const current = metricCurrent(lot, metric);
    const detailPanel = $('metricDetailPanel');
    detailPanel?.classList.toggle('fishDetailExpanded', metric === 'fish');
    const fishPanel = $('fishPopulationPanel');
    if (fishPanel) {
      fishPanel.classList.toggle('active', metric === 'fish');
      fishPanel.hidden = metric !== 'fish';
    }
    $('metricDetailIcon').textContent = detail.icon;
    $('metricDetailTitle').textContent = detail.title;
    $('metricDetailSubtitle').textContent = lot.code + ' · ' + stageLabel(lot.stage);
    $('metricDetailValue').textContent = current.value;
    $('metricDetailNote').textContent = current.note;
    const snapshots = metricSnapshots(lot);
    if (metric === 'fish') renderFishPopulationPanel(lot, snapshots);
    const rows = snapshots.map(snapshot => ({snapshot, value:metricHistoryValue(metric, snapshot)})).filter(row => row.value !== null);
    $('metricHistoryCount').textContent = rows.length + (rows.length === 1 ? ' registro' : ' registros');
    const historyBox = $('metricDetailHistory');
    if (!rows.length) {
      historyBox.innerHTML = `<div class="metricHistoryEmpty">Aún no hay registros de ${esc(detail.title.toLocaleLowerCase('es'))}. Guarda un muestreo con este dato y aparecerá aquí.</div>`;
    } else {
      historyBox.innerHTML = rows.map(({snapshot, value}) => {
        const meta = metricHistoryMeta(metric, snapshot);
        const cumulative = metric === 'feed' ? `<span class="metricHistoryMeta">Acumulado hasta esta fecha: ${nfmt(snapshot.feedCumulative, 2)} kg</span>` : '';
        return `<div class="metricHistoryItem"><div class="metricHistoryItemMain"><span class="metricHistoryDate">${esc(snapshot.h.d || 'Fecha no indicada')}</span>${meta ? `<span class="metricHistoryMeta">${esc(meta)}</span>` : ''}${cumulative}</div><span class="metricHistoryValue">${esc(value)}</span></div>`;
      }).join('');
    }
    $('metricDetailModal')?.classList.add('open');
  }
  function closeMetricDetail() { $('metricDetailModal')?.classList.remove('open'); }
  function closeLote() { if (waterEntryLotId !== null) closeWaterParamEntry(); closeMetricDetail(); $('loteModal')?.classList.remove('open'); activeLoteId = null; }
  function saveLote() {
    if (!activeLoteId) return;
    const lots = getLots();
    const lot = lots.find(item => item.id === activeLoteId);
    if (!lot) return;
    const weightRaw = $('lmWeight').value;
    const weight = weightRaw === '' ? lot.w : Number(weightRaw);
    const lengthRaw = $('lmLength').value;
    const length = lengthRaw === '' ? null : Number(lengthRaw);
    const mortality = Math.max(0, Number($('lmMort').value) || 0);
    const discarded = Math.max(0, Number($('lmDiscard').value) || 0);
    const pelletRaw = $('lmPelletInput').value;
    const pellet = pelletRaw === '' ? null : Number(pelletRaw);
    const feedRaw = $('lmFeedInput').value;
    const feedPeriod = feedRaw === '' ? null : Number(feedRaw);
    if (!Number.isFinite(weight) || weight <= 0) { alert('Ingresa un peso promedio válido mayor que cero.'); return; }
    if (lengthRaw !== '' && (!Number.isFinite(length) || length <= 0)) { alert('Ingresa una talla válida mayor que cero o deja el campo vacío.'); return; }
    if (!Number.isInteger(mortality) || !Number.isInteger(discarded) || mortality < 0 || discarded < 0) { alert('La mortalidad y el descarte deben ser números enteros no negativos.'); return; }
    if (mortality + discarded > lot.n) { alert('La mortalidad y el descarte no pueden superar la cantidad de peces del lote.'); return; }
    if (pelletRaw !== '' && (!Number.isFinite(pellet) || pellet <= 0)) { alert('Ingresa un calibre de pellet válido mayor que cero.'); return; }
    if (feedRaw !== '' && (!Number.isFinite(feedPeriod) || feedPeriod < 0)) { alert('Ingresa una cantidad de alimento válida no negativa.'); return; }

    const previousN = lot.n, previousWeight = lot.w;
    const remainingN = Math.max(0, previousN - mortality - discarded);
    const gainKg = Math.max(0, (weight - previousWeight) * ((previousN + remainingN) / 2) / 1000);
    lot.w = weight;
    if (length !== null) lot.l = length;
    if (pellet !== null) lot.pelletCalibre = pellet;
    lot.n = remainingN;
    lot.m += mortality;
    lot.discarded += discarded;
    let sampleFcr = null;
    if (feedPeriod !== null) {
      lot.alimentoConsumido = (Number(lot.alimentoConsumido) || 0) + feedPeriod;
      if (feedPeriod > 0 && gainKg > 0) { sampleFcr = feedPeriod / gainKg; lot.fcr = sampleFcr; }
    }
    const history = {
      d: today(), w: lot.w, l: lot.l, m: mortality, discard: discarded,
      feedKg: feedPeriod, pelletCalibre: lot.pelletCalibre, fcr: sampleFcr,
      x: $('lmObs').value.trim()
    };
    lot.history.unshift(history);
    persistLots(lots);
    closeLote();
    render();
    if (feedPeriod !== null && feedPeriod > 0 && gainKg <= 0) {
      alert('Muestreo guardado. El FCR no se actualizó porque no se registró ganancia positiva de peso en este periodo.');
    } else {
      alert('Muestreo guardado en la memoria local de TruchApp. Los demás módulos ya pueden consultar este lote.');
    }
  }
  function deleteLote() {
    if (!activeLoteId) return;
    const lot = getLots().find(item => item.id === activeLoteId);
    if (!lot || !confirm('¿Eliminar ' + lot.code + ' y todo su historial? Esta acción no se puede deshacer.')) return;
    persistLots(getLots().filter(item => item.id !== activeLoteId));
    closeLote();
    render();
  }
  function showTutorial() { openTutorial(); }

  window.openLote = openLote;
  window.saveLote = saveLote;
  window.deleteLote = deleteLote;
  window.closeLote = closeLote;
  window.lotesShowTutorial = showTutorial;
  window.lotesOnEnter = setupTutorial;
  window.renderLots = render;
  window.renderLotsForSharedViews = notifySharedDataChanged;

  function init() {
    document.addEventListener('keydown', ev => { if (ev.key !== 'Escape') return; if ($('metricDetailModal')?.classList.contains('open')) closeMetricDetail(); else if ($('waterParamEntryModal')?.classList.contains('open')) closeWaterParamEntry(); else if ($('waterFarmDrawer')?.classList.contains('open')) closeWaterFarmDrawer(); else if ($('waterQualityModal')?.classList.contains('open')) closeWaterQuality(); else if ($('lotesTutorial')?.classList.contains('open')) closeTutorial(); else if ($('performanceModal')?.classList.contains('open')) closePerformance(); else if ($('loteModal')?.classList.contains('open')) closeLote(); });
    render();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
