/* TruchApp — Lotes. Seguimiento local de lotes de Oncorhynchus mykiss. */
(function(){
  const KEY='truchapp_lotes_v1';
  const rootId='lotesRoot';
  const $=id=>document.getElementById(id);
  const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const num=(v,d=0)=>Number(v||0).toLocaleString('es-PE',{minimumFractionDigits:d,maximumFractionDigits:d});
  const kg=v=>num(v,2)+' kg';
  function get(){try{const x=JSON.parse(localStorage.getItem(KEY));return Array.isArray(x)?x:[]}catch{return []}}
  function set(v){try{localStorage.setItem(KEY,JSON.stringify(v))}catch{}}
  function uid(){return 'L'+Date.now().toString(36).toUpperCase()}
  function today(){return new Date().toISOString().slice(0,10)}
  function stageLabel(s){return ({ovas:'Ovas',alevinaje:'Alevinaje',juvenil:'Juvenil',engorde:'Engorde',reproductores:'Reproductores'})[s]||'Producción'}
  function calc(l){
    const initialCount=Number(l.initialCount)||0;
    const initialWeight=Number(l.initialWeight)||0;
    const currentCount=Math.max(0,Number(l.currentCount)||0);
    const currentWeight=Number(l.currentWeight)||0;
    const feed=Number(l.feedKg)||0;
    const harvest=Number(l.harvestKg)||0;
    const initialBio=initialCount*initialWeight/1000;
    const currentBio=currentCount*currentWeight/1000;
    const survival=initialCount>0?(currentCount/initialCount)*100:0;
    const mortality=Math.max(0,initialCount-currentCount);
    const growth=currentWeight-initialWeight;
    const gainBio=Math.max(0,currentBio-initialBio);
    const fcr=gainBio>0&&feed>0?feed/gainBio:null;
    return {initialBio,currentBio,survival,mortality,growth,gainBio,fcr,harvest};
  }
  function troutSvg(){return `<svg class="lotes-fish" viewBox="0 0 120 80" aria-hidden="true"><path d="M6 40C20 19 55 16 82 29L112 12 104 40 112 68 82 51C55 64 20 61 6 40Z" fill="#43d17a" opacity=".95"/><path d="M18 41Q50 31 91 40" stroke="#0b3b2b" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="21" cy="35" r="4" fill="#061009"/><path d="M62 23C71 12 77 7 84 4 86 12 90 19 96 25" fill="#159447"/></svg>`}
  function render(){
    const root=$(rootId); if(!root)return;
    const lots=get();
    const fish=lots.reduce((a,l)=>a+(Number(l.currentCount)||0),0);
    const bio=lots.reduce((a,l)=>a+calc(l).currentBio,0);
    const mortal=lots.reduce((a,l)=>a+calc(l).mortality,0);
    root.innerHTML=`<div class="lotes-wrap">
      <div class="lotes-head"><div><h2>Lotes</h2><p>Seguimiento de existencias, biometrías, alimentación, mortalidad y cosecha por lote.</p></div><div class="lotes-badge">${troutSvg()} Trucha arcoíris</div></div>
      <div class="lotes-kpis"><div class="lotes-kpi"><b>${num(lots.length)}</b><span>Lotes activos</span></div><div class="lotes-kpi"><b>${num(fish)}</b><span>Peces en existencia</span></div><div class="lotes-kpi"><b>${kg(bio)}</b><span>Biomasa estimada</span></div><div class="lotes-kpi"><b>${num(mortal)}</b><span>Bajas acumuladas</span></div></div>
      <div class="card"><div class="label">Nuevo lote</div>
        <div class="lotes-form-grid">
          <div class="lotes-field"><label>Código del lote</label><input class="lotes-input" id="lotCode" placeholder="Ej.: TR-2026-01"></div>
          <div class="lotes-field"><label>Etapa</label><select class="lotes-input" id="lotStage"><option value="alevinaje">Alevinaje</option><option value="juvenil">Juvenil</option><option value="engorde">Engorde</option><option value="reproductores">Reproductores</option><option value="ovas">Ovas</option></select></div>
          <div class="lotes-field"><label>Fecha de siembra / ingreso</label><input class="lotes-input" id="lotDate" type="date" value="${today()}"></div>
          <div class="lotes-field"><label>Origen</label><input class="lotes-input" id="lotOrigin" placeholder="Centro de producción / proveedor"></div>
          <div class="lotes-field"><label>Unidad de cultivo</label><input class="lotes-input" id="lotUnit" placeholder="Estanque, jaula, tanque…"></div>
          <div class="lotes-field"><label>Peces iniciales</label><input class="lotes-input" id="lotN" type="number" min="0" step="1" placeholder="10000"></div>
          <div class="lotes-field"><label>Peso inicial (g)</label><input class="lotes-input" id="lotW0" type="number" min="0" step="0.1" placeholder="20"></div>
          <div class="lotes-field"><label>Peso actual (g)</label><input class="lotes-input" id="lotW1" type="number" min="0" step="0.1" placeholder="60"></div>
          <div class="lotes-field"><label>Peces actuales</label><input class="lotes-input" id="lotN1" type="number" min="0" step="1" placeholder="9800"></div>
          <div class="lotes-field"><label>Alimento acumulado (kg)</label><input class="lotes-input" id="lotFeed" type="number" min="0" step="0.01" placeholder="0"></div>
          <div class="lotes-field"><label>Cosecha acumulada (kg)</label><input class="lotes-input" id="lotHarvest" type="number" min="0" step="0.01" placeholder="0"></div>
          <div class="lotes-field full"><label>Observaciones</label><input class="lotes-input" id="lotNote" placeholder="Biometría, mortalidad, calidad de agua, manejo…"></div>
        </div>
        <div class="lotes-actions-row"><button class="primary" id="lotSave">＋ Crear lote</button><button class="secondary" id="calcBg">🧮 Calculadora</button></div>
        <p class="lotes-muted" style="margin:8px 2px 0">La calculadora sigue disponible, pero queda fuera de la barra principal.</p>
      </div>
      <div class="card"><div class="row"><div class="label" style="margin:0">Mis lotes</div><span class="pill">🐟 seguimiento local</span></div><div id="lotesList" class="lotes-list" style="margin-top:9px"></div></div>
      <div id="loteDetail"></div>
      <div class="card"><h3>Qué conviene registrar</h3><p class="lotes-muted">FAO recomienda mantener registros de existencias y mortalidad, alimentación, almacén y balance de producción. Los muestreos de cantidad y peso permiten estimar crecimiento, conversión, costos y cercanía a la capacidad de carga.</p><p class="lotes-source"><b>Referencias:</b> FAO, <i>Small-scale rainbow trout farming</i> (Technical Paper 561, 2011); FAO, <i>Oncorhynchus mykiss</i>. En Perú, la NTP 032.103:2024 estandariza el método para determinar el factor de conversión alimenticia en trucha arcoíris.</p></div>
    </div>
    <div id="lotesTutorial" class="lotes-tutorial" hidden role="dialog" aria-modal="true" aria-labelledby="lotesTutorialTitle">
      <div class="lotes-tutorial-backdrop" data-close-tutorial></div>
      <div class="card hero lotes-tutorial-card" role="document">
        <button class="lotes-tutorial-close" type="button" aria-label="Cerrar tutorial" data-close-tutorial>×</button>
        <div class="lotes-tutorial-content">
          <div class="lotes-tutorial-icon" aria-hidden="true">🐟</div>
          <h2 id="lotesTutorialTitle">Controla el ciclo de cada lote</h2>
          <p>Registra siembra, población, biometrías, mortalidad, alimentación, movimientos y cosecha. El historial ayuda a comparar crecimiento, supervivencia y manejo.</p>
        </div>
      </div>
    </div>`;
    $('lotDate').value=today();
    setupTutorial();
    $('lotSave').addEventListener('click',createLot);
    $('calcBg').addEventListener('click',()=>{const b=document.querySelector('.nav[data-target="calc"]');if(b)b.click()});
    renderList();
  }
  const TUTORIAL_KEY='truchapp_lotes_tutorial_seen_v1';
  function closeTutorial(){
    const modal=$('lotesTutorial');
    if(!modal)return;
    try{localStorage.setItem(TUTORIAL_KEY,'1')}catch{}
    modal.hidden=true;
  }
  function setupTutorial(){
    const modal=$('lotesTutorial');
    if(!modal)return;
    let seen=false;
    try{seen=localStorage.getItem(TUTORIAL_KEY)==='1'}catch{}
    modal.hidden=seen;
    modal.querySelectorAll('[data-close-tutorial]').forEach(el=>el.addEventListener('click',closeTutorial));
    modal.querySelector('.lotes-tutorial-card')?.addEventListener('click',e=>e.stopPropagation());
  }
  function readForm(){
    const code=$('lotCode').value.trim()||uid();
    const stage=$('lotStage').value;
    const date=$('lotDate').value||today();
    const origin=$('lotOrigin').value.trim();
    const unit=$('lotUnit').value.trim();
    const initialCount=Math.max(0,parseInt($('lotN').value||'0',10));
    const initialWeight=Math.max(0,parseFloat($('lotW0').value||'0'));
    const currentWeight=Math.max(0,parseFloat($('lotW1').value||initialWeight));
    const currentCount=Math.max(0,parseInt($('lotN1').value||initialCount,10));
    const feedKg=Math.max(0,parseFloat($('lotFeed').value||'0'));
    const harvestKg=Math.max(0,parseFloat($('lotHarvest').value||'0'));
    const note=$('lotNote').value.trim();
    if(!(initialCount>0&&initialWeight>0&&currentCount>=0&&currentWeight>0)){alert('Ingresa al menos peces iniciales, peso inicial, peces actuales y peso actual.');return null}
    return {id:uid(),code,date,stage,origin,unit,initialCount,initialWeight,currentCount,currentWeight,feedKg,harvestKg,note,history:[{date,currentCount,currentWeight,feedKg,harvestKg,note}]};
  }
  function createLot(){const l=readForm();if(!l)return;const lots=get();lots.unshift(l);set(lots);render();}
  function renderList(){
    const box=$('lotesList');const lots=get();
    if(!lots.length){box.innerHTML='<div class="empty">Aún no tienes lotes registrados.</div>';return}
    box.innerHTML=lots.map(l=>{
      const c=calc(l);const target=Number(l.targetWeight)||350;const progress=Math.max(0,Math.min(100,(Number(l.currentWeight)||0)/target*100));
      return `<div class="lote-card"><div class="lote-top"><div><div class="lote-code">${esc(l.code)}</div><div class="lote-meta">${stageLabel(l.stage)} · ingreso ${esc(l.date)}${l.unit?' · '+esc(l.unit):''}</div></div><span class="lote-stage">🐟</span></div>
      <div class="lote-grid"><div class="lote-stat"><b>${num(l.currentCount)}</b><span>Peces</span></div><div class="lote-stat"><b>${num(l.currentWeight,1)} g</b><span>Peso prom.</span></div><div class="lote-stat"><b>${kg(c.currentBio)}</b><span>Biomasa</span></div><div class="lote-stat"><b>${num(c.survival,1)}%</b><span>Supervivencia</span></div></div>
      <div class="lote-progress"><i style="width:${progress}%"></i></div><div class="lote-note">Progreso hacia ${num(target)} g: ${num(progress,0)}% · Bajas estimadas por diferencia: ${num(c.mortality)}</div>
      <div class="lote-actions"><button class="open" onclick="window.openLote('${esc(l.id)}')">Ver / actualizar lote</button><button class="danger" onclick="window.deleteLote('${esc(l.id)}')">✕</button></div></div>`;
    }).join('');
  }
  function detail(id){
    const l=get().find(x=>x.id===id);if(!l)return;const c=calc(l);
    const box=$('loteDetail');
    box.innerHTML=`<div class="card"><div class="lotes-detail-title"><div><h3>${esc(l.code)}</h3><div class="lote-meta">${stageLabel(l.stage)} · ${esc(l.unit||'Unidad no indicada')}</div></div><button class="lotes-detail-close" onclick="window.closeLote()">Cerrar</button></div>
      <div class="lotes-detail-grid" style="margin-top:10px"><div class="lotes-detail-item"><span>Biomasa inicial</span><b>${kg(c.initialBio)}</b></div><div class="lotes-detail-item"><span>Biomasa actual</span><b>${kg(c.currentBio)}</b></div><div class="lotes-detail-item"><span>Ganancia de biomasa</span><b>${kg(c.gainBio)}</b></div><div class="lotes-detail-item"><span>Supervivencia</span><b>${num(c.survival,1)}%</b></div><div class="lotes-detail-item"><span>Crecimiento individual</span><b>${num(c.growth,1)} g</b></div><div class="lotes-detail-item"><span>FCR observado</span><b>${c.fcr==null?'—':num(c.fcr,2)}</b></div></div>
      <div style="margin-top:10px" class="label">Actualizar seguimiento</div>
      <div class="lotes-form-grid"><div class="lotes-field"><label>Fecha</label><input class="lotes-input" id="upDate" type="date" value="${today()}"></div><div class="lotes-field"><label>Peces actuales</label><input class="lotes-input" id="upN" type="number" min="0" value="${l.currentCount}"></div><div class="lotes-field"><label>Peso actual (g)</label><input class="lotes-input" id="upW" type="number" min="0" step="0.1" value="${l.currentWeight}"></div><div class="lotes-field"><label>Alimento acumulado (kg)</label><input class="lotes-input" id="upFeed" type="number" min="0" step="0.01" value="${l.feedKg}"></div><div class="lotes-field"><label>Cosecha acumulada (kg)</label><input class="lotes-input" id="upHarvest" type="number" min="0" step="0.01" value="${l.harvestKg}"></div><div class="lotes-field full"><label>Observación del seguimiento</label><input class="lotes-input" id="upNote" placeholder="Cambios observados…"></div></div>
      <button class="primary" style="width:100%;margin-top:10px" onclick="window.updateLote('${esc(l.id)}')">Guardar seguimiento</button>
      <div style="margin-top:12px" class="label">Historial del lote</div>
      ${l.history&&l.history.length?`<table class="lotes-table"><thead><tr><th>Fecha</th><th>Peces</th><th>Peso</th><th>Alimento</th><th>Nota</th></tr></thead><tbody>${l.history.slice().reverse().slice(0,8).map(h=>`<tr><td>${esc(h.date)}</td><td>${num(h.currentCount)}</td><td>${num(h.currentWeight,1)} g</td><td>${num(h.feedKg,2)} kg</td><td>${esc(h.note||'')}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">Sin historial.</div>'}
      <p class="lotes-muted" style="margin-top:10px">Para FCR se usa alimento acumulado ÷ ganancia de biomasa. Interprétalo con mortalidad, desperdicio y periodo de evaluación.</p></div>`;
    box.scrollIntoView({behavior:'smooth',block:'start'});
  }
  function updateLote(id){
    const lots=get();const l=lots.find(x=>x.id===id);if(!l)return;
    l.currentCount=Math.max(0,parseInt($('upN').value||'0',10));
    l.currentWeight=Math.max(0,parseFloat($('upW').value||'0'));
    l.feedKg=Math.max(0,parseFloat($('upFeed').value||'0'));
    l.harvestKg=Math.max(0,parseFloat($('upHarvest').value||'0'));
    const h={date:$('upDate').value||today(),currentCount:l.currentCount,currentWeight:l.currentWeight,feedKg:l.feedKg,harvestKg:l.harvestKg,note:$('upNote').value.trim()};
    (l.history||(l.history=[])).push(h);l.note=h.note||l.note;set(lots);render();detail(id);
  }
  function del(id){if(!confirm('¿Eliminar este lote y todo su historial?'))return;set(get().filter(x=>x.id!==id));render();}
  function close(){const box=$('loteDetail');if(box)box.innerHTML=''}
  window.openLote=detail;window.updateLote=updateLote;window.deleteLote=del;window.closeLote=close;window.renderLots=render;
  function init(){render()}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
