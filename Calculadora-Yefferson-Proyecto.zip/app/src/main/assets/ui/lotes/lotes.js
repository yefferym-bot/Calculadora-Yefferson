
/* TruchApp — módulo Lotes integrado con almacenamiento local compartido. */
(function () {
  'use strict';

  const KEY = 'truchapp_lotes_v1';
  const TUTORIAL_KEY = 'truchapp_lotes_tutorial_v2';
  const rootId = 'lotesRoot';
  const $ = id => document.getElementById(id);
  let activeLoteId = null;
  let rendering = false;
  let tutorialChecked = false;
  let tutorialStepIndex = 0;
  const TUTORIAL_STEPS = [
    {heading:'Conoce el resumen',text:'Los indicadores superiores muestran cuántos lotes tienes registrados, la cantidad de peces en existencia y la biomasa estimada del conjunto.',tipHeading:'Consejo práctico',tipText:'Revisa el resumen después de crear un lote o guardar un nuevo muestreo.'},
    {heading:'Registra un nuevo lote',text:'Pulsa “Crear nuevo lote” e ingresa un código único, etapa productiva, fecha de ingreso, origen, unidad de cultivo, cantidad inicial y pesos. Comprueba los datos antes de guardar.',tipHeading:'Antes de guardar',tipText:'Utiliza códigos distintos para cada lote y registra cantidades y pesos medidos en campo.'},
    {heading:'Actualiza el muestreo',text:'Abre la ficha de un lote y registra peso y talla promedio, mortalidad del periodo, descarte, calibre del pellet, alimento consumido y observaciones sanitarias.',tipHeading:'Para mantener un buen historial',tipText:'Anota el alimento correspondiente al periodo que estás registrando, no una cifra aproximada de todo el ciclo.'},
    {heading:'Interpreta los indicadores',text:'La ficha resume peces actuales, peso promedio, biomasa, supervivencia, talla, alimento acumulado y FCR estimado. Estos indicadores dependen de la calidad de los datos introducidos.',tipHeading:'Recuerda',tipText:'Mortalidad y descarte se registran por separado: el descarte no debe contarse como mortalidad.'},
    {heading:'Consulta la evolución',text:'Los últimos registros permiten comparar crecimiento y manejo a lo largo del tiempo. Abre cada ficha para revisar el historial y actualiza los datos cuando realices nuevos controles.',tipHeading:'Cuidado con los datos',tipText:'Elimina un lote solo cuando corresponda; al hacerlo, también se elimina su historial en esta muestra.'}
  ];

  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[c]);
  const escAttr = value => esc(value).replace(/`/g, '&#96;');
  const nfmt = (value, digits = 1) => Number(value || 0).toLocaleString('es-PE', {
    minimumFractionDigits: digits, maximumFractionDigits: digits
  });
  const whole = value => Number(value || 0).toLocaleString('es-PE', { maximumFractionDigits: 0 });
  const optionalNumber = value => value === '' || value === null || value === undefined || !Number.isFinite(Number(value))
    ? null : Math.max(0, Number(value));
  const today = () => new Date().toISOString().slice(0, 10);
  const isAndroid = () => typeof window.AndroidAI !== 'undefined';

  function newId() { return 'LOTE-' + Date.now().toString(36).toUpperCase(); }
  function stageLabel(stage) {
    const aliases = {
      ovas: 'Ovas', alevinaje: 'Alevinaje', juvenil: 'Juvenil', engorde: 'Engorde',
      reproductores: 'Reproductores', 'alevín': 'Alevinaje'
    };
    const value = String(stage || 'Producción');
    return aliases[value.toLowerCase()] || value;
  }
  function slugStage(stage) {
    const value = stageLabel(stage).toLowerCase();
    return ({ ovas: 'ovas', alevinaje: 'alevinaje', juvenil: 'juvenil', engorde: 'engorde', reproductores: 'reproductores' })[value] || 'alevinaje';
  }
  function historyItem(h, lot) {
    h = h || {};
    return {
      d: String(h.d || h.date || lot.date || today()),
      w: Math.max(0, Number(h.w ?? h.currentWeight ?? lot.w) || 0),
      l: optionalNumber(h.l ?? h.length),
      m: Math.max(0, Number(h.m ?? h.mortality) || 0),
      discard: Math.max(0, Number(h.discard ?? h.discarded) || 0),
      feedKg: optionalNumber(h.feedKg ?? h.alimentoConsumido),
      pelletCalibre: optionalNumber(h.pelletCalibre),
      fcr: optionalNumber(h.fcr),
      x: String(h.x || h.note || '')
    };
  }
  function normalizeLot(source) {
    const src = source || {};
    const id = String(src.id || src.code || newId());
    const code = String(src.code || src.id || id);
    const n = Math.max(0, Math.floor(Number(src.n ?? src.currentCount ?? src.initialCount) || 0));
    const w = Math.max(0, Number(src.w ?? src.currentWeight ?? src.initialWeight) || 0);
    const mortalitySpecified = src.m !== undefined || src.mortality !== undefined;
    const discarded = Math.max(0, Math.floor(Number(src.discarded ?? src.discard ?? 0) || 0));
    let initialN = Math.max(0, Math.floor(Number(src.initialN ?? src.initialCount) || 0));
    if (!initialN) initialN = n + discarded + (mortalitySpecified ? Math.max(0, Math.floor(Number(src.m ?? src.mortality) || 0)) : 0);
    const m = Math.max(0, Math.floor(mortalitySpecified ? (Number(src.m ?? src.mortality) || 0) : initialN - n - discarded));
    initialN = Math.max(initialN, n + m + discarded);
    const initialWeight = Math.max(0, Number(src.w0 ?? src.initialWeight ?? src.w ?? src.currentWeight) || 0);
    const base = {
      id, code,
      stage: stageLabel(src.stage),
      unit: String(src.unit || 'Sin indicar'),
      origin: String(src.origin || 'Sin indicar'),
      date: String(src.date || today()),
      initialN,
      initialWeight,
      n, w,
      l: optionalNumber(src.l ?? src.length),
      pelletCalibre: optionalNumber(src.pelletCalibre ?? src.pelletSize),
      alimentoConsumido: optionalNumber(src.alimentoConsumido ?? src.feedKg),
      fcr: optionalNumber(src.fcr),
      m,
      discarded,
      targetWeight: Math.max(1, Number(src.targetWeight) || 210),
      harvestKg: Math.max(0, Number(src.harvestKg) || 0),
      history: []
    };
    const rawHistory = Array.isArray(src.history) ? src.history : [];
    base.history = rawHistory.map(h => historyItem(h, base));
    if (!base.history.length) {
      base.history.push({ d: base.date, w: base.w, l: base.l, m: 0, discard: 0, feedKg: null, pelletCalibre: base.pelletCalibre, fcr: base.fcr, x: 'Lote registrado' });
    }
    return base;
  }
  function parseLots(raw) {
    try {
      const value = JSON.parse(raw || '[]');
      return Array.isArray(value) ? value.map(normalizeLot) : [];
    } catch (_) { return []; }
  }
  function localLots() {
    try { return parseLots(localStorage.getItem(KEY)); } catch (_) { return []; }
  }
  function nativeLots() {
    if (!isAndroid() || typeof AndroidAI.getLots !== 'function') return null;
    try {
      const parsed = JSON.parse(AndroidAI.getLots());
      return Array.isArray(parsed) ? parsed.map(normalizeLot) : null;
    } catch (_) { return null; }
  }
  function saveLocal(lots) {
    try { localStorage.setItem(KEY, JSON.stringify(lots)); } catch (_) {}
  }
  function saveNative(lots) {
    if (!isAndroid() || typeof AndroidAI.saveLots !== 'function') return;
    try { AndroidAI.saveLots(JSON.stringify(lots)); } catch (_) {}
  }
  function getLots() {
    const local = localLots();
    const native = nativeLots();
    // If this is an existing installation, migrate WebView localStorage lots before relying on
    // the new native preference key, which did not exist in older versions.
    if (local.length && (!native || native.length === 0)) {
      saveNative(local);
      return local;
    }
    if (native && native.length) {
      saveLocal(native);
      return native;
    }
    return local;
  }
  function survival(lot) {
    const initial = Math.max(Number(lot.initialN) || 0, (Number(lot.n) || 0) + (Number(lot.m) || 0) + (Number(lot.discarded) || 0));
    return initial > 0 ? Math.max(0, Number(lot.n) || 0) / initial * 100 : 0;
  }
  function biomass(lot) { return Math.max(0, Number(lot.n) || 0) * Math.max(0, Number(lot.w) || 0) / 1000; }
  function daysSince(dateValue) {
    if (!dateValue) return 0;
    const start = new Date(String(dateValue).slice(0, 10) + 'T00:00:00Z');
    const end = new Date(today() + 'T00:00:00Z');
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime())) return 0;
    return Math.max(0, Math.floor((end.getTime() - start.getTime()) / 86400000));
  }
  function performanceData(lot) {
    const days = daysSince(lot.date);
    const initialWeight = Number(lot.initialWeight) || 0;
    const weight = Number(lot.w) || 0;
    const sgr = days > 0 && initialWeight > 0 && weight > 0
      ? (Math.log(weight / initialWeight) / days) * 100 : null;
    const fcrValue = lot.fcr !== null && lot.fcr !== undefined && Number.isFinite(Number(lot.fcr)) && Number(lot.fcr) > 0
      ? Number(lot.fcr) : null;
    return {lot, biomass: biomass(lot), weight, survival: survival(lot), sgr, fcr: fcrValue, days};
  }
  function performanceMetricValue(row, key) {
    return key === 'biomass' ? row.biomass : key === 'survival' ? row.survival : key === 'weight' ? row.weight : key === 'sgr' ? row.sgr : row.fcr;
  }
  function performanceMetricText(row, key) {
    const value = performanceMetricValue(row, key);
    if (value === null || value === undefined || !Number.isFinite(value)) return '—';
    if (key === 'biomass') return nfmt(value, 1) + ' kg';
    if (key === 'survival') return nfmt(value, 1) + '%';
    if (key === 'weight') return nfmt(value, 1) + ' g';
    if (key === 'sgr') return nfmt(value, 2) + '%/día';
    return nfmt(value, 2);
  }
  function openPerformance() {
    const sort = $('performanceSort');
    if (sort) sort.value = 'biomass';
    renderPerformanceCompare();
    $('performanceModal')?.classList.add('open');
  }
  function closePerformance() { $('performanceModal')?.classList.remove('open'); }
  function renderPerformanceCompare() {
    const summary = $('performanceSummary');
    const content = $('performanceContent');
    if (!summary || !content) return;
    const lots = getLots();
    const totalFish = lots.reduce((sum, lot) => sum + (Number(lot.n) || 0), 0);
    const totalInitial = lots.reduce((sum, lot) => sum + (Number(lot.initialN) || 0), 0);
    const totalBiomass = lots.reduce((sum, lot) => sum + biomass(lot), 0);
    const overallSurvival = totalInitial > 0 ? totalFish / totalInitial * 100 : null;
    summary.innerHTML = `<div class="performanceSummaryCard"><b>${whole(lots.length)}</b><span>Lotes comparados</span></div><div class="performanceSummaryCard"><b>${nfmt(totalBiomass, 1)} kg</b><span>Biomasa viva</span></div><div class="performanceSummaryCard"><b>${overallSurvival === null ? '—' : nfmt(overallSurvival, 1) + '%'}</b><span>Supervivencia global</span></div>`;
    if (!lots.length) {
      content.innerHTML = '<div class="performanceEmpty">Todavía no hay lotes registrados para comparar. Crea un lote y registra sus primeros datos productivos.</div>';
      return;
    }
    const sortKey = $('performanceSort')?.value || 'biomass';
    const rows = lots.map(performanceData);
    rows.sort((a, b) => {
      const av = performanceMetricValue(a, sortKey), bv = performanceMetricValue(b, sortKey);
      const aMissing = av === null || av === undefined || !Number.isFinite(av);
      const bMissing = bv === null || bv === undefined || !Number.isFinite(bv);
      if (aMissing && bMissing) return String(a.lot.code).localeCompare(String(b.lot.code));
      if (aMissing) return 1;
      if (bMissing) return -1;
      return sortKey === 'fcr' ? av - bv : bv - av;
    });
    const vals = rows.map(row => performanceMetricValue(row, sortKey)).filter(value => value !== null && value !== undefined && Number.isFinite(value));
    const maxValue = vals.length ? Math.max(...vals) : 0;
    const minValue = vals.length ? Math.min(...vals) : 0;
    const labels = {biomass:'Biomasa',survival:'Supervivencia',weight:'Peso promedio',sgr:'Crecimiento específico',fcr:'FCR último registrado'};
    content.innerHTML = rows.map((row, index) => {
      const value = performanceMetricValue(row, sortKey);
      const hasValue = value !== null && value !== undefined && Number.isFinite(value);
      let bar = 0;
      if (hasValue && maxValue > 0) bar = sortKey === 'fcr' ? Math.min(100, minValue / value * 100) : Math.min(100, value / maxValue * 100);
      const stage = esc(stageLabel(row.lot.stage));
      const meta = `${stage} · ${esc(row.lot.unit || 'Sin unidad')} · ${row.days} días desde ingreso`;
      const best = index === 0 && hasValue;
      return `<article class="performanceLot"><div class="performanceLotHead"><div><div class="performanceLotTitle">${esc(row.lot.code)}</div><div class="performanceLotMeta">${meta}</div>${best ? '<span class="performanceBest">Mejor en ' + labels[sortKey].toLowerCase() + '</span>' : ''}</div><span class="performanceRank">${String(index + 1).padStart(2, '0')}</span></div><div class="performanceMetricGrid"><div class="performanceMetric"><b>${nfmt(row.biomass, 1)} kg</b><span>Biomasa</span></div><div class="performanceMetric"><b>${nfmt(row.weight, 1)} g</b><span>Peso promedio</span></div><div class="performanceMetric"><b>${nfmt(row.survival, 1)}%</b><span>Supervivencia</span></div><div class="performanceMetric"><b>${row.sgr === null ? '—' : nfmt(row.sgr, 2) + '%'}</b><span>SGR (%/día)</span></div><div class="performanceMetric"><b>${row.fcr === null ? '—' : nfmt(row.fcr, 2)}</b><span>FCR último registro</span></div><div class="performanceMetric"><b>${row.days}</b><span>Días desde ingreso</span></div></div><div class="performanceBarWrap" role="img" aria-label="${labels[sortKey]} de ${esc(row.lot.code)}: ${performanceMetricText(row, sortKey)}"><div class="performanceBar" style="width:${bar}%"></div></div><div class="performanceLotMeta" style="margin-top:5px">${labels[sortKey]}: <b>${performanceMetricText(row, sortKey)}</b></div></article>`;
    }).join('');
  }

  function health(lot) {
    const count = Number(lot.n), weight = Number(lot.w), surv = survival(lot);
    if (!Number.isFinite(count) || count <= 0 || !Number.isFinite(weight) || weight <= 0) return { level: 'critical', label: 'Crítico', survival: surv };
    if (surv < 90) return { level: 'critical', label: 'Crítico', survival: surv };
    if (surv < 95) return { level: 'regular', label: 'Regular', survival: surv };
    return { level: 'good', label: 'Bueno', survival: surv };
  }
  function currentDataSummary(lot) {
    const hs = lot.history && lot.history[0];
    return {
      id: lot.id, code: lot.code, stage: lot.stage, date: lot.date, unit: lot.unit, origin: lot.origin,
      initialN: lot.initialN, initialWeight: lot.initialWeight,
      fish: lot.n, weightG: lot.w, lengthCm: lot.l, biomassKg: biomass(lot), survivalPct: survival(lot),
      pelletCalibreMm: lot.pelletCalibre, feedConsumedKg: lot.alimentoConsumido, fcr: lot.fcr,
      mortalityTotal: lot.m, discardTotal: lot.discarded, harvestKg: lot.harvestKg,
      lastSample: hs ? Object.assign({}, hs) : null,
      history: (lot.history || []).map(h => Object.assign({}, h))
    };
  }
  function notifySharedDataChanged() {
    try { window.dispatchEvent(new CustomEvent('truchapp-lots-updated')); } catch (_) {}
    if (typeof window.refreshAgendaLotOptions === 'function') window.refreshAgendaLotOptions();
    if (typeof window.renderMemory === 'function') window.renderMemory();
    if (typeof window.updateFinanceLotOptions === 'function') window.updateFinanceLotOptions();
  }
  function persistLots(lots) {
    const normalized = (Array.isArray(lots) ? lots : []).map(normalizeLot);
    saveLocal(normalized);
    saveNative(normalized);
    notifySharedDataChanged();
  }
  function apiGetLots() { return getLots().map(currentDataSummary); }
  function apiGetLot(id) {
    const lot = getLots().find(x => x.id === String(id) || x.code === String(id));
    return lot ? currentDataSummary(lot) : null;
  }
  function apiSummary() {
    const lots = getLots();
    return {
      lotCount: lots.length,
      fishCount: lots.reduce((sum, lot) => sum + lot.n, 0),
      biomassKg: lots.reduce((sum, lot) => sum + biomass(lot), 0),
      mortalityTotal: lots.reduce((sum, lot) => sum + lot.m, 0),
      discardTotal: lots.reduce((sum, lot) => sum + lot.discarded, 0),
      lots: lots.map(currentDataSummary)
    };
  }
  window.TruchAppData = Object.assign(window.TruchAppData || {}, {
    getLots: apiGetLots,
    getLot: apiGetLot,
    getLotSummary: apiSummary
  });

  function fishSvg() {
    // A right-facing, teal-blue rainbow trout. The fish stays in place; only a subtle body float and tail flick animate.
    return `<svg class="lotesFish" viewBox="0 0 140 82" role="img" aria-label="Trucha arcoíris nadando suavemente en su sitio" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="lotFishBodyGradient" x1="0" y1="0" x2="0.12" y2="1"><stop offset="0" stop-color="#0b6574"/><stop offset=".42" stop-color="#159caa"/><stop offset=".78" stop-color="#42c7c2"/><stop offset="1" stop-color="#b9f3e6"/></linearGradient>
        <linearGradient id="lotFishFinGradient" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#167d8e"/><stop offset="1" stop-color="#54d7c9"/></linearGradient>
        <linearGradient id="lotFishBellyGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d9fff4" stop-opacity=".25"/><stop offset="1" stop-color="#e6fff8" stop-opacity=".96"/></linearGradient>
      </defs>
      <g class="lotesFishTail">
        <path d="M31 40 C20 32 12 22 4 17 C7 29 8 37 8 41 C7 49 7 57 4 65 C15 59 24 50 32 43 Z" fill="url(#lotFishFinGradient)" stroke="#0b7180" stroke-width="1.2" stroke-linejoin="round"/>
        <path d="M10 23 Q19 35 29 40 M10 59 Q20 48 29 43" fill="none" stroke="#9ef1e2" stroke-opacity=".8" stroke-width="1.2" stroke-linecap="round"/>
      </g>
      <path d="M28 39 C39 24 61 17 83 21 C99 23 111 27 124 34 Q132 39 124 44 C111 51 99 56 82 58 C59 61 39 53 28 43 Z" fill="url(#lotFishBodyGradient)" stroke="#0c7282" stroke-width="1.2"/>
      <path d="M36 43 C52 51 77 55 100 48 C108 46 115 43 123 40 C111 53 95 57 81 58 C60 60 43 53 36 43 Z" fill="url(#lotFishBellyGradient)"/>
      <path d="M50 23 C55 14 63 9 75 8 C72 16 75 20 82 22 Z" fill="url(#lotFishFinGradient)" stroke="#0b7180" stroke-width="1" stroke-linejoin="round"/>
      <path d="M71 57 C78 60 84 64 91 69 C91 61 89 57 84 55 Z" fill="url(#lotFishFinGradient)" stroke="#0b7180" stroke-width="1" stroke-linejoin="round"/>
      <path d="M86 47 C91 51 95 55 100 58 C101 51 99 47 96 44 Z" fill="#25aeb5" stroke="#0b7180" stroke-width="1" stroke-linejoin="round"/>
      <path d="M38 34 Q61 28 82 32 Q100 34 119 38" fill="none" stroke="#8be5da" stroke-opacity=".75" stroke-width="1.3" stroke-linecap="round"/>
      <g fill="#075b70" opacity=".75">
        <ellipse cx="43" cy="31" rx="1.4" ry="1"/><ellipse cx="51" cy="26" rx="1.2" ry=".9"/><ellipse cx="59" cy="31" rx="1.5" ry="1.1"/><ellipse cx="68" cy="25" rx="1.2" ry=".9"/><ellipse cx="75" cy="30" rx="1.5" ry="1.1"/><ellipse cx="84" cy="26" rx="1.2" ry=".9"/><ellipse cx="93" cy="31" rx="1.4" ry="1"/><ellipse cx="101" cy="34" rx="1.2" ry=".9"/><ellipse cx="64" cy="38" rx="1.1" ry=".8"/><ellipse cx="76" cy="38" rx="1.3" ry=".9"/><ellipse cx="88" cy="39" rx="1.1" ry=".8"/>
      </g>
      <path d="M107 29 Q114 31 121 36" fill="none" stroke="#d7fff5" stroke-width="1.1" stroke-linecap="round"/>
      <path d="M104 28 Q112 25 119 34 Q125 40 118 45 Q111 49 103 46 Q110 40 104 28 Z" fill="#36bfc0" stroke="#0d7787" stroke-width="1.1"/>
      <circle cx="115" cy="34" r="4.2" fill="#e9fffb"/><circle cx="116" cy="34" r="2.8" fill="#063d56"/><circle cx="117" cy="33" r="1" fill="#ffffff"/>
      <path d="M124 41 Q128 42 131 40" fill="none" stroke="#075b70" stroke-width="1.2" stroke-linecap="round"/>
      <path d="M54 23 Q68 20 83 23" fill="none" stroke="#aaf7e9" stroke-opacity=".8" stroke-width="1.1" stroke-linecap="round"/>
    </svg>`;
  }
  function render() {
    const root = $(rootId);
    if (!root || rendering) return;
    rendering = true;
    const lots = getLots();
    const totalFish = lots.reduce((sum, lot) => sum + lot.n, 0);
    const totalBiomass = lots.reduce((sum, lot) => sum + biomass(lot), 0);
    root.innerHTML = `
      <div class="lotesModule">
        <div class="lotesHead"><div><h2>Lotes</h2><p>Seguimiento de existencias, biometrías, alimentación, mortalidad y cosecha por lote.</p></div><button class="lotesBadge" id="openPerformanceBtn" type="button" aria-haspopup="dialog" aria-controls="performanceModal" title="Comparar rendimiento de lotes"><span class="lotesFishLane">${fishSvg()}</span><span class="lotesBadgeLabel">Rendimiento de lotes</span></button></div>
        <div class="lotesKpis"><div class="lotesKpi"><b id="kpiLotes">${whole(lots.length)}</b><span>Lotes activos</span></div><div class="lotesKpi"><b id="kpiPeces">${whole(totalFish)}</b><span>Peces en existencia</span></div><div class="lotesKpi"><b id="kpiBiomasa">${nfmt(totalBiomass, 1)} kg</b><span>Biomasa estimada</span></div></div>
        <button class="createLoteTrigger" id="createLoteTrigger" type="button">＋ Crear nuevo lote</button>
        <div class="lotesCard"><div class="lotesHead innerHead"><div><div class="lotesLabel">Mis lotes</div><div class="lotesHint" style="margin:0">Una ficha por lote para seguir el ciclo productivo.</div></div><span class="lotesStage">🐟 seguimiento local</span></div><div class="lotesSearchWrap"><span class="lotesSearchIcon" aria-hidden="true">⌕</span><input class="lotesSearchInput" id="lotesSearch" type="search" autocomplete="off" aria-label="Buscar lotes" placeholder="Buscar por código, etapa, unidad u origen"></div><div class="lotesCards" id="lotesList"></div></div>
        <div class="lotesCard"><div class="lotesLabel">Qué conviene registrar</div><p class="lotesHint" style="font-size:12px">Existencias, mortalidad, biometrías, alimentación, movimientos y cosecha. El historial permite comparar crecimiento, supervivencia y manejo.</p><p class="lotesSource"><b>Referencias técnicas:</b> FAO, <i>Small-scale rainbow trout farming</i> (Technical Paper 561, 2011); la NTP 032.103:2024 describe un método para determinar el factor de conversión alimenticia de trucha arcoíris en Perú.</p></div>
        <button class="lotesBtn secondary alt" id="showTutorialAgain" type="button">Ver tutorial otra vez</button>

        <div id="performanceModal" class="lotesOverlay" aria-modal="true" role="dialog" aria-labelledby="performanceTitle">
          <div class="lotesModal performanceModal" id="performancePanel" role="document">
            <button class="lotesClose" id="closePerformanceBtn" aria-label="Cerrar comparación">×</button>
            <div class="lotesModalIcon">📊</div>
            <h3 id="performanceTitle">Rendimiento de lotes</h3>
            <p class="lotesModalSubtitle">Compara el crecimiento y la eficiencia de los lotes registrados.</p>
            <div class="performanceSummary" id="performanceSummary"></div>
            <div class="lotesField performanceSortField"><label for="performanceSort">Ordenar lotes por indicador</label><select class="lotesInput" id="performanceSort"><option value="biomass">Biomasa (mayor primero)</option><option value="survival">Supervivencia (mayor primero)</option><option value="weight">Peso promedio (mayor primero)</option><option value="sgr">Crecimiento específico (mayor primero)</option><option value="fcr">FCR (menor primero)</option></select></div>
            <div id="performanceContent" class="performanceCompareList"></div>
            <p class="performanceCaveat"><b>Cómo leer los indicadores:</b> biomasa estima los kg de pez vivo; supervivencia compara los peces actuales con los iniciales; crecimiento específico (SGR) estima el aumento porcentual de peso por día; y el FCR muestra el alimento usado por unidad de ganancia de biomasa según el último registro guardado. Para comparar FCR, asegúrate de que los lotes compartan periodos y bases de cálculo comparables.</p>
            <p class="performanceSources">Referencias técnicas: <a href="https://www.fao.org/fishery/docs/CDrom/FAO_Training/FAO_Training/General/x6709e/x6709e10.htm" target="_blank" rel="noopener noreferrer">FAO · relación de conversión alimenticia (FCR)</a> · <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC12153620/" target="_blank" rel="noopener noreferrer">Estudio de trucha arcoíris · SGR, FCR y supervivencia</a>.</p>
          </div>
        </div>

        <div id="loteModal" class="lotesOverlay" aria-modal="true" role="dialog" aria-labelledby="lmTitle">
          <div class="lotesModal" id="lotePanel" role="document">
            <button class="lotesClose" id="closeLoteBtn" aria-label="Cerrar">×</button><div class="lotesModalIcon">🐟</div>
            <h3 id="lmTitle">Lote</h3><p id="lmSubtitle" class="lotesModalSubtitle"></p>
            <div class="lotesStatGrid" style="margin:8px 0 12px">
              <div class="lotesStat"><b id="lmFish">0</b><span>Peces</span></div><div class="lotesStat"><b id="lmWeightStat">0,0 g</b><span>Peso prom.</span></div><div class="lotesStat"><b id="lmBiomass">0,0 kg</b><span>Biomasa</span></div><div class="lotesStat"><b id="lmSurvival">0,0%</b><span>Supervivencia</span></div>
            </div>
            <div class="lotesStatGrid detailExtraGrid" style="margin:0 0 12px">
              <div class="lotesStat"><b id="lmLengthStat">— cm</b><span>Talla</span></div><div class="lotesStat"><b id="lmPellet">— mm</b><span>Pellet calibre</span></div><div class="lotesStat"><b id="lmFeedConsumed">— kg</b><span>Alimento consumido</span></div><div class="lotesStat"><b id="lmFcr">—</b><span>FCR</span></div>
            </div>
            <section class="sampleUpdatePanel" aria-label="Nuevo muestreo o actualización de datos">
              <div class="sampleUpdateHeading"><span class="editMark" aria-hidden="true">✎</span><span>Nuevo muestreo / actualizar</span></div>
              <div class="lotesGrid2">
                <div class="lotesField"><label for="lmWeight">Peso promedio (g)</label><input class="lotesInput" id="lmWeight" type="number" min="0.1" step="0.1"></div>
                <div class="lotesField"><label for="lmLength">Talla promedio (cm)</label><input class="lotesInput" id="lmLength" type="number" min="0.1" step="0.1" placeholder="Ej. 15,5"></div>
                <div class="lotesField"><label for="lmMort">Mortalidad de hoy (u.)</label><input class="lotesInput" id="lmMort" type="number" min="0" step="1" value="0"></div>
                <div class="lotesField discardField"><label for="lmDiscard">Descarte (malformaciones)</label><input class="lotesInput" id="lmDiscard" type="number" min="0" step="1" value="0" placeholder="0"></div>
                <div class="lotesField"><label for="lmPelletInput">Pellet calibre (mm)</label><input class="lotesInput" id="lmPelletInput" type="number" min="0.1" step="0.1" placeholder="Ej. 3,0"></div>
                <div class="lotesField"><label for="lmFeedInput">Alimento consumido (kg)</label><input class="lotesInput" id="lmFeedInput" type="number" min="0" step="0.01" placeholder="En este periodo"></div>
              </div>
              <div class="lotesHint" style="margin-top:8px">El descarte se registra por separado de la mortalidad. El alimento ingresado corresponde a este periodo y se suma al acumulado; el FCR se estima cuando existe ganancia positiva de peso.</div>
              <div class="lotesField" style="margin-top:9px"><label for="lmObs">Observaciones sanitarias</label><textarea class="lotesInput" id="lmObs" rows="3" placeholder="Agallas limpias, buen apetito, comportamiento normal…"></textarea></div>
            </section>
            <div class="lotesActions" style="margin-top:12px"><button class="lotesBtn primary" id="saveLoteBtn" type="button">Guardar muestreo</button></div>
            <button class="lotesBtn dangerBtn" style="margin-top:8px" id="deleteLoteBtn" type="button">Eliminar este lote</button>
            <div style="margin-top:12px;text-align:left"><div class="lotesLabel" style="font-size:10px;letter-spacing:.07em;margin-bottom:6px">ÚLTIMOS REGISTROS</div><div id="lmHistory"></div></div>
          </div>
        </div>

        <div id="createModal" class="lotesOverlay createModal" aria-modal="true" role="dialog" aria-labelledby="createTitle">
          <div class="lotesModal" id="createPanel" role="document">
            <button class="lotesClose" id="closeCreateBtn" aria-label="Cerrar">×</button><div class="lotesModalIcon">🐟</div>
            <h3 id="createTitle">Crear nuevo lote</h3><p class="lotesSubhead">Registra los datos iniciales del lote para comenzar su seguimiento productivo.</p>
            <div class="lotesGrid2">
              <div class="lotesField"><label for="crCode">Código del lote</label><input class="lotesInput" id="crCode" placeholder="TR-2026-03" maxlength="48"></div>
              <div class="lotesField"><label for="crStage">Etapa</label><select class="lotesInput" id="crStage"><option>Alevinaje</option><option>Juvenil</option><option>Engorde</option><option>Reproductores</option><option>Ovas</option></select></div>
              <div class="lotesField"><label for="crDate">Fecha de siembra / ingreso</label><input class="lotesInput" id="crDate" type="date"></div>
              <div class="lotesField"><label for="crOrigin">Origen</label><input class="lotesInput" id="crOrigin" placeholder="Centro / proveedor"></div>
              <div class="lotesField"><label for="crUnit">Unidad de cultivo</label><input class="lotesInput" id="crUnit" placeholder="Estanque / jaula / tanque"></div>
              <div class="lotesField"><label for="crFish">Peces iniciales</label><input class="lotesInput" id="crFish" type="number" min="1" step="1" placeholder="10000"></div>
              <div class="lotesField"><label for="crW0">Peso inicial (g)</label><input class="lotesInput" id="crW0" type="number" min="0.1" step="0.1" placeholder="20"></div>
              <div class="lotesField"><label for="crW">Peso actual (g)</label><input class="lotesInput" id="crW" type="number" min="0.1" step="0.1" placeholder="20"></div>
            </div>
            <div id="createModalMsg" class="lotesHint createModalMsg" style="display:none;margin-top:8px"></div>
            <div class="lotesActions" style="margin-top:12px"><button class="lotesBtn primary" id="createLoteBtn" type="button">＋ Crear lote</button></div>
          </div>
        </div>

        <div id="lotesTutorial" class="lotesOverlay" aria-modal="true" role="dialog" aria-labelledby="lotesTutorialTitle">
          <div class="lotesModal lotesTutorialModal" id="lotesTutorialPanel" role="document">
            <button class="lotesClose" id="closeTutorialBtn" aria-label="Cerrar tutorial">×</button>
            <div class="lotesModalIcon">🐟</div>
            <h3 id="lotesTutorialTitle">Aprende a llevar el control de tus lotes</h3>
            <p class="lotesTutorialIntro">Una guía breve para registrar tus datos productivos y entender los indicadores principales.</p>
            <div class="lotesTutorialProgressHeader"><span id="lotesTutorialStepCount">PASO 1 DE 5</span><span>GUÍA DE LOTES</span></div>
            <div class="lotesTutorialTrack" role="progressbar" aria-label="Progreso del tutorial" aria-valuemin="1" aria-valuemax="5" aria-valuenow="1" id="lotesTutorialProgress"><i id="lotesTutorialProgressFill"></i></div>
            <div class="lotesTutorialStepCard">
              <div class="lotesTutorialStepNumber" id="lotesTutorialStepNumber">01</div>
              <div><h4 id="lotesTutorialStepHeading">Conoce el resumen</h4><p id="lotesTutorialStepText">Los indicadores superiores muestran los lotes registrados, los peces que quedan en existencia y la biomasa estimada.</p></div>
            </div>
            <div class="lotesTutorialTip"><b id="lotesTutorialTipHeading">Consejo práctico</b><p id="lotesTutorialTipText">Revisa el resumen después de registrar un lote o guardar un muestreo.</p></div>
            <div class="lotesTutorialDots" id="lotesTutorialDots" aria-label="Pasos del tutorial"></div>
            <div class="lotesTutorialActions"><button class="lotesBtn secondary alt" id="lotesTutorialPrev" type="button" disabled>Anterior</button><button class="lotesBtn primary" id="lotesTutorialNext" type="button">Siguiente →</button></div>
            <small class="lotesTutorialFooter">Puedes cerrar con ×, tocar fuera de la ventana o presionar Escape.</small>
          </div>
        </div>
      </div>`;

    bindEvents();
    renderKpis();
    renderList();
    rendering = false;
    notifySharedDataChanged();
  }
  function bindEvents() {
    $('createLoteTrigger')?.addEventListener('click', openCreateLote);
    $('createLoteBtn')?.addEventListener('click', createLoteFromModal);
    $('closeCreateBtn')?.addEventListener('click', closeCreateLote);
    $('closeLoteBtn')?.addEventListener('click', closeLote);
    $('openPerformanceBtn')?.addEventListener('click', openPerformance);
    $('closePerformanceBtn')?.addEventListener('click', closePerformance);
    $('performanceSort')?.addEventListener('change', renderPerformanceCompare);
    $('saveLoteBtn')?.addEventListener('click', saveLote);
    $('deleteLoteBtn')?.addEventListener('click', deleteLote);
    $('showTutorialAgain')?.addEventListener('click', openTutorial);
    $('lotesSearch')?.addEventListener('input', renderList);
    $('closeTutorialBtn')?.addEventListener('click', closeTutorial);
    $('lotesTutorialPrev')?.addEventListener('click', () => { if (tutorialStepIndex > 0) { tutorialStepIndex--; renderTutorialStep(); } });
    $('lotesTutorialNext')?.addEventListener('click', () => {
      if (tutorialStepIndex < TUTORIAL_STEPS.length - 1) { tutorialStepIndex++; renderTutorialStep(); }
      else closeTutorial();
    });
    $('loteModal')?.addEventListener('click', closeLote);
    $('createModal')?.addEventListener('click', closeCreateLote);
    $('performanceModal')?.addEventListener('click', closePerformance);
    $('lotesTutorial')?.addEventListener('click', closeTutorial);
    ['lotePanel', 'createPanel', 'performancePanel', 'lotesTutorialPanel'].forEach(id => $(id)?.addEventListener('click', ev => ev.stopPropagation()));
  }
  function renderTutorialStep() {
    const step = TUTORIAL_STEPS[tutorialStepIndex];
    if (!step) return;
    const setText = (id, value) => { const el = $(id); if (el) el.textContent = value; };
    setText('lotesTutorialStepCount', `PASO ${tutorialStepIndex + 1} DE ${TUTORIAL_STEPS.length}`);
    setText('lotesTutorialStepNumber', String(tutorialStepIndex + 1).padStart(2, '0'));
    setText('lotesTutorialStepHeading', step.heading);
    setText('lotesTutorialStepText', step.text);
    setText('lotesTutorialTipHeading', step.tipHeading);
    setText('lotesTutorialTipText', step.tipText);
    const fill = $('lotesTutorialProgressFill');
    if (fill) fill.style.width = `${((tutorialStepIndex + 1) / TUTORIAL_STEPS.length) * 100}%`;
    const progress = $('lotesTutorialProgress');
    if (progress) progress.setAttribute('aria-valuenow', String(tutorialStepIndex + 1));
    const prev = $('lotesTutorialPrev');
    if (prev) prev.disabled = tutorialStepIndex === 0;
    const next = $('lotesTutorialNext');
    if (next) next.textContent = tutorialStepIndex === TUTORIAL_STEPS.length - 1 ? 'Entendido, empezar' : 'Siguiente →';
    const dots = $('lotesTutorialDots');
    if (dots) {
      dots.innerHTML = TUTORIAL_STEPS.map((_, i) => `<button type="button" class="lotesTutorialDot${i === tutorialStepIndex ? ' active' : ''}" aria-label="Ir al paso ${i + 1}" aria-current="${i === tutorialStepIndex ? 'step' : 'false'}"></button>`).join('');
      dots.querySelectorAll('button').forEach((dot, i) => dot.addEventListener('click', () => { tutorialStepIndex = i; renderTutorialStep(); }));
    }
  }
  function openTutorial() {
    tutorialStepIndex = 0;
    renderTutorialStep();
    $('lotesTutorial')?.classList.add('open');
  }
  function setupTutorial() {
    const modal = $('lotesTutorial');
    if (!modal || tutorialChecked) return;
    tutorialChecked = true;
    let seen = false;
    try { seen = localStorage.getItem(TUTORIAL_KEY) === '1'; } catch (_) {}
    if (!seen) openTutorial(); else modal.classList.remove('open');
  }
  function closeTutorial() {
    tutorialChecked = true;
    $('lotesTutorial')?.classList.remove('open');
    try { localStorage.setItem(TUTORIAL_KEY, '1'); localStorage.setItem('truchapp_lotes_tutorial_seen_v1', '1'); } catch (_) {}
  }
  function renderKpis() {
    const root = $(rootId); if (!root) return;
    const lots = getLots();
    const count = lots.reduce((sum, lot) => sum + lot.n, 0);
    const bio = lots.reduce((sum, lot) => sum + biomass(lot), 0);
    const lotCount = root.querySelector('#kpiLotes'), fishCount = root.querySelector('#kpiPeces'), bioCount = root.querySelector('#kpiBiomasa');
    if (lotCount) lotCount.textContent = whole(lots.length);
    if (fishCount) fishCount.textContent = whole(count);
    if (bioCount) bioCount.textContent = nfmt(bio, 1) + ' kg';
  }
  function renderList() {
    const box = $('lotesList');
    if (!box) return;
    const lots = getLots();
    const searchValue = ($('lotesSearch')?.value || '').trim().toLocaleLowerCase('es');
    if (!lots.length) {
      box.innerHTML = '<div class="lotesEmpty">Aún no tienes lotes registrados. Pulsa “Crear nuevo lote” para ingresar el primero.</div>';
      return;
    }
    const filteredLots = searchValue ? lots.filter(l => [l.code, l.id, stageLabel(l.stage), l.stage, l.unit, l.origin, l.date].filter(value => value != null).join(' ').toLocaleLowerCase('es').includes(searchValue)) : lots;
    if (!filteredLots.length) {
      box.innerHTML = '<div class="lotesEmpty">No se encontraron lotes con esa búsqueda. Prueba con otro código, etapa, unidad u origen.</div>';
      return;
    }
    box.innerHTML = filteredLots.map(l => {
      const surv = survival(l), bio = biomass(l), target = Number(l.targetWeight) || 210;
      const progress = Math.max(0, Math.min(100, (Number(l.w) || 0) / target * 100));
      const state = health(l);
      return `<div class="lotesLote" data-lote="${escAttr(l.id)}">
        <div class="lotesLoteTop"><div><div class="lotesCode">${esc(l.code)}</div><div class="lotesMeta">${esc(stageLabel(l.stage))} · ingreso ${esc(l.date)} · ${esc(l.unit)}${l.origin && l.origin !== 'Sin indicar' ? ' · ' + esc(l.origin) : ''}</div></div><div class="lotesHealth"><span class="lotesStage">Estado</span><span class="healthLight ${state.level}" title="Estado ${state.label} · Supervivencia ${nfmt(surv)}%" role="img" aria-label="Estado ${state.label}. Supervivencia ${nfmt(surv)} por ciento."></span></div></div>
        <div class="lotesStatGrid"><div class="lotesStat"><b>${whole(l.n)}</b><span>Peces</span></div><div class="lotesStat"><b>${nfmt(l.w)} g</b><span>Peso prom.</span></div><div class="lotesStat"><b>${nfmt(bio)} kg</b><span>Biomasa</span></div><div class="lotesStat"><b>${nfmt(surv)}%</b><span>Supervivencia</span></div></div>
        <div class="lotesProgress"><i style="width:${progress}%"></i></div><div class="lotesNote">Progreso hacia ${whole(target)} g: ${nfmt(progress)}% · Mortalidad: ${whole(l.m)} · Descarte: ${whole(l.discarded)}</div>
        <div class="lotesActions"><button class="lotesBtn secondary openLoteBtn" data-lote-id="${escAttr(l.id)}" type="button">Ver / actualizar lote</button></div>
      </div>`;
    }).join('');
    box.querySelectorAll('.openLoteBtn').forEach(btn => btn.addEventListener('click', () => openLote(btn.dataset.loteId)));
  }
  function openCreateLote() {
    const date = $('crDate'); if (date && !date.value) date.value = today();
    const msg = $('createModalMsg'); if (msg) { msg.style.display = 'none'; msg.textContent = ''; }
    $('createModal')?.classList.add('open');
  }
  function closeCreateLote() { $('createModal')?.classList.remove('open'); }
  function createLoteFromModal() {
    const code = $('crCode').value.trim();
    const stage = $('crStage').value;
    const date = $('crDate').value || today();
    const origin = $('crOrigin').value.trim() || 'Sin indicar';
    const unit = $('crUnit').value.trim() || 'Sin indicar';
    const initialN = Math.max(0, Math.floor(Number($('crFish').value) || 0));
    const initialWeight = Math.max(0, Number($('crW0').value) || 0);
    const weight = Math.max(0, Number($('crW').value) || initialWeight);
    const msg = $('createModalMsg');
    const fail = text => { msg.textContent = text; msg.style.display = 'block'; msg.classList.add('error'); };
    msg.classList.remove('error');
    if (!code || initialN <= 0 || initialWeight <= 0 || weight <= 0) { fail('Completa código, peces iniciales, peso inicial y peso actual con valores válidos.'); return; }
    const lots = getLots();
    if (lots.some(l => l.code.toLowerCase() === code.toLowerCase() || l.id.toLowerCase() === code.toLowerCase())) { fail('Ya existe un lote con ese código.'); return; }
    const lot = normalizeLot({ id: code, code, stage, unit, date, origin, initialN, initialWeight, n: initialN, w: weight, l: null, pelletCalibre: null, alimentoConsumido: null, fcr: null, m: 0, discarded: 0, harvestKg: 0, history: [{ d: date, w: weight, l: null, m: 0, discard: 0, feedKg: null, pelletCalibre: null, fcr: null, x: 'Lote creado' }] });
    persistLots([lot, ...lots]);
    closeCreateLote();
    render();
    const card = Array.from(document.querySelectorAll('.lotesLote')).find(el => el.dataset.lote === lot.id);
    if (card) { card.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); card.classList.add('createdPulse'); setTimeout(() => card.classList.remove('createdPulse'), 1000); }
  }
  function openLote(id) {
    const lot = getLots().find(l => l.id === String(id) || l.code === String(id));
    if (!lot) return;
    activeLoteId = lot.id;
    $('lmTitle').textContent = lot.code + ' · ' + stageLabel(lot.stage);
    $('lmSubtitle').textContent = lot.unit + ' · ingreso ' + lot.date + (lot.origin && lot.origin !== 'Sin indicar' ? ' · origen ' + lot.origin : '');
    $('lmFish').textContent = whole(lot.n);
    $('lmWeightStat').textContent = nfmt(lot.w) + ' g';
    $('lmBiomass').textContent = nfmt(biomass(lot)) + ' kg';
    $('lmSurvival').textContent = nfmt(survival(lot)) + '%';
    $('lmLengthStat').textContent = lot.l == null ? '— cm' : nfmt(lot.l) + ' cm';
    $('lmPellet').textContent = lot.pelletCalibre == null ? '— mm' : nfmt(lot.pelletCalibre) + ' mm';
    $('lmFeedConsumed').textContent = lot.alimentoConsumido == null ? '— kg' : nfmt(lot.alimentoConsumido, 2) + ' kg';
    $('lmFcr').textContent = lot.fcr == null ? '—' : nfmt(lot.fcr, 2);
    $('lmWeight').value = lot.w;
    $('lmLength').value = lot.l == null ? '' : lot.l;
    $('lmMort').value = '0';
    $('lmDiscard').value = '0';
    $('lmPelletInput').value = lot.pelletCalibre == null ? '' : lot.pelletCalibre;
    $('lmFeedInput').value = '';
    $('lmObs').value = '';
    $('lmHistory').innerHTML = (lot.history || []).slice(0, 5).map(h => {
      const details = [];
      if (h.l != null) details.push('talla ' + nfmt(h.l) + ' cm');
      details.push('mortalidad ' + whole(h.m));
      if (Number(h.discard) > 0) details.push('descarte ' + whole(h.discard));
      if (h.feedKg != null) details.push('alimento ' + nfmt(h.feedKg, 2) + ' kg');
      if (h.fcr != null) details.push('FCR ' + nfmt(h.fcr, 2));
      return `<div class="lotesHistoryItem"><b>${esc(h.d)}</b> · ${nfmt(h.w)} g · ${details.join(' · ')}<br><span>${esc(h.x || '')}</span></div>`;
    }).join('') || '<div class="lotesHint">Sin registros.</div>';
    $('loteModal').classList.add('open');
  }
  function closeLote() { $('loteModal')?.classList.remove('open'); activeLoteId = null; }
  function saveLote() {
    if (!activeLoteId) return;
    const lots = getLots();
    const lot = lots.find(item => item.id === activeLoteId);
    if (!lot) return;
    const weightRaw = $('lmWeight').value;
    const weight = weightRaw === '' ? lot.w : Number(weightRaw);
    const lengthRaw = $('lmLength').value;
    const length = lengthRaw === '' ? null : Number(lengthRaw);
    const mortality = Math.max(0, Number($('lmMort').value) || 0);
    const discarded = Math.max(0, Number($('lmDiscard').value) || 0);
    const pelletRaw = $('lmPelletInput').value;
    const pellet = pelletRaw === '' ? null : Number(pelletRaw);
    const feedRaw = $('lmFeedInput').value;
    const feedPeriod = feedRaw === '' ? null : Number(feedRaw);
    if (!Number.isFinite(weight) || weight <= 0) { alert('Ingresa un peso promedio válido mayor que cero.'); return; }
    if (lengthRaw !== '' && (!Number.isFinite(length) || length <= 0)) { alert('Ingresa una talla válida mayor que cero o deja el campo vacío.'); return; }
    if (!Number.isInteger(mortality) || !Number.isInteger(discarded) || mortality < 0 || discarded < 0) { alert('La mortalidad y el descarte deben ser números enteros no negativos.'); return; }
    if (mortality + discarded > lot.n) { alert('La mortalidad y el descarte no pueden superar la cantidad de peces del lote.'); return; }
    if (pelletRaw !== '' && (!Number.isFinite(pellet) || pellet <= 0)) { alert('Ingresa un calibre de pellet válido mayor que cero.'); return; }
    if (feedRaw !== '' && (!Number.isFinite(feedPeriod) || feedPeriod < 0)) { alert('Ingresa una cantidad de alimento válida no negativa.'); return; }

    const previousN = lot.n, previousWeight = lot.w;
    const remainingN = Math.max(0, previousN - mortality - discarded);
    const gainKg = Math.max(0, (weight - previousWeight) * ((previousN + remainingN) / 2) / 1000);
    lot.w = weight;
    if (length !== null) lot.l = length;
    if (pellet !== null) lot.pelletCalibre = pellet;
    lot.n = remainingN;
    lot.m += mortality;
    lot.discarded += discarded;
    let sampleFcr = null;
    if (feedPeriod !== null) {
      lot.alimentoConsumido = (Number(lot.alimentoConsumido) || 0) + feedPeriod;
      if (feedPeriod > 0 && gainKg > 0) { sampleFcr = feedPeriod / gainKg; lot.fcr = sampleFcr; }
    }
    const history = {
      d: today(), w: lot.w, l: lot.l, m: mortality, discard: discarded,
      feedKg: feedPeriod, pelletCalibre: lot.pelletCalibre, fcr: sampleFcr,
      x: $('lmObs').value.trim()
    };
    lot.history.unshift(history);
    persistLots(lots);
    closeLote();
    render();
    if (feedPeriod !== null && feedPeriod > 0 && gainKg <= 0) {
      alert('Muestreo guardado. El FCR no se actualizó porque no se registró ganancia positiva de peso en este periodo.');
    } else {
      alert('Muestreo guardado en la memoria local de TruchApp. Los demás módulos ya pueden consultar este lote.');
    }
  }
  function deleteLote() {
    if (!activeLoteId) return;
    const lot = getLots().find(item => item.id === activeLoteId);
    if (!lot || !confirm('¿Eliminar ' + lot.code + ' y todo su historial? Esta acción no se puede deshacer.')) return;
    persistLots(getLots().filter(item => item.id !== activeLoteId));
    closeLote();
    render();
  }
  function showTutorial() { openTutorial(); }

  window.openLote = openLote;
  window.saveLote = saveLote;
  window.deleteLote = deleteLote;
  window.closeLote = closeLote;
  window.lotesShowTutorial = showTutorial;
  window.lotesOnEnter = setupTutorial;
  window.renderLots = render;
  window.renderLotsForSharedViews = notifySharedDataChanged;

  function init() {
    document.addEventListener('keydown', ev => { if (ev.key !== 'Escape') return; if ($('lotesTutorial')?.classList.contains('open')) closeTutorial(); if ($('performanceModal')?.classList.contains('open')) closePerformance(); });
    render();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

