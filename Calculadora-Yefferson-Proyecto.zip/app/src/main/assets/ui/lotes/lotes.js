/* TruchApp - módulo Lotes de trucha arcoíris.
   Registro local independiente de memoria/IA. Los cálculos son operativos; los
   parámetros productivos deben contrastarse con condiciones reales de la granja. */
(function(){
  const KEY='truchapp_lotes_v1';
  const $=id=>document.getElementById(id);
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const get=()=>{try{return JSON.parse(localStorage.getItem(KEY))||[]}catch{return[]}};
  const set=v=>{try{localStorage.setItem(KEY,JSON.stringify(v))}catch{}};
  const n=v=>{const x=parseFloat(v);return Number.isFinite(x)?x:0};
  const nf=(v,d=0)=>Number(v||0).toLocaleString('es-PE',{minimumFractionDigits:d,maximumFractionDigits:d});
  const today=()=>new Date().toISOString().slice(0,10);
  const biomass=(count,g)=>Math.max(0,n(count))*Math.max(0,n(g))/1000;
  const fishIcon='<svg viewBox="0 0 64 40" aria-hidden="true"><path d="M7 20C14 10 27 7 39 13L57 4 51 20 57 36 39 27C27 33 14 30 7 20Z" fill="currentColor"/><path d="M14 20Q31 15 47 20" stroke="#ffffff" stroke-width="2.5" fill="none" stroke-linecap="round"/><circle cx="17" cy="17" r="2.2" fill="#ffffff"/></svg>';
  let openId=null;

  function render(){
    const root=$('lotesRoot'); if(!root)return;
    const list=get();
    const totalFish=list.reduce((a,x)=>a+n(x.currentCount),0);
    const totalBio=list.reduce((a,x)=>a+biomass(x.currentCount,x.currentWeight),0);
    const active=list.length;
    const harvestReady=list.filter(x=>n(x.currentWeight)>=350).length;
    root.innerHTML=`
      <div class="lotes-wrap">
        <div class="lotes-head"><div><h2>Lotes</h2><p>Seguimiento de cada grupo de trucha arcoíris durante la producción.</p></div><span class="lotes-badge">🐟 Gestión productiva</span></div>
        <div class="card hero"><h3>Controla el ciclo de cada lote</h3><p>Registra siembra, población, biometrías, mortalidad, alimentación, movimientos y cosecha. El historial ayuda a comparar crecimiento, supervivencia y manejo.</p></div>
        <div class="lotes-stats">
          <div class="card lotes-stat"><div class="icon">🐟</div><b>${active}</b><span>Lotes registrados</span></div>
          <div class="card lotes-stat"><div class="icon">🧮</div><b>${nf(totalFish)}</b><span>Peces actuales estimados</span></div>
          <div class="card lotes-stat"><div class="icon">⚖️</div><b>${nf(totalBio,1)} kg</b><span>Biomasa actual estimada</span></div>
          <div class="card lotes-stat"><div class="icon">🎣</div><b>${harvestReady}</b><span>Con peso ≥350 g</span></div>
        </div>
        <div class="card"><div class="label">Acciones rápidas</div><div class="lotes-actions">
          <button class="lotes-action" id="newLoteBtn"><span class="fish">${fishIcon}</span><span><b>Nuevo lote</b><small>Registrar una nueva siembra</small></span></button>
          <button class="lotes-action" id="infoLoteBtn"><span>📋</span><span><b>Qué registrar</b><small>Ficha de manejo y control</small></span></button>
        </div></div>
        <div class="card"><div class="row"><div class="label" style="margin:0">Mis lotes</div><span class="hint">${active} registrado${active===1?'':'s'}</span></div><div class="list" id="loteList">
          ${list.length?list.map(renderItem).join(''):'<div class="empty">Todavía no hay lotes. Crea el primero para empezar el seguimiento.</div>'}
        </div></div>
        <div class="card"><p class="lote-note"><b>Buenas prácticas de gestión:</b> FAO señala que los registros de origen, fecha y cantidad sembrada, tamaño inicial, mortalidad, muestreos de crecimiento, alimentación, supervivencia y cosecha permiten estimar crecimiento, conversión, costos y capacidad de carga; también recomienda realizar muestreos periódicos y clasificar por tamaños cuando la densidad lo requiera.</p><div class="lote-source">Referencia aplicada en este módulo: FAO, <i>Oncorhynchus mykiss</i> y manual de registros de alimentación/gestión de granja. Las frecuencias y valores concretos deben adaptarse a la etapa y condiciones reales del cultivo.</div></div>
        ${modalHtml()}
      </div>`;
    $('newLoteBtn').onclick=()=>openForm();
    $('infoLoteBtn').onclick=()=>openInfo();
    root.querySelectorAll('[data-open-lote]').forEach(b=>b.onclick=()=>openDetail(b.dataset.openLote));
    root.querySelectorAll('[data-delete-lote]').forEach(b=>b.onclick=()=>deleteLote(b.dataset.deleteLote));
  }

  function renderItem(x){
    const surv=x.initialCount>0?Math.max(0,Math.min(100,(x.currentCount/x.initialCount)*100)):0;
    const bio=biomass(x.currentCount,x.currentWeight);
    const gain=x.currentWeight>0&&x.initialWeight>0?x.currentWeight-x.initialWeight:0;
    return `<div class="lote-item">
      <div class="lote-top"><span class="lote-code">${esc(x.code)}</span><span class="lote-stage">${esc(x.stage||'Sin etapa')}</span></div>
      <div class="lote-meta">Siembra: ${esc(x.stockDate||'—')} · Origen: ${esc(x.source||'—')} · Unidad: ${esc(x.unit||'—')}</div>
      <div class="lote-grid">
        <div class="lote-kpi"><b>${nf(x.currentCount)}</b><span>Peces</span></div>
        <div class="lote-kpi"><b>${nf(x.currentWeight,1)} g</b><span>Peso prom.</span></div>
        <div class="lote-kpi"><b>${nf(bio,1)} kg</b><span>Biomasa</span></div>
        <div class="lote-kpi"><b>${nf(surv,1)}%</b><span>Supervivencia*</span></div>
      </div>
      <div class="lote-progress"><i style="width:${Math.max(0,Math.min(100,x.currentWeight>0?x.currentWeight/350*100:0))}%"></i></div>
      <div class="row" style="margin-top:7px;align-items:center"><span class="hint">${gain>0?'Ganancia de peso: '+nf(gain,1)+' g':'Peso inicial registrado: '+nf(x.initialWeight,1)+' g'}</span><button class="mini secondary" data-open-lote="${esc(x.id)}">Abrir lote</button></div>
    </div>`;
  }

  function modalHtml(){return `
    <div class="lote-modal" id="loteModal" hidden onclick="if(event.target===this)window.closeLoteModal()"><div class="lote-panel" id="lotePanel"></div></div>`}

  function openModal(html){const m=$('loteModal');$('lotePanel').innerHTML=html;m.hidden=false}
  function closeModal(){const m=$('loteModal');if(m)m.hidden=true;openId=null}
  window.closeLoteModal=closeModal;

  function openForm(){
    openModal(`<div class="row"><h2 style="font-size:20px;margin:0">Nuevo lote</h2><button class="x" id="closeLm">✕</button></div>
      <p class="hint" style="margin:3px 0 10px">Registra la información inicial del grupo para poder seguir su evolución.</p>
      <div class="lotes-form">
        <div class="lotes-field"><label>Código del lote</label><input class="lotes-input" id="lcCode" placeholder="Ej.: L-2026-01"></div>
        <div class="lotes-field"><label>Etapa</label><select class="lotes-input" id="lcStage"><option>Alevinaje</option><option>Juvenil</option><option>Engorde</option><option>Reproductores</option></select></div>
        <div class="lotes-field"><label>Fecha de siembra</label><input class="lotes-input" id="lcDate" type="date" value="${today()}"></div>
        <div class="lotes-field"><label>Unidad / estanque / jaula</label><input class="lotes-input" id="lcUnit" placeholder="Ej.: Jaula 5"></div>
        <div class="lotes-field"><label>Origen de los peces</label><input class="lotes-input" id="lcSource" placeholder="Ej.: Centro de alevines"></div>
        <div class="lotes-field"><label>N° peces sembrados</label><input class="lotes-input" id="lcCount" type="number" min="0" step="1" placeholder="Ej.: 5000"></div>
        <div class="lotes-field"><label>Peso promedio inicial (g)</label><input class="lotes-input" id="lcWeight" type="number" min="0" step="0.1" placeholder="Ej.: 20"></div>
        <div class="lotes-field full"><label>Observación inicial</label><textarea class="lotes-input" id="lcNote" rows="2" placeholder="Calidad del agua, traslado, estado de los peces…"></textarea></div>
      </div>
      <button class="primary" id="saveLote" style="width:100%;margin-top:12px">Guardar lote</button>`);
    $('closeLm').onclick=closeModal;$('saveLote').onclick=saveLote;
  }

  function saveLote(){
    const code=$('lcCode').value.trim()||('L-'+today().replaceAll('-','-')+'-'+(get().length+1));
    const count=Math.max(0,Math.floor(n($('lcCount').value))), weight=Math.max(0,n($('lcWeight').value));
    if(!(count>0&&weight>0)){alert('Ingresa la cantidad sembrada y el peso promedio inicial.');return}
    const list=get();list.unshift({id:String(Date.now()),code,stage:$('lcStage').value,stockDate:$('lcDate').value||today(),unit:$('lcUnit').value.trim(),source:$('lcSource').value.trim(),initialCount:count,currentCount:count,initialWeight:weight,currentWeight:weight,note:$('lcNote').value.trim(),mortality:0,feedKg:0,history:[{date:$('lcDate').value||today(),type:'Siembra',detail:`${count} peces · ${weight} g promedio`}]});set(list);closeModal();render();
  }

  function openDetail(id){
    const x=get().find(a=>a.id===id);if(!x)return;openId=id;
    openModal(`<div class="row"><h2 style="font-size:20px;margin:0">${esc(x.code)}</h2><button class="x" id="closeLm">✕</button></div>
      <div class="lote-meta">${esc(x.stage||'')} · ${esc(x.unit||'Sin unidad')} · siembra ${esc(x.stockDate||'—')}</div>
      <div class="lote-grid" style="margin-top:12px"><div class="lote-kpi"><b>${nf(x.currentCount)}</b><span>Peces actuales</span></div><div class="lote-kpi"><b>${nf(x.currentWeight,1)} g</b><span>Peso prom.</span></div><div class="lote-kpi"><b>${nf(biomass(x.currentCount,x.currentWeight),1)} kg</b><span>Biomasa</span></div><div class="lote-kpi"><b>${nf(x.mortality)}</b><span>Bajas acumuladas</span></div></div>
      <div class="card" style="margin-top:12px"><div class="label">Registrar seguimiento</div><div class="lotes-form">
        <div class="lotes-field"><label>Peso promedio actual (g)</label><input class="lotes-input" id="ldWeight" type="number" min="0" step="0.1" value="${x.currentWeight}"></div>
        <div class="lotes-field"><label>Mortalidad desde último registro</label><input class="lotes-input" id="ldMort" type="number" min="0" step="1" value="0"></div>
        <div class="lotes-field"><label>Alimento registrado (kg)</label><input class="lotes-input" id="ldFeed" type="number" min="0" step="0.01" value="0"></div>
        <div class="lotes-field"><label>Fecha</label><input class="lotes-input" id="ldDate" type="date" value="${today()}"></div>
        <div class="lotes-field full"><label>Observación / calidad de agua / manejo</label><textarea class="lotes-input" id="ldNote" rows="2" placeholder="Temperatura, oxígeno, clasificación, traslado, apetito…"></textarea></div>
      </div><button class="primary" id="saveFollow" style="width:100%;margin-top:10px">Guardar seguimiento</button></div>
      <div class="card"><div class="label">Historial reciente</div><div class="lote-log">${(x.history||[]).slice().reverse().slice(0,10).map(h=>`<div class="lote-log-row"><b>${esc(h.date)}</b> · ${esc(h.type)}<br><span class="hint">${esc(h.detail)}</span></div>`).join('')||'<div class="empty">Sin registros.</div>'}</div></div>
      <div class="lote-tools"><button class="secondary" id="saveAsRecord">📊 Guardar también en registros técnicos</button><button class="mini danger" id="deleteFromDetail">Eliminar lote</button></div>
      <p class="lote-note" style="margin-top:10px">* Supervivencia estimada = peces actuales ÷ peces sembrados × 100. Es una estimación operativa basada en los conteos registrados.</p>`);
    $('closeLm').onclick=closeModal;$('saveFollow').onclick=saveFollow;$('deleteFromDetail').onclick=()=>deleteLote(id);$('saveAsRecord').onclick=()=>saveAsTechnicalRecord(id);
  }

  function saveFollow(){
    const list=get(),x=list.find(a=>a.id===openId);if(!x)return;
    const w=Math.max(0,n($('ldWeight').value)),mort=Math.max(0,Math.floor(n($('ldMort').value))),feed=Math.max(0,n($('ldFeed').value));
    const date=$('ldDate').value||today(),note=$('ldNote').value.trim();
    x.currentWeight=w||x.currentWeight;x.currentCount=Math.max(0,x.currentCount-mort);x.mortality+=mort;x.feedKg+=feed;
    x.history=x.history||[];x.history.push({date,type:'Seguimiento',detail:`${x.currentCount} peces · ${x.currentWeight} g · bajas ${mort}${feed?' · alimento '+nf(feed,2)+' kg':''}${note?' · '+note:''}`});set(list);
    openDetail(openId);
  }

  function deleteLote(id){
    const x=get().find(a=>a.id===id);if(!x)return;if(!confirm('¿Eliminar el lote '+x.code+' y su historial?'))return;set(get().filter(a=>a.id!==id));closeModal();render();
  }

  function saveAsTechnicalRecord(id){
    const x=get().find(a=>a.id===id);if(!x)return;
    try{const list=JSON.parse(localStorage.getItem('records'))||[];list.push({date:today(),type:'Lote '+x.code,value:String(x.currentWeight),unit:'g',note:`${x.currentCount} peces · biomasa ${nf(biomass(x.currentCount,x.currentWeight),2)} kg`});localStorage.setItem('records',JSON.stringify(list));alert('Registro técnico guardado.');}catch{alert('No se pudo guardar el registro técnico.')}}

  function openInfo(){openModal(`<div class="row"><h2 style="font-size:20px;margin:0">Ficha de gestión del lote</h2><button class="x" id="closeLm">✕</button></div><div class="card"><div class="label">Datos de identidad</div><p class="lote-note">Código, origen, fecha de siembra y unidad de cultivo. Son claves para rastrear cada grupo durante el ciclo.</p></div><div class="card"><div class="label">Producción</div><p class="lote-note">Cantidad sembrada, peso promedio, biomasa estimada, mortalidad, supervivencia y muestreos de crecimiento.</p></div><div class="card"><div class="label">Alimentación y agua</div><p class="lote-note">Registra alimento usado y las condiciones que ayuden a interpretar el consumo y crecimiento: temperatura, oxígeno, pH y observaciones.</p></div><div class="card"><div class="label">Manejo</div><p class="lote-note">Anota clasificaciones, traslados, cambios de unidad, incidentes y cosechas. FAO destaca que los registros permiten aprender del ciclo y planificar mejor el siguiente.</p></div><p class="lote-source">La estructura de esta ficha se inspira en los tipos de registros productivos descritos por FAO para existencias, mortalidad, tamaño, alimentación, crecimiento, supervivencia y cosecha. Los campos no sustituyen los protocolos específicos de tu granja.</p>`);$('closeLm').onclick=closeModal;}

  window.renderLotes=render;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',render);else render();
})();
