/* Consulta de alimentación del lote: sin escrituras ni reservas de stock. */
(function(root,factory){const F=typeof module==='object'&&module.exports?require('../../feeding/feeding-data.js'):root.TruchAppFeedingData;const api=factory(F);if(typeof module==='object'&&module.exports)module.exports=api;else root.TruchAppLotFeedingData=api;})(typeof window==='object'?window:globalThis,function(F){
 'use strict';
 const finite=v=>typeof v==='number'&&Number.isFinite(v),EPS=1e-6;
 const validDate=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&!Number.isNaN(Date.parse(d+'T12:00:00Z'))&&new Date(d+'T12:00:00Z').toISOString().slice(0,10)===d;
 const shift=(date,n)=>{const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);};
 const days=(a,b)=>(Date.parse(b+'T12:00:00Z')-Date.parse(a+'T12:00:00Z'))/86400000;
 const expirySort=(a,b)=>(a.expiry||'9999-12-31').localeCompare(b.expiry||'9999-12-31')||String(a.firstDate||'').localeCompare(String(b.firstDate||''))||a.batch.localeCompare(b.batch);
 const SOURCES=[
  {name:'PRODUCE / SINACUI · Cultivo de trucha (2022), alimentación',url:'https://rnia.produce.gob.pe/wp-content/uploads/2022/08/Manual-de-Trucha.pdf'},
  {name:'FAO · Feeding rate, frequency and biomass assessment, sección 8',url:'https://www.fao.org/4/s4314e/s4314e09.htm'},
  {name:'FONDEPES · Crianza de trucha en ambientes convencionales, almacenamiento',url:'https://rnia.produce.gob.pe/wp-content/uploads/2019/09/Manual-de-Crianza-de-Trucha-en-Ambientes-Convencionales.pdf'}
 ];
 // Escenario de consumo constante desde mañana; primero vence, primero se usa.
 // Todos los saldos están disponibles hoy. No anticipa compras ni crecimiento.
 function projection(batches,dailyKg,start){
  if(!finite(dailyKg)||dailyKg<=0)return null;
  let covered=0,discardedKg=0;
  for(const batch of batches.slice().sort(expirySort)){
   if(batch.expiry&&!validDate(batch.expiry))throw new Error('Revisa las fechas de vencimiento del alimento en Almacén.');
   const limit=batch.expiry?Math.max(0,days(start,batch.expiry)+1):Infinity;
   const usableDays=Math.min(batch.kg/dailyKg,Math.max(0,limit-covered));
   covered+=usableDays;discardedKg+=Math.max(0,batch.kg-usableDays*dailyKg);
  }
  const fullDays=Math.floor(covered+EPS);
  return{days:covered,fullDays,partialKg:Math.max(0,(covered-fullDays)*dailyKg),discardedKg,start};
 }
 function product(item,movements,today,planKg){
  const factor=F.unitKg(item),balances=F.batchBalances(movements,item.id,today),negative=balances.some(b=>b.qty< -EPS),positive=balances.filter(b=>b.qty>EPS).map(b=>({...b,kg:b.qty*factor}));
  if(positive.some(b=>b.expiry&&!validDate(b.expiry)))throw new Error('Revisa las fechas de vencimiento del alimento en Almacén.');
  const usable=positive.filter(b=>!b.expiry||b.expiry>=today).sort(expirySort),expired=positive.filter(b=>b.expiry&&b.expiry<today),start=shift(today,-6);
  const first=movements.filter(m=>String(m.itemId)===String(item.id)&&m.date<=today).map(m=>m.date).sort()[0],begin=first&&first>start?first:start,windowDays=Math.max(1,days(begin,today)+1);
  const outgoing=movements.filter(m=>String(m.itemId)===String(item.id)&&m.date>=begin&&m.date<=today&&['salida','ajuste-'].includes(m.type)).reduce((sum,m)=>sum+(m.source==='feeding'&&finite(m.feedKg)?m.feedKg:Number(m.qty||0)*factor),0),average=outgoing/windowDays;
  const usableKg=negative?null:usable.reduce((sum,b)=>sum+b.kg,0),next=shift(today,1);
  return{id:String(item.id),name:String(item.name||item.code||item.id),code:String(item.code||''),unit:item.unit,factor,negative,usableKg,batches:usable,expiredKg:expired.reduce((sum,b)=>sum+b.kg,0),unknownExpiryKg:usable.filter(b=>!b.expiry).reduce((sum,b)=>sum+b.kg,0),soonKg:usable.filter(b=>b.expiry&&b.expiry<=shift(today,7)).reduce((sum,b)=>sum+b.kg,0),average,windowDays,outgoing,coverage:negative?null:projection(usable,planKg,next),globalCoverage:negative||average<=EPS?null:projection(usable,average,next)};
 }
 function build({state,stock,plan,today,selectedId}){
  const planKg=finite(plan?.kg)&&plan.kg>=0?plan.kg:null,daily=Array.isArray(state.daily)?state.daily:[],actual=daily.find(r=>r.date===today),delivered=finite(actual?.feed)?actual.feed:null;
  const recent=Array.from({length:7},(_,i)=>{const date=shift(today,i-6),row=daily.find(r=>r.date===date);return{date,kg:finite(row?.feed)?row.feed:null,linked:!!row?.feedStock?.lines?.length,record:row||null};});
  let error=stock?.error||'',products=[],invalidUnits=0;
  if(!error){try{
   if(!stock||!Array.isArray(stock.items)||!Array.isArray(stock.movements))throw new Error('No se pudo consultar el almacén.');
   invalidUnits=stock.items.filter(i=>i.active!==false&&i.category==='Alimento balanceado'&&F.unitKg(i)===null).length;
   products=stock.items.filter(i=>i.active!==false&&F.feedItem(i)).map(i=>product(i,stock.movements,today,planKg)).sort((a,b)=>a.name.localeCompare(b.name));
  }catch(e){error=e.message||'No se pudo consultar el almacén.';products=[];}}
  let chosen=selectedId;
  if(chosen===undefined){const last=daily.filter(r=>r.date<=today).slice().sort((a,b)=>b.date.localeCompare(a.date)).flatMap(r=>r.feedStock?.lines||[]).find(l=>products.some(p=>p.id===String(l.itemId)));chosen=last?String(last.itemId):products.length===1?products[0].id:null;}
  const selected=products.find(p=>p.id===chosen)||null,known=recent.filter(r=>r.kg!==null);
  return{planKg,planReason:plan?.reason||'Plan sin definir',mode:plan?.mode||null,delivered,pending:planKg===null||delivered===null?null:Math.max(0,planKg-delivered),excess:planKg===null||delivered===null?null:Math.max(0,delivered-planKg),products,selected,error,invalidUnits,recent,recordedDays:known.length,weekKg:known.length?known.reduce((sum,r)=>sum+r.kg,0):null};
 }
 return{build,projection,SOURCES,shift};
});
