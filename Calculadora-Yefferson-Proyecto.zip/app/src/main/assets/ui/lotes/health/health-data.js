/* Sanidad por lote: observaciones y seguimiento; no emite diagnósticos. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TruchAppHealthData=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const copy=v=>JSON.parse(JSON.stringify(v));
 const TYPES={observation:'Observación',prevention:'Bioseguridad',sample:'Muestreo / laboratorio',followup:'Seguimiento'};
 const VERDICTS={unassessed:'Sin diagnóstico',suspected:'Sospecha registrada',confirmed:'Confirmado por laboratorio'};
 const ROUTES={unknown:'Por evaluar',horizontal:'Posible horizontal',vertical:'Posible vertical',both:'Ambas por evaluar'};
 const SIGNS={none:'Sin signos visibles',appetite:'Menor apetito',lethargy:'Poca actividad',surface:'Boqueo / superficie',swimming:'Nado anormal',darkening:'Oscurecimiento',lesions:'Lesiones externas',gills:'Cambios en branquias',eyes:'Cambios en ojos',abdomen:'Abdomen aumentado'};
 const SOURCES=[
  {id:'sanipes',name:'SANIPES · Virus de la necrosis pancreática infecciosa',url:'https://www.sanipes.gob.pe/vnpi/',checked:'2026-10-22'},
  {id:'woah',name:'WOAH · Manual acuático, infección por IHNV, capítulo 2.3.5',url:'https://www.woah.org/fileadmin/Home/eng/Health_standards/aahm/current/2.3.05_IHN.pdf',checked:'2026-10-22'},
  {id:'usgs',name:'USGS · Fish Health Program: bacterial kidney disease',url:'https://www.usgs.gov/labs/fish-health-program/science/bacterial-kidney-disease-bkd-fhp',checked:'2026-10-22'},
  {id:'produce',name:'PRODUCE / SINACUI · Manual para una acuicultura sostenible: cultivo de trucha (2022), sección 8.2',url:'https://rnia.produce.gob.pe/wp-content/uploads/2022/08/Manual-de-Trucha.pdf',checked:'2026-10-22'},
  {id:'fao',name:'FAO · Small-scale rainbow trout farming, Technical Paper 561 (2011), sección 9.5',url:'https://www.fao.org/4/i2125e/i2125e.pdf',checked:'2026-10-22'}
 ];
 const DISEASES=[
  {id:'ipn',name:'Necrosis pancreática infecciosa · IPN/VNPI',routes:'Horizontal y vertical',text:'SANIPES describe el contagio por agua contaminada y la transmisión de progenitores a descendencia mediante ovas y esperma. Los adultos pueden portar el virus. La presencia del agente requiere evaluación y pruebas; estos ejemplos no indican que exista en tu lote.',source:'sanipes'},
  {id:'bkd',name:'Enfermedad bacteriana del riñón · BKD',routes:'Horizontal y vertical',text:'Renibacterium salmoninarum puede pasar entre peces que comparten un sistema de agua y a la siguiente generación mediante ovas infectadas. Un registro de signos no identifica esta bacteria ni demuestra la vía de transmisión.',source:'usgs'},
  {id:'ihn',name:'Necrosis hematopoyética infecciosa · IHN',routes:'Principalmente horizontal',text:'WOAH describe transmisión principalmente horizontal y evidencia insuficiente para demostrar verdadera transmisión vertical. La contaminación de la superficie de las ovas no equivale a infección dentro de ellas.',source:'woah'}
 ];
 const validDate=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&!Number.isNaN(Date.parse(d+'T12:00:00Z'))&&new Date(d+'T12:00:00Z').toISOString().slice(0,10)===d;
 const validTime=t=>typeof t==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(t);
 function today(){const d=new Date();return[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');}
 function normalize(raw){
  if(raw===undefined)return{version:1,records:[]};
  if(!raw||raw.version!==1||!Array.isArray(raw.records))throw new Error('No se pudo leer Sanidad. Los registros originales se conservan.');
  return copy(raw);
 }
 function validate(raw,context={}){
  if(raw===undefined)return raw;
  if(!raw||raw.version!==1||!Array.isArray(raw.records))throw new Error('Formato de Sanidad no compatible.');
  const ids=new Set(),now=context.today||today();
  for(const r of raw.records){
   if(!r||typeof r!=='object'||Array.isArray(r)||typeof r.id!=='string'||!r.id||r.id.length>100||ids.has(r.id))throw new Error('Registro sanitario inválido o duplicado.');
   ids.add(r.id);
   if(!validDate(r.date)||r.date>now||context.start&&r.date<context.start||!validTime(r.time))throw new Error('Revisa la fecha y hora del registro sanitario.');
   if(!Object.hasOwn(TYPES,r.type)||!Object.hasOwn(VERDICTS,r.verdict)||!Object.hasOwn(ROUTES,r.route)||typeof r.closed!=='boolean')throw new Error('Revisa el tipo y estado del registro sanitario.');
   if(!Array.isArray(r.signs)||new Set(r.signs).size!==r.signs.length||r.signs.some(s=>!Object.hasOwn(SIGNS,s))||r.signs.includes('none')&&r.signs.length>1)throw new Error('Revisa los signos observados.');
   if(r.affected!==null&&(!Number.isInteger(r.affected)||r.affected<0||Number.isFinite(context.initialN)&&r.affected>context.initialN)||r.signs.includes('none')&&r.affected>0)throw new Error('Revisa la cantidad de peces observados con signos.');
   for(const [key,max]of [['point',120],['description',2000],['actions',2000],['disease',160],['labRef',200],['professional',120],['origin',500]]){
    if(typeof r[key]!=='string'||r[key].length>max)throw new Error('Revisa el campo sanitario: '+key+'.');
   }
   if(!r.description.trim())throw new Error('Describe lo observado o la medida realizada.');
   if(r.verdict==='confirmed'&&(!r.disease.trim()||!r.labRef.trim()))throw new Error('Para registrar confirmación por laboratorio, indica el diagnóstico y la referencia del resultado.');
   if(r.reviewDate!==null&&(!validDate(r.reviewDate)||r.reviewDate<r.date))throw new Error('La próxima revisión debe ser igual o posterior al registro.');
  }
  return raw;
 }
 function summary(raw,day=today()){
  const records=normalize(raw).records,open=records.filter(r=>!r.closed),due=open.filter(r=>r.reviewDate&&r.reviewDate<=day);
  const sorted=records.slice().sort((a,b)=>(b.date+'T'+b.time).localeCompare(a.date+'T'+a.time));
  return{total:records.length,open:open.length,due:due.length,closed:records.length-open.length,last:sorted[0]||null};
 }
 function list(raw,options={}){
  const q=String(options.query||'').trim().toLocaleLowerCase('es'),filter=options.filter||'all';
  return normalize(raw).records.filter(r=>(filter==='all'||filter==='open'&&!r.closed||filter==='closed'&&r.closed||filter==='due'&&!r.closed&&r.reviewDate&&r.reviewDate<=(options.today||today()))&&(!q||[r.description,r.actions,r.disease,r.point,r.professional,r.labRef,r.origin,...r.signs.map(s=>SIGNS[s])].join(' ').toLocaleLowerCase('es').includes(q))).sort((a,b)=>(b.date+'T'+b.time).localeCompare(a.date+'T'+a.time));
 }
 function record(values,previous){
  const now=new Date().toISOString();
  return{...(previous||{}),id:previous?.id||'SAN-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9),date:values.date,time:values.time,type:values.type,point:String(values.point||'').trim(),signs:[...values.signs],affected:values.affected,description:String(values.description||'').trim(),actions:String(values.actions||'').trim(),verdict:values.verdict,disease:String(values.disease||'').trim(),labRef:String(values.labRef||'').trim(),professional:String(values.professional||'').trim(),origin:String(values.origin||'').trim(),route:values.route,reviewDate:values.reviewDate||null,closed:!!values.closed,createdAt:previous?.createdAt||now,updatedAt:now};
 }
 function upsert(raw,r,context){validate({version:1,records:[r]},context);const next=normalize(raw),index=next.records.findIndex(v=>v.id===r.id);if(index<0)next.records.push(copy(r));else next.records[index]=copy(r);validate(next,context);return next;}
 function remove(raw,id){const next=normalize(raw);next.records=next.records.filter(r=>r.id!==id);return next;}
 return{TYPES,VERDICTS,ROUTES,SIGNS,SOURCES,DISEASES,normalize,validate,summary,list,record,upsert,remove,today,validDate};
});
