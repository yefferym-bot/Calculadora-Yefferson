/* El mismo bloque entra en configuración; el borrador no escribe producción. */
(function(){
 'use strict';
 const Cards=window.TruchAppListCards;
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const svg=p=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+p+'</svg>';
 const check=svg('<path d="m5 12 4 4L19 6"/>'),cross=svg('<path d="m6 6 12 12M18 6 6 18"/>');
 const left=svg('<path d="m14 6-6 6 6 6"/>'),right=svg('<path d="m10 6 6 6-6 6"/>');
 const motion=window.matchMedia('(prefers-reduced-motion: reduce)');
 const reduce=()=>motion.matches||!!document.querySelector('.phone.tn-menu-reduced');
 const ease='cubic-bezier(.22,1,.36,1)';
 let session=null;
 const same=(a,b)=>a.length===b.length&&a.every((id,i)=>id===b[i]);
 function animate(s,el,frames,options){
  if(reduce()||!el?.animate)return Promise.resolve();
  const animation=el.animate(frames,{duration:260,easing:ease,...options});s.motion.add(animation);
  return animation.finished.catch(()=>{}).finally(()=>{if(!['both','forwards'].includes(options?.fill))s.motion.delete(animation);});
 }
 function cancelMotion(s){for(const a of s.motion)a.cancel();s.motion.clear();}
 function setMessage(text,error=false){if(!session)return;const p=session.workspace.querySelector('#lc-message');p.textContent=text;p.classList.toggle('is-error',error);}
 function freezeBackground(workspace){
  const saved=[];let node=workspace;
  while(node.parentElement){for(const other of node.parentElement.children)if(other!==node&&!['SCRIPT','STYLE','LINK'].includes(other.tagName)){saved.push([other,other.inert]);other.inert=true;}if(node.parentElement===document.body)break;node=node.parentElement;}
  return saved;
 }
 const rects=s=>new Map([...s.grid.querySelectorAll('[data-selected-id]')].map(el=>[el.dataset.selectedId,el.getBoundingClientRect()]));
 function drawSlots(animateChange=false){
  const s=session,before=animateChange?rects(s):new Map();
  s.grid.innerHTML=s.draft.length?s.draft.map((id,index)=>{const m=s.metrics[id];return`<div class="lotesStat lc-slot${s.active===index?' is-active':''}" data-selected-id="${id}"><button type="button" class="lc-pick" data-pick="${index}" aria-pressed="${s.active===index}" aria-label="Ordenar ${esc(m.label)}, posición ${index+1}"><b>${esc(m.value)}</b><span>${esc(m.short)}</span></button><button type="button" class="lc-remove" data-remove="${index}" aria-label="Quitar ${esc(m.label)}"><span aria-hidden="true">${svg('<path d="M5 12h14"/>')}</span></button></div>`;}).join(''):'<p class="lc-empty">Elige al menos un indicador de la lista.</p>';
  if(animateChange)for(const el of s.grid.querySelectorAll('[data-selected-id]')){
   const old=before.get(el.dataset.selectedId),now=el.getBoundingClientRect();
   if(old)animate(s,el,[{transform:`translate(${old.left-now.left}px,${old.top-now.top}px)`},{transform:'translate(0,0)'}]);
   else animate(s,el,[{opacity:0,transform:'translateY(8px) scale(.97)'},{opacity:1,transform:'translateY(0) scale(1)'}]);
  }
  paintControls();
 }
 function paintControls(){
  const s=session;s.workspace.querySelector('#lc-count').textContent=s.draft.length+' / '+Cards.limit;
  for(const option of s.workspace.querySelectorAll('[data-add]')){
   const chosen=s.draft.includes(option.dataset.add);option.classList.toggle('is-chosen',chosen);option.disabled=s.busy||chosen;
   option.setAttribute('aria-pressed',String(chosen));option.setAttribute('aria-label',(chosen?'Seleccionada: ':'Añadir ')+Cards.byId[option.dataset.add].label);
   option.querySelector('.lc-add').innerHTML=chosen?check:'+';
  }
  s.order.hidden=s.active===null||!s.draft[s.active];
  s.order.querySelector('#lc-position').textContent=s.active===null?'':'Posición '+(s.active+1)+' · ordenar';
  s.order.querySelector('#lc-earlier').disabled=s.busy||s.active===null||s.active===0;
  s.order.querySelector('#lc-later').disabled=s.busy||s.active===null||s.active>=s.draft.length-1;
  s.workspace.querySelector('#lc-save').disabled=s.busy||!Cards.valid(s.draft);
  s.workspace.querySelector('#lc-cancel').disabled=s.busy;s.workspace.querySelector('#lc-close').disabled=s.busy;
  s.workspace.querySelectorAll('[data-pick],[data-remove]').forEach(b=>b.disabled=s.busy);
 }
 function note(id,s){
  const summary=s.summary,ind=s.indicators;
  const format=n=>Number(n).toLocaleString('es-PE',{maximumFractionDigits:2});
  const date=value=>value?new Date(value+'T12:00:00').toLocaleDateString('es-PE',{day:'2-digit',month:'2-digit',year:'numeric'}):'Sin registro';
  return({fish:'Mortalidad: '+format(summary.mortality)+' · Descarte: '+format(summary.discard),consumed:s.metrics.consumed.raw===null?'Sin registro':'Total registrado',feed:s.metrics.feed.raw===null?'Sin cálculo':'Ración planificada',survival:'Respecto al ingreso',growth:date(summary.last?.date),length:date(ind.lengthSample?.date),biomass:ind.density===null?'Definir volumen':format(ind.density)+' kg/m³',condition:ind.condition===null?'Requiere peso y talla':'Mismo control',sgr:ind.sgr===null?'Añadir biometría':'Crecimiento por día',cv:ind.cv===null?'Requiere pesos individuales':'Variación de la muestra',fcr:summary.fcr===null?'Sin período completo':'Conversión del período',efficiency:ind.efficiency===null?'Sin cálculo':'Eficiencia del período',density:ind.density===null?'Definir volumen':'Biomasa / volumen'})[id]||'';
 }
 function catalog(s){
  return ['Situación actual','Biometría','Indicadores'].map(group=>'<h4>'+group+'</h4><div class="lc-options">'+Cards.catalog.filter(c=>c.group===group).map(c=>`<button type="button" class="lc-option" data-add="${c.id}"><span class="lc-option-label">${esc(c.label)}</span><b>${esc(s.metrics[c.id].value)}</b><small>${esc(note(c.id,s))}</small><span class="lc-add" aria-hidden="true">+</span></button>`).join('')+'</div>').join('');
 }
 function focusPick(index){session?.grid.querySelector('[data-pick="'+index+'"]')?.focus({preventScroll:true});}
 function add(id){
  const s=session;if(!s||s.busy||s.closing||!Cards.byId[id]||s.draft.includes(id))return;
  if(s.draft.length>=Cards.limit){setMessage('Puedes mostrar hasta ocho indicadores. Quita uno con − para añadir otro.');return;}
  s.draft.push(id);s.active=null;drawSlots(true);setMessage(Cards.byId[id].label+' añadido. '+s.draft.length+' de ocho.');
 }
 function move(delta){
  const s=session;if(!s||s.busy||s.closing||s.active===null)return;
  const from=s.active,to=from+delta;if(to<0||to>=s.draft.length)return;
  [s.draft[from],s.draft[to]]=[s.draft[to],s.draft[from]];s.active=to;drawSlots(true);focusPick(to);setMessage('Indicador movido a la posición '+(to+1)+'.');
 }
 function restore(s,saved){
  cancelMotion(s);
  s.grid.replaceChildren(...s.originalGrid);s.actions.replaceChildren(...s.originalActions);s.order.remove();s.card.classList.remove('lc-active-card');
  s.buttons.forEach(([b,disabled])=>{b.disabled=disabled;});s.opener.setAttribute('aria-expanded','false');
  if(s.placeholder.isConnected)s.placeholder.replaceWith(s.card);
  s.workspace.remove();s.inert.forEach(([el,value])=>{el.inert=value;});
  s.scroll.style.overflow=s.overflow;s.scroll.scrollTop=s.scrollTop;
  session=null;const opener=s.afterClose?.(saved)||s.opener;if(opener?.isConnected)opener.focus({preventScroll:true});
 }
 async function close(saved=false){
  const s=session;if(!s||s.busy||s.closing)return;s.closing=true;
  const from=s.card.getBoundingClientRect();cancelMotion(s);
  const base=s.card.getBoundingClientRect(),target=s.placeholder.getBoundingClientRect();
  s.workspace.classList.add('lc-closing');s.workspace.inert=true;
  const initial=`translate(${from.left-base.left}px,${from.top-base.top}px) scale(${from.width/base.width},${from.height/base.height})`;
  const final=`translate(${target.left-base.left}px,${target.top-base.top}px) scale(${target.width/base.width},${saved?1:target.height/base.height})`;
  await Promise.all([animate(s,s.card,[{transform:initial},{transform:final}],{duration:220,fill:'forwards'}),animate(s,s.available,[{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(8px)'}],{duration:160,fill:'forwards'})]);
  if(session===s)restore(s,saved);
 }
 async function save(){
  const s=session;if(!s||s.busy||s.closing||!Cards.valid(s.draft))return;
  if(same(s.initial,s.draft)){close(false);return;}
  s.busy=true;s.workspace.setAttribute('aria-busy','true');paintControls();
  s.workspace.querySelector('#lc-save span').textContent='Guardando…';setMessage('Guardando el diseño…');
  try{await s.save(s.id,s.draft.slice());s.busy=false;close(true);}
  catch(error){s.busy=false;paintControls();setMessage(error.message||'No se pudo guardar. Inténtalo otra vez.',true);s.workspace.querySelector('#lc-save span').textContent='Guardar diseño';s.workspace.querySelector('#lc-message').focus({preventScroll:true});}
  finally{s.workspace.removeAttribute('aria-busy');}
 }
 function open(options){
  if(session||!options.card?.isConnected)return;
  const data=options.read(options.id);if(!data)return;
  const card=options.card,origin=card.getBoundingClientRect(),module=card.closest('.lotesModule'),scroll=document.querySelector('.phone>.content');
  if(!module||!scroll)return;
  const placeholder=document.createElement('div');placeholder.className='lc-placeholder';placeholder.style.height=origin.height+'px';placeholder.setAttribute('aria-hidden','true');card.before(placeholder);
  const workspace=document.createElement('div');workspace.id='lotCardsEditor';workspace.className='lc-workspace';workspace.setAttribute('role','dialog');workspace.setAttribute('aria-modal','true');workspace.setAttribute('aria-label','Configurar indicadores de '+data.lot.code);
  const navigation=document.getElementById('bottomNav');workspace.style.setProperty('--lc-nav-height',(navigation?.getBoundingClientRect().height||79)+'px');
  workspace.innerHTML=`<div class="lc-backdrop" aria-hidden="true"></div><div class="lc-stage"><div class="lc-focus-slot"></div><section class="lc-available" aria-labelledby="lc-title"><div class="lc-heading"><h2 id="lc-title">Indicadores del lote</h2><span id="lc-count" aria-live="polite"></span><button type="button" class="lc-close" id="lc-close" aria-label="Cancelar configuración">${cross}</button></div><p class="lc-intro">Toca + para elegir qué datos mostrar</p><div id="lc-catalog"></div></section><p id="lc-message" class="lc-message" role="status" aria-live="polite" tabindex="-1"></p></div>`;
  const grid=card.querySelector('[data-custom-cards]'),actions=card.querySelector('.lotesActions');
  const summary=window.TruchAppLotSummary.summary(data.detail);
  const s={...options,data,summary,indicators:window.TruchAppLotIndicators.calculate(data.detail,summary),workspace,card,placeholder,grid,actions,originalGrid:[...grid.childNodes],originalActions:[...actions.childNodes],buttons:[...card.querySelectorAll('.lotesHealth button')].map(b=>[b,b.disabled]),scroll,scrollTop:scroll.scrollTop,overflow:scroll.style.overflow,initial:Cards.selection(data.lot),draft:Cards.selection(data.lot),metrics:Cards.metrics(data.detail),active:null,busy:false,closing:false,motion:new Set()};session=s;
  module.append(workspace);workspace.querySelector('.lc-focus-slot').append(card);card.classList.add('lc-active-card');
  const order=document.createElement('div');order.className='lc-order';order.hidden=true;order.innerHTML=`<span id="lc-position"></span><div><button type="button" id="lc-earlier" aria-label="Mover indicador una posición antes">${left}</button><button type="button" id="lc-later" aria-label="Mover indicador una posición después">${right}</button></div>`;grid.after(order);s.order=order;
  actions.innerHTML=`<button type="button" class="lc-cancel" id="lc-cancel">Cancelar</button><button type="button" class="lc-save" id="lc-save">${check}<span>Guardar diseño</span></button>`;
  s.buttons.forEach(([b])=>{b.disabled=true;});options.opener.setAttribute('aria-expanded','true');
  s.available=workspace.querySelector('.lc-available');workspace.querySelector('#lc-catalog').innerHTML=catalog(s);drawSlots();
  s.inert=freezeBackground(workspace);scroll.style.overflow='hidden';
  workspace.addEventListener('click',event=>{
   if(s!==session||s.closing)return;
   const remove=event.target.closest('[data-remove]'),pick=event.target.closest('[data-pick]'),option=event.target.closest('[data-add]');
   if(remove&&!s.busy){const index=Number(remove.dataset.remove),id=s.draft[index];if(!id)return;s.draft.splice(index,1);s.active=null;drawSlots(true);setMessage(Cards.byId[id].label+' quitado del diseño.');if(s.draft.length)focusPick(Math.min(index,s.draft.length-1));else s.workspace.querySelector('[data-add]:not([disabled])')?.focus({preventScroll:true});}
   else if(pick&&!s.busy){s.active=Number(pick.dataset.pick);drawSlots();focusPick(s.active);}
   else if(option)add(option.dataset.add);
   else if(event.target.closest('#lc-cancel,#lc-close'))close(false);
   else if(event.target.closest('#lc-save'))save();
   else if(event.target.closest('#lc-earlier'))move(-1);
   else if(event.target.closest('#lc-later'))move(1);
  });
  workspace.classList.add('is-open');
  const final=card.getBoundingClientRect();
  workspace.inert=true;
  const entry=animate(s,card,[{transform:`translate(${origin.left-final.left}px,${origin.top-final.top}px) scale(${origin.width/final.width},${origin.height/final.height})`},{transform:'translate(0,0) scale(1)'}],{duration:360});
  const appearance=animate(s,s.available,[{opacity:0,transform:'translateY(14px)'},{opacity:1,transform:'translateY(0)'}],{duration:300,delay:90,fill:'both'});
  Promise.all([entry,appearance]).then(()=>{if(session===s&&!s.closing){workspace.inert=false;focusPick(0);}});
 }
 document.addEventListener('keydown',event=>{
  const s=session;if(!s)return;
  if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();close(false);return;}
  if(event.key!=='Tab')return;
  const nodes=[...s.workspace.querySelectorAll('button:not([disabled]),[tabindex="0"]')].filter(el=>el.getClientRects().length),first=nodes[0],last=nodes.at(-1);
  if(!first){event.preventDefault();return;}
  const outsideOrder=!nodes.includes(document.activeElement);
  if(event.shiftKey&&(document.activeElement===first||outsideOrder)){event.preventDefault();last.focus();}
  else if(!event.shiftKey&&(document.activeElement===last||outsideOrder)){event.preventDefault();first.focus();}
 },true);
 motion.addEventListener?.('change',()=>{if(session&&reduce())cancelMotion(session);});
 window.TruchAppListCardsEditor={open,close:()=>close(false),get isOpen(){return!!session;}};
})();
