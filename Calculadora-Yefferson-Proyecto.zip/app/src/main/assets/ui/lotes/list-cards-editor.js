(function(){
 'use strict';
 const Cards=window.TruchAppListCards;
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const icon=(path)=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+path+'</svg>';
 const closeIcon=icon('<path d="m6 6 12 12M18 6 6 18"/>');
 const leftIcon=icon('<path d="m14 6-6 6 6 6"/>'),rightIcon=icon('<path d="m10 6 6 6-6 6"/>');
 const checkIcon=icon('<path d="m5 12 4 4L19 6"/>');
 let dialog=null,session=null,closing=false;
 function ensure(){
  if(dialog)return;
  dialog=document.createElement('dialog');dialog.id='lotCardsEditor';dialog.className='lc-editor';
  dialog.setAttribute('aria-labelledby','lc-title');dialog.setAttribute('aria-describedby','lc-intro');
  dialog.innerHTML=`<div class="lc-handle" aria-hidden="true"></div>
   <header class="lc-head"><div><p class="lc-eyebrow" id="lc-lot"></p><h2 id="lc-title">Editar y ordenar</h2></div><button type="button" class="lc-icon lc-close" data-close aria-label="Cancelar edición">${closeIcon}</button></header>
   <div class="lc-scroll"><section class="lc-selected" aria-labelledby="lc-selected-title">
    <div class="lc-section-heading"><h3 id="lc-selected-title">Tus cuatro tarjetas</h3><span id="lc-count"></span></div>
    <p class="lc-intro" id="lc-intro">Toca una posición y elige qué mostrar abajo.</p>
    <div class="lc-slots" id="lc-slots"></div>
    <div class="lc-order"><span id="lc-position"></span><div><button type="button" class="lc-icon" id="lc-earlier" aria-label="Mover tarjeta una posición antes">${leftIcon}</button><button type="button" class="lc-icon" id="lc-later" aria-label="Mover tarjeta una posición después">${rightIcon}</button></div></div>
   </section><section class="lc-available" aria-labelledby="lc-available-title"><div class="lc-section-heading"><h3 id="lc-available-title">Tarjetas disponibles</h3><button type="button" class="lc-reset" id="lc-reset">Restablecer</button></div><div id="lc-catalog"></div></section></div>
   <p class="lc-message" id="lc-message" role="status" aria-live="polite"></p>
   <footer class="lc-footer"><button type="button" class="lc-cancel" data-close>Cancelar</button><button type="button" class="lc-save" id="lc-save">${checkIcon}<span>Guardar cambios</span></button></footer>`;
  document.body.append(dialog);
  dialog.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',close));
  dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
  dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)close();}});
  dialog.addEventListener('close',()=>{const opener=session?.opener;session=null;closing=false;dialog.classList.remove('lc-closing');opener?.focus({preventScroll:true});});
  dialog.querySelector('#lc-slots').addEventListener('click',event=>{
   const button=event.target.closest('button');if(!button||!session||session.busy)return;
   const index=Number(button.dataset.index);if(!Number.isInteger(index))return;
   session.active=index;
   if(button.dataset.action==='remove'){session.draft[index]=null;draw('Posición '+(index+1)+' vacía. Elige una tarjeta.');focusSlot(index);}
   else{draw();focusSlot(index);}
  });
  dialog.querySelector('#lc-catalog').addEventListener('click',event=>{
   const button=event.target.closest('[data-add]');if(!button||!session||session.busy||button.disabled)return;
   const id=button.dataset.add,index=session.active;
   if(!Cards.byId[id]||session.draft.includes(id))return;
   session.draft[index]=id;const empty=session.draft.indexOf(null);if(empty!==-1)session.active=empty;
   draw(Cards.byId[id].label+' en la posición '+(index+1)+'.');focusSlot(session.active);pulse(index);
  });
  dialog.querySelector('#lc-earlier').addEventListener('click',()=>move(-1));
  dialog.querySelector('#lc-later').addEventListener('click',()=>move(1));
  dialog.querySelector('#lc-reset').addEventListener('click',()=>{if(!session||session.busy)return;session.draft=Cards.defaults.slice();session.active=0;draw('Diseño original preparado. Pulsa Guardar cambios para aplicarlo.');focusSlot(0);});
  dialog.querySelector('#lc-save').addEventListener('click',save);
 }
 function focusSlot(index){dialog.querySelector('.lc-pick[data-index="'+index+'"]').focus({preventScroll:true});}
 function pulse(index){if(!window.matchMedia('(prefers-reduced-motion: reduce)').matches)dialog.querySelector('.lc-slot[data-index="'+index+'"]').animate([{transform:'scale(.96)',opacity:.65},{transform:'scale(1)',opacity:1}],{duration:220,easing:'cubic-bezier(.2,0,0,1)'});}
 function draw(message=''){
  const s=session,metrics=s.metrics,count=s.draft.filter(Boolean).length;
  dialog.querySelector('#lc-count').textContent=count+' / 4';
  dialog.querySelector('#lc-position').textContent='Posición '+(s.active+1)+' · cambiar u ordenar';
  dialog.querySelector('#lc-slots').innerHTML=s.draft.map((id,index)=>{
   const card=id?metrics[id]:null;
   return `<article class="lc-slot${s.active===index?' is-active':''}${!card?' is-empty':''}" data-index="${index}"><button type="button" class="lc-pick" data-index="${index}" aria-pressed="${s.active===index}" aria-label="Posición ${index+1}: ${esc(card?.label||'vacía')}. Elegir para reemplazar"><span class="lc-number">${index+1}</span><strong>${esc(card?.value||'+')}</strong><span class="lc-slot-label">${esc(card?.short||'Elegir tarjeta')}</span></button>${card?`<button type="button" class="lc-remove" data-action="remove" data-index="${index}" aria-label="Quitar ${esc(card.label)} de la posición ${index+1}"><span aria-hidden="true">−</span></button>`:''}</article>`;
  }).join('');
  dialog.querySelector('#lc-catalog').innerHTML=['Situación actual','Biometría','Indicadores'].map(group=>`<h4>${group}</h4><div class="lc-options">`+Cards.catalog.filter(c=>c.group===group).map(c=>{
   const selected=s.draft.includes(c.id),m=metrics[c.id];
   return `<button type="button" class="lc-option${selected?' is-chosen':''}" data-add="${c.id}" ${selected?'disabled':''} aria-label="${selected?'Ya seleccionada: ':'Mostrar en posición '+(s.active+1)+': '}${esc(c.label)}"><span class="lc-option-text"><b>${esc(m.value)}</b><span>${esc(c.label)}</span></span><span class="lc-add" aria-hidden="true">${selected?checkIcon:'+'}</span></button>`;
  }).join('')+'</div>').join('');
  dialog.querySelector('#lc-earlier').disabled=s.active===0||!s.draft[s.active];
  dialog.querySelector('#lc-later').disabled=s.active===3||!s.draft[s.active];
  dialog.querySelector('#lc-save').disabled=!Cards.valid(s.draft);
  dialog.querySelector('#lc-message').textContent=message;
 }
 function move(delta){
  if(!session||session.busy)return;const from=session.active,to=from+delta;
  if(to<0||to>3||!session.draft[from])return;
  [session.draft[from],session.draft[to]]=[session.draft[to],session.draft[from]];session.active=to;
  draw('Tarjeta movida a la posición '+(to+1)+'.');focusSlot(to);pulse(to);
 }
 function close(){
  if(!session||session.busy||closing)return;closing=true;
  if(window.matchMedia('(prefers-reduced-motion: reduce)').matches){dialog.close();return;}
  dialog.classList.add('lc-closing');setTimeout(()=>{if(dialog.open)dialog.close();},150);
 }
 async function save(){
  if(!session||session.busy||!Cards.valid(session.draft))return;
  const current=session;current.busy=true;dialog.setAttribute('aria-busy','true');
  dialog.querySelectorAll('button').forEach(b=>b.disabled=true);
  dialog.querySelector('#lc-save span').textContent='Guardando…';
  dialog.querySelector('#lc-message').textContent='Guardando tus tarjetas…';
  try{current.opener=await current.save(current.id,current.draft.slice())||current.opener;current.busy=false;dialog.close();}
  catch(error){current.busy=false;draw(error.message||'No se pudo guardar. Inténtalo otra vez.');dialog.querySelectorAll('[data-close],#lc-reset').forEach(b=>b.disabled=false);dialog.querySelector('#lc-save span').textContent='Guardar cambios';dialog.querySelector('#lc-save').focus({preventScroll:true});}
  finally{dialog.removeAttribute('aria-busy');}
 }
 function open(options){
  ensure();if(dialog.open||closing)return;
  const data=options.read(options.id);if(!data)return;
  session={...options,draft:Cards.selection(data.lot),metrics:Cards.metrics(data.detail),active:0,busy:false};
  dialog.querySelector('#lc-lot').textContent=data.lot.code;
  dialog.querySelector('#lc-save span').textContent='Guardar cambios';
  dialog.querySelectorAll('[data-close],#lc-reset').forEach(b=>b.disabled=false);
  draw();dialog.showModal();focusSlot(0);
 }
 window.TruchAppListCardsEditor={open,close,get isOpen(){return!!dialog?.open;}};
})();
