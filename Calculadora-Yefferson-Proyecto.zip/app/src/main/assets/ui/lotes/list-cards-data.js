/* Presentation preferences only. Production calculations stay in the detail modules. */
(function(root,factory){
 'use strict';
 const api=factory(root?root.TruchAppLotSummary:require('./detail/summary-data.js'),root?root.TruchAppLotIndicators:require('./detail/summary-indicators.js'));
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.TruchAppListCards=api;
})(typeof window==='object'?window:null,function(Summary,Indicators){
 'use strict';
 const defaults=Object.freeze(['fish','growth','biomass','survival']);
 const catalog=Object.freeze([
  {id:'fish',label:'Peces vivos',short:'Peces',group:'Situación actual',digits:0,unit:''},
  {id:'consumed',label:'Alimento total consumido',short:'Alimento consumido',group:'Situación actual',digits:2,unit:'kg'},
  {id:'feed',label:'Alimentación para hoy',short:'Alimentación hoy',group:'Situación actual',digits:2,unit:'kg'},
  {id:'survival',label:'Supervivencia',short:'Supervivencia',group:'Situación actual',digits:1,unit:'%'},
  {id:'growth',label:'Peso promedio (g)',short:'Peso prom.',group:'Biometría',digits:2,unit:'g'},
  {id:'length',label:'Talla promedio (cm)',short:'Talla prom.',group:'Biometría',digits:2,unit:'cm'},
  {id:'biomass',label:'Biomasa',short:'Biomasa',group:'Biometría',digits:2,unit:'kg'},
  {id:'condition',label:'Factor de Condición (K)',short:'Condición (K)',group:'Indicadores',digits:2,unit:''},
  {id:'sgr',label:'TCE / SGR',short:'TCE / SGR',group:'Indicadores',digits:2,unit:'%'},
  {id:'cv',label:'Coeficiente de Variación (CV)',short:'Variación (CV)',group:'Indicadores',digits:1,unit:'%'},
  {id:'fcr',label:'Conversión FCR',short:'Conversión FCR',group:'Indicadores',digits:2,unit:''},
  {id:'efficiency',label:'Tasa de Eficiencia Alimenticia (TEA)',short:'Eficiencia (TEA)',group:'Indicadores',digits:1,unit:'%'},
  {id:'density',label:'Densidad de Carga (kg/m³)',short:'Densidad',group:'Indicadores',digits:2,unit:'kg/m³'}
 ].map(Object.freeze));
 const byId=Object.freeze(Object.fromEntries(catalog.map(c=>[c.id,c])));
 const valid=ids=>Array.isArray(ids)&&ids.length===4&&ids.every(id=>typeof id==='string'&&Object.hasOwn(byId,id))&&new Set(ids).size===4;
 function selection(lot){return valid(lot?.listCards)?lot.listCards.slice():defaults.slice();}
 function updateLots(lots,id,ids){
  if(!valid(ids))throw new Error('Elige cuatro tarjetas diferentes antes de guardar.');
  if(!lots.some(l=>String(l.id)===String(id)))throw new Error('Este lote ya no está disponible. Cierra el editor y revisa la lista.');
  return lots.map(l=>String(l.id)===String(id)?{...l,listCards:ids.slice()}:l);
 }
 function metrics(data){
  const s=Summary.summary(data),m=Indicators.calculate(data,s),plan=Summary.feedingPlan(data,s);
  const raw={fish:s.fish,consumed:s.feedKnown?s.food:null,feed:plan.kg,survival:s.survival,
   growth:s.weight,length:m.lengthSample?.length??null,biomass:s.biomass,condition:m.condition,
   sgr:m.sgr,cv:m.cv,fcr:s.fcr,efficiency:m.efficiency,density:m.density};
  return Object.fromEntries(catalog.map(c=>{
   const value=typeof raw[c.id]==='number'&&Number.isFinite(raw[c.id])?raw[c.id]:null;
   const text=value===null?'—':value.toLocaleString('es-PE',{maximumFractionDigits:c.digits});
   return[c.id,{...c,raw:value,value:text+(c.unit?(c.unit==='%'?'':' ')+c.unit:'')}];
  }));
 }
 return{defaults,catalog,byId,valid,selection,updateLots,metrics};
});
