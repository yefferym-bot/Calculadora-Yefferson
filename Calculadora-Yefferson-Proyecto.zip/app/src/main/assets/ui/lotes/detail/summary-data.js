/* Read-only calculations shared by detail and list cards. */
(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.TruchAppLotSummary=api;})(typeof window==='object'?window:null,function(){
'use strict';
const finite=v=>typeof v==='number'&&Number.isFinite(v);
const dateNow=()=>{const d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,10);};
const addDays=(date,n)=>{const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);};
const dayOffset=n=>addDays(dateNow(),n);
const daySpan=(a,b)=>(Date.parse(b+'T12:00:00Z')-Date.parse(a+'T12:00:00Z'))/86400000;
const stamp=r=>`${r.date}T${r.time||'00:00'}`;
const sortAsc=rows=>rows.slice().sort((a,b)=>stamp(a).localeCompare(stamp(b)));
const shortDate=d=>new Date(d+'T12:00:00').toLocaleDateString('es-PE',{day:'numeric',month:'short'});
const legacyRows=data=>[...data.samples.filter(r=>r.legacyPeriod),...(data.openingBalance?[data.openingBalance]:[])];
const latestWater=(data,param)=>sortAsc(data.water.filter(r=>r.lotId===data.lot.id&&r.param===param)).at(-1)||null;
const waterAge=r=>r?(Date.now()-new Date(stamp(r)).getTime())/3600000:Infinity;
const waterFresh=(data,r)=>!!r&&waterAge(r)>=0&&waterAge(r)<=data.settings.waterFreshHours;

function fishAt(data,date=dateNow()){
 const old=legacyRows(data).filter(r=>r.date<=date),daily=data.daily.filter(r=>r.date<=date);
 return data.lot.initialN-(data.openingBalance&&data.openingBalance.date<=date?(Number(data.openingBalance.stockAdjustment)||0):0)-[...old,...daily].reduce((n,r)=>n+Number(r.mortality||0)+Number(r.discard||0),0);
}
function periodData(data,previous,last){
 const days=daySpan(previous.date,last.date),startFish=fishAt(data,previous.date),endFish=fishAt(data,last.date);
 const startBiomass=startFish*previous.weight/1000,endBiomass=endFish*last.weight/1000,gain=endBiomass-startBiomass;
 const rows=data.daily.filter(r=>r.date>previous.date&&r.date<=last.date),covered=new Set(rows.filter(r=>finite(r.feed)).map(r=>r.date)).size;
 const legacy=last.legacyPeriod&&finite(last.feed),feed=legacy?last.feed:rows.reduce((n,r)=>n+(finite(r.feed)?r.feed:0),0);
 const lossDays=legacy?days:new Set(rows.filter(r=>finite(r.mortality)&&finite(r.discard)).map(r=>r.date)).size;
 const feedComplete=legacy||covered===days,stockComplete=legacy||lossDays===days,complete=days>0&&feedComplete&&stockComplete,fcr=complete&&gain>0?feed/gain:null;
 return{previous,last,days,startFish,endFish,startBiomass,endBiomass,gain,feed,covered:legacy?days:covered,lossDays,feedComplete,stockComplete,complete,legacy,fcr};
}
function summary(data){
 const samples=sortAsc(data.samples),last=samples.at(-1),prev=samples.at(-2),fish=fishAt(data),lossRows=[...legacyRows(data),...data.daily];
 const mortality=lossRows.reduce((n,r)=>n+Number(r.mortality||0),0),discard=lossRows.reduce((n,r)=>n+Number(r.discard||0),0);
 const knownFeed=[...legacyRows(data),...data.daily].filter(r=>finite(r.feed)),food=knownFeed.reduce((n,r)=>n+r.feed,0);
 const latestValue=key=>samples.slice().reverse().find(r=>finite(r[key]))?.[key]??null;
 const periods=samples.slice(1).map((r,i)=>periodData(data,samples[i],r)),period=periods.at(-1)||null;
 const days=prev?daySpan(prev.date,last.date):0,growth=prev&&days>0?(last.weight-prev.weight)/days:null;
 const today=data.daily.find(r=>r.date===dateNow())||null,week=data.daily.filter(r=>r.date>=dayOffset(-6)&&r.date<=dateNow());
 return{fish,mortality,discard,food,feedKnown:knownFeed.length>0,weight:last.weight,biomass:fish*last.weight/1000,survival:fish/data.lot.initialN*100,last,prev,samples,periods,period,fcr:period?.fcr??null,growth,biometryAge:daySpan(last.date,dateNow()),length:latestValue('length'),pellet:latestValue('pellet'),today,week,weekMortality:week.filter(r=>finite(r.mortality)).reduce((n,r)=>n+r.mortality,0),weekMortalityDays:week.filter(r=>finite(r.mortality)).length,density:finite(data.settings.volume)&&data.settings.volume>0?fish*last.weight/1000/data.settings.volume:null};
}
function waterIssues(data){const issues=[],o=latestWater(data,'oxygen'),t=latestWater(data,'temperature'),cfg=data.settings;
 if(o&&finite(cfg.oxygenMin)&&o.value<cfg.oxygenMin)issues.push('Oxígeno por debajo de tu referencia');
 if(t&&((finite(cfg.tempMin)&&t.value<cfg.tempMin)||(finite(cfg.tempMax)&&t.value>cfg.tempMax)))issues.push('Temperatura fuera de tu referencia');
 return issues;
}
function feedingPlan(data,s=summary(data)){
 const p=data.settings.feedPlan;if(!p)return{kg:null,reason:'Plan sin definir',mode:null};
 if(p.mode==='manual')return{kg:p.kg,reason:'Ración manual · '+shortDate(p.updated),mode:'manual'};
 const t=latestWater(data,'temperature'),o=latestWater(data,'oxygen');let reason='';
 if(s.biometryAge>data.settings.biometryDays)reason='Actualizar biometría';
 else if(s.weight<p.weightMin||s.weight>p.weightMax)reason='Peso fuera de la fila de la tabla';
 else if(!waterFresh(data,t)||!waterFresh(data,o))reason='Medir temperatura y oxígeno recientes';
 else if(!finite(o.value)||o.value<=0)reason='Revisar la medición de oxígeno';
 else if(t.value<p.tempMin||t.value>p.tempMax)reason='Temperatura fuera de la fila';
 else if(waterIssues(data).length)reason='Revisar las condiciones del agua';
 else if(s.today?.appetite==='bajo')reason='Revisar apetito antes de usar la tabla';
 return{kg:reason?null:s.biomass*p.rate/100,reason:reason||'Orientativa según tu tabla',mode:'table'};
}
return{summary,feedingPlan};
});
