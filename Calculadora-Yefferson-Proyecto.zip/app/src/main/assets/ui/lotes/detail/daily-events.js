/* Registros por momento; los totales diarios conservan la interfaz de los cálculos. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TruchAppDailyEvents=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const copy=v=>JSON.parse(JSON.stringify(v)),finite=v=>typeof v==='number'&&Number.isFinite(v),round=n=>Math.round(n*1e9)/1e9;
 const order=rows=>rows.slice().sort((a,b)=>String(a.time).localeCompare(String(b.time))||String(a.id).localeCompare(String(b.id)));
 function entries(day){
  if(!day)return[];
  if(day.entriesVersion===1)return copy(day.entries||[]);
  const r=copy(day);delete r.entries;delete r.entriesVersion;
  return[{...r,kind:'dailyTotal'}];
 }
 function aggregate(day,rows){
  const list=order(copy(rows)),result={...copy(day),entriesVersion:1,entries:list};
  for(const key of ['feed','mortality','discard']){const known=list.filter(r=>finite(r[key]));result[key]=known.length?round(known.reduce((n,r)=>n+r[key],0)):null;}
  result.time=list.at(-1)?.time||day.time||'00:00';
  result.appetite=list.filter(r=>r.appetite).at(-1)?.appetite||'';result.note=list.filter(r=>r.note).at(-1)?.note||'';
  result.waterParams=list.filter(r=>Array.isArray(r.waterParams)).at(-1)?.waterParams||day.waterParams;
  delete result.waterReadingIds;delete result.feedStock;
  const linked=list.filter(r=>r.feedStock);
  if(linked.length)result.feedStock={version:1,lines:linked.flatMap(r=>copy(r.feedStock.lines||[]))};
  return result;
 }
 function validateDay(day){
  if(day.entriesVersion===undefined)return;
  if(day.entriesVersion!==1||!Array.isArray(day.entries)||!day.entries.length||day.entries.length>500)throw Error('El día debe tener entre 1 y 500 registros.');
  const ids=new Set();
  for(const e of day.entries){
   if(typeof e.id!=='string'||!e.id||ids.has(e.id)||!['moment','dailyTotal'].includes(e.kind)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(e.time)||e.date!==day.date||e.simulated)throw Error('Registro por hora no válido o duplicado.');ids.add(e.id);
   if(e.feed!==null&&(!finite(e.feed)||e.feed<0)||[e.mortality,e.discard].some(v=>v!==null&&(!Number.isSafeInteger(v)||v<0)))throw Error('Revisa alimento y bajas de cada registro.');
   if(typeof e.note!=='string'||e.note.length>1000||typeof e.appetite!=='string'||!['','normal','bajo','alto','sin_observar'].includes(e.appetite))throw Error('Revisa el apetito y las observaciones del registro.');
   if(e.feedStock){const lines=e.feedStock.lines,total=Array.isArray(lines)?lines.reduce((n,l)=>n+(finite(l.kg)?l.kg:NaN),0):NaN;if(e.feedStock.version!==1||!finite(total)||!finite(e.feed)||Math.abs(total-e.feed)>1e-6)throw Error('El alimento vinculado no coincide con su registro de origen.');}
  }
  const expected=aggregate(day,day.entries);
  for(const key of ['feed','mortality','discard','time','appetite','note'])if(day[key]!==expected[key])throw Error('El total del día no coincide con sus registros.');
  if(JSON.stringify(day.feedStock)!==JSON.stringify(expected.feedStock))throw Error('Las entregas vinculadas no coinciden con sus registros.');
 }
 function update(data,date,entry,waterRows=[],removeId=null,newDayId=''){
  const result=copy(data),old=result.daily.find(r=>r.date===date),oldEntries=entries(old),id=removeId||entry.id,previous=oldEntries.find(r=>r.id===id);
  if(removeId&&!previous)throw Error('Ese registro ya no está disponible. Vuelve a abrir el día.');
  let list=oldEntries.filter(r=>r.id!==id);if(!removeId)list.push(copy(entry));
  result.daily=result.daily.filter(r=>r.date!==date);
  let day=null;
  if(list.length){day=aggregate(old||{id:newDayId,date},list);validateDay(day);result.daily.push(day);}
  const owned=new Set(Object.values(previous?.waterReadingIds||{}));
  result.water=result.water.filter(r=>!owned.has(String(r.sourceReadingId||r.id))).concat(copy(waterRows));
  if(entry?.waterParams)result.dailyWaterParams=copy(entry.waterParams);
  return{state:result,day,previous};
 }
 return{entries,aggregate,validateDay,update,order};
});
