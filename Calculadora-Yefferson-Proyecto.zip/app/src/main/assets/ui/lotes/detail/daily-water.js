/* Mediciones del registro diario: mismo historial de agua, sin ceros implícitos. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TruchAppDailyWater=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const DEFAULTS=['temperature','oxygen','ph','tan'];
 const source=r=>String(r.sourceReadingId||r.id);
 const copy=v=>JSON.parse(JSON.stringify(v));
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function references(data,checkRows=false){
  const refs=new Map(),bySource=new Map();
  if(checkRows)for(const row of data.water||[]){const id=source(row);if(!bySource.has(id))bySource.set(id,[]);bySource.get(id).push(row);}
  for(const day of data.daily||[]){
   if(day.waterReadingIds===undefined)continue;
   if(!day.waterReadingIds||Array.isArray(day.waterReadingIds)||typeof day.waterReadingIds!=='object'||Object.keys(day.waterReadingIds).length>60)throw Error('Revisa las mediciones del registro diario.');
   for(const [param,id]of Object.entries(day.waterReadingIds)){
    if(!/^[a-zA-Z][a-zA-Z0-9]*$/.test(param)||typeof id!=='string'||!id||id.length>250||refs.has(id))throw Error('La medición diaria está duplicada o no es válida.');
    if(checkRows){const rows=bySource.get(id)||[];if(rows.length!==1||rows[0].param!==param||rows[0].date!==day.date||rows[0].time!==day.time||String(rows[0].lotId)!==String(data.lot.id))throw Error('La medición no coincide con la fecha y el lote del registro diario.');}
    refs.set(id,{param,date:day.date,dayId:day.id});
   }
  }
  return refs;
 }
 function reconcileShared(records,current,next,lot){
  const before=references(current),after=references(next,true),rows=new Map((next.water||[]).map(r=>[source(r),r]));
  return records.flatMap(reading=>{
   const id=String(reading.id),old=before.get(id),wanted=after.get(id);
   if(!old&&!wanted)return[reading];
   const owned=String(reading.lotId||'')===String(lot.id)||!reading.lotId&&String(reading.lotCode||'')===String(lot.code);
   if(!owned||!old||wanted&&(wanted.param!==old.param||wanted.dayId!==old.dayId))throw Error('La medición de agua pertenece a otro registro.');
   if(reading.date!==old.date||!reading.params||Object.keys(reading.params).length!==1||!Object.hasOwn(reading.params,old.param)||reading.custom)throw Error('La medición vinculada cambió. Cierra la ficha y vuelve a abrirla.');
   if(!wanted)return[];
   const r=rows.get(id);
   return[{...reading,date:r.date,time:r.time,point:r.point,lotCode:next.lot.code,params:{[r.param]:{value:r.value,unit:r.unit}},note:r.note||''}];
  });
 }
 const paths={
  temperature:'<path d="M10 14.8V5a2 2 0 0 1 4 0v9.8a4 4 0 1 1-4 0Z"/><path d="M12 9v9"/>',
  oxygen:'<circle cx="8" cy="14" r="5"/><circle cx="18" cy="6" r="3"/><circle cx="18" cy="19" r="2"/>',
  ph:'<path d="M12 2c-3 5-8 10-8 14a8 8 0 0 0 16 0c0-4-5-9-8-14Z"/><text x="12" y="18" text-anchor="middle" stroke="none" fill="currentColor" font-size="8" font-family="sans-serif">pH</text>',
  flask:'<path d="M9 3h6m-5 0v7L4 20a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1l-6-10V3M8 15h8"/>'
 };
 function icon(key){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(paths[key]||paths.flask)+'</svg>';}
 function create({document,catalog,getState}){
  const $=id=>document.getElementById(id),params=catalog.flatMap(g=>g.params),byId=Object.fromEntries(params.map(p=>[p.id,p]));
  let selected=[...DEFAULTS],values={};
  function snapshot(){for(const id of selected){const el=$('dailyWater-'+id);if(el)values[id]=el.value;}}
  function label(p){return p.id==='temperature'?'Temperatura (°C)':p.id==='ph'?'pH':p.id==='tan'?'Nitrógeno amoniacal total <small>(TAN · mg N/L)</small>':esc(p.label)+' <span>('+esc(p.unit)+')</span>';}
  function render(){
   $('dailyWaterFields').innerHTML=selected.map(id=>{const p=byId[id];return`<div class="field dailyWaterField"><label for="dailyWater-${id}"><span class="dailyIcon">${icon(id)}</span><span>${label(p)}</span></label><input id="dailyWater-${id}" data-daily-water="${id}" type="${p.kind==='text'?'text':'number'}" ${p.kind==='text'?'maxlength="200"':'step="any" inputmode="decimal"'} placeholder="Sin medir" value="${esc(values[id]??'')}">${DEFAULTS.includes(id)?'':`<button type="button" class="dailyRemoveParam" data-daily-remove="${id}" aria-label="Quitar ${esc(p.label)}">Quitar</button>`}</div>`;}).join('');
   const available=params.filter(p=>!selected.includes(p.id));
   $('dailyWaterParam').innerHTML='<option value="">Selecciona un parámetro</option>'+catalog.map(g=>{const choices=g.params.filter(p=>!selected.includes(p.id));return choices.length?`<optgroup label="${esc(g.title)}">${choices.map(p=>`<option value="${p.id}">${esc(p.label)} (${esc(p.unit)})</option>`).join('')}</optgroup>`:'';}).join('');
   $('dailyWaterAdd').disabled=!available.length;
  }
  function closePicker(){ $('dailyWaterPicker').hidden=true;$('dailyWaterAdd').setAttribute('aria-expanded','false'); }
  function fill(record){
   const state=getState(),wanted=record?.waterParams||state.dailyWaterParams||DEFAULTS;
   selected=[...new Set([...DEFAULTS,...(Array.isArray(wanted)?wanted:[]),...Object.keys(record?.waterReadingIds||{})])].filter(id=>byId[id]);values={};
   for(const [param,id]of Object.entries(record?.waterReadingIds||{})){const row=state.water.find(r=>source(r)===id);if(row)values[param]=row.value;}
   render();closePicker();
  }
  function draft(record,old){
   snapshot();const rows=[],links={};
   for(const id of selected){
    const p=byId[id],raw=String(values[id]??'').trim(),el=$('dailyWater-'+id);
    if(el?.validity?.badInput)return{error:'Ingresa un resultado válido para '+p.label+'.'};
    if(!raw)continue;
    const value=p.kind==='text'?raw:Number(raw.replace(',','.'));
    if(p.kind!=='text'&&(!Number.isFinite(value)||!['temperature','orp'].includes(id)&&value<0)||id==='ph'&&(value<0||value>14))return{error:'Revisa el resultado de '+p.label+(id==='ph'?': debe estar entre 0 y 14.':'.')};
    const readingId=old?.waterReadingIds?.[id]||'DAILY-WATER-'+record.id+'-'+id,previous=getState().water.find(r=>source(r)===readingId);
    links[id]=readingId;
    rows.push({...previous,id:readingId+'::'+id,sourceReadingId:readingId,lotId:getState().lot.id,param:id,value,unit:p.unit,date:record.date,time:record.time,point:previous?.point||getState().lot.cageAssignment||getState().lot.unit||'Lote',note:previous?.note||''});
   }
   return{rows,links,params:[...selected]};
  }
  $('dailyWaterAdd').addEventListener('click',()=>{const picker=$('dailyWaterPicker');picker.hidden=!picker.hidden;$('dailyWaterAdd').setAttribute('aria-expanded',String(!picker.hidden));if(!picker.hidden)$('dailyWaterParam').focus();});
  $('dailyWaterParam').addEventListener('change',()=>{const id=$('dailyWaterParam').value;if(!byId[id]||selected.includes(id))return;snapshot();selected.push(id);render();closePicker();$('dailyWater-'+id).focus();});
  $('dailyWaterFields').addEventListener('click',e=>{const b=e.target.closest('[data-daily-remove]');if(!b)return;snapshot();selected=selected.filter(id=>id!==b.dataset.dailyRemove);delete values[b.dataset.dailyRemove];render();$('dailyWaterAdd').focus();});
  return{fill,draft,snapshot:()=>{snapshot();return{selected:[...selected],values:copy(values)};},restore:s=>{selected=s.selected;values=s.values;render();closePicker();}};
 }
 return{DEFAULTS,references,reconcileShared,create};
});
