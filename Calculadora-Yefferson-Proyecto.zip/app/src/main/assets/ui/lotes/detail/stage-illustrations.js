/* Original SVG artwork and motion from etapas-trucha-v9.html (Yefferson's approved source).
 * Stage comes from the saved lot, never from weight or a demo default.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.TruchAppStageIllustrations=api;})(typeof window==='object'?window:null,function(){
'use strict';

/* ============ COPIA DESDE AQUÍ: íconos animados de cada etapa ============ */

/* Animación suave de ida y vuelta (la animación va dentro del propio SVG) */
const mov = (tipo, valores, dur, ph = 0) =>
  `<animateTransform attributeName="transform" type="${tipo}" values="${valores}" keyTimes="0;.5;1" calcMode="spline" keySplines=".45 0 .55 1;.45 0 .55 1" dur="${dur}s" begin="${-ph}s" repeatCount="indefinite"/>`;

/* Igual, pero con 5 puntos (para pulsos que se repiten dos veces por ciclo) */
const mov5 = (tipo, valores, dur, ph = 0) =>
  `<animateTransform attributeName="transform" type="${tipo}" values="${valores}" keyTimes="0;.25;.5;.75;1" calcMode="spline" keySplines=".45 0 .55 1;.45 0 .55 1;.45 0 .55 1;.45 0 .55 1" dur="${dur}s" begin="${-ph}s" repeatCount="indefinite"/>`;

/* Cola como TELA: la forma se calcula en 16 cuadros y cada parte lleva un retraso distinto,
   así la ondulación viaja desde la base hasta las puntas (los bordes ondulan, las puntas
   van como látigo, los radios se curvan y un brillo con su sombra recorre la cola). */
function framesCola(g, N = 16){
  const r = v => +v.toFixed(2);
  const { bx, y0, y1, tx, ty, nx, ym, A, B, C, D, rayos } = g;
  const cola = [], rays = [];
  for (let k = 0; k <= N; k++){
    const a = 2 * Math.PI * (k % N) / N;
    const w1 = A * Math.sin(a - .6), w2 = A * Math.sin(a - 2.0);      // la onda viaja hacia la punta
    const wt = Math.sin(a - 2.6);
    const txk = tx + B * wt, tyk = ty - C * wt, nxk = nx + D * Math.sin(a - 3.4);
    const L = txk - bx, dy = tyk - y0;
    const c1x = bx + .33 * L, c1y = y0 + .33 * dy + w1;
    const c2x = bx + .66 * L, c2y = y0 + .66 * dy + w2;
    const m = v => r(2 * ym - v);                                      // espejo: arriba y abajo iguales
    cola.push(`M${bx} ${y0}C${r(c1x)} ${r(c1y)} ${r(c2x)} ${r(c2y)} ${r(txk)} ${r(tyk)}Q${r(nxk)} ${ym} ${r(txk)} ${m(tyk)}C${r(c2x)} ${m(c2y)} ${r(c1x)} ${m(c1y)} ${bx} ${y1}Z`);
    if (rayos){
      let d = '';
      [0, .25, .5, .75, 1].forEach(f => {
        const by = y0 + (y1 - y0) * f;
        const exr = (1 - f) * (1 - f) * txk + 2 * f * (1 - f) * nxk + f * f * txk;
        const eyr = tyk + (2 * ym - 2 * tyk) * f;
        const ex = bx + (exr - bx) * .92, ey = by + (eyr - by) * .92;
        const mf = (ym - eyr) / (ym - tyk);
        d += `M${bx} ${r(by)}Q${r((bx + ex) / 2)} ${r((by + ey) / 2 + mf * w2 * .8)} ${r(ex)} ${r(ey)}`;
      });
      rays.push(d);
    }
  }
  return { f: cola, r: rayos ? rays : null };
}
const COLA_PEZ    = framesCola({bx:90, y0:27, y1:33, tx:111, ty:17, nx:107, ym:30, A:1.8, B:1.6, C:1.3, D:1.2, rayos:true});
const COLA_ALEVIN = framesCola({bx:48, y0:20, y1:20, tx:61,  ty:9,  nx:56,  ym:20, A:.9,  B:.9,  C:.7,  D:.6,  rayos:false});

/* Cola con profundidad (se acerca y se aleja) + ondulación de tela */
const colaProfunda = ({ id, px, py, T, ph, ancho, frames, rayos, color, op = 1, extra = '' }) => {
  const anim = a => `<animate attributeName="d" values="${a.join(';')}" dur="${T}s" begin="${-ph}s" repeatCount="indefinite"/>`;
  const rayosSvg = rayos
    ? `<path d="${rayos[0]}" fill="none" stroke="#000" stroke-opacity=".2" stroke-width=".6" stroke-linecap="round">${anim(rayos)}</path>`
    : '';
  const barrido = (attr, a, b) =>
    `<animate attributeName="${attr}" values="${a};${b}" calcMode="spline" keySplines=".4 0 .6 1" dur="${T}s" begin="${-ph}s" repeatCount="indefinite"/>`;
  return `<g transform="translate(${px} ${py})">
    <defs>
      <linearGradient id="${id}Co" gradientUnits="userSpaceOnUse" x1="${px}" y1="0" x2="${px + ancho}" y2="0">
        <stop offset="0" stop-color="${color}" stop-opacity="${op}"/><stop offset="1" stop-color="${color}" stop-opacity="${+(op * .72).toFixed(2)}"/>
      </linearGradient>
      <linearGradient id="${id}Br" gradientUnits="userSpaceOnUse" x1="${px - 8}" y1="0" x2="${px + 4}" y2="0">
        <stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset=".3" stop-color="#000" stop-opacity=".22"/>
        <stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset=".75" stop-color="#fff" stop-opacity=".32"/>
        <stop offset="1" stop-color="#fff" stop-opacity="0"/>
        ${barrido('x1', px - 8, px + ancho)}${barrido('x2', px + 4, px + ancho + 12)}
      </linearGradient>
    </defs>
    <g>${mov('scale', '.8 .8;1.2 1.2;.8 .8', T, ph)}
      <animate attributeName="opacity" values=".68;1;.68" keyTimes="0;.5;1" calcMode="spline" keySplines=".45 0 .55 1;.45 0 .55 1" dur="${T}s" begin="${-ph}s" repeatCount="indefinite"/>
      <g>${mov5('scale', '.9 1;1 1;.9 1;1 1;.9 1', T, ph)}
        <g transform="translate(${-px} ${-py})">
          <path d="${frames[0]}" fill="url(#${id}Co)">${anim(frames)}</path>
          ${rayosSvg}
          <path d="${frames[0]}" fill="url(#${id}Br)">${anim(frames)}</path>
          ${extra}
        </g>
      </g>
    </g>
  </g>`;
};

/* ===== ALETAS INFERIORES (pectoral, pélvica y anal) con ondulación de tela ===== */
const mezcla = (a, b, t) => {
  const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
  const [r1, g1, b1] = p(a), [r2, g2, b2] = p(b);
  const hx = v => Math.round(v).toString(16).padStart(2, '0');
  return '#' + hx(r1 + (r2 - r1) * t) + hx(g1 + (g2 - g1) * t) + hx(b1 + (b2 - b1) * t);
};

/* Calcula los cuadros de una aleta en abanico: la base queda fija en el cuerpo y la onda
   viaja hasta el borde libre; los radios se curvan con un pequeño desfase entre ellos. */
function framesAleta(g, N = 12){
  const r = v => +v.toFixed(2);
  const { B0, B1, T0, T1, FC, A, rays = 5, lag = 1.7 } = g;
  const lerp = (p, q, t) => [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t];
  const bc = lerp(B0, B1, .5), tc = lerp(T0, T1, .5);
  let ex = tc[0] - bc[0], ey = tc[1] - bc[1];
  const L = Math.hypot(ex, ey); ex /= L; ey /= L;
  const nx = -ey, ny = ex;                                   // perpendicular al eje de la aleta
  const pt = (p, d) => [p[0] + nx * d, p[1] + ny * d];
  const P = p => `${r(p[0])} ${r(p[1])}`;
  const out = { f: [], r: [], b: [], bc, tc };
  for (let k = 0; k <= N; k++){
    const a = 2 * Math.PI * (k % N) / N;
    const d1 = A * .3 * Math.sin(a - lag * .3), d2 = A * .7 * Math.sin(a - lag * .7);
    const dt = A * Math.sin(a - lag), db = A * Math.sin(a - lag - .6);
    const c1 = pt(lerp(B0, T0, .33), d1), c2 = pt(lerp(B0, T0, .66), d2);
    const t0 = pt(T0, dt), t1 = pt(T1, db), fc = pt(FC, (dt + db) * .55);
    const e1 = pt(lerp(T1, B1, .33), d2 * .9), e2 = pt(lerp(T1, B1, .66), d1 * .9);
    out.f.push(`M${P(B0)}C${P(c1)} ${P(c2)} ${P(t0)}Q${P(fc)} ${P(t1)}C${P(e1)} ${P(e2)} ${P(B1)}Z`);
    out.b.push(`M${P(B0)}C${P(c1)} ${P(c2)} ${P(t0)}`);
    let d = '';
    for (let i = 0; i < rays; i++){
      const f = rays === 1 ? .5 : i / (rays - 1);
      const bp = lerp(B0, B1, f);
      const ep0 = [(1 - f) * (1 - f) * t0[0] + 2 * f * (1 - f) * fc[0] + f * f * t1[0],
                   (1 - f) * (1 - f) * t0[1] + 2 * f * (1 - f) * fc[1] + f * f * t1[1]];
      const ep = lerp(bp, ep0, .9);
      const dm = A * .7 * Math.sin(a - lag * .7 - f * .6);
      d += `M${P(bp)}Q${P(pt(lerp(bp, ep, .5), dm * .8))} ${P(ep)}`;
    }
    out.r.push(d);
  }
  return out;
}

/* Forma de cada aleta en el pez grande (coordenadas del viewBox 120x60) */
const FR_PECT = framesAleta({ B0:[29,36.5], B1:[30,40],    T0:[43.5,39.5], T1:[41,47.5],  FC:[46.6,45.3], A:1.5, rays:6, lag:1.7 });
const FR_PELV = framesAleta({ B0:[50,44.8], B1:[53.8,45.6], T0:[56,53],     T1:[62.5,50.8], FC:[61.8,54.2], A:1.2, rays:4, lag:1.6 });
const FR_ANAL = framesAleta({ B0:[69,42.8], B1:[79.5,39.2], T0:[71.5,50.5], T1:[83.5,41.5], FC:[78.8,48],   A:1.7, rays:5, lag:1.9 });
/* Y en el alevín (viewBox 64x40), más pequeñas */
const FR_PECT_A = framesAleta({ B0:[14.5,22.5], B1:[15.5,25.5], T0:[24.5,26],   T1:[23,30.5],  FC:[26.9,29.8], A:.8, rays:3, lag:1.7 });
const FR_PELV_A = framesAleta({ B0:[27,27.6],   B1:[30,28],     T0:[31.5,33.5], T1:[36,32],    FC:[35.5,34.4], A:.7, rays:3, lag:1.6 });
const FR_ANAL_A = framesAleta({ B0:[38,26.8],   B1:[45,23.8],   T0:[39.5,32],   T1:[48,26.3],  FC:[44.85,31.1], A:.8, rays:3, lag:1.9 });

/* Aleta con movimiento: remada (rotación) + entra y sale (escala) + ondulación de tela */
const aletaViva = ({ id, fr, T, ph, rot, esc, color, color2, op = .95, borde = 0, estatica = false, dx = 0, dy = 0 }) => {
  const [px, py] = fr.bc, [tx, ty] = fr.tc;
  const anim = a => `<animate attributeName="d" values="${a.join(';')}" dur="${T}s" begin="${-ph}s" repeatCount="indefinite"/>`;
  const relleno = `<path d="${fr.f[0]}" fill="url(#${id})">${estatica ? '' : anim(fr.f)}</path>`;
  const rayos = estatica ? '' :
    `<path d="${fr.r[0]}" fill="none" stroke="#000" stroke-opacity=".22" stroke-width=".5" stroke-linecap="round">${anim(fr.r)}</path>`;
  const filo = (estatica || !borde) ? '' :
    `<path d="${fr.b[0]}" fill="none" stroke="#fff" stroke-opacity="${borde}" stroke-width=".9" stroke-linecap="round">${anim(fr.b)}</path>`;
  let interior = `<g transform="translate(${-px} ${-py})">${relleno}${rayos}${filo}</g>`;
  if (esc) interior = `<g>${mov('scale', `${esc[0]} ${esc[0]};${esc[1]} ${esc[1]};${esc[0]} ${esc[0]}`, T, ph)}${interior}</g>`;
  if (rot) interior = `<g>${mov('rotate', `${rot[0]} 0 0;${rot[1]} 0 0;${rot[0]} 0 0`, T, ph)}${interior}</g>`;
  return `<g transform="translate(${dx} ${dy})"><g transform="translate(${px} ${py})">
    <defs><linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${px}" y1="${py}" x2="${tx}" y2="${ty}">
      <stop offset="0" stop-color="${color}" stop-opacity="${op}"/><stop offset="1" stop-color="${color2}" stop-opacity="${+(op * .78).toFixed(2)}"/>
    </linearGradient></defs>
    ${interior}
  </g></g>`;
};

/* Burbujitas que suben desde la boca */
const burbujas = (ph = 0, cy0 = 28, cy1 = 4, xs = [4, 7, 2], r = 1) =>
  xs.map((x, i) => {
    const b = -(i * 0.95 + ph);
    return `<circle cx="${x}" cy="${cy0}" r="${r}" fill="none" stroke="#d7eef5" stroke-width=".7" opacity="0">
      <animate attributeName="cy" values="${cy0};${cy1}" dur="2.8s" begin="${b}s" repeatCount="indefinite"/>
      <animate attributeName="r" values="${r*.7};${r*1.7}" dur="2.8s" begin="${b}s" repeatCount="indefinite"/>
      <animate attributeName="opacity" values="0;.85;.85;0" keyTimes="0;.15;.7;1" dur="2.8s" begin="${b}s" repeatCount="indefinite"/>
    </circle>`;
  }).join('');

/* Generador de trucha (juvenil, engorde, reproductores) */
const CUERPO = 'M8 31C13 23 26 15 46 14C64 13 80 21 93 27L93 33C80 40 64 47 46 46C28 46 14 40 8 31Z';
const MANCHAS = [[30,22],[38,19],[46,18],[54,19],[62,21],[70,24],[78,27],[42,24],[58,25],[34,26],[50,22],[66,27],[74,22],[86,29],[26,25],[82,24]];

function pez(o){
  const p = o.id, d = o.d, T = o.T, ph = o.ph, y = v => +(30 + (v - 30) * d).toFixed(1);
  const manchas = MANCHAS.slice(0, o.nsp).map(([x,yy]) => `<circle cx="${x}" cy="${yy}" r="${o.sr || 1.1}"/>`).join('');
  const colaManchas = o.nsp > 3 ? [[98,25],[103,23],[100,32],[104,37],[97,38]].map(([x,yy]) => `<circle cx="${x}" cy="${yy}" r="${(o.sr||1.1)*.9}"/>`).join('') : '';
  const parr = o.parr ? [[31,11],[40,12],[49,12],[58,11],[67,9],[76,6]].map(([x,ry]) => `<ellipse cx="${x}" cy="30" rx="2.8" ry="${ry}"/>`).join('') : '';
  const gancho = o.kype ? `<path d="M9.5 32Q7 38 12.5 37L16.5 34.4Z" fill="${o.back}" stroke="#0b1a1f" stroke-width=".6"/>` : '';
  const c2 = o.fin2, c2b = mezcla(o.fin2, '#ffffff', .4);
  const c2d = mezcla(o.fin2, '#000000', .5), c2db = mezcla(o.fin2, '#000000', .3);
  const pectCerca = aletaViva({ id: p + 'Pc',  fr: FR_PECT, T: 1.6, ph: ph,        rot: [-7, 9], esc: [.9, 1.08],  color: c2, color2: c2b, borde: .3 });
  const pectLejos = aletaViva({ id: p + 'PcF', fr: FR_PECT, T: 1.6, ph: ph + .8,   rot: [9, -7], esc: [.9, 1.08],  color: c2d, color2: c2db, op: .6, estatica: true, dx: 2.6, dy: 1.4 });
  const pelvCerca = aletaViva({ id: p + 'Pv',  fr: FR_PELV, T: 1.9, ph: ph + .3,   rot: [-5, 6], esc: [.94, 1.05], color: c2, color2: c2b, borde: .45 });
  const pelvLejos = aletaViva({ id: p + 'PvF', fr: FR_PELV, T: 1.9, ph: ph + 1.25, rot: [6, -5], esc: [.94, 1.05], color: c2d, color2: c2db, op: .6, estatica: true, dx: 3, dy: .6 });
  const anal      = aletaViva({ id: p + 'An',  fr: FR_ANAL, T: T,   ph: ph + T * .3, rot: [-2.5, 2.5],             color: c2, color2: c2b, borde: .45 });
  return `<svg viewBox="0 0 120 60" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="${p}Cu" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${o.back}"/><stop offset=".4" stop-color="${o.mid}"/>
      <stop offset=".62" stop-color="${o.belly}"/><stop offset="1" stop-color="${o.belly}"/>
    </linearGradient>
    <linearGradient id="${p}Ba" gradientUnits="userSpaceOnUse" x1="20" y1="0" x2="95" y2="0">
      <stop offset="0" stop-color="${o.band}" stop-opacity="0"/><stop offset=".28" stop-color="${o.band}" stop-opacity="${o.bandOp}"/>
      <stop offset=".8" stop-color="${o.band}" stop-opacity="${o.bandOp}"/><stop offset="1" stop-color="${o.band}" stop-opacity=".3"/>
    </linearGradient>
    <clipPath id="${p}Cl"><path d="${CUERPO}"/></clipPath>
  </defs>
  <g transform="translate(60 30) scale(${o.sc}) translate(-60 -30)">
    ${burbujas(ph)}
    <g>${mov('translate', '0 0;0 -1.2;0 0', 2.6, ph)}
     <g>${mov('rotate', '1.2 62 30;-1.2 62 30;1.2 62 30', T, ph)}
      <g transform="translate(0 30) scale(1 ${d}) translate(0 -30)">
        ${colaProfunda({ id: p + 'Ta', px: 90, py: 30, T, ph, ancho: 21, frames: COLA_PEZ.f, rayos: COLA_PEZ.r,
            color: o.fin, extra: `<g fill="#0c171b" opacity=".7">${colaManchas}</g>` })}
        <g>${mov('rotate', '-2.5 56 15;2.5 56 15;-2.5 56 15', T, ph + T * .2)}
          <path d="M46 14.5Q50 4 57 4.5L64 6Q64 12 66 16Z" fill="${o.fin}"/>
        </g>
        <path d="M77 23Q80 15 85 24Z" fill="${o.fin}"/>
        ${pectLejos}
        ${pelvLejos}
        ${anal}
        ${pelvCerca}
        <path d="${CUERPO}" fill="url(#${p}Cu)" stroke="#0b1a1f" stroke-opacity=".45" stroke-width=".8"/>
        <g clip-path="url(#${p}Cl)">
          <path d="M20 32Q55 29 95 31" stroke="url(#${p}Ba)" stroke-width="${o.bandW}" fill="none" stroke-linecap="round"/>
          <g fill="#1d3b33" opacity=".5">${parr}</g>
          <g fill="#0c171b" opacity=".75">${manchas}</g>
          <path d="M22 22Q48 14 80 24" stroke="#fff" stroke-opacity=".3" stroke-width="2.4" fill="none" stroke-linecap="round"/>
          <path d="M27 28.5Q55 26.5 91 29.5" stroke="#0b1a1f" stroke-opacity=".28" stroke-width=".8" stroke-dasharray="1.2 1.8" fill="none"/>
        </g>
        <path d="M25 18.5Q32 31 25 44" stroke="#0b1a1f" stroke-opacity=".4" stroke-width="1.1" fill="none"/>
        <path d="M8 31L18 33.6L20 31.5" stroke="#0b1a1f" stroke-width=".9" fill="none" stroke-linecap="round"/>
        ${gancho}
        ${pectCerca}
      </g>
      <circle cx="17" cy="${y(26)}" r="3.7" fill="#cfd8d8" stroke="#0b1a1f" stroke-width=".6"/>
      <circle cx="17" cy="${y(26)}" r="2.4" fill="#0d1417"/>
      <circle cx="16.1" cy="${y(25.1)}" r=".85" fill="#fff"/>
     </g>
    </g>
  </g>
</svg>`;
}

const SVG_JUVENIL = pez({id:'ju', sc:.82, d:.84, T:.8, ph:.3, back:'#56796a', mid:'#9bbaa8', belly:'#eef3ea',
  band:'#e7a4b2', bandOp:.55, bandW:3, fin:'#6f8f86', fin2:'#f0b9a0', parr:true, nsp:5, sr:.9});

const SVG_ENGORDE = pez({id:'en', sc:.95, d:1, T:1, ph:.6, back:'#3f6b78', mid:'#86aeb5', belly:'#f1f5f3',
  band:'#e9899f', bandOp:.85, bandW:5.5, fin:'#5d8792', fin2:'#e3a6ad', nsp:12, sr:1.1});

const SVG_REPRODUCTOR = pez({id:'re', sc:1, d:1.08, T:1.25, ph:.1, back:'#26454f', mid:'#4f7d86', belly:'#d9c3c0',
  band:'#c8344f', bandOp:.95, bandW:9, fin:'#2f5560', fin2:'#c05560', kype:true, nsp:16, sr:1.25});

/* Alevín (sin saco vitelino): aletea rápido porque es pequeño */
const FORMA = 'M6 20C14 8 36 8 50 18L50 22C36 32 14 32 6 20Z';
const COLA  = 'M48 20L61 9L58 20L61 31Z';
const alPect = aletaViva({ id: 'alPc', fr: FR_PECT_A, T: .9,  ph: .2,  rot: [-8, 10], esc: [.9, 1.08], color: '#cfe6da', color2: '#eef8f2', op: .85, borde: .3 });
const alPelv = aletaViva({ id: 'alPv', fr: FR_PELV_A, T: 1.1, ph: .5,  rot: [-6, 7],  esc: [.94, 1.05], color: '#cfe6da', color2: '#eef8f2', op: .85, borde: .4 });
const alAnal = aletaViva({ id: 'alAn', fr: FR_ANAL_A, T: .55, ph: .35, rot: [-3, 3],                    color: '#cfe6da', color2: '#eef8f2', op: .85, borde: .4 });
const SVG_ALEVIN = `<svg viewBox="0 0 64 40" xmlns="http://www.w3.org/2000/svg">
    ${burbujas(.2, 22, 3, [11, 14], .8)}
    <g transform="translate(10 6) scale(.68)">
     <g>${mov('translate', '0 0;0 -1;0 0', 2.2, .2)}
      <g>${mov('rotate', '1.8 30 20;-1.8 30 20;1.8 30 20', .55, .2)}
        ${colaProfunda({ id: 'alTa', px: 48, py: 20, T: .55, ph: .2, ancho: 13, frames: COLA_ALEVIN.f, rayos: null,
            color: '#b9d3c4', op: .85 })}
        ${alPelv}
        ${alAnal}
        <path d="${FORMA}" fill="#cfe5d6" opacity=".9"/>
        <circle cx="13" cy="18" r="3.4" fill="#10231f"/><circle cx="12.2" cy="17.2" r="1" fill="#fff"/>
        <path d="M22 20Q36 17 48 20" stroke="#8fb8a0" stroke-width="1.5" fill="none"/>
        ${alPect}
      </g>
     </g>
    </g></svg>`;

/* Ovas: no nadan, solo un brillo y un balanceo muy suave del agua */
const SVG_OVAS = `<svg viewBox="0 0 64 40" xmlns="http://www.w3.org/2000/svg">
    <g>${mov('rotate', '1.2 32 22;-1.2 32 22;1.2 32 22', 4.5)}
    <g fill="#f29a3a">
      <circle cx="22" cy="26" r="7"/><circle cx="36" cy="27" r="7"/><circle cx="44" cy="19" r="6.5"/>
      <circle cx="29" cy="16" r="7"/><circle cx="16" cy="15" r="6"/>
    </g>
    <g fill="#d9741c" opacity=".5">
      <circle cx="22" cy="28" r="3"/><circle cx="36" cy="29" r="3"/><circle cx="44" cy="21" r="2.8"/>
      <circle cx="29" cy="18" r="3"/><circle cx="16" cy="17" r="2.5"/>
    </g>
    <g fill="#fff" opacity=".8">
      <animate attributeName="opacity" values=".85;.4;.85" dur="3s" repeatCount="indefinite"/>
      <circle cx="19.5" cy="23" r="1.6"/><circle cx="33.5" cy="24" r="1.6"/><circle cx="42" cy="16.5" r="1.5"/>
      <circle cx="26.5" cy="13" r="1.6"/><circle cx="14" cy="12.5" r="1.3"/>
    </g>
    </g>
  </svg>`;

const ETAPAS = {
  Alevinaje:     { svg: SVG_ALEVIN,       detalle: 'Ya se alimenta por sí solo' },
  Juvenil:       { svg: SVG_JUVENIL,      detalle: 'Marcas parr en el costado' },
  Engorde:       { svg: SVG_ENGORDE,      detalle: 'Crecimiento a talla comercial' },
  Reproductores: { svg: SVG_REPRODUCTOR,  detalle: 'Selección para desove' },
  Ovas:          { svg: SVG_OVAS,         detalle: 'Huevos fertilizados' }
};

const aliases={ovas:'Ovas',ova:'Ovas',alevinaje:'Alevinaje',alevin:'Alevinaje',alevines:'Alevinaje',alevino:'Alevinaje',alevinos:'Alevinaje',juvenil:'Juvenil',juveniles:'Juvenil',engorde:'Engorde',reproductor:'Reproductores',reproductores:'Reproductores'};
function resolve(stage){const name=String(stage??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLocaleLowerCase('es');return Object.hasOwn(aliases,name)?aliases[name]:null;}
function render(element,stage){if(!element)return false;const name=resolve(stage)||'';element.hidden=!name;if(element.dataset.stageIllustration===name)return false;element.dataset.stageIllustration=name;element.innerHTML=name?ETAPAS[name].svg:'';return true;}
return{resolve,render};
});
