/* Approved food popup. All navigation is read-only; registration uses the existing form. */
(function(root){'use strict';
const D=root.TruchAppConsumedData;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(v,d=3)=>Number(v).toLocaleString('es-PE',{maximumFractionDigits:d});
const dateLabel=date=>new Date(date+'T12:00:00').toLocaleDateString('es-PE',{day:'numeric',month:'short'});
const fullDate=date=>new Date(date+'T12:00:00').toLocaleDateString('es-PE',{day:'numeric',month:'long',year:'numeric'});
const monthLabel=month=>new Date(month+'-01T12:00:00').toLocaleDateString('es-PE',{month:'long',year:'numeric'});
function create(ctx){
 const doc=ctx.document;let range='Max',date=null,pointKey=null,gesture=null;
 const get=id=>doc.getElementById(id);
 function model(){
  const state=ctx.getState(),today=ctx.today(),view=D.windowData(state,today,range);
  if(!view.rows.some(r=>r.date===date)){date=view.end;pointKey=null;}
  const points=D.series(view);let index=points.findIndex(p=>p.key===pointKey);
  if(index<0)index=range==='1D'?Math.max(0,points.map(p=>p.value!==null).lastIndexOf(true)):points.findIndex(p=>p.date===date);
  const selected=points[index]||null,day=view.rows.find(r=>r.date===date)||null;
  return{state,today,view,points,index,selected,day,page:D.page(view.rows,date)};
 }
 function graph(m){
  const known=m.points.filter(p=>p.value!==null),intraday=range==='1D';
  if(!known.length)return'<div class="foodEmpty" role="status">'+(m.view.rows.length?'Sin registros de alimento en este período. Los campos vacíos no equivalen a 0 kg.':'El lote todavía no tiene días de cultivo para este período.')+'</div>';
  const w=640,h=255,left=45,right=22,top=38,bottom=34,base=h-bottom,max=D.scale(known.reduce((n,p)=>Math.max(n,p.value),0));
  const maxX=intraday?1439:Math.max(1,m.points.length-1),x=p=>left+(m.points.length===1&&!intraday?.5:p.x/maxX)*(w-left-right),y=v=>top+(1-v/max)*(base-top),geometry=D.plot(m.points,m.index),paths=geometry.segments.map(segment=>({segment,d:segment.map((p,i)=>(i?'L':'M')+x(p).toFixed(2)+','+y(p.value).toFixed(2)).join(' ')}));
  const grid=[0,1,2,3].map(i=>{const v=max*i/3;return`<path class="foodGrid" d="M${left},${y(v)}H${w-right}"/><text class="foodTick" x="${left-11}" y="${y(v)+4}" text-anchor="end">${fmt(v,3)}</text>`;}).join('');
  const ticks=intraday?[{x:0,text:'00:00'},{x:720,text:'12:00'},{x:1439,text:'23:59'}]:[...new Set([0,Math.floor((m.points.length-1)/2),m.points.length-1])].map(i=>({x:m.points[i].x,text:dateLabel(m.points[i].date)+(D.span(m.view.start,m.view.end)>366?' '+m.points[i].date.slice(0,4):'')}));
  const axis=ticks.map(t=>`<text class="foodTick" x="${left+(m.points.length===1&&!intraday?.5:t.x/maxX)*(w-left-right)}" y="${h-9}" text-anchor="middle">${esc(t.text)}</text>`).join('');
  const selected=m.selected,selectedLabel=selected?(intraday?selected.time:dateLabel(selected.date))+' · '+(selected.value===null?'Sin registro':fmt(selected.value)+' kg'):'';
  let cursor='';if(selected){const cx=x(selected),cy=selected.value===null?base:y(selected.value),labelWidth=Math.min(220,Math.max(140,selectedLabel.length*7)),labelX=Math.max(left,Math.min(w-right-labelWidth,cx-labelWidth/2));cursor=`<path class="foodGuide" d="M${cx},${top}V${base}"/>${selected.value===null?'':`<circle class="foodSelectedPoint" cx="${cx}" cy="${cy}" r="6.5"/>`}<rect class="foodTooltip" x="${labelX}" y="3" width="${labelWidth}" height="26" rx="7"/><text class="foodTooltipText" x="${labelX+labelWidth/2}" y="21" text-anchor="middle">${esc(selectedLabel)}</text>`;}
  const area=paths.map(({segment,d})=>`<path class="foodArea" d="${d} L${x(segment.at(-1))},${base} L${x(segment[0])},${base} Z"/>`).join('');
  const line=paths.map(({d})=>`<path class="foodLine" d="${d}"/>`).join('');
  const dots=paths.flatMap(p=>p.segment).filter(p=>m.points.length<=32||p.index===m.index||paths.some(s=>s.segment.length===1&&s.segment[0].index===p.index)).map(p=>`<circle class="foodPoint" cx="${x(p)}" cy="${y(p.value)}" r="${m.points.length>32?2:3.3}"><title>${esc((intraday?p.time:fullDate(p.date))+': '+fmt(p.value)+' kg')}</title></circle>`).join('');
  return`<div class="foodPlot" tabindex="0" role="slider" aria-label="Alimento registrado. Usa las flechas para consultar los puntos" aria-valuemin="0" aria-valuemax="${Math.max(1,m.points.length-1)}" aria-valuenow="${Math.max(0,m.index)}" aria-valuetext="${esc(selectedLabel)}"><svg viewBox="0 0 ${w} ${h}" aria-hidden="true"><defs><linearGradient id="foodFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#61cba5" stop-opacity=".38"/><stop offset="1" stop-color="#61cba5" stop-opacity=".025"/></linearGradient></defs><text class="foodTick" x="${left-20}" y="22">kg</text>${grid}${area}${line}${dots}${cursor}${axis}</svg></div><p class="foodChartHelp">Toca o desliza para consultar ${intraday?'un registro':'un día'}.${m.view.known.length<m.view.rows.length?' Los días sin dato interrumpen la línea.':''}${geometry.reduced?' Vista resumida; la selección muestra el dato exacto.':''}</p>`;
 }
 function calendar(m){
  if(!m.view.rows.length)return'';
  const months=[...new Set(m.view.rows.map(r=>r.date.slice(0,7)))],page=m.page;
  return`<section class="foodCalendar" aria-label="Registros de alimentación"><h3>Registros de alimentación</h3><div class="foodMonth"><label class="foodSrOnly" for="foodMonth">Mes de los registros</label><select id="foodMonth">${months.map(month=>`<option value="${month}"${month===date.slice(0,7)?' selected':''}>${esc(monthLabel(month))}</option>`).join('')}</select><button type="button" data-food-today>Hoy</button></div><div class="foodWeek"><button type="button" data-food-page="-1" aria-label="Días anteriores"${page.index===0?' disabled':''}>‹</button><span aria-live="polite">${esc(dateLabel(page.rows[0].date)+(page.rows.length>1?' – '+dateLabel(page.rows.at(-1).date):'')+' '+page.rows.at(-1).date.slice(0,4))}</span><button type="button" data-food-page="1" aria-label="Días siguientes"${page.index===page.count-1?' disabled':''}>›</button></div><div class="foodDays" aria-label="Seleccionar día">${page.rows.map(row=>`<button type="button" data-food-date="${row.date}" class="foodDay ${row.status}${row.date===date?' selected':''}" aria-pressed="${row.date===date}" aria-label="${esc(fullDate(row.date)+': '+(row.value!==null?fmt(row.value)+' kg':row.status==='legacy'?'Total anterior sin desglose':'Sin registro'))}"><b>${Number(row.date.slice(-2))}</b><span aria-hidden="true">${row.value!==null?'●':row.status==='legacy'?'≈':'—'}</span></button>`).join('')}</div></section>`;
 }
 function content(){
  const m=model(),s=ctx.summary(),today=s.today,total=s.feedKnown?fmt(s.food)+' kg':'— kg',knownToday=D.finite(today?.feed),editable=m.day?.editable&&!ctx.readOnly();
  const dayValue=m.day?.value,selectedText=D.finite(dayValue)?fmt(dayValue)+' kg registrado'+(dayValue===1?'':'s'):m.day?.status==='legacy'?'Sin desglose diario':'Sin registro';
  return`<div class="foodHero"><div><strong>${esc(total)}</strong><span>Total registrado en el lote</span></div><div class="foodToday"><span>Hoy</span><b>${knownToday?fmt(today.feed)+' kg':'Sin registro'}</b></div></div><div class="foodRange" role="group" aria-label="Período del gráfico de alimento">${D.ranges.map(value=>`<button type="button" data-food-range="${value}" aria-pressed="${range===value}" aria-label="${{ '1D':'Un día','5D':'Cinco días','1M':'Un mes','6M':'Seis meses','1A':'Un año',Max:'Todo el historial' }[value]}">${value}</button>`).join('')}</div><h3 class="foodChartTitle">Alimento suministrado por ${range==='1D'?'registro':'día'}</h3>${graph(m)}${calendar(m)}${m.day?`<div class="foodSelectedDay" aria-live="polite"><span>${esc(fullDate(date))}</span><strong>${esc(selectedText)}</strong></div>`:''}${m.view.legacyKnown?`<p class="foodLegacy">El total incluye ${fmt(m.view.legacyTotal)} kg anteriores sin desglose diario.</p>`:''}<div class="foodActions"><button type="button" class="primary" data-food-register${editable?'':' disabled'}>${ctx.readOnly()?'Solo consulta':'Registrar alimentación'}</button><button type="button" class="textbtn" data-food-history>Ver historial diario →</button></div><p class="foodSrOnly">Cómo se calcula: se suman los registros diarios y los totales antiguos conservados, sin descontar stock al consultar. El gráfico muestra cantidades suministradas registradas, no la ingestión real. Un campo vacío no equivale a cero confirmado.</p>`;
 }
 function render(){return'<div id="foodConsumedPanel">'+content()+'</div>';}
 function update(focus){const panel=get('foodConsumedPanel');if(!panel)return;panel.innerHTML=content();if(focus)panel.querySelector(focus)?.focus({preventScroll:true});}
 function pick(index,focus=false){const m=model(),p=m.points[Math.max(0,Math.min(m.points.length-1,index))];if(!p||p.key===m.selected?.key)return;date=p.date;pointKey=p.key;update(focus?'.foodPlot':null);}
 function pointer(event){const plot=get('foodConsumedPanel')?.querySelector('.foodPlot svg');if(!plot)return;const box=plot.getBoundingClientRect(),m=model(),x=(event.clientX-box.left)/box.width*640,ratio=Math.max(0,Math.min(1,(x-45)/(640-45-22))),max=range==='1D'?1439:Math.max(1,m.points.length-1),target=ratio*max;let index=0;for(let i=1;i<m.points.length;i++)if(Math.abs(m.points[i].x-target)<Math.abs(m.points[index].x-target))index=i;pick(index);}
 function mount(){
  const panel=get('foodConsumedPanel');if(!panel||panel.dataset.ready)return;panel.dataset.ready='true';
  panel.addEventListener('click',event=>{
   const target=event.target.closest('button');if(!target||target.disabled)return;
   if(target.dataset.foodRange){range=target.dataset.foodRange;pointKey=null;update('[data-food-range="'+range+'"]');}
   else if(target.dataset.foodDate){date=target.dataset.foodDate;pointKey=null;update('[data-food-date="'+date+'"]');}
   else if(target.dataset.foodPage){const m=model();date=D.pageDate(m.view.rows,date,Number(target.dataset.foodPage));pointKey=null;update('[data-food-page="'+target.dataset.foodPage+'"]');}
   else if(target.hasAttribute('data-food-today')){date=ctx.today();pointKey=null;update('[data-food-today]');}
   else if(target.hasAttribute('data-food-register')){if(model().day?.editable&&!ctx.readOnly())ctx.onRegister(date);}
   else if(target.hasAttribute('data-food-history'))ctx.onHistory();
  });
  panel.addEventListener('change',event=>{if(event.target.id==='foodMonth'){const m=model(),row=m.view.rows.find(r=>r.date.startsWith(event.target.value));if(row){date=row.date;pointKey=null;update('#foodMonth');}}});
  panel.addEventListener('keydown',event=>{
   const m=model(),plot=event.target.closest('.foodPlot'),day=event.target.closest('[data-food-date]');if(!plot&&!day)return;
   let index=plot?m.index:m.view.rows.findIndex(r=>r.date===day.dataset.foodDate),next;
   if(event.key==='ArrowLeft')next=index-1;else if(event.key==='ArrowRight')next=index+1;else if(event.key==='Home')next=0;else if(event.key==='End')next=(plot?m.points:m.view.rows).length-1;else return;
   event.preventDefault();if(plot)pick(next,true);else{date=m.view.rows[Math.max(0,Math.min(m.view.rows.length-1,next))].date;pointKey=null;update('[data-food-date="'+date+'"]');}
  });
  panel.addEventListener('pointerdown',event=>{if(!event.target.closest('.foodPlot'))return;gesture={id:event.pointerId,x:event.clientX,y:event.clientY};if(event.pointerType!=='touch'){panel.setPointerCapture?.(event.pointerId);pointer(event);}});
  panel.addEventListener('pointermove',event=>{if(!gesture||gesture.id!==event.pointerId)return;if(Math.abs(event.clientX-gesture.x)>8&&Math.abs(event.clientX-gesture.x)>Math.abs(event.clientY-gesture.y)*1.2){panel.setPointerCapture?.(event.pointerId);pointer(event);}});
  panel.addEventListener('pointerup',event=>{if(gesture?.id===event.pointerId){pointer(event);gesture=null;}});
  panel.addEventListener('pointercancel',()=>{gesture=null;});
 }
 return{render,mount,reset(){range='Max';date=null;pointKey=null;gesture=null;}};
}
root.TruchAppConsumedChart={create};
})(window);
