/* Read-only food view: observations plus explicitly marked automatic day-close defaults. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.TruchAppConsumedData=api;})(typeof window==='object'?window:null,function(){
 'use strict';
 const ranges=['1D','5D','1M','6M','1A','Max'];
 const finite=v=>typeof v==='number'&&Number.isFinite(v);
 const shift=(date,n)=>{const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);};
 const span=(a,b)=>Math.round((Date.parse(b+'T12:00:00Z')-Date.parse(a+'T12:00:00Z'))/86400000);
 function monthsBack(date,n){const d=new Date(date+'T12:00:00Z'),day=d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()-n);const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(day,last));return d.toISOString().slice(0,10);}
 function start(lotDate,today,range){let from=range==='1D'?today:range==='5D'?shift(today,-4):range==='1M'?shift(monthsBack(today,1),1):range==='6M'?shift(monthsBack(today,6),1):range==='1A'?shift(monthsBack(today,12),1):lotDate;return from<lotDate?lotDate:from;}
 function legacyRows(state){return[...(state.samples||[]).filter(r=>r.legacyPeriod),...(state.openingBalance?[state.openingBalance]:[])];}
 function closureForToday(today,checkpoint){return{version:1,policy:'missing-food-zero',through:shift(today,-1),checkpoint:checkpoint?.through||null};}
 function windowData(state,today,range='Max',closure=null){
  if(!ranges.includes(range))range='Max';const from=start(state.lot.date,today,range),end=today;
  const legacy=legacyRows(state),last=legacy.filter(r=>r!==state.openingBalance||r.mortality||r.discard||r.stockAdjustment||r.feed>0).map(r=>r.date).sort().at(-1),min=last?shift(last,1):state.lot.date;
  const records=new Map((state.daily||[]).map(r=>[r.date,r])),rows=[];
  const closing=closure?.version===1&&closure.policy==='missing-food-zero'&&/^\d{4}-\d{2}-\d{2}$/.test(closure.through||'')?closure.through:null;
  for(let date=from;date<=end;date=shift(date,1)){
   const record=records.get(date)||null,observed=finite(record?.feed),hasEntry=record?.entriesVersion===1&&Array.isArray(record.entries)&&record.entries.some(e=>finite(e?.feed));
   const automatic=!observed&&!hasEntry&&date>=min&&date<today&&closing!==null&&date<=closing,value=observed?record.feed:automatic?0:null;
   rows.push({date,record,value,automatic,status:automatic?'automatic':observed?'known':date<min?'legacy':'missing',editable:date>=min});
  }
  const known=rows.filter(r=>r.value!==null),older=legacy.filter(r=>finite(r.feed));
  return{range,start:from,end,rows,known,total:known.length?known.reduce((n,r)=>n+r.value,0):null,legacyTotal:older.reduce((n,r)=>n+r.feed,0),legacyKnown:older.length>0};
 }
 function series(view){
  if(view.range!=='1D')return view.rows.map((r,i)=>({...r,key:r.date,x:i}));
  const day=view.rows[0];if(!day)return[];const r=day.record;
  const entries=r?.entriesVersion===1&&Array.isArray(r.entries)?r.entries:r?[r]:[];
  return entries.map((entry,i)=>{const time=/^\d{2}:\d{2}$/.test(entry.time||'')?entry.time:'18:00',value=finite(entry.feed)?entry.feed:null;return{...day,key:entry.id||day.date+'-'+i,time,x:Number(time.slice(0,2))*60+Number(time.slice(3)),value,note:entry.note||'',kind:entry.kind||'dailyTotal'};}).sort((a,b)=>a.x-b.x);
 }
 function page(rows,date){if(!rows.length)return{rows:[],index:0,count:0};const index=Math.max(0,rows.findIndex(r=>r.date===date)),first=rows.length%7||7,pageIndex=index<first?0:1+Math.floor((index-first)/7),offset=pageIndex===0?0:first+(pageIndex-1)*7;return{rows:rows.slice(offset,offset+(pageIndex===0?first:7)),index:pageIndex,count:Math.ceil(rows.length/7)};}
 function pageDate(rows,date,step){const current=page(rows,date),target=Math.max(0,Math.min(current.count-1,current.index+step)),first=rows.length%7||7,offset=target===0?0:first+(target-1)*7;return rows[Math.min(rows.length-1,offset+(target===0?first:7)-1)]?.date||date;}
 function scale(max){if(!(max>0))return 1;const raw=max/3,power=10**Math.floor(Math.log10(raw)),step=[1,2,2.5,5,10].map(n=>n*power).find(n=>n>=raw);return Math.ceil(max/step)*step;}
 // Bounded representatives retain extrema; a prefix of missing values prevents
 // connecting across gaps skipped by reduction. Selected values always remain exact.
 function plot(points,selected=-1,limit=240){
  const missing=[0];for(const p of points)missing.push(missing.at(-1)+(p.value===null?1:0));
  const indices=new Set([0,points.length-1]);if(selected>=0)indices.add(selected);
  const width=points.length<=limit?1:Math.ceil(points.length/Math.max(1,Math.floor(limit/4)));
  for(let first=0;first<points.length;first+=width){const end=Math.min(points.length,first+width);let lo=-1,hi=-1;indices.add(first);indices.add(end-1);for(let i=first;i<end;i++)if(points[i].value!==null){if(lo<0||points[i].value<points[lo].value)lo=i;if(hi<0||points[i].value>points[hi].value)hi=i;}if(lo>=0)indices.add(lo);if(hi>=0)indices.add(hi);}
  const segments=[];let segment=[],previous=-1;
  for(const i of [...indices].filter(i=>i>=0&&i<points.length).sort((a,b)=>a-b)){
   if(points[i].value===null){if(segment.length)segments.push(segment);segment=[];previous=i;continue;}
   if(previous>=0&&missing[i]-missing[previous+1]>0){if(segment.length)segments.push(segment);segment=[];}
   segment.push({...points[i],index:i});previous=i;
  }
  if(segment.length)segments.push(segment);return{segments,reduced:points.length>limit};
 }
 return{ranges,finite,shift,span,monthsBack,start,closureForToday,windowData,series,page,pageDate,scale,plot};
});
