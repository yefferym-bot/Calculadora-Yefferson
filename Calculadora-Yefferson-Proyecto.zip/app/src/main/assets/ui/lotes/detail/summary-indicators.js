/* Consultas del resumen. No escribe registros, existencias ni movimientos. */
(function(root,factory){
 'use strict';
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.TruchAppLotIndicators=api;
})(typeof window==='object'?window:null,function(){
 'use strict';
 const finite=v=>typeof v==='number'&&Number.isFinite(v);
 const positive=v=>finite(v)&&v>0;
 const safe=v=>finite(v)?v:null;
 const sources=[
  {title:'Trucha arcoíris: K y crecimiento específico (2024)',url:'https://doi.org/10.3390/ani14172567'},
  {title:'Definiciones de CV y eficiencia alimenticia (2025)',url:'https://doi.org/10.47853/FAS.2025.e2'}
 ];
 function calculate(data,s){
  const last=s.last,previous=s.prev,p=s.period;
  const lengthSample=s.samples.slice().reverse().find(r=>positive(r.length))||null;
  const weights=Array.isArray(last.individualWeights)?last.individualWeights:[];
  const validWeights=weights.length>=2&&weights.every(positive);
  const mean=validWeights?weights.reduce((sum,w)=>sum+w/weights.length,0):null;
  const sd=validWeights?Math.sqrt(weights.reduce((sum,w)=>sum+(w-mean)**2,0)/(weights.length-1)):null;
  const days=previous?(Date.parse(last.date+'T12:00:00Z')-Date.parse(previous.date+'T12:00:00Z'))/86400000:0;
  const condition=positive(last.weight)&&positive(last.length)?safe(100*last.weight/(last.length**3)):null;
  const sgr=previous&&days>0&&positive(previous.weight)&&positive(last.weight)?safe(100*(Math.log(last.weight)-Math.log(previous.weight))/days):null;
  // Conserva la cobertura y la ganancia neta del FCR existente. TEA es su inversa
  // porcentual solo con alimento positivo; cero alimento no permite dividir.
  const efficiency=p?.complete&&positive(p.gain)&&positive(p.feed)?safe(100*p.gain/p.feed):null;
  const feedRows=[...data.samples.filter(r=>r.legacyPeriod),...(data.openingBalance?[data.openingBalance]:[]),...data.daily].filter(r=>finite(r.feed));
  const feedDate=feedRows.map(r=>r.date).sort().at(-1)||null;
  const density=positive(data.settings.volume)&&finite(s.biomass)?safe(s.biomass/data.settings.volume):null;
  return{condition,sgr,cv:validWeights&&positive(mean)?safe(sd/mean*100):null,cvCount:weights.length,cvMean:mean,cvSd:sd,efficiency,density,lengthSample,feedDate,days};
 }
 return{calculate,sources};
});
