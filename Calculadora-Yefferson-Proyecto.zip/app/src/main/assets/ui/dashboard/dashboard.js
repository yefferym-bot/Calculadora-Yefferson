/* TruchApp — Inicio operativo. Los registros productivos siguen perteneciendo a sus módulos. */
(function () {
  'use strict';
  const D=window.TruchAppHomeData;if(!D)return;
  const SETTINGS='truchapp_inicio_control_v1';
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=(v,n=0)=>D.num(v)===null?'—':Number(v).toLocaleString('es-PE',{maximumFractionDigits:n});
  const money=v=>D.num(v)===null?'—':'S/ '+fmt(v,2);
  const valuedCost=(value,unpriced)=>value===0&&unpriced>0?'Por valorizar':money(value);
  const short=d=>D.date(d)?.toLocaleDateString('es-PE',{day:'numeric',month:'short'})||'Sin fecha';
  const read=(k,f)=>{try{return JSON.parse(localStorage.getItem(k))??f;}catch(_){return f;}};
  const arr=x=>Array.isArray(x)?x.filter(v=>v&&typeof v==='object'):[];
  let state={center:'all',days:7,lot:'',metric:'weight',taskTab:'today',expanded:false},model=null,dialog=null,previousFocus=null,ready=false;
  try{const v=read(SETTINGS,{}).view||{};state={...state,center:String(v.center||'all'),days:v.days===30?30:7};}catch(_){}
  function icon(name){
    const paths={
      alert:'<path d="m10.3 4.6-8 14A1.6 1.6 0 0 0 3.7 21h16.6a1.6 1.6 0 0 0 1.4-2.4l-8-14a2 2 0 0 0-3.4 0Z"/><path d="M12 9v5M12 17v.2"/>',
      arrow:'<path d="M5 12h14m-5-5 5 5-5 5"/>',
      clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      check:'<path d="m5 12 4 4L19 6"/>',
      fish:'<path d="M5 12c4-8 11-8 16 0-5 8-12 8-16 0Z"/><path d="m5 12-4-4v8l4-4ZM15 8c-2 3-2 5 0 8"/><circle cx="17.5" cy="11" r=".7"/>',
      water:'<path d="M12 3c-3 5-7 8-7 12a7 7 0 0 0 14 0c0-4-4-7-7-12Z"/><path d="M8 15c0 2 1 3 3 3"/>',
      calendar:'<rect x="4" y="5" width="16" height="16" rx="3"/><path d="M8 3v4M16 3v4M4 10h16M8 14h3M8 17h2M14 16l2 2 4-5"/>',
      chart:'<path d="M4 3v17h17M8 16v-4M13 16V9M18 16V6"/>',
      sliders:'<path d="M4 6h8m4 0h4M4 12h2m4 0h10M4 18h10m4 0h2"/><circle cx="14" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="16" cy="18" r="2"/>',
      link:'<path d="m10 13 4-4M8 15l-1 1a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0M16 9l1-1a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0"/>',
      close:'<path d="m6 6 12 12M18 6 6 18"/>',
      plus:'<path d="M12 5v14M5 12h14"/>'
    };
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(paths[name]||paths.chart)+'</svg>';
  }
  function dataArray(key,nativeMethod){
    let raw=null;try{raw=localStorage.getItem(key);if(raw!==null)return arr(JSON.parse(raw));}catch(_){}
    try{if(window.AndroidAI&&nativeMethod&&typeof AndroidAI[nativeMethod]==='function')return arr(JSON.parse(AndroidAI[nativeMethod]()));}catch(_){}
    return [];
  }
  function collect(){
    let lots=[];try{lots=arr(window.TruchAppData?.getLots?.());}catch(_){}
    if(!window.TruchAppData?.getLots)lots=dataArray('truchapp_lotes_v1','getLots');
    let stock=null,stockError='';try{stock=window.TruchAppFeeding?.snapshot?.()||null;if(!stock)stockError='Los datos de alimentación todavía no están disponibles.';}catch(error){stockError=error.message||'Revisa los registros del almacén.';}
    return D.build({stock,stockError,agenda:read('truchapp_agenda_workbook_v1',{records:[],limits:{}}),lots,water:dataArray('truchapp_lotes_water_quality_v1'),centers:dataArray('truchapp_lotes_water_farms_v1'),
      activities:dataArray('activities','getActivities'),finance:read('truchapp_finance_v1',null),settings:read(SETTINGS,{}),view:state,now:new Date()});
  }
  function centerName(id){return model.centers.find(c=>c.id===id)?.name||'Sin centro asociado';}
  function scopeName(){return model.selectedCenter==='all'?'Todos los centros':model.selectedCenter==='unlinked'?'Registros sin centro':centerName(model.selectedCenter);}
  function age(m){
    if(m.age===null)return short(m.date)+' · Hora sin indicar';
    if(m.age<1)return 'Hace '+Math.max(0,Math.floor(m.age*60))+' min';
    if(m.age<24)return 'Hace '+Math.floor(m.age)+' h';
    return 'Hace '+Math.floor(m.age/24)+' días';
  }
  function alertRow(a,index){
    const meta=a.measurement?age(a.measurement)+' · '+short(a.measurement.date)+(a.measurement.time?' '+a.measurement.time:''):a.date?short(a.date)+(a.time?' · '+a.time:''):'';
    return `<button type="button" class="op-alert op-${a.tone}" data-op="alert" data-index="${index}"><span class="op-alert-icon">${icon(a.tone==='missing'?'clock':'alert')}</span><span class="op-alert-copy"><strong>${esc(a.title)}</strong><span>${esc(a.reason)}</span>${meta?'<small>'+esc(meta)+'</small>':''}<b>${esc(a.action)} →</b></span></button>`;
  }
  function summaryTile(value,label,glyph,metric,note){
    return `<button type="button" class="op-stat" data-op="lot-list" data-metric="${metric}"><span class="op-stat-icon">${icon(glyph)}</span><strong>${value}</strong><span>${label}</span>${note?'<small>'+note+'</small>':''}</button>`;
  }
  function chartMarkup(t){
    if(!t.points.length)return `<div class="op-chart-empty">${icon('chart')}<strong>Sin datos del periodo</strong><span>${esc(t.empty)}</span><button type="button" class="op-text-button" data-op="${t.lotId==='all'?'lotes':'lot'}" data-id="${esc(t.lotId)}">Registrar o consultar datos →</button></div>`;
    const width=600,height=218,left=53,right=16,top=18,bottom=34;
    const plotW=width-left-right,plotH=height-top-bottom;
    const values=t.points.map(p=>p.value),maxValue=Math.max(...values),minValue=Math.min(...values);
    const low=t.metric==='weight'?Math.max(0,minValue-Math.max((maxValue-minValue)*.15,minValue*.025,.01)):0;
    const high=t.metric==='mortality'?Math.max(3,Math.ceil((maxValue+1)/3)*3):Math.max(maxValue+Math.max((maxValue-low)*.15,.001),low+.001);
    const decimals=t.metric==='mortality'?0:maxValue<1?3:1;
    const start=D.date(model.range.start).getTime(),end=D.date(model.range.end).getTime();
    const x=p=>left+(D.date(p.date).getTime()-start)/Math.max(1,end-start)*plotW;
    const y=v=>top+(high-v)/(high-low)*plotH;
    const grid=Array.from({length:4},(_,i)=>{const value=high-(high-low)*i/3,yy=y(value);return `<path d="M${left} ${yy}H${width-right}" stroke="#e6efea"/><text x="${left-8}" y="${yy+4}" text-anchor="end">${fmt(value,decimals)}</text>`;}).join('');
    let marks='';
    if(t.metric==='weight'){
      const line=t.points.map((p,i)=>(i?'L':'M')+x(p).toFixed(1)+','+y(p.value).toFixed(1)).join(' ');
      marks=`<path d="${line}" fill="none" stroke="#188b7a" stroke-width="2.6"/>`+t.points.map(p=>`<circle cx="${x(p)}" cy="${y(p.value)}" r="4.5" fill="#188b7a" stroke="#fff" stroke-width="2"><title>${esc(short(p.date)+': '+fmt(p.value,2)+' '+t.unit)}</title></circle>`).join('');
    }else{
      const barW=Math.min(23,plotW/Math.max(t.points.length*1.8,10));
      marks=t.points.map(p=>`<rect x="${x(p)-barW/2}" y="${y(p.value)}" width="${barW}" height="${Math.max(.6,top+plotH-y(p.value))}" rx="3" fill="${t.metric==='mortality'?'#d58d6a':'#539b8a'}"><title>${esc(short(p.date)+': '+fmt(p.value,2)+' '+t.unit+' · '+p.detail)}</title></rect>`).join('');
    }
    const axis=`<text x="${left}" y="${height-10}">${esc(short(model.range.start))}</text><text x="${left+plotW/2}" y="${height-10}" text-anchor="middle">${esc(short(D.shift(model.range.start,model.range.days/2|0)))}</text><text x="${width-right}" y="${height-10}" text-anchor="end">${esc(short(model.range.end))}</text><text x="${left}" y="11">${esc(t.unit)}</text>`;
    return `<svg class="op-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(({weight:'Peso registrado',mortality:'Mortalidad registrada',feed:'Alimento por periodo'})[t.metric]+', '+t.points.length+' fechas con datos. Consulta los valores debajo de la gráfica.')}">${grid}${marks}${axis}</svg>`;
  }
  function trends(){
    const t=model.trend,labels={weight:'Peso',mortality:'Mortalidad',feed:'Alimento'},last=t.points[t.points.length-1];
    let headline=t.metric==='weight'?(last?fmt(last.value,last.value<1?3:1)+' g':'—'):t.points.length?fmt(t.points.reduce((s,p)=>s+p.value,0),t.metric==='feed'?3:0)+' '+t.unit:'—';
    let sub=t.metric==='weight'&&last?'Última biometría: '+short(last.date):t.metric==='feed'?'Periodos completos registrados':'Mortalidad registrada en el periodo';
    if(t.metric==='weight'&&t.points.length>1){const delta=last.value-t.points[0].value;sub=(delta>0?'+':'')+fmt(delta,Math.abs(delta)<1?3:1)+' g entre '+short(t.points[0].date)+' y '+short(last.date);}
    return `<section class="op-card" aria-labelledby="opTrendTitle"><div class="op-section-head"><div><span class="op-eyebrow">REGISTROS DEL PERIODO</span><h3 id="opTrendTitle">Evolución de los lotes</h3></div><span class="op-section-icon">${icon('chart')}</span></div>
      <label class="op-select-label" for="opChartLot">Lote para consultar</label><select id="opChartLot" class="op-select"><option value="all" ${t.lotId==='all'?'selected':''}>Todos los lotes del filtro</option>${model.scoped.map(l=>`<option value="${esc(l.id)}" ${t.lotId===l.id?'selected':''}>${esc(l.code)}</option>`).join('')}</select>
      <div class="op-tabs" role="group" aria-label="Indicador de la gráfica">${Object.entries(labels).map(([id,label])=>`<button type="button" data-op="metric" data-value="${id}" id="opMetric-${id}" class="${t.metric===id?'selected':''}" aria-pressed="${t.metric===id}">${label}</button>`).join('')}</div>
      <div class="op-chart-headline"><strong>${headline}</strong><span>${esc(sub)}</span></div>${chartMarkup(t)}<p class="op-caption">${esc(t.caption)}</p>
      ${t.points.length?`<details class="op-data-details"><summary>Ver valores registrados (${t.points.length})</summary><div class="op-data-scroll"><table><thead><tr><th>Fecha</th><th>Valor (${esc(t.unit)})</th><th>Registro</th></tr></thead><tbody>${t.points.slice().reverse().map(p=>`<tr><td>${esc(short(p.date))}</td><td>${fmt(p.value,2)}</td><td>${esc(p.detail)}</td></tr>`).join('')}</tbody></table></div></details>`:''}
      <div class="op-period-totals"><div><span>FCR del conjunto</span><b data-op-metric="fcr">${fmt(model.fcr.value,2)}</b></div><div><span>Alimento registrado</span><b>${fmt(model.summary.feed,2)} <small>kg</small></b></div><div><span>Mortalidad registrada</span><b>${fmt(model.summary.mortalityPeriod)} <small>peces</small></b></div></div>
      <p class="op-caption">${model.fcr.value===null?esc(model.fcr.reason):'FCR: '+esc(short(model.fcr.start))+'–'+esc(short(model.fcr.end))+' · '+fmt(model.fcr.count)+' lotes con existencias, alimento completo y fechas comunes.'}</p>
      ${model.summary.crossing?'<p class="op-caption">'+fmt(model.summary.crossing)+' periodos de alimento cruzan el inicio del intervalo y no se suman.</p>':''}
      <details class="op-data-details"><summary>Cómo interpretar estos indicadores</summary><p>El FCR del conjunto divide el alimento total entre la ganancia estimada de biomasa de los mismos lotes y fechas. La ganancia usa los cambios de peso y las existencias reconstruidas con mortalidad y descarte. Los valores de FCR anteriores de cada lote no se promedian.</p><p>Los puntos de la gráfica corresponden a registros. Un día sin registro no se convierte en cero. El alimento representa periodos entre muestreos; no se reparte como consumo diario.</p></details>
      </section>`;
  }
  function taskRows(){
    const tab=state.taskTab,items=tab==='overdue'?model.tasks.overdue:tab==='upcoming'?model.tasks.upcoming:model.tasks.today;
    const empty=tab==='today'?(model.tasks.totalToday?'Las actividades de hoy están completadas.':'No hay actividades pendientes para hoy.'):tab==='overdue'?'No hay pendientes vencidos en los registros consultados.':'No hay próximas actividades programadas.';
    return items.length?items.slice(0,6).map(t=>`<article class="op-task"><button type="button" class="op-task-main" data-op="task" data-id="${esc(t.id)}" data-date="${esc(t.date)}"><span class="op-task-dot ${t.high?'high':''}"></span><span><strong>${esc(t.title)}</strong><small>${t.date===model.today?'Hoy':esc(short(t.date))}${t.time?' · '+esc(t.time):''}${t.high?' · Prioridad alta':''}${t.overdue?' · Vencida':''}</small></span><i>${icon('arrow')}</i></button>${t.lotId||t.lotCode?`<button type="button" class="op-task-lot" data-op="task-lot" data-id="${esc(t.lotId||t.lotCode)}">${icon('fish')}${esc(t.lotCode||model.lots.find(l=>l.id===String(t.lotId))?.code||'Ver lote')}</button>`:''}</article>`).join('')+(items.length>6?'<p class="op-caption">Mostrando 6 de '+items.length+' actividades. Consulta el resto en Agenda.</p>':''):`<div class="op-empty-inline">${icon('calendar')}<span>${empty}</span></div>`;
  }
  function projection(){
    const f=model.finance;
    return `<section class="op-card op-finance" aria-labelledby="opFinanceTitle"><div class="op-section-head"><div><span class="op-eyebrow">PROYECCIÓN DEL CICLO</span><h3 id="opFinanceTitle">Resumen económico</h3></div><button type="button" class="op-text-button" data-op="finanzas">Abrir ${icon('arrow')}</button></div>
      ${f.available?`<div class="op-finance-main"><span>${f.profit<0?'Pérdida estimada':'Utilidad estimada'}</span><strong class="${f.profit<0?'op-negative':''}" data-op-metric="profit">${money(f.profit)}</strong><small>${esc(f.center?centerName(f.center):'Proyección general sin centro asociado')}</small></div><div class="op-finance-pair"><div><span>Ingreso estimado</span><b>${money(f.revenue)}</b></div><div><span>Costo del ciclo</span><b>${valuedCost(f.cost,f.unpriced)}</b></div></div><p class="op-caption">Alimento estimado: ${money(f.feedCost)} · Margen: ${fmt(f.margin,1)}%. Valores calculados con los datos guardados en Finanzas.</p>`:`<p class="op-empty-copy">${esc(f.reason)}</p><button type="button" class="op-soft-button" data-op="${model.selectedCenter==='all'?'finanzas':'settings'}">${model.selectedCenter==='all'?'Completar proyección':'Revisar asociación del centro'} →</button>`}
      ${f.associationChanged?'<button type="button" class="op-text-button" data-op="settings">La proyección cambió: confirma su centro →</button>':''}<p class="op-finance-note">La proyección guardada corresponde a un ciclo. No representa ventas mensuales ni la suma de todas las granjas.</p></section>`;
  }
  function smallMetric(label,value,note=''){return `<div><span>${label}</span><strong>${value}</strong>${note?'<small>'+note+'</small>':''}</div>`;}
  function feedingPanel(){
    const f=model.decisions.feeding,w=model.decisions.warehouse,planned=f.planned===null?'—':fmt(f.planned,2)+' kg',actual=f.actual===null?'—':fmt(f.actual,2)+' kg';
    return `<section class="op-card op-feed-panel" aria-labelledby="opFeedTitle"><div class="op-section-head"><div><span class="op-eyebrow">ORGANIZAR LAS ENTREGAS</span><h3 id="opFeedTitle">Alimentación y existencias</h3></div><button type="button" class="op-text-button" data-op="feeding-detail">Ver detalle ${icon('arrow')}</button></div>
      <button type="button" class="op-read-metrics" data-op="feeding-detail" aria-label="Ver alimentación planificada y registrada por lote">${smallMetric('Planificado hoy',planned,f.planKnown+'/'+f.planTotal+' tareas con cantidad')}${smallMetric('Registrado hoy',actual,fmt(f.coverage)+'/'+fmt(model.scoped.length)+' lotes con dato')}</button>
      <div class="op-inline-summary"><span>${fmt(f.pending)} entregas pendientes en Agenda</span><button type="button" class="op-text-button" data-op="agenda">Abrir Agenda →</button></div>
      <p class="op-caption">Alimento valorizado hoy: <b>${w.error?'—':valuedCost(f.cost,f.unpriced)}</b>${f.unpriced>0?' · '+fmt(f.unpriced,2)+' kg sin valorizar':''}. La cantidad planificada es la que registraste en tus tareas.</p>
      <div class="op-stock-head"><strong>Disponibilidad de alimento</strong><span>Almacén global</span></div>
      ${w.error?'<p class="op-empty-copy">'+esc(w.error)+'</p>':w.products.length?`<div class="op-stock-list">${w.products.slice(0,2).map(p=>`<button type="button" class="op-stock-row ${p.low||p.negative?'op-stock-warning':''}" data-op="stock"><span><strong>${esc(p.name)}</strong><small>${p.negative?'Saldo por revisar':fmt(p.usableKg,2)+' kg utilizables'}${p.soonKg>0?' · '+fmt(p.soonKg,2)+' kg próximos a vencer':''}${p.expiredKg>0?' · '+fmt(p.expiredKg,2)+' kg vencidos':''}</small></span><b>${p.days===null?'Sin estimación':fmt(p.days,1)+' días'}<small>${p.active?'Cobertura estimada':'Producto inactivo'}</small></b></button>`).join('')}</div>`:'<p class="op-empty-copy">Registra un alimento y sus entradas en Almacén para consultar disponibilidad.</p>'}
      <button type="button" class="op-text-button op-full-link" data-op="stock">Ver existencias y vencimientos ${icon('arrow')}</button>
    </section>`;
  }
  function spark(p){
    const max=Math.max(1,...p.points.map(d=>d.value||0)),step=21,width=Math.max(70,p.points.length*step),bars=p.points.map((d,i)=>{const h=d.value===null?8:Math.max(d.value>0?3:1,d.value/max*26);return `<rect x="${i*step+4}" y="${31-h}" width="12" height="${h}" rx="2" ${d.value===null?'fill="none" stroke="#b5c6bd" stroke-dasharray="2 2"':'fill="'+(p.increase?'#c58065':'#6aab90')+'"'}><title>${esc(short(d.date)+': '+(d.value===null?'Sin dato':fmt(d.value)+' muertes'))}</title></rect>`}).join('');
    return `<svg class="op-spark" viewBox="0 0 ${width} 35" role="img" aria-label="${esc(p.code+': mortalidad de los últimos siete días. '+p.points.map(d=>short(d.date)+': '+(d.value===null?'sin dato':d.value)).join('; '))}">${bars}</svg>`;
  }
  function performancePanel(){
    const all=model.decisions.performance,ordered=all.slice().sort((a,b)=>Number(b.increase||b.growthPerDay<0)-Number(a.increase||a.growthPerDay<0)||Number(b.partial)-Number(a.partial)||(b.bioAge||0)-(a.bioAge||0));
    return `<section class="op-card" aria-labelledby="opLotPerformanceTitle"><div class="op-section-head"><div><span class="op-eyebrow">CAMBIOS RECIENTES</span><h3 id="opLotPerformanceTitle">Qué lote conviene revisar</h3></div><button type="button" class="op-text-button" data-op="performance">Ver ${fmt(all.length)} ${icon('arrow')}</button></div>
      ${ordered.length?`<div class="op-performance-list">${ordered.slice(0,2).map(p=>`<button type="button" class="op-performance-row" data-op="performance" data-id="${esc(p.id)}"><span class="op-performance-top"><strong>${esc(p.code)}</strong><span class="op-evidence-tag ${p.increase||p.growthPerDay<0?'warning':''}">${p.increase?'Más mortalidad':p.growthPerDay<0?'Revisar peso':!p.partial&&p.expected>0?'Seguimiento registrado':'Faltan registros'}</span></span><span class="op-performance-data"><span><b>${fmt(p.mortality)}</b> muertes en 7 días<small>${p.coverage}/${p.expected} días con dato${p.comparable?' · antes: '+fmt(p.previousMortality):''}</small></span>${spark(p)}</span><small>${p.hasFollowup?'Biometría':'Peso de ingreso'}: ${p.bioDate?esc(short(p.bioDate)):'sin dato'}${p.bioAge!==null?' · hace '+p.bioAge+' días':''} · Crecimiento: ${fmt(p.growthPerDay,2)} g/día</small></button>`).join('')}</div>`:'<p class="op-empty-copy">Los cambios por lote aparecerán cuando registres producción y controles diarios.</p>'}
      <button type="button" class="op-quality-button" data-op="quality">${icon('clock')} Fechas y registros disponibles ${icon('arrow')}</button>
    </section>`;
  }
  function economic(){
    const e=model.decisions.economics;
    return `<section class="op-card op-real-cost" aria-labelledby="opRealCostTitle"><div class="op-section-head"><div><span class="op-eyebrow">SEGÚN ENTREGAS VINCULADAS</span><h3 id="opRealCostTitle">Costo de alimentación registrado</h3></div><button type="button" class="op-text-button" data-op="costs">Por lote ${icon('arrow')}</button></div>
      <div class="op-real-cost-value"><strong>${e.error?'—':valuedCost(e.cost,e.unpriced)}</strong><span>${esc(short(D.shift(model.range.start,1)))} – ${esc(short(model.today))} · ${fmt(e.linkedKg,2)} kg valorizados</span></div>
      <p class="op-caption">${e.error?esc(e.error):e.unpriced>0?'Valoración parcial: '+fmt(e.unpriced,2)+' kg de alimento registrado sin costo vinculado.':e.covered<model.scoped.length?'Hay lotes sin consumos registrados en este periodo.':'Importe de alimento según registros del periodo.'}${e.excluded?' '+fmt(e.excluded)+' saldos o periodos antiguos sin desglose no se distribuyen por día.':''}</p>
      <button class="op-cost-unit" type="button" data-op="costs"><span>Alimento por kg ganado<small>${e.unitCost===null?'Consultar el intervalo completo de cada lote':esc(short(e.unitStart))+' – '+esc(short(e.unitEnd))+' · mismas fechas en todos los lotes'}</small></span><b>${e.error?'—':e.unitCost===null?'Por lote':money(e.unitCost)+'/kg'}</b></button>
      <p class="op-caption">El costo por kg ganado usa el aumento neto de biomasa entre biometrías. Estos importes corresponden al alimento; los demás gastos se consultan en Finanzas.</p>
      <details class="op-projection-fold" data-op-detail="projection"><summary>Consultar proyección económica del ciclo</summary>${projection()}</details>
    </section>`;
  }
  function feedDetail(){
    const f=model.decisions.feeding;
    openDialog('Alimentación de hoy',`<p class="op-dialog-help">${esc(scopeName())} · ${esc(short(model.today))}. Lo registrado se consulta una sola vez desde el día del lote, incluso si se guardó desde Agenda.</p>${f.rows.map(r=>`<section class="op-detail-block"><h4>${esc(r.code)} · ${esc(r.unit||'')}</h4><dl class="op-definition-list"><div><dt>Plan registrado</dt><dd>${fmt(r.planned,2)} kg · ${r.planKnown}/${r.planTotal} tareas con cantidad</dd></div><div><dt>Cantidad del día</dt><dd>${fmt(r.actual,2)} kg</dd></div><div><dt>Entregas pendientes</dt><dd>${r.pending}</dd></div><div><dt>Diferencia con el plan</dt><dd>${r.planned!==null&&r.actual!==null&&r.planKnown===r.planTotal?fmt(r.actual-r.planned,2)+' kg':'Faltan datos comparables'}</dd></div><div><dt>Costo vinculado</dt><dd>${model.decisions.warehouse.error?'—':valuedCost(r.cost,r.unpriced)}${r.unpriced>0?' · '+fmt(r.unpriced,2)+' kg sin valorizar':''}</dd></div></dl><button type="button" class="op-soft-button" data-op="${r.next?'task':'lot'}" data-id="${esc(r.next?.id||r.id)}" data-date="${esc(r.next?.date||'')}">${r.next?'Registrar entrega pendiente':'Abrir lote'} →</button></section>`).join('')||'<p class="op-empty-copy">No hay lotes en este filtro.</p>'}<p class="op-dialog-help">La diferencia describe tus registros y no indica una ración adicional. Revisa las condiciones del lote y tu protocolo antes de modificar la alimentación.</p>`);
  }
  function stockDetail(){
    const w=model.decisions.warehouse;
    openDialog('Existencias de alimento',`<p class="op-dialog-help">Almacén global: esta disponibilidad se comparte entre todos los centros. La cobertura es una estimación con salidas y ajustes registrados; supone un ritmo constante de uso. Revisa también los vencimientos de los lotes del alimento.</p>${w.error?'<p class="op-dialog-help">'+esc(w.error)+'</p>':w.products.map(p=>`<section class="op-detail-block"><h4>${esc(p.name)}</h4><dl class="op-definition-list"><div><dt>Utilizable hoy</dt><dd>${fmt(p.usableKg,2)} kg</dd></div><div><dt>Cobertura estimada</dt><dd>${fmt(p.days,1)} días</dd></div><div><dt>Salidas y ajustes medios</dt><dd>${fmt(p.average,2)} kg/día · ${p.windowDays} días</dd></div><div><dt>Vencidos</dt><dd>${fmt(p.expiredKg,2)} kg</dd></div><div><dt>Vencen en 14 días</dt><dd>${fmt(p.soonKg,2)} kg</dd></div><div><dt>Sin fecha de vencimiento</dt><dd>${fmt(p.unknownExpiryKg,2)} kg</dd></div></dl>${p.days===null?'<p class="op-dialog-help">'+(p.negative?'Corrige los saldos negativos para poder estimar cobertura.':'Faltan salidas registradas para estimar cuánto durará este alimento.')+'</p>':''}<div class="op-data-scroll"><table><thead><tr><th>Lote del alimento</th><th>Saldo kg</th><th>Vence</th></tr></thead><tbody>${p.batches.map(b=>`<tr><td>${esc(b.batch)}</td><td>${fmt(b.kg,2)}</td><td>${b.expiry?esc(short(b.expiry)):'Sin fecha'}</td></tr>`).join('')}</tbody></table></div></section>`).join('')||'<p class="op-empty-copy">No hay alimentos convertibles a kg en Almacén.</p>'}<button type="button" class="op-soft-button" data-op="almacen">Abrir Almacén →</button>`);
  }
  function performanceDetail(id='',qualityOnly=false){
    const rows=model.decisions.performance.filter(p=>!id||p.id===id);
    openDialog(qualityOnly?'Fechas y cobertura de registros':'Rendimiento por lote',rows.map(p=>`<section class="op-detail-block"><h4>${esc(p.code)} · ${esc(p.stage||'')}</h4><dl class="op-definition-list"><div><dt>${p.hasFollowup?'Última biometría':'Peso de ingreso'}</dt><dd>${p.bioDate?esc(short(p.bioDate)):'Sin dato'}${p.bioAge!==null?' · hace '+p.bioAge+' días':''}</dd></div><div><dt>Mortalidad registrada</dt><dd>${p.coverage}/${p.expected} días · ${fmt(p.mortality)} peces</dd></div><div><dt>Descarte registrado</dt><dd>${p.discardCoverage}/${p.expected} días · ${fmt(p.discard)} peces</dd></div><div><dt>Alimento registrado</dt><dd>${p.feedCoverage}/${p.expected} días</dd></div><div><dt>Semana anterior</dt><dd>${p.comparable?fmt(p.previousMortality)+' muertes':'Comparación pendiente: faltan dos semanas completas'}</dd></div><div><dt>Crecimiento observado</dt><dd>${fmt(p.growthPerDay,2)} g/día${p.growthStart?' · '+esc(short(p.growthStart))+' – '+esc(short(p.growthEnd)):''}</dd></div><div><dt>FCR del último intervalo</dt><dd>${fmt(p.fcr,2)}${p.fcrStart?' · '+esc(short(p.fcrStart))+' – '+esc(short(p.fcrEnd)):''}</dd></div></dl>${spark(p)}<p class="op-dialog-help">La biomasa utiliza el último peso guardado. Un espacio sin registro permanece sin dato; una barra con valor cero requiere un registro confirmado.</p><button type="button" class="op-soft-button" data-op="lot" data-id="${esc(p.id)}">Abrir lote →</button></section>`).join('')||'<p class="op-empty-copy">Todavía no hay lotes para consultar.</p>');
  }
  function costsDetail(){
    const e=model.decisions.economics;
    openDialog('Costo alimentario por lote',`<p class="op-dialog-help">Importes registrados entre ${esc(short(D.shift(model.range.start,1)))} y ${esc(short(model.today))}. El costo por kg ganado corresponde al último intervalo entre biometrías de cada lote, indicado con sus fechas.</p>${e.error?'<p class="op-dialog-help">'+esc(e.error)+'</p>':''}${e.rows.map(r=>`<section class="op-detail-block"><h4>${esc(r.code)}</h4><dl class="op-definition-list"><div><dt>Alimento valorizado del periodo</dt><dd>${e.error?'—':valuedCost(r.cost,r.unpriced)}</dd></div><div><dt>Sin valorizar</dt><dd>${fmt(r.unpriced,2)} kg</dd></div><div><dt>Días con alimento registrado</dt><dd>${r.days}</dd></div><div><dt>Último intervalo biométrico</dt><dd>${r.period?esc(short(r.period.start))+' – '+esc(short(r.period.end)):'Falta seguimiento'}</dd></div><div><dt>Alimento por kg ganado</dt><dd>${!e.error&&r.period?.ready?money(r.period.costPerKgGain)+'/kg':'Por completar'}</dd></div></dl><p class="op-dialog-help">${esc(r.period?.reason||r.reason)}</p><button type="button" class="op-soft-button" data-op="lot" data-id="${esc(r.id)}">Revisar lote →</button></section>`).join('')||'<p class="op-empty-copy">No hay lotes en este filtro.</p>'}`);
  }
  function waterDetail(){
    const points=model.measurements.slice().sort((a,b)=>Number(b.fresh&&b.review)-Number(a.fresh&&a.review)||Number(a.fresh)-Number(b.fresh));
    openDialog('Control del agua',`<p class="op-dialog-help">Cada medición conserva su punto, fecha y hora. Los rangos de cada lote se comparten con Agenda; los puntos sin lote utilizan los ajustes generales.</p>${points.map(m=>`<section class="op-detail-block"><h4>${esc(m.place)}</h4><dl class="op-definition-list"><div><dt>${esc(m.label)}</dt><dd>${fmt(m.value,2)} ${esc(m.unit)}</dd></div><div><dt>Medición</dt><dd>${esc(short(m.date))} ${esc(m.time)} · ${esc(age(m))}</dd></div><div><dt>Estado del dato</dt><dd>${m.fresh?(m.review?'Fuera del rango configurado':'Reciente'):'Actualizar medición'}</dd></div><div><dt>Vigencia configurada</dt><dd>${m.maxAgeHours} h · ${m.limitSource==='lote'?'rango del lote':'rango general'}</dd></div></dl><button type="button" class="op-soft-button" data-op="water-item" data-farm="${esc(m.farmId)}" data-id="${esc(m.lotId)}">Consultar / registrar →</button></section>`).join('')||'<p class="op-empty-copy">Faltan mediciones para evaluar el agua.</p>'}`);
  }
  function persistView(){
    try{localStorage.setItem(SETTINGS,JSON.stringify({...read(SETTINGS,{}),view:{center:state.center,days:state.days}}));}catch(_){announce('El filtro no pudo guardarse; seguirá activo mientras uses esta pantalla.');}
  }
  function render(){
    const root=document.getElementById('dashboardRoot');if(!root || dialog)return;
    const focused=document.activeElement?.id,opened=[...root.querySelectorAll('details[data-op-detail][open]')].map(d=>d.dataset.opDetail);
    model=collect();state.center=model.selectedCenter;state.lot=model.trend.lotId;
    const s=model.summary,visible=state.expanded?model.alerts:model.alerts.slice(0,3);
    const attention=model.alerts.filter(a=>['danger','warning'].includes(a.tone)).length;
    const core=['oxygen','temperature'].map(p=>model.measurements.filter(m=>m.parameter===p).sort((a,b)=>((b.fresh&&b.review?4:!b.fresh?3:b.review?2:1)-(a.fresh&&a.review?4:!a.fresh?3:a.review?2:1))||(b.stamp||0)-(a.stamp||0))[0]).filter(Boolean);
    const completed=model.tasks.completedToday.length,total=model.tasks.totalToday,progress=total?completed/total*100:0;
    root.innerHTML=`<div class="op-home">
      <div class="op-top"><div><h2>Inicio</h2><p>${esc(model.now.toLocaleDateString('es-PE',{weekday:'long',day:'numeric',month:'long'}))}</p></div><button type="button" class="op-icon-button" data-op="settings" id="opSettings" aria-label="Configurar centros, vínculos y límites de Inicio">${icon('sliders')}</button></div>
      <div class="op-filter-row"><label for="opCenter" class="op-filter"><span>Granja / centro</span><select id="opCenter" class="op-select"><option value="all">Todos los centros</option>${model.centers.map(c=>`<option value="${esc(c.id)}" ${state.center===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}<option value="unlinked" ${state.center==='unlinked'?'selected':''}>Sin centro asociado</option></select></label><button type="button" class="op-link-button" data-op="settings">${icon('link')}<span>Vincular<br>registros</span></button></div>
      <section class="op-hero op-state-${model.state.tone}" aria-labelledby="opHeroTitle"><div><span class="op-eyebrow">CONTROL DE TU GRANJA</span><h3 id="opHeroTitle">${esc(model.state.title)}</h3><p>${esc(scopeName())} · ${attention?fmt(attention)+' avisos de revisión':model.state.tone==='good'?'Últimos registros consultados':'Revisa la información pendiente'}</p></div><img src="ui/dashboard/trout.svg" alt="" width="140" height="82"><span class="op-hero-tag"><i></i>Datos guardados</span></section>
      <section class="op-card" aria-labelledby="opPriorityTitle"><div class="op-section-head"><div><span class="op-eyebrow">QUÉ ATENDER PRIMERO</span><h3 id="opPriorityTitle">Atención prioritaria</h3></div><span class="op-count ${attention?'op-count-alert':''}" data-op-metric="alerts">${fmt(model.alerts.length)}</span></div><div class="op-alert-list">${visible.length?visible.map(a=>alertRow(a,model.alerts.indexOf(a))).join(''):'<div class="op-clear">'+icon('check')+'<span>No se detectan avisos en los registros disponibles.</span></div>'}</div>
      ${model.alerts.length>3?`<button type="button" class="op-expand" data-op="expand">${state.expanded?'Mostrar menos':'Ver los '+fmt(model.alerts.length)+' avisos'}</button>`:''}
      <div class="op-coverage"><span><b>${fmt(model.coverage.fresh)}/${fmt(model.coverage.total)}</b> lotes o puntos de centro con O₂ y temperatura recientes</span><small>Rango y vigencia por lote compartidos con Agenda</small></div>
      ${core.length?`<div class="op-latest-water">${core.map(m=>`<button type="button" data-op="water-item" data-parameter="${m.parameter}" data-farm="${esc(m.farmId)}" data-id="${esc(m.lotId)}" class="${m.fresh?'':'op-stale'} ${m.fresh&&m.review?'op-water-warning':''}"><span>${esc(m.label)} <i>${m.fresh?(m.review?'Revisar':'Reciente'):'Actualizar'}</i></span><strong>${fmt(m.value,2)} <small>${esc(m.unit)}</small></strong><small>${esc(m.place)} · ${esc(short(m.date))} ${esc(m.time)} · ${esc(age(m))}</small></button>`).join('')}</div>`:''}<button type="button" class="op-text-button op-full-link" data-op="water-detail">Ver puntos y mediciones →</button></section>
      ${feedingPanel()}
      <section aria-labelledby="opProductionTitle"><div class="op-section-head op-outside-head"><h3 id="opProductionTitle">Resumen productivo</h3><button type="button" class="op-text-button" data-op="lotes">Ver lotes ${icon('arrow')}</button></div><div class="op-stats">
      ${summaryTile(fmt(s.lots),'Lotes registrados','fish','lots','Del filtro actual')}${summaryTile(fmt(s.fish),'Peces en existencia','fish','fish','Últimas existencias guardadas')}${summaryTile(fmt(s.biomass,1)+' <small>kg</small>','Biomasa actual','chart','biomass','Calculada con peso y existencias')}${summaryTile(s.survival===null?'—':fmt(s.survival,1)+'<small>%</small>','Supervivencia acumulada','water','survival','Respecto a los peces iniciales')}</div><div class="op-daily-note"><span>Mortalidad registrada hoy<small>${fmt(s.mortalityTodayCoverage)}/${fmt(s.lots)} lotes con registro hoy</small></span><b data-op-metric="mortalityToday">${fmt(s.mortalityToday)}${s.mortalityToday===null?'':' peces'}</b></div></section>
      <div class="op-period-bar"><div><span class="op-eyebrow">PERIODO DE ANÁLISIS</span><p>${esc(short(model.range.start))} — ${esc(short(model.range.end))}</p></div><div class="op-period-switch" role="group" aria-label="Periodo de análisis"><button type="button" data-op="period" data-value="7" id="opPeriod7" class="${state.days===7?'selected':''}" aria-pressed="${state.days===7}">7 días</button><button type="button" data-op="period" data-value="30" id="opPeriod30" class="${state.days===30?'selected':''}" aria-pressed="${state.days===30}">30 días</button></div></div>
      ${performancePanel()}
      ${trends()}
      <section class="op-card" aria-labelledby="opWorkTitle"><div class="op-section-head"><div><span class="op-eyebrow">QUÉ HACER HOY</span><h3 id="opWorkTitle">Trabajo de hoy</h3></div><button type="button" class="op-icon-button op-small-icon" data-op="new-activity" aria-label="Crear una actividad">${icon('plus')}</button></div><div class="op-work-progress"><span>${fmt(completed)} de ${fmt(total)} completadas hoy</span><b>${fmt(progress)}%</b><div><i style="width:${progress}%"></i></div></div><div class="op-tabs" role="group" aria-label="Actividades a mostrar">${[['today','Hoy',model.tasks.today.length],['overdue','Vencidas',model.tasks.overdue.length],['upcoming','Próximas',model.tasks.upcoming.length]].map(([id,label,count])=>`<button type="button" id="opTaskTab-${id}" data-op="task-tab" data-value="${id}" class="${state.taskTab===id?'selected':''}" aria-pressed="${state.taskTab===id}">${label} <small>${fmt(count)}</small></button>`).join('')}</div><div class="op-task-list">${taskRows()}</div><p class="op-caption">${state.center==='all'?'Las actividades repetidas se consultan por fecha.':'Solo se muestran actividades vinculadas a los lotes de este filtro.'} Para repeticiones vencidas se revisan los últimos ${state.days} días.</p><button type="button" class="op-text-button op-full-link" data-op="agenda">Abrir Agenda ${icon('arrow')}</button></section>
      ${economic()}<div class="op-footer"><span class="op-legend-dot danger"></span>Revisar <span class="op-legend-dot warning"></span>Pendiente <span class="op-legend-dot missing"></span>Faltan datos</div><div id="opAnnouncement" class="op-announcement" role="status" aria-live="polite"></div>
      </div>`;
    opened.forEach(id=>{const d=[...root.querySelectorAll('details[data-op-detail]')].find(d=>d.dataset.opDetail===id);if(d)d.open=true});
    if(focused && document.getElementById(focused))document.getElementById(focused).focus({preventScroll:true});
  }
  function announce(text){const el=document.getElementById('opAnnouncement');if(el)el.textContent=text;}
  function closeDialog(){if(dialog){const current=dialog;dialog=null;try{current.close();}catch(_){}current.remove();if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});}}
  function openDialog(title,body){
    closeDialog();previousFocus=document.activeElement;
    dialog=document.createElement('dialog');dialog.className='op-dialog';dialog.setAttribute('aria-labelledby','opDialogTitle');
    dialog.innerHTML=`<div class="op-dialog-head"><h3 id="opDialogTitle">${esc(title)}</h3><button type="button" class="op-icon-button" data-op="close" aria-label="Cerrar">${icon('close')}</button></div><div class="op-dialog-body">${body}</div>`;
    document.getElementById('dashboardRoot').appendChild(dialog);
    const current=dialog;current.addEventListener('close',()=>{if(dialog===current)dialog=null;current.remove();if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});});
    current.addEventListener('click',event=>{if(event.target===current){const r=current.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeDialog();}});
    if(typeof current.showModal==='function')current.showModal();else current.setAttribute('open','');
    return current;
  }
  function settingsDialog(){
    const c=model.config;
    const options=selected=>'<option value="">Sin centro asociado</option>'+model.centers.map(f=>`<option value="${esc(f.id)}" ${selected===f.id?'selected':''}>${esc(f.name)}</option>`).join('');
    const html=`<form id="opSettingsForm"><h4>Vincular lotes a sus centros</h4><p class="op-dialog-help">Usa los centros registrados en Calidad del agua. Los vínculos permiten filtrar producción y actividades.</p>${model.lots.length?model.lots.map((l,i)=>`<label class="op-form-field"><span>${esc(l.code)}${model.inferred.has(l.id)?'<small>Centro identificado en sus mediciones</small>':''}</span><select name="lot-${i}" class="op-select">${options(model.centerByLot.get(l.id))}</select></label>`).join(''):'<p class="op-dialog-help">Primero registra un lote en Lotes.</p>'}${!model.centers.length?'<button type="button" class="op-soft-button" data-op="water">+ Crear un centro en Calidad del agua</button>':''}
      <h4>Proyección económica</h4><label class="op-form-field"><span>Centro al que corresponde la proyección guardada</span><select name="financeCenter" class="op-select">${options(c.financeCenter)}</select></label><p class="op-dialog-help">Finanzas conserva una proyección de ciclo. Así puedes identificarla al filtrar por centro.</p>
      <h4>Vigencia de las mediciones</h4><label class="op-form-field"><span>Considerar reciente durante (horas)</span><input name="freshness" type="number" min="1" max="720" step="1" required value="${c.freshnessHours}"></label>
      <h4>Rangos generales de Inicio y Agenda</h4><p class="op-dialog-help">Estos rangos se aplican cuando el lote no tiene sus propios límites en Agenda. Ajústalos a tu protocolo, etapa y sistema. Dejar un límite vacío desactiva su aviso.</p><div class="op-form-grid"><label class="op-form-field"><span>Oxígeno mínimo (mg/L)</span><input name="oxygenMin" type="number" min="0" max="30" step="0.1" value="${c.limits.oxygenMin??''}"></label><label class="op-form-field"><span>CO₂ máximo (mg/L)</span><input name="co2Max" type="number" min="0.01" max="200" step="0.01" value="${c.limits.co2Max??''}"></label><label class="op-form-field"><span>pH mínimo</span><input name="phMin" type="number" min="0" max="14" step="0.1" value="${c.limits.phMin??''}"></label><label class="op-form-field"><span>pH máximo</span><input name="phMax" type="number" min="0" max="14" step="0.1" value="${c.limits.phMax??''}"></label><label class="op-form-field"><span>Temperatura mínima (°C)</span><input name="temperatureMin" type="number" min="-5" max="50" step="0.1" value="${c.limits.temperatureMin??''}"></label><label class="op-form-field"><span>Temperatura máxima (°C)</span><input name="temperatureMax" type="number" min="-5" max="50" step="0.1" value="${c.limits.temperatureMax??''}"></label></div><label class="op-form-field"><span>Cobertura objetivo de alimento (días)</span><input name="stockDays" type="number" min="1" max="90" step="1" required value="${c.stockDays}"></label><p class="op-form-error" id="opSettingsError" role="alert"></p><div class="op-form-actions"><button type="button" class="op-soft-button" data-op="close">Cancelar</button><button type="submit" class="op-primary-button">Guardar ajustes</button></div></form>`;
    const node=openDialog('Configurar Inicio',html),form=node.querySelector('form');
    form.addEventListener('submit',event=>{
      event.preventDefault();const fd=new FormData(form),number=name=>fd.get(name)===''?null:Number(fd.get(name)),phMin=number('phMin'),phMax=number('phMax'),temperatureMin=number('temperatureMin'),temperatureMax=number('temperatureMax');
      if(phMin!==null&&phMax!==null&&phMin>=phMax){node.querySelector('#opSettingsError').textContent='El pH mínimo debe ser menor que el máximo.';return;}
      if(temperatureMin!==null&&temperatureMax!==null&&temperatureMin>=temperatureMax){node.querySelector('#opSettingsError').textContent='La temperatura mínima debe ser menor que la máxima.';return;}
      const assignments=Object.create(null);model.lots.forEach((l,i)=>assignments[l.id]=String(fd.get('lot-'+i)||''));
      const next={...read(SETTINGS,{}),assignments,financeCenter:String(fd.get('financeCenter')||''),financeSignature:D.financeSignature(read('truchapp_finance_v1',null)),freshnessHours:Number(fd.get('freshness')),
        stockDays:number('stockDays'),limits:{oxygenMin:number('oxygenMin'),co2Max:number('co2Max'),phMin,phMax,temperatureMin,temperatureMax},view:{center:state.center,days:state.days}};
      try{localStorage.setItem(SETTINGS,JSON.stringify(next));}catch(_){node.querySelector('#opSettingsError').textContent='No se pudieron guardar los ajustes. Libera espacio o vuelve a intentarlo.';return;}
      closeDialog();window.dispatchEvent(new CustomEvent('truchapp-home-settings-updated'));render();announce('Rangos compartidos, vínculos y cobertura guardados.');
    });
  }
  function lotList(metric){
    const labels={lots:'Lotes del filtro',fish:'Existencias por lote',biomass:'Biomasa por lote',survival:'Supervivencia por lote'};
    const lots=model.scoped.slice().sort((a,b)=>metric==='survival'?(a.survivalPct??100)-(b.survivalPct??100):metric==='biomass'?b.biomassKg-a.biomassKg:metric==='fish'?b.fish-a.fish:a.code.localeCompare(b.code));
    openDialog(labels[metric]||labels.lots,`<p class="op-dialog-help">${esc(scopeName())} · Últimos valores guardados</p>${lots.length?lots.map(l=>`<button type="button" class="op-lot-row" data-op="lot" data-id="${esc(l.id)}"><span><strong>${esc(l.code)}</strong><small>${fmt(l.fish)} peces · ${fmt(l.weightG,1)} g · ${fmt(l.biomassKg,1)} kg</small></span><b>${metric==='survival'?fmt(l.survivalPct,1)+'%':icon('arrow')}</b></button>`).join(''):'<p class="op-empty-copy">No hay lotes en este filtro.</p>'}<button type="button" class="op-soft-button" data-op="lotes">Abrir módulo Lotes →</button>`);
  }
  function route(target,after){
    closeDialog();const button=document.querySelector('.bottom .nav[data-target="'+target+'"]');if(!button)return;
    button.click();const main=document.querySelector('.content');if(main)main.scrollTop=0;
    if(after)requestAnimationFrame(()=>requestAnimationFrame(after));
  }
  function openWater(farmId,lotId){
    route('lotes',()=>{
      document.getElementById('openWaterQualityBtn')?.click();
      requestAnimationFrame(()=>{
        const farm=farmId||model.centerByLot.get(String(lotId))||'';
        if(farm)Array.from(document.querySelectorAll('[data-water-farm-select]')).find(el=>el.dataset.waterFarmSelect===farm)?.click();
      });
    });
  }
  function openLot(id){
    const lot=model.lots.find(l=>l.id===String(id)||l.code===String(id));
    if(!lot){announce('El lote ya no está disponible.');return;}
    route('lotes',()=>window.openLote?.(lot.id));
  }
  function openTask(id,date){route('agenda',()=>{if(!window.TruchAppAgendaOpenRecord?.(id,date)&&!window.TruchAppAgendaOpenTask?.(id))window.alert('Esta actividad ya no está disponible. Revisa la Agenda.');});}
  function action(event){
    const button=event.target.closest('[data-op]');if(!button)return;
    const a=button.dataset.op;
    if(a==='close'){closeDialog();return;}
    if(a==='settings'){settingsDialog();return;}
    if(a==='lot-list'){lotList(button.dataset.metric);return;}
    if(a==='period'){state.days=Number(button.dataset.value)===30?30:7;persistView();render();return;}
    if(a==='metric'){state.metric=button.dataset.value;render();return;}
    if(a==='task-tab'){state.taskTab=button.dataset.value;render();return;}
    if(a==='expand'){state.expanded=!state.expanded;render();return;}
    if(a==='lot'||a==='task-lot'){openLot(button.dataset.id);return;}
    if(a==='task'){openTask(button.dataset.id,button.dataset.date);return;}
    if(a==='water-item'){openWater(button.dataset.farm,button.dataset.id);return;}
    if(a==='water'){openWater('','');return;}
    if(a==='alert'){
      const issue=model.alerts[Number(button.dataset.index)];if(!issue)return;
      if(issue.target==='settings')settingsDialog();else if(issue.target==='lot')openLot(issue.lotId);else if(issue.target==='water')openWater(issue.farmId,issue.lotId);else if(issue.target==='task')openTask(issue.taskId,issue.occurrenceDate);else if(issue.target==='stock')stockDetail();else if(issue.target==='almacen')route('almacen');else route('agenda');return;
    }
    if(a==='feeding-detail'){feedDetail();return;}
    if(a==='stock'){stockDetail();return;}
    if(a==='performance'){performanceDetail(button.dataset.id);return;}
    if(a==='quality'){performanceDetail('',true);return;}
    if(a==='costs'){costsDetail();return;}
    if(a==='water-detail'){waterDetail();return;}
    if(a==='new-activity'){route('agenda',()=>document.getElementById('addTaskBtn')?.click());return;}
    if(['agenda','lotes','finanzas','almacen'].includes(a))route(a);
  }
  function init(){
    if(ready)return;const root=document.getElementById('dashboardRoot');if(!root)return;ready=true;
    root.addEventListener('click',action);root.addEventListener('change',event=>{
      if(event.target.id==='opCenter'){state.center=event.target.value;state.lot='';state.expanded=false;persistView();render();}
      if(event.target.id==='opChartLot'){state.lot=event.target.value;render();}
    });render();
  }
  window.renderDashboard=()=>{if(!ready)init();else render();};
  ['truchapp-lots-updated','truchapp-stock-updated','truchapp-agenda-updated','truchapp-home-settings-updated','truchapp-data-restored','storage'].forEach(name=>window.addEventListener(name,()=>{if(document.getElementById('inicio')?.classList.contains('active'))render();}));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&document.getElementById('inicio')?.classList.contains('active'))render();});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
  setInterval(()=>{const focused=document.activeElement;if(!document.hidden&&!dialog&&document.getElementById('inicio')?.classList.contains('active')&&!['SELECT','INPUT','TEXTAREA'].includes(focused?.tagName))render();},60000);
})();
