/* TruchApp - Dashboard/Inicio. Solo presentación y navegación. */
(function(){
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
  function get(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}}
  function go(target){const b=document.querySelector('.nav[data-target="'+target+'"]');if(b)b.click()}
  function render(){
    const root=document.getElementById('dashboardRoot');
    if(!root)return;
    const p=get('profile',{}), a=get('activities',[]), m=get('memories',[]), r=get('records',[]);
    let status='IA local';
    try{
      if(typeof window.AndroidAI!=='undefined'&&AndroidAI.getModelState){
        const st=JSON.parse(AndroidAI.getModelState());
        status=st.ready?'IA lista':(st.downloading?'IA descargando':'IA por preparar');
      }else status='Modo demo';
    }catch(e){}
    const name=p.name?esc(p.name):'Bienvenido';
    const exp=p.experience==='experiencia'?'Con experiencia en el rubro':p.experience==='principiante'?'Recién iniciando en el rubro':'Perfil aún por completar';
    const sorted=a.slice().sort((x,y)=>(String(x.date||'')+String(x.time||'')).localeCompare(String(y.date||'')+String(y.time||'')));
    root.innerHTML=`
      <div class="dashboard-wrap">
        <div class="dashboard-title"><div><h2>Inicio</h2><p>${name} · ${esc(exp)}</p></div><span class="dashboard-status">● ${esc(status)}</span></div>
        <div class="card hero dashboard-hero"><h3>Tu centro de control</h3><p>Accede rápido a la calculadora, la IA local, tu agenda y la memoria de TruchApp.</p></div>
        <div class="dashboard-grid">
          <div class="card dashboard-stat"><div class="icon">📅</div><b>${a.length}</b><span>Actividades programadas</span></div>
          <div class="card dashboard-stat"><div class="icon">🧠</div><b>${m.length + (p.name?1:0) + (p.role?1:0) + (p.experience?1:0)}</b><span>Datos de memoria</span></div>
          <div class="card dashboard-stat"><div class="icon">📊</div><b>${r.length}</b><span>Registros técnicos</span></div>
          <div class="card dashboard-stat"><div class="icon">🐟</div><b>Local</b><span>Enfoque de TruchApp</span></div>
        </div>
        <div class="card"><div class="label">Accesos rápidos</div><div class="dashboard-actions">
          <button class="dashboard-action" data-go="calc"><span>⌨️</span><span><b>Calcular</b><small>Operaciones y fórmulas</small></span></button>
          <button class="dashboard-action" data-go="ai"><span class="ia">✨</span><span><b>IA</b><small>Pregúntale a TruchApp</small></span></button>
          <button class="dashboard-action" data-go="agenda"><span>📅</span><span><b>Agenda</b><small>Actividades y avisos</small></span></button>
          <button class="dashboard-action" data-go="memory"><span>🧠</span><span><b>Memoria</b><small>Tu perfil y registros</small></span></button>
        </div></div>
        <div class="card"><div class="label">Próximas actividades</div><div class="dashboard-list">${sorted.slice(0,3).map(x=>`<div class="item"><span class="tag">local</span><strong>${esc(x.title)}</strong><small>📅 ${esc(x.date)} ${esc(x.time||'')}</small></div>`).join('')||'<div class="dashboard-empty">No hay actividades programadas.</div>'}</div></div>
      </div>`;
    root.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
  }
  function init(){
    render();
    window.renderDashboard=render;
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
