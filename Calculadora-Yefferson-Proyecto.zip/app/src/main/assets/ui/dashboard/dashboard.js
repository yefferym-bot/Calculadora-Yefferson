/* TruchApp — Inicio. Consulta los módulos existentes sin modificar sus registros. */
(function () {
  'use strict';
  const LOTS_KEY = 'truchapp_lotes_v1';
  const WATER_KEY = 'truchapp_lotes_water_quality_v1';
  const FINANCE_KEY = 'truchapp_finance_v1';
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
  function read(key, fallback) { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch (_) { return fallback; } }
  function rows(value) { return Array.isArray(value) ? value.filter(x => x && typeof x === 'object') : []; }
  function numeric(value) { if (value === null || value === undefined || String(value).trim() === '') return null; const n = Number(value); return Number.isFinite(n) ? n : null; }
  function fmt(value, digits = 0) { return numeric(value) === null ? '—' : Number(value).toLocaleString('es-PE', {maximumFractionDigits:digits}); }
  function money(value) { return numeric(value) === null ? '—' : 'S/ ' + fmt(value, 2); }
  function dayKey(date) { return [date.getFullYear(), String(date.getMonth()+1).padStart(2,'0'), String(date.getDate()).padStart(2,'0')].join('-'); }
  function dateValue(key) { if (!/^\d{4}-\d{2}-\d{2}$/.test(String(key || ''))) return null; const d = new Date(key + 'T12:00:00'); return Number.isFinite(d.getTime()) && dayKey(d) === key ? d : null; }
  function shortDate(key) { const d = dateValue(key); return d ? d.toLocaleDateString('es-PE', {day:'numeric', month:'short'}) : 'Sin fecha'; }
  function icon(name) {
    const paths = {
      fish:'<path d="M5 12c4-8 11-8 16 0-5 8-12 8-16 0Z"/><path d="m5 12-4-4v8l4-4ZM15 8c-2 3-2 5 0 8"/><circle cx="17.5" cy="11" r=".7" fill="currentColor" stroke="none"/>',
      coins:'<ellipse cx="9" cy="6" rx="6" ry="3"/><path d="M3 6v5c0 4 12 4 12 0V6M3 10c0 4 12 4 12 0M6 17c0 4 15 4 15 0v-6c0-2-3-3-6-3M9 19v2M15 15v6M21 15c-2 2-4 2-6 2"/>',
      water:'<path d="M12 3c-3 5-7 8-7 12a7 7 0 0 0 14 0c0-4-4-7-7-12Z"/><path d="M8 15c0 2 1 3 3 3"/>',
      calendar:'<rect x="4" y="5" width="16" height="16" rx="3"/><path d="M8 3v4M16 3v4M4 10h16M8 14h3M8 17h2M14 16l2 2 4-5"/>',
      temperature:'<path d="M9 14.5V5a3 3 0 0 1 6 0v9.5a5 5 0 1 1-6 0Z"/><path d="M12 8v10M18 6h3M18 10h2"/>',
      alert:'<path d="m10.3 4.6-8 14A1.6 1.6 0 0 0 3.7 21h16.6a1.6 1.6 0 0 0 1.4-2.4l-8-14a2 2 0 0 0-3.4 0Z"/><path d="M12 9v5M12 17v.2"/>',
      arrow:'<path d="M5 12h14m-5-5 5 5-5 5"/>',
      check:'<path d="m5 12 4 4L19 6"/>',
      chart:'<path d="M4 3v17h17M8 16v-4M13 16V9M18 16V6"/><path d="m6 9 6-4 5 1 4-4"/>',
      clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'
    };
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (paths[name] || paths.chart) + '</svg>';
  }
  function lotsData() {
    try { if (window.TruchAppData && typeof window.TruchAppData.getLots === 'function') return rows(window.TruchAppData.getLots()); } catch (_) {}
    let source = rows(read(LOTS_KEY, []));
    if (!source.length) try { if (window.AndroidAI && typeof window.AndroidAI.getLots === 'function') source = rows(JSON.parse(window.AndroidAI.getLots())); } catch (_) {}
    return source.map(lot => {
      const fish = Math.max(0, numeric(lot.n ?? lot.currentCount) || 0), weight = Math.max(0, numeric(lot.w ?? lot.currentWeight) || 0);
      const initial = Math.max(fish, numeric(lot.initialN ?? lot.initialCount) || 0);
      return {...lot, fish, weightG:weight, initialN:initial, biomassKg:fish*weight/1000, survivalPct:initial ? fish/initial*100 : null};
    });
  }
  function biological(lots, today) {
    const fish = lots.reduce((s, l) => s + (numeric(l.fish) || 0), 0);
    const biomass = lots.reduce((s, l) => s + (numeric(l.biomassKg) || 0), 0);
    const initial = lots.reduce((s, l) => s + (numeric(l.initialN) || 0), 0);
    const fcr = lots.map(l => numeric(l.fcr)).filter(n => n !== null && n > 0);
    const growth = [];
    lots.forEach(lot => {
      // Una sola biometría por fecha: el registro más reciente de ese día.
      const seen = new Set();
      const history = rows(lot.history).filter(h => {
        if (!dateValue(h.d) || h.d > today || !(numeric(h.w) > 0) || seen.has(h.d)) return false;
        seen.add(h.d); return true;
      }).sort((a,b) => b.d.localeCompare(a.d));
      if (history.length < 2) return;
      const latest = history[0], previous = history[1];
      const days = Math.round((dateValue(latest.d)-dateValue(previous.d))/86400000);
      const weekly = days > 0 ? (Math.pow(Number(latest.w)/Number(previous.w), 7/days)-1)*100 : null;
      if (weekly !== null && Number.isFinite(weekly)) growth.push(weekly);
    });
    const critical = lots.filter(l => !(numeric(l.fish) > 0) || !(numeric(l.weightG) > 0) || (numeric(l.survivalPct) !== null && Number(l.survivalPct) < 90));
    const regular = lots.filter(l => numeric(l.survivalPct) !== null && Number(l.survivalPct) < 95);
    const state = !lots.length ? {text:'Sin datos', tone:'muted'} : critical.length ? {text:'Revisar', tone:'danger'} : regular.length ? {text:'Atención', tone:'warning'} : {text:'Estable', tone:'good'};
    return {fish, biomass, survival:initial > 0 ? Math.min(100, fish/initial*100) : null,
      fcr:fcr.length ? fcr.reduce((s,n)=>s+n,0)/fcr.length : null, fcrCount:fcr.length,
      growth:growth.length ? growth.reduce((s,n)=>s+n,0)/growth.length : null, state, critical};
  }
  function financeData() {
    const f = read(FINANCE_KEY, null);
    // Finanzas es un simulador del ciclo; sus valores nunca se presentan como ventas mensuales.
    if (!f || !(numeric(f.n) > 0) || !(numeric(f.w1) > 0) || !(numeric(f.price) > 0)) return null;
    const finalBio = Number(f.n)*(Number(f.s)||0)/100*(Number(f.w1)||0)/1000;
    const initialBio = Number(f.n)*(Number(f.w0)||0)/1000;
    const feedCost = Math.max(0, finalBio-initialBio)*(Number(f.fcr)||0)*(Number(f.feed)||0);
    const cost = feedCost + ['seed','labor','energy','transport','health','maint','other'].reduce((s,k)=>s+(numeric(f[k])||0),0);
    const revenue = finalBio*Number(f.price);
    return {revenue, feedCost, profit:revenue-cost};
  }
  function waterData(now) {
    const specs = {temperature:{label:'Temperatura',unit:'°C',icon:'temperature'},oxygen:{label:'Oxígeno disuelto',unit:'mg/L',icon:'water'},ph:{label:'pH',unit:'',icon:'water'},carbonDioxide:{label:'CO₂',unit:'mg/L',icon:'water'}};
    const latest = new Map();
    rows(read(WATER_KEY, [])).slice().sort((a,b)=>(String(b.date||'')+String(b.time||'')).localeCompare(String(a.date||'')+String(a.time||''))).forEach(r => {
      const stamp = dateValue(r.date) ? new Date(r.date+'T'+(/^\d{2}:\d{2}$/.test(r.time||'') ? r.time : '00:00')).getTime() : null;
      if (stamp !== null && stamp > now.getTime()) return;
      Object.keys(specs).forEach(key => {
        const entry = r.params && r.params[key];
        const value = numeric(entry && typeof entry === 'object' ? entry.value : entry);
        if (value === null) return;
        const point = [r.farmId||r.farmName||r.site||'',r.lotId||r.lotCode||'',r.point||''].join('|');
        const id = point+'|'+key;
        if (latest.has(id)) return;
        // Se usan las mismas referencias ya presentes en el módulo Calidad del agua.
        const review = key==='oxygen' ? value<5.5 : key==='ph' ? value<6.5||value>8.5 : key==='carbonDioxide' ? value>=2 : false;
        latest.set(id, {...specs[key],key,value,review,date:r.date,time:r.time,stamp,
          place:String(r.lotCode||r.farmName||r.site||r.point||'Punto de medición')});
      });
    });
    const measurements = [...latest.values()];
    const review = measurements.filter(r=>r.review);
    const ordered = measurements.slice().sort((a,b)=>Number(b.review)-Number(a.review) || (b.stamp||0)-(a.stamp||0));
    return {review, display:ordered.slice(0,2), total:measurements.length};
  }
  function activityData(now) {
    let source = rows(read('activities', []));
    if (!source.length) try { if (window.AndroidAI && typeof window.AndroidAI.getActivities === 'function') source = rows(JSON.parse(window.AndroidAI.getActivities())); } catch (_) {}
    const today = dayKey(now);
    const done = t => !!(t.done || t.completed);
    const high = t => ['high','alta'].includes(String(t.priority||'').toLowerCase());
    function occurs(t, key) {
      if (!dateValue(t.date) || done(t) || key < t.date || (Array.isArray(t.completedDates) && t.completedDates.includes(key))) return false;
      if (!t.repeat || t.repeat==='once') return t.date===key;
      if (t.repeat==='daily') return true;
      const weekday = dateValue(key).getDay();
      if (t.repeat==='weekdays') return weekday>=1 && weekday<=5;
      if (t.repeat==='custom') return Array.isArray(t.repeatDates) ? t.repeatDates.includes(key) : Array.isArray(t.repeatDays) && t.repeatDays.includes(weekday);
      return false;
    }
    const pending = [];
    source.forEach(t => {
      if (done(t) || !String(t.title||t.name||'').trim() || !dateValue(t.date)) return;
      const recurring = t.repeat && t.repeat !== 'once';
      let key = null;
      if (!recurring) key = occurs(t,t.date) ? t.date : null;
      else if (t.repeat==='custom' && Array.isArray(t.repeatDates)) key = t.repeatDates.filter(d=>d>=today && occurs(t,d)).sort()[0]||null;
      else {
        const cursor = dateValue(t.date > today ? t.date : today);
        for (let i=0;i<370;i++) { const candidate=dayKey(cursor); if(occurs(t,candidate)){key=candidate;break} cursor.setDate(cursor.getDate()+1); }
      }
      if (!key) return;
      const time = /^\d{2}:\d{2}$/.test(t.time||'') ? t.time : '';
      const overdue = new Date(key+'T'+(time||'23:59')).getTime() < now.getTime();
      pending.push({...t,title:String(t.title||t.name),date:key,time,high:high(t),overdue});
    });
    pending.sort((a,b)=>(a.date+(a.time||'23:59')).localeCompare(b.date+(b.time||'23:59')) || Number(b.high)-Number(a.high));
    return {pending, highToday:source.filter(t=>high(t)&&occurs(t,today)).length, overdue:pending.filter(t=>t.overdue).length};
  }
  function navigate(target, selector) {
    const button = document.querySelector('.bottom .nav[data-target="'+target+'"]');
    if (!button) return;
    button.click();
    const content = document.querySelector('.content'); if (content) content.scrollTop=0;
    if (selector) requestAnimationFrame(()=>requestAnimationFrame(()=>document.querySelector('#'+target+' '+selector)?.click()));
  }
  function cardHeader(id, name, glyph, tone, target, selector) {
    return '<h3 class="home-card-heading" id="'+id+'"><button class="home-card-link" type="button" data-home-target="'+target+'"'+(selector?' data-home-open="'+selector+'"':'')+'><span class="home-icon '+tone+'">'+icon(glyph)+'</span><span>'+name+'</span><span class="home-link-arrow">'+icon('arrow')+'</span></button></h3>';
  }
  function render() {
    const root = document.getElementById('dashboardRoot'); if (!root) return;
    const now = new Date(), today = dayKey(now), lots = lotsData();
    const bio=biological(lots,today), finance=financeData(), water=waterData(now), tasks=activityData(now);
    let model='IA por preparar';
    try { if(window.AndroidAI && typeof window.AndroidAI.getModelState==='function'){const st=JSON.parse(window.AndroidAI.getModelState());model=st.ready?'IA lista':st.downloading?'IA descargando':'IA por preparar';} } catch (_) {}
    const alerts=water.review.length+bio.critical.length;
    const survival=bio.survival===null?'—':fmt(bio.survival,1)+'%';
    root.innerHTML=`
      <div class="home-overview">
        <div class="home-status-row"><span class="home-live-status"><i></i>${esc(model)}</span></div>
        <section class="home-banner" aria-labelledby="homePanelTitle">
          <div class="home-banner-copy"><h2 id="homePanelTitle">Panel de Rendimiento<br>Global de la Granja</h2><p>${fmt(lots.length)} lotes <span>·</span> ${fmt(bio.fish)} peces <span>·</span> ${fmt(bio.biomass,1)} kg</p></div>
          <svg class="home-banner-chart" viewBox="0 0 200 120" aria-hidden="true"><g stroke="#b5ead4" stroke-opacity=".13"><path d="M4 25h188M4 50h188M4 75h188M4 100h188M30 15v90M65 15v90M100 15v90M135 15v90M170 15v90"/></g><g fill="#bbf3e3" fill-opacity=".17"><path d="M15 98h12v8H15ZM40 87h12v19H40ZM65 76h12v30H65ZM90 64h12v42H90ZM115 54h12v52h-12ZM140 36h12v70h-12ZM165 19h12v87h-12Z"/></g><path d="m8 97 29-14 25 2 27-23 23 5 26-26 23 3 24-24" stroke="#55d9bf" stroke-width="2" fill="none"/><path d="m8 101 29-7 25-10 27-6 23-17 26-6 23-22 24-7" stroke="#e9ce73" stroke-width="2" fill="none"/></svg>
          <img class="home-banner-trout" src="ui/dashboard/trout.svg" alt="" width="140" height="82">
        </section>
        <div class="home-panel-grid">
          <section class="home-panel" aria-labelledby="homeBioTitle">
            ${cardHeader('homeBioTitle','Indicadores<br>Biológicos Clave','fish','blue','lotes','#openPerformanceBtn')}
            <div class="home-card-body">
              <div class="home-highlight"><span class="home-metric-label">FCR promedio <small>(alimento)</small></span><strong class="home-metric-value" data-home-metric="fcr">${fmt(bio.fcr,2)}</strong></div>
              <div class="home-metric"><span class="home-metric-label">Crecimiento semanal</span><strong class="home-metric-value ${bio.growth===null?'is-muted':bio.growth>=0?'is-good':'is-danger'}" data-home-metric="growth">${bio.growth===null?'—':(bio.growth>0?'+':'')+fmt(bio.growth,2)+'%'}</strong><small class="home-metric-note">Equivalente entre biometrías</small></div>
              <div class="home-health"><div><span class="home-metric-label">Estado global</span><strong class="home-state is-${bio.state.tone}" data-home-metric="state">${bio.state.text}</strong></div><div class="home-health-ring is-${bio.state.tone}" style="--home-ring:${bio.survival??0}%" role="img" aria-label="Supervivencia global: ${esc(survival)}"><span>${esc(survival)}</span></div></div>
            </div>
            <p class="home-card-note">${lots.length?'Promedios de lotes con registros':'Registra tus lotes para comenzar'}</p>
          </section>
          <section class="home-panel" aria-labelledby="homeFinanceTitle">
            ${cardHeader('homeFinanceTitle','Rentabilidad y<br>Finanzas','coins','gold','finanzas')}
            <div class="home-card-body home-finance-body">
              <div class="home-finance-metric"><span class="home-metric-label">Ingreso estimado</span><strong class="home-metric-value" data-home-metric="revenue">${money(finance?.revenue)}</strong><span class="home-tiny-graphic home-gold">${icon('chart')}</span></div>
              <div class="home-finance-metric"><span class="home-metric-label">Costo de alimento</span><strong class="home-metric-value" data-home-metric="feedCost">${money(finance?.feedCost)}</strong><span class="home-tiny-graphic">${icon('chart')}</span></div>
              <div class="home-finance-metric"><span class="home-metric-label">Utilidad estimada</span><strong class="home-metric-value ${finance&&finance.profit<0?'is-danger':''}" data-home-metric="profit">${money(finance?.profit)}</strong></div>
            </div>
            <p class="home-card-note">${finance?'Proyección del ciclo · Finanzas':'Completa precio y costos del ciclo'}</p>
          </section>
          <section class="home-panel" aria-labelledby="homeWaterTitle">
            ${cardHeader('homeWaterTitle','Monitoreo de<br>Lotes Críticos','water','teal','lotes','#openWaterQualityBtn')}
            <div class="home-card-body home-water-body">${water.display.length?water.display.map(r=>`<div class="home-water-reading ${r.review?'needs-review':'home-highlight'}"><span class="home-reading-icon">${icon(r.icon)}</span><div><span class="home-reading-place">${esc(r.place)}</span><span class="home-metric-label">${esc(r.label)}</span><strong class="home-reading-value">${fmt(r.value,2)} <small>${esc(r.unit)}</small></strong><span class="home-reading-meta ${r.review?'is-danger':''}">${r.review?'Revisar · ':''}${esc(shortDate(r.date))}${r.time?' · '+esc(r.time):''}</span></div></div>`).join(''):`<div class="home-no-readings">${icon('temperature')}<b>Sin mediciones</b><span>Registra temperatura y oxígeno en Calidad del agua.</span></div>`}</div>
            <p class="home-card-note">Últimas mediciones guardadas</p>
          </section>
          <section class="home-panel" aria-labelledby="homeAlertsTitle">
            ${cardHeader('homeAlertsTitle','Tareas y Alertas<br>Críticas','calendar','coral','agenda')}
            <div class="home-card-body home-alert-body">
              <div class="home-alert-metric"><span class="home-metric-label">Alertas por revisar</span><div class="home-alert-value"><span class="home-alert-symbol ${alerts?'is-danger':'is-muted'}">${icon('alert')}</span><strong class="home-metric-value ${alerts?'is-danger':'is-good'}" data-home-metric="alerts">${fmt(alerts)}</strong></div><small class="home-metric-note">${water.total||lots.length?'Agua y estado de lotes':'Sin registros para evaluar'}</small></div>
              <div class="home-alert-metric"><span class="home-metric-label">Tareas críticas hoy</span><div class="home-alert-value"><span class="home-alert-symbol ${tasks.highToday?'is-warning':'is-muted'}">${icon('calendar')}</span><strong class="home-metric-value ${tasks.highToday?'is-danger':'is-good'}" data-home-metric="highToday">${fmt(tasks.highToday)}</strong></div><small class="home-metric-note">Prioridad alta en Agenda</small></div>
            </div>
            <p class="home-card-note ${tasks.overdue?'is-danger':''}">${tasks.overdue?fmt(tasks.overdue)+' actividades vencidas':'Organiza el trabajo de hoy'}</p>
          </section>
        </div>
        <section class="home-activities" aria-labelledby="homeActivitiesTitle">
          <div class="home-activities-head"><h3 id="homeActivitiesTitle">Próximas actividades</h3><button type="button" class="home-view-all" data-home-target="agenda">Ver todas ${icon('arrow')}</button></div>
          <div class="home-activity-list">${tasks.pending.length?tasks.pending.slice(0,3).map(t=>`<button type="button" class="home-activity-row" data-home-target="agenda"><span class="home-activity-icon ${t.overdue?'is-danger':t.high?'is-warning':''}">${icon(t.overdue?'alert':t.high?'calendar':'clock')}</span><span class="home-activity-text"><strong>${esc(t.title)}</strong><small>${t.overdue?'Vencida · ':''}${t.date===today?'Hoy':esc(shortDate(t.date))}${t.time?' · '+esc(t.time):''}${t.lotCode?' · '+esc(t.lotCode):''}</small></span><span class="home-activity-arrow">${icon('arrow')}</span></button>`).join(''):'<div class="home-activities-empty">No tienes actividades pendientes.<button type="button" data-home-target="agenda" data-home-open="#addTaskBtn">+ Crear actividad</button></div>'}</div>
        </section>
      </div>`;
    root.querySelectorAll('[data-home-target]').forEach(button=>button.addEventListener('click',()=>navigate(button.dataset.homeTarget,button.dataset.homeOpen)));
  }
  window.renderDashboard = render;
  ['truchapp-lots-updated','truchapp-stock-updated','truchapp-data-restored','storage'].forEach(name=>window.addEventListener(name,()=>{if(document.getElementById('inicio')?.classList.contains('active'))render();}));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden && document.getElementById('inicio')?.classList.contains('active'))render();});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',render);else render();
  setInterval(()=>{if(!document.hidden && document.getElementById('inicio')?.classList.contains('active'))render();},60000);
})();
