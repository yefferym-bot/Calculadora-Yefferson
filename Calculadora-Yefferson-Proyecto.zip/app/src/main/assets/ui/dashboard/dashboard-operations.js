/* Lectura operativa de alimentación, existencias y rendimiento. No modifica registros. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TruchAppHomeOperations=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const array=v=>Array.isArray(v)?v:[],n=v=>v===null||v===undefined||v===''?null:Number.isFinite(Number(v))?Number(v):null;
 const days=(a,b)=>Math.round((Date.parse(b+'T12:00:00Z')-Date.parse(a+'T12:00:00Z'))/86400000);
 const shift=(day,count)=>{const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+count);return d.toISOString().slice(0,10)};
 const engines=()=>typeof window==='object'?{L:window.TruchAppLotDetailData,F:window.TruchAppFeedingData}:{L:require('../lotes/lot-detail-data.js'),F:require('../feeding/feeding-data.js')};
 function detailOf(lot){const {L}=engines();return lot.detailState||L?.fromLot({...lot,n:lot.fish,w:lot.weightG,m:lot.mortalityTotal,discarded:lot.discardTotal,alimentoConsumido:lot.feedConsumedKg,l:lot.lengthCm,pelletCalibre:lot.pelletCalibreMm})||null;}
 function daily(lot,today){
  const rows=lot.detailState?.daily||array(lot.history).filter(r=>r.type==='daily').map(r=>({date:r.d,time:r.time,feed:r.feedKg,mortality:r.m,discard:r.discard}));
  return rows.filter(r=>/^\d{4}-\d{2}-\d{2}$/.test(r.date)&&r.date<=today);
 }
 function series(rows,start,end,field){const result=[];for(let date=start;date<=end;date=shift(date,1)){const day=rows.filter(r=>r.date===date&&n(r[field])!==null);result.push({date,value:day.length?day.reduce((sum,r)=>sum+Number(r[field]),0):null})}return result}
 function performance(lot,today){
  const {L}=engines(),detail=detailOf(lot),rows=daily(lot,today),start=shift(today,-6),previousStart=shift(today,-13),previousEnd=shift(today,-7),birth=lot.date||start;
  const current=series(rows,birth>start?birth:start,today,'mortality'),previous=series(rows,birth>previousStart?birth:previousStart,previousEnd,'mortality');
  const coverage=current.filter(r=>r.value!==null).length,previousCoverage=previous.filter(r=>r.value!==null).length,total=coverage?current.reduce((s,r)=>s+(r.value||0),0):null,previousTotal=previousCoverage?previous.reduce((s,r)=>s+(r.value||0),0):null;
  const discarded=series(rows,birth>start?birth:start,today,'discard'),discardCoverage=discarded.filter(r=>r.value!==null).length,discard=discardCoverage?discarded.reduce((sum,r)=>sum+(r.value||0),0):null;
  const comparable=current.length===7&&previous.length===7&&coverage===7&&previousCoverage===7;
  const samples=array(detail?.samples).filter(s=>s.date<=today&&n(s.weight)!==null).sort((a,b)=>(a.date+(a.time||'')).localeCompare(b.date+(b.time||''))),last=samples.at(-1),prior=samples.at(-2),duration=prior&&last?days(prior.date,last.date):0;
  const gainG=duration>0?last.weight-prior.weight:null,feedCoverage=series(rows,birth>start?birth:start,today,'feed').filter(r=>r.value!==null).length;
  const period=detail&&L?L.summary(detail).periods.at(-1):null;
  const bioDate=last?.date||lot.date||null,bioAge=bioDate?days(bioDate,today):null,biometryDays=n(detail?.settings?.biometryDays)||14;
  return{id:String(lot.id),code:lot.code,stage:lot.stage,unit:lot.unit,fish:lot.fish,weight:lot.weightG,biomass:lot.biomassKg,
   mortality:total,discard,discardCoverage,previousMortality:previousTotal,coverage,expected:current.length,previousCoverage,comparable,increase:comparable&&total>previousTotal,
   points:current,feedCoverage,bioDate,bioAge,hasFollowup:!!last&&!last.initial,biometryDays,gainG,growthPerDay:gainG===null?null:gainG/duration,
   growthStart:prior?.date||null,growthEnd:last?.date||null,fcr:period?.fcr??null,fcrStart:period?.previous.date||null,fcrEnd:period?.last.date||null,
   fcrReference:n(detail?.settings?.fcrReference),partial:coverage<current.length||feedCoverage<current.length||discardCoverage<current.length};
 }
 function feeding(input,context){
  const {scoped,today,tasks}=context,movements=array(input.stock?.movements),records=array(input.agenda?.records);
  const rows=scoped.map(lot=>{
   const actual=daily(lot,today).filter(r=>r.date===today&&n(r.feed)!==null),value=actual.length?actual.reduce((s,r)=>s+Number(r.feed),0):null;
   const plan=tasks.today.concat(tasks.completedToday).filter(t=>t.kind==='feeding'&&String(t.lotId||t.assignmentId)===lot.id),known=plan.filter(t=>n(t.plannedQuantity)!==null),pending=tasks.today.filter(t=>t.kind==='feeding'&&String(t.lotId||t.assignmentId)===lot.id);
   const deliveries=movements.filter(m=>m.source==='feeding'&&String(m.linkedLotId)===lot.id&&m.date===today),pricedKg=deliveries.reduce((s,m)=>s+(n(m.feedKg)||0),0),cost=value===null?null:deliveries.reduce((s,m)=>s+(n(m.qty)||0)*(n(m.unitCost)||0),0);
   return {id:lot.id,code:lot.code,stage:lot.stage,unit:lot.unit,actual:value,planned:known.length?known.reduce((s,t)=>s+Number(t.plannedQuantity),0):null,planKnown:known.length,planTotal:plan.length,pending:pending.length,next:pending[0]||null,
    pricedKg,cost,unpriced:value===null?null:Math.max(0,value-pricedKg),resultCount:records.filter(r=>r.kind==='feeding'&&String(r.lotId)===lot.id&&r.measuredDate===today).length};
  });
  return {rows,actual:rows.some(r=>r.actual!==null)?rows.reduce((s,r)=>s+(r.actual||0),0):null,planned:rows.some(r=>r.planned!==null)?rows.reduce((s,r)=>s+(r.planned||0),0):null,
   planKnown:rows.reduce((s,r)=>s+r.planKnown,0),planTotal:rows.reduce((s,r)=>s+r.planTotal,0),pending:rows.reduce((s,r)=>s+r.pending,0),coverage:rows.filter(r=>r.actual!==null).length,
   cost:rows.some(r=>r.cost!==null)?rows.reduce((s,r)=>s+(r.cost||0),0):null,unpriced:rows.some(r=>r.unpriced!==null)?rows.reduce((s,r)=>s+(r.unpriced||0),0):null};
 }
 function warehouse(input,context){
  const {F}=engines(),today=context.today,stock=input.stock||{},movements=array(stock.movements),start=shift(today,-6),horizon=shift(today,14),target=n(input.settings?.stockDays)??7;
  const products=!F?[]:array(stock.items).filter(F.feedItem).map(item=>{
   const factor=F.unitKg(item),batches=F.batchBalances(movements,item.id,today),negative=batches.some(b=>b.qty< -F.EPS),positive=batches.filter(b=>b.qty>F.EPS);
   const usable=item.active===false?[]:positive.filter(b=>!b.expiry||b.expiry>=today),usableKg=usable.reduce((s,b)=>s+b.qty*factor,0),expired=positive.filter(b=>b.expiry&&b.expiry<today),soon=usable.filter(b=>b.expiry&&b.expiry<=horizon);
   const known=movements.filter(m=>m.itemId===item.id&&m.date<=today).map(m=>m.date).sort()[0],begin=known&&known>start?known:start,count=known?Math.max(1,days(begin,today)+1):7;
   const outgoing=movements.filter(m=>m.itemId===item.id&&m.date>=begin&&m.date<=today&&['salida','ajuste-'].includes(m.type)).reduce((s,m)=>s+(m.source==='feeding'&&n(m.feedKg)!==null?Number(m.feedKg):Number(m.qty||0)*factor),0),average=outgoing/count;
   const cover=negative?null:usableKg<=F.EPS?0:average>F.EPS?usableKg/average:null;
   return {id:String(item.id),name:item.name,code:item.code,active:item.active!==false,usableKg:negative?null:usableKg,negative,batches:positive.map(b=>({...b,kg:b.qty*factor})),expiredKg:expired.reduce((s,b)=>s+b.qty*factor,0),soonKg:soon.reduce((s,b)=>s+b.qty*factor,0),soonDate:soon.map(b=>b.expiry).sort()[0]||null,
    unknownExpiryKg:usable.filter(b=>!b.expiry).reduce((s,b)=>s+b.qty*factor,0),days:cover,average,windowDays:count,start:begin,target,low:cover!==null&&cover<target};
  }).sort((a,b)=>Number(b.negative)-Number(a.negative)||Number(b.low)-Number(a.low)||Number(b.expiredKg>0)-Number(a.expiredKg>0)||Number(b.soonKg>0)-Number(a.soonKg>0)||a.name.localeCompare(b.name));
  return {products,error:input.stockError||'',target,horizonDays:14,global:true};
 }
 function economics(input,context){
  const {F,L}=engines(),moves=array(input.stock?.movements),ids=new Set(context.scoped.map(l=>l.id));
  const valued=moves.filter(m=>m.source==='feeding'&&ids.has(String(m.linkedLotId))&&m.date>context.range.start&&m.date<=context.today);
  const rows=context.scoped.map(lot=>{
   const data=detailOf(lot),known=daily(lot,context.today).filter(r=>r.date>context.range.start&&n(r.feed)!==null);
   let legacyKg=0,excluded=0;
   if(data){const samples=array(data.samples).slice().sort((a,b)=>(a.date+(a.time||'')).localeCompare(b.date+(b.time||'')));samples.forEach((r,i)=>{if(r.legacyPeriod&&n(r.feed)!==null&&r.date<=context.today&&r.date>context.range.start){if(samples[i-1]?.date>=context.range.start)legacyKg+=Number(r.feed);else excluded++}});if(data.openingBalance?.feed>0&&data.openingBalance.date>context.range.start&&data.openingBalance.date<=context.today)excluded++;}
   const recorded=known.length||legacyKg>0?known.reduce((s,r)=>s+Number(r.feed),0)+legacyKg:null,priced=valued.filter(m=>String(m.linkedLotId)===lot.id),linkedKg=priced.reduce((s,m)=>s+Number(m.feedKg||0),0),cost=recorded===null&&!priced.length?null:priced.reduce((s,m)=>s+Number(m.qty||0)*Number(m.unitCost||0),0);
   const report=data&&F&&L?F.costReport(data,L.summary(data),moves):null;
   return {id:lot.id,code:lot.code,recorded,linkedKg,cost,unpriced:recorded===null?null:Math.max(0,recorded-linkedKg),days:new Set(known.map(r=>r.date)).size,excluded,period:report?.period||null,reason:report?.reason||'Faltan biometrías y entregas valorizadas.'};
  });
  const periods=rows.filter(r=>context.scoped.find(l=>l.id===r.id)?.fish>0).map(r=>r.period),common=periods.length>0&&periods.every(p=>p?.ready&&p.start===periods[0]?.start&&p.end===periods[0]?.end);
  const cost=rows.some(r=>r.cost!==null)?rows.reduce((s,r)=>s+(r.cost||0),0):null;
  return {rows,cost,linkedKg:rows.reduce((s,r)=>s+r.linkedKg,0),unpriced:rows.some(r=>r.unpriced!==null)?rows.reduce((s,r)=>s+(r.unpriced||0),0):null,
   excluded:rows.reduce((s,r)=>s+r.excluded,0),covered:rows.filter(r=>r.recorded!==null).length,
   unitCost:common?periods.reduce((s,p)=>s+p.cost,0)/periods.reduce((s,p)=>s+p.gain,0):null,unitStart:common?periods[0].start:null,unitEnd:common?periods[0].end:null,error:input.stockError||''};
 }
 function build(input,context){
  const result={feeding:feeding(input,context),warehouse:warehouse(input,context),performance:context.scoped.map(l=>performance(l,context.today)),economics:economics(input,context)};
  if(input.stockError){
   result.warehouse.products=[];result.feeding.cost=null;result.feeding.unpriced=null;
   result.feeding.rows.forEach(r=>{r.cost=null;r.pricedKg=null;r.unpriced=null});
   result.economics.cost=null;result.economics.linkedKg=null;result.economics.unpriced=null;result.economics.unitCost=null;
   result.economics.rows.forEach(r=>{r.cost=null;r.linkedKg=null;r.unpriced=null;if(r.period)r.period={...r.period,ready:false,costPerKgGain:null,reason:input.stockError}});
  }
  return result;
 }
 return {build,daily,series,days};
});
