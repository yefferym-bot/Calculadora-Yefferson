/* TruchApp — cálculos de Inicio. Sin acceso a almacenamiento ni cambios a los registros. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.TruchAppHomeData = api;
})(typeof window === 'object' ? window : globalThis, function () {
  'use strict';
  const array = value => Array.isArray(value) ? value.filter(x=>x && typeof x==='object') : [];
  function num(value) { if(value==null || typeof value==='boolean' || String(value).trim()==='')return null; const n=Number(value); return Number.isFinite(n)?n:null; }
  const positive = value => Math.max(0,num(value)||0);
  function key(d) { return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'); }
  function date(value) { if(!/^\d{4}-\d{2}-\d{2}$/.test(String(value||'')))return null; const d=new Date(value+'T12:00:00'); return Number.isFinite(d.getTime()) && key(d)===value?d:null; }
  function shift(value,n) { const d=date(value); if(!d)return ''; d.setDate(d.getDate()+n); return key(d); }
  function stamp(day,time) { if(!date(day)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(String(time||'')))return null; return new Date(day+'T'+time).getTime(); }
  function settings(raw) {
    const s=raw && typeof raw==='object'?raw:{};
    const l=s.limits && typeof s.limits==='object'?s.limits:{};
    const assignments=Object.create(null);
    if(s.assignments && typeof s.assignments==='object')Object.entries(s.assignments).forEach(([k,v])=>{if(typeof v==='string')assignments[k]=v;});
    const bounded=(v,f,min,max)=>num(v)!==null && Number(v)>=min && Number(v)<=max?Number(v):f;
    let phMin=bounded(l.phMin,6.5,0,14),phMax=bounded(l.phMax,8.5,0,14);
    if(phMin>=phMax){phMin=6.5;phMax=8.5;}
    return {assignments,financeCenter:typeof s.financeCenter==='string'?s.financeCenter:'',financeSignature:typeof s.financeSignature==='string'?s.financeSignature:'',
      freshnessHours:bounded(s.freshnessHours,24,1,168),
      limits:{oxygenMin:bounded(l.oxygenMin,5.5,0,30),phMin,phMax,co2Max:bounded(l.co2Max,2,0.01,200)}};
  }
  function normalizeLot(l) {
    const fish=positive(l.fish ?? l.n ?? l.currentCount),weight=positive(l.weightG ?? l.w ?? l.currentWeight);
    const mortality=positive(l.mortalityTotal ?? l.m),discard=positive(l.discardTotal ?? l.discarded);
    const initial=Math.max(fish+mortality+discard,positive(l.initialN ?? l.initialCount));
    return {...l,id:String(l.id||l.code||''),code:String(l.code||l.id||'Lote'),fish,weightG:weight,initialN:initial,
      initialWeight:positive(l.initialWeight ?? l.w0),mortalityTotal:mortality,discardTotal:discard,
      biomassKg:fish*weight/1000,survivalPct:initial>0?fish/initial*100:null,history:array(l.history)};
  }
  function detailEngine() { return typeof window==='object' && window.TruchAppLotDetailData ? window.TruchAppLotDetailData : typeof require==='function' ? require('../lotes/lot-detail-data.js') : null; }
  function mortalityPoints(lot,histories) { const engine=detailEngine();return lot.detailState && engine ? engine.dailyMortality(lot.detailState) : histories.get(lot.id).filter(h=>!h.isInitial); }
  function snapshots(lot,today) {
    if(lot.detailState && detailEngine())return detailEngine().homeSnapshots(lot.detailState,today);
    const history=lot.history.map((h,index)=>({...h,index,d:String(h.d||h.date||''),w:num(h.w ?? h.currentWeight),m:positive(h.m ?? h.mortality),discard:positive(h.discard ?? h.discarded),feedKg:num(h.feedKg ?? h.alimentoConsumido)}))
      .filter(h=>date(h.d) && h.d<=today).sort((a,b)=>b.d.localeCompare(a.d)||a.index-b.index);
    let newerLosses=0;
    const result=history.map(h=>{
      const fish=lot.fish+newerLosses;
      newerLosses+=h.m+h.discard;
      return {...h,fish,isInitial:/^lote (registrado|creado)\.?$/i.test(String(h.x||h.note||'').trim())};
    });
    return result.reverse();
  }
  function intervals(points) {
    return points.slice(1).map((end,index)=>{
      const start=points[index];
      if(end.detailPeriod)return {...end.detailPeriod};
      return {start:start.d,end:end.d,feed:end.feedKg,gain:start.w>0 && end.w>0?(end.w-start.w)*(start.fish+end.fish)/2000:null,
        valid:!end.isInitial && end.feedKg!==null && end.feedKg>=0 && start.w>0 && end.w>0};
    });
  }
  function comparableFcr(lots,histories,range) {
    const selected=lots.filter(l=>l.fish>0);
    const unavailable={value:null,feed:null,gain:null,count:selected.length,start:null,end:null,reason:'Registra pesos y alimento de los lotes entre fechas comunes.'};
    if(!selected.length)return {...unavailable,reason:'Todavía no hay lotes con existencias para comparar.'};
    const dates=selected.map(l=>new Set(histories.get(l.id).filter(h=>h.w>0 && h.d>=range.start && h.d<=range.end).map(h=>h.d)));
    const common=[...dates[0]].filter(d=>dates.every(set=>set.has(d))).sort();
    if(common.length<2)return {...unavailable,reason:'Faltan dos fechas de biometría comunes a todos los lotes del conjunto.'};
    let missing=false,nonPositive=false;
    for(let e=common.length-1;e>0;e--)for(let s=0;s<e;s++){
      let feed=0,gain=0,valid=true;
      for(const lot of selected){
        const hs=histories.get(lot.id);
        const a=hs.map(h=>h.d).lastIndexOf(common[s]),b=hs.map(h=>h.d).lastIndexOf(common[e]);
        const parts=intervals(hs).slice(a,b);
        if(!parts.length || parts.some(p=>!p.valid)){missing=true;valid=false;break;}
        feed+=parts.reduce((sum,p)=>sum+p.feed,0);
        gain+=parts.reduce((sum,p)=>sum+p.gain,0);
      }
      if(valid && gain>0 && Number.isFinite(feed/gain))return {value:feed/gain,feed,gain,count:selected.length,start:common[s],end:common[e],reason:''};
      if(valid && gain<=0)nonPositive=true;
    }
    return {...unavailable,reason:missing?'Falta alimento registrado en uno o más intervalos; no se calcula un FCR parcial.':nonPositive?'La ganancia estimada de biomasa del periodo no es positiva.':unavailable.reason};
  }
  function taskModel(source,now,range) {
    const today=key(now),pending=[],completedToday=[];
    const validTasks=array(source).filter(t=>date(t.date) && String(t.title||t.name||'').trim());
    function occurs(t,d) {
      if(d<t.date)return false;
      if(!t.repeat || t.repeat==='once')return d===t.date;
      if(t.repeat==='daily')return true;
      const weekday=date(d).getDay();
      if(t.repeat==='weekdays')return weekday>=1 && weekday<=5;
      if(t.repeat==='custom')return Array.isArray(t.repeatDates)?t.repeatDates.includes(d):Array.isArray(t.repeatDays)&&t.repeatDays.includes(weekday);
      return d===t.date;
    }
    function occurrence(t,d) {
      const time=/^([01]\d|2[0-3]):[0-5]\d$/.test(t.time||'')?t.time:'';
      return {...t,id:String(t.id??''),title:String(t.title||t.name),date:d,time,
        high:['alta','high'].includes(String(t.priority||'').toLowerCase()),
        overdue:(stamp(d,time||'23:59')||Infinity)<now.getTime()};
    }
    for(const t of validTasks){
      const recurring=t.repeat && t.repeat!=='once';
      const isDone=d=>recurring?(!!t.done || (Array.isArray(t.completedDates)&&t.completedDates.includes(d))):!!(t.done||t.completed);
      if(occurs(t,today) && isDone(today))completedToday.push(occurrence(t,today));
      if(!recurring){if(!isDone(t.date))pending.push(occurrence(t,t.date));continue;}
      if(t.done)continue;
      const begin=t.date>shift(range.start,1)?t.date:shift(range.start,1);
      for(let d=begin;d<=today;d=shift(d,1))if(occurs(t,d)&&!isDone(d))pending.push(occurrence(t,d));
      // Solo la siguiente aparición futura; no se crean registros nuevos.
      if(t.repeat==='custom' && Array.isArray(t.repeatDates)){
        const next=t.repeatDates.filter(d=>date(d)&&d>today&&occurs(t,d)&&!isDone(d)).sort()[0];
        if(next)pending.push(occurrence(t,next));
      }else{
        let d=t.date>today?t.date:shift(today,1);
        for(let i=0;i<370;i++,d=shift(d,1))if(occurs(t,d)&&!isDone(d)){pending.push(occurrence(t,d));break;}
      }
    }
    const sort=(a,b)=>a.date.localeCompare(b.date)||(a.time||'23:59').localeCompare(b.time||'23:59')||Number(b.high)-Number(a.high);
    pending.sort(sort);
    const todayPending=pending.filter(t=>t.date===today).sort((a,b)=>Number(b.high)-Number(a.high)||sort(a,b));
    return {today:todayPending,completedToday,overdue:pending.filter(t=>t.overdue),upcoming:pending.filter(t=>t.date>today),pending,
      totalToday:todayPending.length+completedToday.length,highToday:todayPending.filter(t=>t.high).length};
  }
  function trend(lots,histories,range,metric,lotId) {
    const selected=lotId==='all'?lots:lots.filter(l=>l.id===lotId);
    const points=[],groups=new Map();
    if(metric==='weight'){
      const byLot=selected.map(l=>{
        const map=new Map(); histories.get(l.id).filter(h=>h.w>0 && h.d>=range.start && h.d<=range.end).forEach(h=>map.set(h.d,h));return map;
      });
      const dates=byLot.length?[...byLot[0].keys()].filter(d=>byLot.every(map=>map.has(d))).sort():[];
      dates.forEach(d=>{
        const records=byLot.map(map=>map.get(d));
        const fish=records.reduce((s,h)=>s+h.fish,0);
        const value=fish>0?records.reduce((s,h)=>s+h.w*h.fish,0)/fish:null;
        if(value!==null)points.push({date:d,value,detail:selected.length===1?'Peso registrado':'Peso ponderado en fecha común',count:records.length});
      });
    }else if(metric==='mortality'){
      selected.forEach(l=>mortalityPoints(l,histories).filter(h=>h.d>range.start && h.d<=range.end).forEach(h=>{
        const g=groups.get(h.d)||{date:h.d,value:0,count:0};g.value+=h.m;g.count++;groups.set(h.d,g);
      }));
      points.push(...[...groups.values()].sort((a,b)=>a.date.localeCompare(b.date)).map(g=>({...g,detail:g.count+' registro(s) de mortalidad'})));
    }else{
      selected.forEach(l=>intervals(histories.get(l.id)).filter(p=>p.valid && p.start>=range.start && p.end<=range.end).forEach(p=>{
        const g=groups.get(p.end)||{date:p.end,value:0,count:0,starts:new Set()};g.value+=p.feed;g.count++;g.starts.add(p.start);groups.set(p.end,g);
      }));
      points.push(...[...groups.values()].sort((a,b)=>a.date.localeCompare(b.date)).map(g=>({date:g.date,value:g.value,count:g.count,
        detail:g.starts.size===1?'Periodo '+[...g.starts][0]+' → '+g.date:g.count+' periodos con cierre en esta fecha'})));
    }
    return {metric,lotId,points,unit:metric==='weight'?'g':metric==='mortality'?'peces':'kg',
      caption:metric==='weight'?(selected.length>1?'Solo fechas con biometrías de todos los lotes seleccionados.':'Se muestran los pesos guardados en las fechas de biometría.'):
        metric==='mortality'?'Se suman mortalidades registradas por fecha. Los días sin registro quedan sin dato.':'Consumo de periodos completos, agrupado por fecha de cierre; no es consumo diario.',
      empty:metric==='weight'&&selected.length>1?'No hay fechas comunes. Selecciona un lote para consultar sus biometrías.':'No hay registros suficientes en este periodo.'};
  }
  function financeSignature(raw) {
    if(!raw || typeof raw!=='object')return '';
    return JSON.stringify(['n','w0','w1','s','fcr','price','feed','seed','labor','energy','transport','health','maint','other','invest'].map(k=>num(raw[k])??0));
  }
  function finance(raw,selectedCenter,config) {
    if(!raw || typeof raw!=='object' || !(num(raw.n)>0) || !(num(raw.w1)>0) || !(num(raw.price)>0))return {available:false,reason:'Completa la proyección en Finanzas.'};
    const sameCenter=selectedCenter==='unlinked'?!config.financeCenter:config.financeCenter===selectedCenter;
    const changed=!!config.financeCenter && !!config.financeSignature && config.financeSignature!==financeSignature(raw);
    if(selectedCenter!=='all' && changed)return {available:false,reason:'La proyección cambió después de asociarla. Confirma su centro en los ajustes de Inicio.'};
    if(selectedCenter!=='all' && !sameCenter)return {available:false,reason:config.financeCenter?'La proyección guardada corresponde a otro centro.':'La proyección guardada todavía no tiene un centro asociado.'};
    const s=num(raw.s),fcr=num(raw.fcr),feedPrice=num(raw.feed),w0=num(raw.w0);
    const fields=['n','w0','w1','s','fcr','price','feed','seed','labor','energy','transport','health','maint','other'];
    if(s===null||s<0||s>100||fcr===null||w0===null||feedPrice===null||fields.some(k=>num(raw[k])!==null&&Number(raw[k])<0))return {available:false,reason:'Revisa los valores guardados de producción, supervivencia y costos.'};
    const initial=Number(raw.n)*w0/1000,final=Number(raw.n)*s/100*Number(raw.w1)/1000;
    const feedKg=Math.max(0,final-initial)*fcr,feedCost=feedKg*feedPrice;
    const cost=feedCost+['seed','labor','energy','transport','health','maint','other'].reduce((total,k)=>total+(num(raw[k])||0),0);
    const revenue=final*Number(raw.price),profit=revenue-cost;
    return {available:true,revenue,profit,cost,feedCost,feedKg,center:changed?'':config.financeCenter,associationChanged:changed,margin:revenue>0?profit/revenue*100:null};
  }
  function build(input) {
    const now=input.now instanceof Date?input.now:new Date(),today=key(now),config=settings(input.settings),view=input.view||{};
    const range={days:Number(view.days)===30?30:7,end:today};range.start=shift(today,-range.days);
    const lots=array(input.lots).map(normalizeLot),rawWater=array(input.water);
    const centers=array(input.centers).filter(c=>c.id && String(c.id)!=='__unassigned__').map(c=>({...c,id:String(c.id),name:String(c.name||'Centro')}));
    rawWater.forEach(r=>{if(r.farmId && String(r.farmId)!=='__unassigned__' && !centers.some(c=>c.id===String(r.farmId)))centers.push({id:String(r.farmId),name:String(r.farmName||'Centro sin ficha')});});
    const resolveLot=r=>{
      const id=r.lotId||(r.assignmentType==='lot'?r.assignmentId:''),code=r.lotCode||(r.assignmentType==='lot'?r.assignmentLabel:'');
      return lots.find(l=>id && String(id)===l.id)||(()=>{const matches=lots.filter(l=>code && String(code)===l.code);return matches.length===1?matches[0]:null;})();
    };
    const centerByLot=new Map(),inferred=new Set();
    lots.forEach(l=>{
      if(Object.prototype.hasOwnProperty.call(config.assignments,l.id))centerByLot.set(l.id,config.assignments[l.id]);
      else {
        const candidates=new Set(rawWater.filter(r=>resolveLot(r)?.id===l.id && r.farmId && String(r.farmId)!=='__unassigned__').map(r=>String(r.farmId)));
        if(candidates.size===1){centerByLot.set(l.id,[...candidates][0]);inferred.add(l.id);}else centerByLot.set(l.id,'');
      }
      if(!centers.some(c=>c.id===centerByLot.get(l.id)))centerByLot.set(l.id,'');
    });
    let selectedCenter=String(view.center||'all');
    if(!['all','unlinked'].includes(selectedCenter) && !centers.some(c=>c.id===selectedCenter))selectedCenter='all';
    const belongs=id=>selectedCenter==='all'||(selectedCenter==='unlinked'?!centerByLot.get(id):centerByLot.get(id)===selectedCenter);
    const scoped=lots.filter(l=>belongs(l.id)),histories=new Map(scoped.map(l=>[l.id,snapshots(l,today)]));
    const waterCenter=r=>r.farmId && String(r.farmId)!=='__unassigned__'?String(r.farmId):centerByLot.get(resolveLot(r)?.id)||'';
    const water=rawWater.filter(r=>selectedCenter==='all'||(selectedCenter==='unlinked'?!waterCenter(r):waterCenter(r)===selectedCenter));
    const tasksSource=array(input.activities).filter(t=>{if(selectedCenter==='all')return true;const l=resolveLot(t);return l?belongs(l.id):selectedCenter==='unlinked';});
    const tasks=taskModel(tasksSource,now,range),alerts=[],latest=new Map();
    const specs={oxygen:{label:'Oxígeno',unit:'mg/L'},temperature:{label:'Temperatura',unit:'°C'},ph:{label:'pH',unit:''},carbonDioxide:{label:'CO₂',unit:'mg/L'}};
    water.slice().sort((a,b)=>(String(b.date||'')+String(b.time||'')).localeCompare(String(a.date||'')+String(a.time||''))).forEach(r=>{
      if(!date(r.date) || r.date>today)return;
      const ts=stamp(r.date,r.time);if(ts!==null&&ts>now.getTime())return;
      Object.entries(specs).forEach(([parameter,spec])=>{
        const item=r.params && r.params[parameter],value=num(item && typeof item==='object'?item.value:item);if(value===null)return;
        const point=[waterCenter(r),resolveLot(r)?.id||r.lotId||r.lotCode||'',String(r.point||''),String(r.site||'')].join('|');
        const id=point+'|'+parameter;if(latest.has(id))return;
        const age=ts===null?null:(now.getTime()-ts)/3600000,fresh=age!==null&&age<=config.freshnessHours;
        const limits=config.limits;
        const review=parameter==='oxygen'?value<limits.oxygenMin:parameter==='ph'?value<limits.phMin||value>limits.phMax:parameter==='carbonDioxide'?value>=limits.co2Max:false;
        const bound=parameter==='oxygen'?'umbral mínimo '+limits.oxygenMin+' mg/L':parameter==='ph'?'intervalo '+limits.phMin+'–'+limits.phMax:parameter==='carbonDioxide'?'umbral '+limits.co2Max+' mg/L':'';
        latest.set(id,{...spec,parameter,value,point,farmId:waterCenter(r),lotId:resolveLot(r)?.id||'',date:r.date,time:r.time||'',stamp:ts,age,fresh,review,bound,
          place:String(r.lotCode||r.farmName||centers.find(c=>c.id===waterCenter(r))?.name||r.site||r.point||'Punto sin centro')});
      });
    });
    const measurements=[...latest.values()];
    measurements.forEach(m=>{
      if(m.review)alerts.push({type:'water',tone:m.fresh?'danger':'warning',title:m.label+': '+m.value+' '+m.unit,
        reason:m.place+' · Fuera del '+m.bound+(m.fresh?'':'. Actualiza la medición antes de evaluar el estado actual.'),measurement:m,action:'Ver medición',target:'water',farmId:m.farmId,lotId:m.lotId});
      else if(!m.fresh)alerts.push({type:'stale',tone:'missing',title:'Actualizar '+m.label.toLowerCase(),reason:m.place+' · La última medición no es reciente.',measurement:m,action:'Actualizar registro',target:'water',farmId:m.farmId,lotId:m.lotId});
    });
    const entities=[];
    const selectedCenters=selectedCenter==='all'?centers:selectedCenter==='unlinked'?[]:centers.filter(c=>c.id===selectedCenter);
    selectedCenters.forEach(c=>entities.push({id:c.id,name:c.name,farmId:c.id,lotId:'',match:m=>m.farmId===c.id}));
    scoped.filter(l=>!centerByLot.get(l.id)).forEach(l=>entities.push({id:'lot-'+l.id,name:l.code,farmId:'',lotId:l.id,match:m=>m.lotId===l.id}));
    if(!entities.length && measurements.length)entities.push({id:'legacy',name:'Puntos sin centro',farmId:'',lotId:'',match:()=>true});
    let freshCoverage=0;
    entities.forEach(entity=>{
      const missing=['oxygen','temperature'].filter(p=>!measurements.some(m=>entity.match(m)&&m.parameter===p));
      if(missing.length)alerts.push({type:'missing',tone:'missing',title:'Faltan mediciones en '+entity.name,reason:missing.map(p=>specs[p].label).join(' y ')+'. No hay registros para evaluar estos parámetros.',action:'Registrar medición',target:'water',farmId:entity.farmId,lotId:entity.lotId});
      if(['oxygen','temperature'].every(p=>measurements.some(m=>entity.match(m)&&m.parameter===p&&m.fresh)))freshCoverage++;
    });
    scoped.forEach(l=>{
      const hs=histories.get(l.id),lastDate=hs[hs.length-1]?.d||l.date;
      if(l.survivalPct!==null && l.survivalPct<95)alerts.push({type:'lot',tone:l.survivalPct<90?'danger':'warning',title:l.code+' · Supervivencia '+l.survivalPct.toFixed(1)+'%',reason:'Supervivencia acumulada respecto a '+l.initialN+' peces iniciales. Revisa mortalidad y descarte registrados.',date:lastDate,action:'Abrir lote',target:'lot',lotId:l.id});
      if(l.fish>0 && !(l.weightG>0))alerts.push({type:'lot-data',tone:'missing',title:'Falta el peso de '+l.code,reason:'Registra una biometría para calcular su biomasa.',date:lastDate,action:'Registrar biometría',target:'lot',lotId:l.id});
    });
    const highOverdue=tasks.overdue.filter(t=>t.high);
    const taskSeen=new Set();highOverdue.forEach(t=>{if(taskSeen.has(t.id))return;taskSeen.add(t.id);alerts.push({type:'task',tone:'danger',title:t.title,reason:'Actividad vencida de prioridad alta.',date:t.date,time:t.time,action:'Abrir actividad',target:'task',taskId:t.id,lotId:resolveLot(t)?.id||''});});
    const normalOverdue=tasks.overdue.filter(t=>!t.high);
    if(normalOverdue.length)alerts.push({type:'task',tone:'warning',title:normalOverdue.length+' actividades pendientes vencidas',reason:'Consulta fechas y responsables en Agenda.',action:'Ver pendientes',target:'agenda',date:normalOverdue[0].date});
    const unlinked=lots.filter(l=>!centerByLot.get(l.id));
    if(unlinked.length && selectedCenter==='all')alerts.push({type:'link',tone:'missing',title:unlinked.length+' lotes sin centro asociado',reason:'Vincúlalos para incluirlos en el filtro de su granja.',action:'Vincular lotes',target:'settings'});
    if(!lots.length && !centers.length)alerts.push({type:'start',tone:'missing',title:'Empieza con tus registros',reason:'Crea un centro y un lote para consultar producción y mediciones.',action:'Registrar un centro',target:'water'});
    const rank={danger:0,warning:1,missing:2,info:3};alerts.sort((a,b)=>rank[a.tone]-rank[b.tone]);
    const severity=alerts.some(a=>a.tone==='danger')?'danger':alerts.some(a=>a.tone==='warning')?'warning':alerts.length||!entities.length?'missing':'good';
    const title={danger:'Requiere atención',warning:'Hay registros por revisar',missing:'Faltan datos para evaluar',good:'Sin avisos en registros disponibles'}[severity];
    const fish=scoped.reduce((s,l)=>s+l.fish,0),initial=scoped.reduce((s,l)=>s+l.initialN,0);
    const records=scoped.flatMap(l=>mortalityPoints(l,histories).map(h=>({...h,lotId:l.id})));
    const todayRecords=records.filter(h=>h.d===today && !h.periodTotal);
    const mortalityRecords=records.filter(h=>h.d>range.start && h.d<=range.end);
    let feed=0,feedRecords=0,crossing=0;
    scoped.forEach(l=>intervals(histories.get(l.id)).forEach(p=>{if(p.valid && p.end<=today && p.end>range.start){if(p.start>=range.start){feed+=p.feed;feedRecords++;}else crossing++;}}));
    let chartLot=String(view.lot||'');if(chartLot!=='all'&&!scoped.some(l=>l.id===chartLot))chartLot=scoped[0]?.id||'all';
    const metric=['weight','mortality','feed'].includes(view.metric)?view.metric:'weight';
    return {now,today,range,config,lots,scoped,centers,selectedCenter,centerByLot,inferred,unlinked,alerts,state:{tone:severity,title},measurements,
      coverage:{fresh:freshCoverage,total:entities.length},tasks,
      summary:{lots:scoped.length,fish,biomass:scoped.reduce((s,l)=>s+l.biomassKg,0),survival:initial>0?fish/initial*100:null,
        mortalityToday:todayRecords.length?todayRecords.reduce((s,h)=>s+h.m,0):null,mortalityTodayCoverage:new Set(todayRecords.map(h=>h.lotId)).size,
        mortalityPeriod:mortalityRecords.length?mortalityRecords.reduce((s,h)=>s+h.m,0):null,feed:feedRecords?feed:null,feedRecords,crossing},
      fcr:comparableFcr(scoped,histories,range),trend:trend(scoped,histories,range,metric,chartLot),finance:finance(input.finance,selectedCenter,config)};
  }
  return {build,settings,date,dayKey:key,shift,num,financeSignature};
});
