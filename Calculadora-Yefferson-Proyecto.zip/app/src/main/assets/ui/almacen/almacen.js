/* TruchAPP Almacén / Kardex: inventario local con trazabilidad por lote y fecha de vencimiento. */
(function () {
  'use strict';
  const KEY = 'truchapp_almacen_kardex_v1';
  const $ = id => document.getElementById(id);
  const root = () => $('almacenRoot');
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const escAttr = value => esc(value).replace(/`/g, '&#96;');
  const money = value => 'S/ ' + Number(value || 0).toLocaleString('es-PE',{minimumFractionDigits:2,maximumFractionDigits:2});
  const num = (value, digits=2) => Number(value || 0).toLocaleString('es-PE',{minimumFractionDigits:0,maximumFractionDigits:digits});
  const localDate = () => { const d = new Date(); return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'); };
  const makeId = prefix => prefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2,7);
  let memoryStore = null, renderSnapshot=null;
  let productLimit=30, movementLimit=30;
  let state = {tab:'inventory',filter:'all',query:'',modal:null,selectedItem:null,editId:null};
  function readData() {
    if(renderSnapshot)return renderSnapshot.data;
    try { const raw = localStorage.getItem(KEY); if (raw) { const d = JSON.parse(raw); return {...d,items:Array.isArray(d.items)?d.items:[],movements:Array.isArray(d.movements)?d.movements:[]}; } } catch (error) { throw new Error('No se pudo leer el almacén. Se conserva el original.'); }
    return memoryStore || {items:[],movements:[]};
  }
  function saveData(data) {
    window.TruchAppFeeding.validateInventory(data);
    const payload=JSON.stringify(data);localStorage.setItem(KEY,payload);
    if(localStorage.getItem(KEY)!==payload)throw new Error('El dispositivo no confirmó el guardado del almacén.');
    if(window.TruchAppStorage)window.TruchAppStorage.afterCommit(()=>{memoryStore=data;});else memoryStore=data;
    const notify=()=>window.dispatchEvent(new CustomEvent('truchapp-stock-updated',{detail:{items:data.items.length,movements:data.movements.length}}));if(window.TruchAppStorage)window.TruchAppStorage.afterCommit(notify);else notify();
  }
  function allItems() { return readData().items; }
  function allMovements() { if(renderSnapshot)return renderSnapshot.movements;return window.TruchAppFeedingData.combinedMovements(readData(),window.TruchAppData?.getLots?.()||[]); }
  function findItem(id) { return allItems().find(x => x.id === id); }
  function signedQty(m) {
    if (m.type === 'entrada' || m.type === 'devolucion' || m.type === 'ajuste+') return Number(m.qty)||0;
    return -(Number(m.qty)||0);
  }
  function batchKey(m) { return String(m.batch || '').trim() || 'SIN-LOTE'; }
  function batchBalances(itemId) {
    if(renderSnapshot?.balances.has(itemId))return renderSnapshot.balances.get(itemId);const rows=window.TruchAppFeedingData.batchBalances(allMovements(),itemId).filter(b=>b.qty>0.000001);if(renderSnapshot)renderSnapshot.balances.set(itemId,rows);return rows;
  }
  function itemStock(itemId) { return batchBalances(itemId).reduce((sum,b)=>sum+b.qty,0); }
  function itemValue(itemId) { return batchBalances(itemId).reduce((sum,b)=>sum+b.value,0); }
  function itemAvgCost(itemId) { const qty=itemStock(itemId); return qty>0?itemValue(itemId)/qty:0; }
  function itemMoves(itemId) { return allMovements().filter(m=>m.itemId===itemId).slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'') || (Number(b.createdAt)||0)-(Number(a.createdAt)||0)); }
  function nextCode() { const codes=allItems().map(x=>Number(String(x.code||'').match(/(\d+)$/)?.[1]||0)); return 'ALM-'+String(Math.max(0,...codes)+1).padStart(4,'0'); }
  function categoryName(value) { return value || 'Otros'; }
  function itemStatus(item) {
    const stock=itemStock(item.id), min=Math.max(0,Number(item.minStock)||0);
    if (stock <= 0.000001) return {label:'Sin stock',cls:'out'};
    if (min > 0 && stock <= min) return {label:'Stock bajo',cls:'low'};
    return {label:'Disponible',cls:'ok'};
  }
  function expiryFlags() {
    const now = new Date(localDate()+'T00:00:00');
    const out=[];
    for (const item of allItems()) for (const b of batchBalances(item.id)) if (b.expiry) {
      const days=Math.floor((new Date(b.expiry+'T00:00:00')-now)/86400000);
      if (days < 0) out.push({item,batch:b,days,kind:'expired'});
      else if (days <= 60) out.push({item,batch:b,days,kind:'soon'});
    }
    return out.sort((a,b)=>a.days-b.days);
  }
  function formatDate(date) { if (!date) return 'Sin fecha'; const [y,m,d]=String(date).split('-'); return y&&m&&d?`${d}/${m}/${y}`:date; }
  function movementLabel(type,source) { return source==='feeding'?'Salida · alimentación':({entrada:'Entrada',salida:'Salida',devolucion:'Devolución','ajuste+':'Ajuste (+)','ajuste-':'Ajuste (−)'})[type] || type; }
  function sumAll() {
    const data=readData(), active=data.items.filter(i=>i.active!==false);
    return {count:active.length,units:active.reduce((s,i)=>s+itemStock(i.id),0),value:active.reduce((s,i)=>s+itemValue(i.id),0),low:active.filter(i=>itemStatus(i).cls==='low').length,out:active.filter(i=>itemStatus(i).cls==='out').length,expiry:expiryFlags().length};
  }
  function productCard(item) {
    const stock=itemStock(item.id), value=itemValue(item.id), status=itemStatus(item), batches=batchBalances(item.id).length;
    const last=allMovements().filter(m=>m.itemId===item.id).sort((a,b)=>(b.date||'').localeCompare(a.date||''))[0];
    return `<article class="al-product" data-item-card="${escAttr(item.id)}"><div class="al-product-top"><div style="min-width:0"><div class="al-product-title">${esc(item.name)}</div><div class="al-product-code">${esc(item.code)} · ${esc(categoryName(item.category))}</div></div><span class="al-badge ${status.cls}">${status.label}</span></div><div class="al-product-meta">${esc(item.location||'Ubicación no indicada')}${item.brand?' · '+esc(item.brand):''} · ${batches} lote(s) con saldo</div><div class="al-product-stats"><div class="al-product-stat"><b>${num(stock,3)} ${esc(item.unit)}</b><span>Stock actual</span></div><div class="al-product-stat"><b>${money(value)}</b><span>Valor estimado</span></div><div class="al-product-stat"><b>${num(item.minStock,3)} ${esc(item.unit)}</b><span>Stock mínimo</span></div></div><div class="al-product-meta">${last?'Último movimiento: '+esc(formatDate(last.date))+' · '+esc(movementLabel(last.type,last.source)):'Sin movimientos registrados'}</div><div class="al-product-actions"><button class="al-btn al-btn-soft al-btn-mini" data-action="movement" data-id="${escAttr(item.id)}">＋ Movimiento</button><button class="al-btn al-btn-plain al-btn-mini" data-action="detail" data-id="${escAttr(item.id)}">Ver Kardex</button><button class="al-btn al-btn-plain al-btn-mini" data-action="edit" data-id="${escAttr(item.id)}">Editar</button></div></article>`;
  }
  function filteredItems() {
    const q=state.query.trim().toLocaleLowerCase('es-PE');
    return allItems().filter(i=>i.active!==false).filter(i=>{
      const stock=itemStock(i.id), status=itemStatus(i);
      const matched=!q || [i.name,i.code,i.category,i.location,i.brand].join(' ').toLocaleLowerCase('es-PE').includes(q);
      const byFilter=state.filter==='all' || (state.filter==='low'&&status.cls==='low') || (state.filter==='out'&&status.cls==='out') || (state.filter==='expiry'&&expiryFlags().some(x=>x.item.id===i.id));
      return matched&&byFilter&&i && stock>=0;
    }).sort((a,b)=>a.name.localeCompare(b.name,'es'));
  }
  function inventoryPane() {
    const items=filteredItems();
    return `<div class="al-card"><div class="al-card-head"><div><h3 class="al-section-title">Inventario actual</h3><p class="al-section-sub">Existencias calculadas desde entradas, salidas y ajustes.</p></div><span class="al-count">${items.length} producto(s)</span></div><input class="al-search" id="alSearch" type="search" value="${escAttr(state.query)}" placeholder="Buscar producto, código o ubicación…" autocomplete="off" aria-label="Buscar productos"><div class="al-filter-row"><button class="al-filter ${state.filter==='all'?'active':''}" data-action="filter" data-filter="all">Todos</button><button class="al-filter ${state.filter==='low'?'active':''}" data-action="filter" data-filter="low">Stock bajo</button><button class="al-filter ${state.filter==='out'?'active':''}" data-action="filter" data-filter="out">Sin stock</button><button class="al-filter ${state.filter==='expiry'?'active':''}" data-action="filter" data-filter="expiry">Por vencer</button></div><div id="alProductList" class="al-product-list">${items.length?items.slice(0,productLimit).map(productCard).join('')+(items.length>productLimit?'<button class="farm-page-more" data-action="more-products">Mostrar 30 productos más</button>':''):'<div class="al-empty"><strong>Tu inventario está listo para comenzar</strong>Registra el primer insumo y después añade una entrada para calcular automáticamente su saldo.<br><br><button class="al-btn al-btn-primary" data-action="new-item">＋ Registrar producto</button></div>'}</div></div><p class="al-footnote">El stock se calcula a partir de los movimientos guardados. No se puede aumentar o descontar una existencia editando la ficha del producto.</p>`;
  }
  function kardexPane() {
    const data=readData(), rows=allMovements().slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'') || (Number(b.createdAt)||0)-(Number(a.createdAt)||0)).filter(m=>{
      const item=data.items.find(i=>i.id===m.itemId); const q=state.query.trim().toLowerCase(); return !q || [item?.name,item?.code,m.doc,m.batch,m.party,m.destination,m.notes].join(' ').toLowerCase().includes(q);
    });
    return `<div class="al-card"><div class="al-card-head"><div><h3 class="al-section-title">Kardex valorizado</h3><p class="al-section-sub">Historial cronológico de ingresos, retiros y saldos.</p></div><button class="al-btn al-btn-soft al-btn-mini" data-action="export">⇩ CSV</button></div><input class="al-search" id="alSearch" type="search" value="${escAttr(state.query)}" placeholder="Filtrar por producto, lote o documento…" autocomplete="off"><div class="al-table-wrap"><table class="al-table"><thead><tr><th>Fecha / doc.</th><th>Producto / lote</th><th>Movimiento</th><th class="al-number">Entrada</th><th class="al-number">Salida</th><th class="al-number">Saldo actual</th><th class="al-number">Costo unit.</th><th class="al-number">Valor</th></tr></thead><tbody>${rows.length?rows.slice(0,movementLimit).map(m=>{const i=data.items.find(x=>x.id===m.itemId);const entry=signedQty(m)>0;return `<tr><td>${esc(formatDate(m.date))}<br><span style="color:var(--al-muted)">${esc(m.doc||'—')}</span></td><td><b>${esc(i?.name||'Producto eliminado')}</b><br><span style="color:var(--al-muted)">${esc(i?.code||'')} · ${esc(m.batch||'SIN-LOTE')}</span></td><td>${esc(movementLabel(m.type,m.source))}</td><td class="al-number ${entry?'al-in':''}">${entry?num(m.qty,3)+' '+esc(i?.unit||''): '—'}</td><td class="al-number ${!entry?'al-out':''}">${!entry?num(m.qty,3)+' '+esc(i?.unit||''):'—'}</td><td class="al-number"><b>${num(itemStock(m.itemId),3)} ${esc(i?.unit||'')}</b></td><td class="al-number">${money(m.unitCost)}</td><td class="al-number">${money((Number(m.qty)||0)*(Number(m.unitCost)||0))}</td></tr>`}).join(''):'<tr><td colspan="8"><div class="al-empty">Todavía no hay movimientos. Registra una entrada para comenzar el Kardex.</div></td></tr>'}</tbody></table></div>${rows.length>movementLimit?`<button class="farm-page-more" data-action="more-movements">Mostrar 30 movimientos más · ${movementLimit} de ${rows.length}</button>`:""}<p class="al-footnote">Los importes son estimaciones a partir del costo unitario registrado por movimiento. El saldo mostrado corresponde al saldo actual del producto, no a un saldo histórico por fila.</p></div>`;
  }
  function alertsPane() {
    const data=readData(), items=data.items.filter(i=>i.active!==false), expiry=expiryFlags(), low=items.filter(i=>['low','out'].includes(itemStatus(i).cls));
    const blocks=[];
    low.forEach(i=>{const s=itemStatus(i),batches=batchBalances(i.id);blocks.push(`<div class="al-alert ${s.cls==='out'?'danger':''}"><span class="al-alert-icon">${s.cls==='out'?'!':'⚑'}</span><div class="al-alert-text"><b>${esc(i.name)} · ${s.label}</b>Saldo: ${num(itemStock(i.id),3)} ${esc(i.unit)} · mínimo configurado: ${num(i.minStock,3)} ${esc(i.unit)}<div style="margin-top:5px"><button class="al-btn al-btn-plain al-btn-mini" data-action="movement" data-id="${escAttr(i.id)}">Registrar reposición</button></div></div></div>`)});
    expiry.forEach(x=>blocks.push(`<div class="al-alert ${x.kind==='expired'?'danger':''}"><span class="al-alert-icon">${x.kind==='expired'?'!':'◷'}</span><div class="al-alert-text"><b>${esc(x.item.name)} · lote ${esc(x.batch.batch)}</b>${x.kind==='expired'?'Vencido hace '+Math.abs(x.days)+' día(s)':'Vence '+(x.days===0?'hoy':'en '+x.days+' día(s)')} · ${formatDate(x.batch.expiry)} · saldo ${num(x.batch.qty,3)} ${esc(x.item.unit)}</div></div>`));
    return `<div class="al-card"><div class="al-card-head"><div><h3 class="al-section-title">Alertas de almacén</h3><p class="al-section-sub">Puntos que requieren reposición o revisión sanitaria.</p></div><span class="al-count">${blocks.length} alerta(s)</span></div><div class="al-alert-list">${blocks.length?blocks.join(''):'<div class="al-empty"><strong>Todo tranquilo por ahora</strong>No hay productos con stock bajo ni lotes vencidos o próximos a vencer entre los datos registrados.</div>'}</div><p class="al-footnote">Para alimento, productos veterinarios y químicos, captura lote y vencimiento tal como aparecen en la etiqueta. Esta alerta no sustituye la evaluación técnica ni autoriza el uso de productos vencidos.</p></div>`;
  }
  function itemModal() {
    const item=state.editId?findItem(state.editId):null;
    const v=(k,def='')=>escAttr(item?.[k]??def);
    return `<div class="al-modal open" data-modal="item"><section class="al-modal-panel" role="dialog" aria-modal="true" aria-labelledby="alItemTitle"><div class="al-modal-head"><div><h3 id="alItemTitle">${item?'Editar producto':'Registrar producto'}</h3><p>Identificación del insumo y su ubicación en almacén.</p></div><button class="al-close" type="button" data-action="close-modal" aria-label="Cerrar">×</button></div><form class="al-form" data-form="item"><div class="al-field"><label for="alItemName">Nombre del producto *</label><input class="al-input" id="alItemName" name="name" required maxlength="100" value="${v('name')}" placeholder="Ej. Alimento trucha 2 mm"></div><div class="al-grid2"><div class="al-field"><label for="alItemCode">Código interno</label><input class="al-input" id="alItemCode" name="code" value="${v('code',nextCode())}" readonly></div><div class="al-field"><label for="alItemCategory">Categoría *</label><select class="al-select" id="alItemCategory" name="category" required>${['Alimento balanceado','Productos veterinarios','Desinfectantes y químicos','Reactivos y calidad de agua','Equipos y repuestos','Materiales de cultivo','Bioseguridad y EPP','Otros'].map(c=>`<option ${item?.category===c?'selected':''}>${c}</option>`).join('')}</select></div></div><div class="al-grid2"><div class="al-field"><label for="alItemUnit">Unidad de control *</label><select class="al-select" id="alItemUnit" name="unit" required>${['kg','saco','unidad','L','mL','g','rollo','par','frasco','caja','metro'].map(c=>`<option ${v('unit','kg')===c?'selected':''}>${c}</option>`).join('')}</select></div><div class="al-field"><label for="alItemMin">Stock mínimo de alerta</label><input class="al-input" id="alItemMin" name="minStock" type="number" min="0" step="0.001" value="${v('minStock','0')}"></div></div><div class="al-field" id="alItemPackField" ${item?.unit==='saco'&&item?.category==='Alimento balanceado'?'':'hidden'}><label for="alItemKgPerUnit">Contenido por saco (kg)</label><input class="al-input" id="alItemKgPerUnit" name="kgPerUnit" type="number" min="0.001" step="any" value="${v('kgPerUnit')}" placeholder="Según la etiqueta del producto"><small>Permite convertir los kg entregados a la unidad del almacén. Los productos en kg o g se convierten automáticamente.</small></div><div class="al-grid2"><div class="al-field"><label for="alItemLocation">Ubicación</label><input class="al-input" id="alItemLocation" name="location" maxlength="80" value="${v('location')}" placeholder="Estante A · zona seca"></div><div class="al-field"><label for="alItemBrand">Marca / proveedor habitual</label><input class="al-input" id="alItemBrand" name="brand" maxlength="80" value="${v('brand')}" placeholder="Opcional"></div></div><div class="al-field"><label for="alItemNotes">Notas de manejo / conservación</label><textarea class="al-textarea" id="alItemNotes" name="notes" maxlength="500" placeholder="Ej. almacenar sobre parihuela, lugar seco y ventilado…">${esc(item?.notes||'')}</textarea></div><div class="al-form-help">La ficha no genera stock por sí sola. Registra una <b>entrada</b> con cantidad, costo, lote del proveedor y vencimiento cuando corresponda.</div><div class="al-form-actions"><button class="al-btn al-btn-plain" type="button" data-action="close-modal">Cancelar</button><button class="al-btn al-btn-primary" type="submit">${item?'Guardar cambios':'Crear producto'}</button></div></form></section></div>`;
  }
  function movementModal() {
    if (!allItems().some(i=>i.active!==false)) return `<div class="al-modal open" data-modal="movement"><section class="al-modal-panel" role="dialog" aria-modal="true"><div class="al-modal-head"><div><h3>Primero registra un producto</h3><p>El movimiento quedará ligado a un producto del inventario.</p></div><button class="al-close" data-action="close-modal">×</button></div><div class="al-form-help">No puedes registrar entradas o salidas sin crear antes la ficha del producto.</div><button class="al-btn al-btn-primary" style="width:100%;margin-top:12px" data-action="new-item">＋ Registrar producto</button></section></div>`;
    const selected=findItem(state.selectedItem), items=allItems().filter(i=>i.active!==false);
    return `<div class="al-modal open" data-modal="movement"><section class="al-modal-panel" role="dialog" aria-modal="true" aria-labelledby="alMovementTitle"><div class="al-modal-head"><div><h3 id="alMovementTitle">Registrar movimiento</h3><p>Entrada, salida, devolución o corrección del saldo.</p></div><button class="al-close" type="button" data-action="close-modal" aria-label="Cerrar">×</button></div><form class="al-form" data-form="movement"><div class="al-field"><label for="alMovItem">Producto *</label><select class="al-select" id="alMovItem" name="itemId" required>${items.map(i=>`<option value="${escAttr(i.id)}" ${(selected?.id===i.id)?'selected':''}>${esc(i.code)} · ${esc(i.name)} (${num(itemStock(i.id),3)} ${esc(i.unit)})</option>`).join('')}</select></div><div class="al-grid2"><div class="al-field"><label for="alMovType">Tipo de movimiento *</label><select class="al-select" id="alMovType" name="type"><option value="entrada">Entrada / compra</option><option value="salida">Salida / consumo</option><option value="devolucion">Devolución a almacén</option><option value="ajuste+">Ajuste positivo</option><option value="ajuste-">Ajuste negativo</option></select></div><div class="al-field"><label for="alMovDate">Fecha *</label><input class="al-input" id="alMovDate" name="date" type="date" required value="${localDate()}"></div></div><div class="al-grid2"><div class="al-field"><label for="alMovQty">Cantidad *</label><input class="al-input" id="alMovQty" name="qty" type="number" min="0.001" step="0.001" required placeholder="0.000"></div><div class="al-field"><label for="alMovCost">Costo unitario (S/) *</label><input class="al-input" id="alMovCost" name="unitCost" type="number" min="0" step="0.0001" value="${selected?Number(itemAvgCost(selected.id)).toFixed(4):''}" placeholder="0.00" required></div></div><div class="al-grid2"><div class="al-field"><label for="alMovBatch">Lote del proveedor</label><input class="al-input" id="alMovBatch" name="batch" maxlength="80" list="alBatchOptions" placeholder="Ej. LT-0826"><datalist id="alBatchOptions">${(selected?batchBalances(selected.id):[]).map(b=>`<option value="${escAttr(b.batch)}">${num(b.qty,3)} ${esc(selected?.unit||'')} disponibles · vence ${esc(formatDate(b.expiry))}</option>`).join('')}</datalist></div><div class="al-field"><label for="alMovExpiry">Vencimiento (si aplica)</label><input class="al-input" id="alMovExpiry" name="expiry" type="date"></div></div><div class="al-grid2"><div class="al-field"><label for="alMovDoc">Documento / comprobante</label><input class="al-input" id="alMovDoc" name="doc" maxlength="100" placeholder="Factura, guía, vale…"></div><div class="al-field"><label for="alMovParty">Proveedor / responsable</label><input class="al-input" id="alMovParty" name="party" maxlength="100" placeholder="Nombre o razón social"></div></div><div class="al-grid2"><div class="al-field"><label for="alMovDestination">Destino / área usuaria</label><input class="al-input" id="alMovDestination" name="destination" maxlength="100" placeholder="Ej. Jaula 03 / Alevinaje"></div><div class="al-field"><label for="alMovLot">Lote productivo asociado</label><select class="al-select" id="alMovLot" name="linkedLot"><option value="">Sin asignar</option>${(window.TruchAppData?.getLots?.()||[]).map(l=>`<option value="${escAttr(l.code)}">${esc(l.code)} · ${esc(l.stage||'Producción')}</option>`).join('')}</select></div></div><div class="al-field"><label for="alMovNotes">Observaciones</label><textarea class="al-textarea" id="alMovNotes" name="notes" maxlength="500" placeholder="Motivo, condición del envase, lote medicado separado, etc."></textarea></div><div class="al-form-help" id="alMovHelp">Para que el alimento entregado descuente stock y registre su costo por lote, usa Registro diario en Lotes. Una salida manual no crea ese registro. Para registrar una salida, indica el lote del insumo si necesitas seleccionar uno específico. Si se deja vacío, el sistema descuenta primero los lotes con vencimiento más próximo (FEFO) y evita saldos negativos.</div><div class="al-form-actions"><button class="al-btn al-btn-plain" type="button" data-action="close-modal">Cancelar</button><button class="al-btn al-btn-primary" type="submit">Guardar movimiento</button></div></form></section></div>`;
  }
  function detailModal() {
    const item=findItem(state.selectedItem); if(!item) return '';
    const moves=itemMoves(item.id); const batches=batchBalances(item.id);
    return `<div class="al-modal open" data-modal="detail"><section class="al-modal-panel" role="dialog" aria-modal="true" aria-labelledby="alDetailTitle"><div class="al-modal-head"><div><h3 id="alDetailTitle">Kardex del producto</h3><p>Movimientos y trazabilidad por lote.</p></div><button class="al-close" type="button" data-action="close-modal" aria-label="Cerrar">×</button></div><div class="al-detail-head"><strong>${esc(item.name)}</strong><small>${esc(item.code)} · ${esc(categoryName(item.category))}<br>Stock actual: ${num(itemStock(item.id),3)} ${esc(item.unit)} · Valor estimado: ${money(itemValue(item.id))}<br>Ubicación: ${esc(item.location||'No indicada')}</small></div><div class="al-card-head"><h4 class="al-section-title" style="font-size:14px">Lotes con saldo</h4><span class="al-count">${batches.length}</span></div><div class="al-table-wrap" style="margin-bottom:12px"><table class="al-table" style="min-width:360px"><thead><tr><th>Lote proveedor</th><th>Vencimiento</th><th class="al-number">Saldo</th><th class="al-number">Costo prom.</th></tr></thead><tbody>${batches.length?batches.map(b=>`<tr><td>${esc(b.batch)}</td><td>${esc(formatDate(b.expiry))}</td><td class="al-number">${num(b.qty,3)} ${esc(item.unit)}</td><td class="al-number">${money(b.cost)}</td></tr>`).join(''):'<tr><td colspan="4">Sin existencias registradas.</td></tr>'}</tbody></table></div><div class="al-card-head"><h4 class="al-section-title" style="font-size:14px">Historial de movimientos</h4><span class="al-count">${moves.length} registro(s)</span></div><div class="al-table-wrap"><table class="al-table" style="min-width:470px"><thead><tr><th>Fecha / tipo</th><th>Lote</th><th>Documento / destino</th><th class="al-number">Cantidad</th><th class="al-number">Costo unitario</th><th>Observaciones</th></tr></thead><tbody>${moves.length?moves.map(m=>`<tr><td>${esc(formatDate(m.date))}<br>${esc(movementLabel(m.type,m.source))}</td><td>${esc(m.batch||'SIN-LOTE')}<br><span style="color:var(--al-muted)">${m.expiry?'Vence '+esc(formatDate(m.expiry)):'Sin vencimiento'}</span></td><td>${esc(m.doc||'—')}<br>${esc(m.destination||m.party||'—')}${m.linkedLot?'<br>Lote productivo '+esc(m.linkedLot):''}</td><td class="al-number">${signedQty(m)>0?'+':'−'}${num(m.qty,3)} ${esc(item.unit)}</td><td class="al-number">${money(m.unitCost)}</td><td>${esc(m.notes||'—')}</td></tr>`).join(''):'<tr><td colspan="6">Todavía no hay movimientos para este producto.</td></tr>'}</tbody></table></div><div class="al-form-actions" style="margin-top:12px"><button class="al-btn al-btn-plain" data-action="export-item" data-id="${escAttr(item.id)}">⇩ Exportar Kardex</button><button class="al-btn al-btn-primary" data-action="movement" data-id="${escAttr(item.id)}">＋ Movimiento</button></div></section></div>`;
  }
  function render() {
    if(renderSnapshot)return renderPrepared();const data=readData();renderSnapshot={data,movements:window.TruchAppFeedingData.combinedMovements(data,window.TruchAppData?.getLots?.()||[]),balances:new Map()};try{return renderPrepared();}finally{renderSnapshot=null;}
  }
  function renderPrepared() {
    const el=root(); if(!el) return;
    const s=sumAll();
    const tabs=[['inventory','Inventario'],['kardex','Kardex'],['alerts','Alertas']];
    const pane=state.tab==='kardex'?kardexPane():state.tab==='alerts'?alertsPane():inventoryPane();
    el.innerHTML=`<div class="al-wrap"><div class="al-head"><div><h2>Almacén</h2><p>Inventario, movimientos y trazabilidad de insumos acuícolas.</p></div><div class="al-mark" aria-hidden="true">▤</div></div><div class="al-kpis"><div class="al-kpi"><div class="al-kpi-top"><span>Productos activos</span><span class="al-kpi-icon">▤</span></div><b>${num(s.count,0)}</b><small>Fichas en inventario</small></div><div class="al-kpi"><div class="al-kpi-top"><span>Valor estimado</span><span class="al-kpi-icon">S/</span></div><b>${money(s.value)}</b><small>Según costos registrados</small></div><div class="al-kpi"><div class="al-kpi-top"><span>Stock bajo / cero</span><span class="al-kpi-icon">⚑</span></div><b>${num(s.low+s.out,0)}</b><small>${s.out} sin stock · ${s.low} bajo mínimo</small></div><div class="al-kpi"><div class="al-kpi-top"><span>Lotes por revisar</span><span class="al-kpi-icon">◷</span></div><b>${num(s.expiry,0)}</b><small>Vencidos o vencen en 60 días</small></div></div><div class="al-actions"><button class="al-btn al-btn-primary" data-action="new-item">＋ Registrar producto</button><button class="al-btn al-btn-soft" data-action="movement">⇄ Movimiento</button></div><div class="al-tabs" role="tablist" aria-label="Secciones del almacén">${tabs.map(t=>`<button class="al-tab ${state.tab===t[0]?'active':''}" role="tab" aria-selected="${state.tab===t[0]}" data-action="tab" data-tab="${t[0]}">${t[1]}</button>`).join('')}</div>${pane}<p class="al-footnote">Control local de insumos de acuicultura · Las salidas no pueden superar el saldo disponible. Los productos veterinarios y los alimentos medicados requieren la trazabilidad y condiciones de conservación aplicables.</p>${state.modal==='item'?itemModal():state.modal==='movement'?movementModal():state.modal==='detail'?detailModal():''}</div>`;
  }
  function openModal(which,id) { state.modal=which; state.selectedItem=id||state.selectedItem; state.editId=which==='edit'?id:null; if(which==='edit') state.modal='item'; render(); }
  function closeModal() { state.modal=null; state.editId=null; render(); }
  function toast(message) { window.alert(message); }
  function serializeForm(form) { return Object.fromEntries(new FormData(form).entries()); }
  async function saveItem(form) {
    const v=serializeForm(form), name=String(v.name||'').trim();
    if(!name){toast('Escribe el nombre del producto.');return;}
    const data=readData(), isEdit=!!state.editId;
    const kgPerUnit=v.unit==='saco'&&String(v.kgPerUnit||'').trim()?Number(v.kgPerUnit):null;
    if(v.unit==='saco'&&v.category==='Alimento balanceado'&&(!Number.isFinite(kgPerUnit)||kgPerUnit<=0)){toast('Indica el contenido real de cada saco en kg para vincular las entregas.');return;}
    const previous=isEdit?data.items.find(i=>i.id===state.editId):null;
    if(previous&&allMovements().some(m=>m.itemId===previous.id)&&(previous.unit!==v.unit||previous.kgPerUnit>0&&previous.kgPerUnit!==kgPerUnit)){toast('El producto ya tiene movimientos. Conserva su unidad y el contenido del saco; si cambian, crea otro producto.');return;}
    if(previous&&allMovements().some(m=>m.itemId===previous.id&&m.source==='feeding')&&v.category!=='Alimento balanceado'){toast('Este alimento tiene entregas vinculadas. Conserva su categoría para mantener la trazabilidad.');return;}
    if(isEdit) {
      const idx=data.items.findIndex(i=>i.id===state.editId); if(idx<0)return;
      data.items[idx]={...data.items[idx],name,category:v.category,unit:v.unit,minStock:Math.max(0,Number(v.minStock)||0),location:String(v.location||'').trim(),brand:String(v.brand||'').trim(),notes:String(v.notes||'').trim(),updatedAt:Date.now()};
    } else {
      if(data.items.some(i=>i.name.trim().toLocaleLowerCase('es-PE')===name.toLocaleLowerCase('es-PE')&&i.active!==false)){toast('Ya existe un producto activo con ese nombre. Puedes editar su ficha para actualizarlo.');return;}
      data.items.push({id:makeId('item'),code:nextCode(),name,category:v.category,unit:v.unit,minStock:Math.max(0,Number(v.minStock)||0),location:String(v.location||'').trim(),brand:String(v.brand||'').trim(),notes:String(v.notes||'').trim(),active:true,createdAt:Date.now()});
    }
    const savedItem=isEdit?data.items.find(i=>i.id===state.editId):data.items.at(-1);savedItem.kgPerUnit=kgPerUnit;
    if(window.TruchAppStorage)await window.TruchAppStorage.runAsync('Guardar almacén',()=>saveData(data));else saveData(data); state.modal=null; state.editId=null; state.tab='inventory'; state.filter='all'; state.query=''; render();
  }
  async function saveMovement(form) {
    const v=serializeForm(form), data=readData(), item=data.items.find(i=>i.id===v.itemId&&i.active!==false);
    if(!item){toast('Selecciona un producto activo.');return;}
    const qty=Number(v.qty), cost=Number(v.unitCost), type=v.type, lot=String(v.batch||'').trim(), date=v.date||localDate();
    if(!Number.isFinite(qty)||qty<=0){toast('La cantidad debe ser mayor que cero.');return;}
    if(!Number.isFinite(cost)||cost<0){toast('El costo unitario debe ser cero o mayor.');return;}
    const batchRows=batchBalances(item.id), available=itemStock(item.id);
    const incoming=['entrada','devolucion','ajuste+'].includes(type);
    const outgoing=['salida','ajuste-'].includes(type);
    const draft={date,doc:String(v.doc||'').trim(),party:String(v.party||'').trim(),destination:String(v.destination||'').trim(),linkedLot:String(v.linkedLot||'').trim(),notes:String(v.notes||'').trim(),expiry:String(v.expiry||'').trim(),createdAt:Date.now()};
    if(incoming) {
      if(type==='entrada'&&item.category!=='Otros'&&!lot&&['Alimento balanceado','Productos veterinarios','Desinfectantes y químicos','Reactivos y calidad de agua'].includes(item.category)) {
        const ok=window.confirm('No has indicado lote del proveedor. Registrar sin lote reduce la trazabilidad. ¿Deseas continuar?'); if(!ok)return;
      }
      if(type==='entrada'&&item.category!=='Otros'&&['Alimento balanceado','Productos veterinarios','Desinfectantes y químicos'].includes(item.category)&&!v.expiry){const ok=window.confirm('Este insumo suele requerir control de vencimiento. No has indicado fecha; ¿confirmas que no aplica o no está disponible?');if(!ok)return;}
      data.movements.push({id:makeId('mov'),itemId:item.id,type,date,qty,batch:lot||'SIN-LOTE',expiry:draft.expiry,unitCost:cost,...draft});
    } else if(outgoing) {
      if(qty>available+0.000001){toast(`Saldo insuficiente. Hay ${num(available,3)} ${item.unit} disponibles; no se guardó la salida.`);return;}
      let allocations=[];
      if(lot) {
        const b=batchRows.find(x=>x.batch.toLowerCase()===lot.toLowerCase());
        if(!b){toast('El lote indicado no tiene existencias registradas. Deja el campo vacío para descontar por FEFO o elige un lote disponible.');return;}
        if(qty>b.qty+0.000001){toast(`El lote ${lot} solo tiene ${num(b.qty,3)} ${item.unit} disponibles.`);return;}
        allocations=[{batch:b.batch,qty,cost:b.cost,expiry:b.expiry}];
      } else {
        const sorted=batchRows.slice().sort((a,b)=>{
          if(a.expiry&&b.expiry)return a.expiry.localeCompare(b.expiry)||(a.firstDate||'').localeCompare(b.firstDate||'');
          if(a.expiry)return -1;if(b.expiry)return 1;return (a.firstDate||'').localeCompare(b.firstDate||'');
        });
        let remaining=qty;
        for(const b of sorted){if(remaining<=0.000001)break;const take=Math.min(remaining,b.qty);if(take>0)allocations.push({batch:b.batch,qty:take,cost:b.cost,expiry:b.expiry});remaining-=take;}
        if(remaining>0.000001){toast('No se pudo asignar la salida a lotes disponibles.');return;}
      }
      for(const a of allocations)data.movements.push({...draft,id:makeId('mov'),itemId:item.id,type,date,qty:a.qty,batch:a.batch,expiry:a.expiry||draft.expiry||'',unitCost:a.cost});
    } else { toast('Tipo de movimiento no válido.'); return; }
    if(window.TruchAppStorage)await window.TruchAppStorage.runAsync('Guardar almacén',()=>saveData(data));else saveData(data); state.modal=null; state.selectedItem=item.id; state.tab='inventory'; state.query=''; render();
  }
  function exportCsv(itemId) {
    const data=readData(); const rows=allMovements().filter(m=>!itemId||m.itemId===itemId).slice().sort((a,b)=>(a.date||'').localeCompare(b.date||''));
    const headers=['Fecha','Codigo producto','Producto','Categoria','Unidad','Tipo movimiento','Cantidad','Lote proveedor','Vencimiento','Costo unitario S/','Valor movimiento S/','Documento','Proveedor o responsable','Destino/area','Lote productivo','Observaciones','Saldo actual'];
    const csvCell=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
    const out=[headers.map(csvCell).join(';')];
    rows.forEach(m=>{const i=data.items.find(x=>x.id===m.itemId)||{};out.push([m.date,i.code,i.name,i.category,i.unit,movementLabel(m.type,m.source),(signedQty(m)>0?'+':'-')+num(m.qty,3),m.batch,m.expiry,Number(m.unitCost||0).toFixed(4),(Number(m.qty||0)*Number(m.unitCost||0)).toFixed(2),m.doc,m.party,m.destination,m.linkedLot,m.notes,num(itemStock(m.itemId),3)].map(csvCell).join(';'));});
    const blob=new Blob(['\ufeff'+out.join('\r\n')],{type:'text/csv;charset=utf-8;'}), url=URL.createObjectURL(blob), a=document.createElement('a');a.href=url;a.download=itemId?`Kardex-${(findItem(itemId)?.code||'producto')}.csv`:`TruchAPP-Kardex-${localDate()}.csv`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function handleClick(event) {
    const b=event.target.closest('[data-action]'); if(!b||!root()?.contains(b))return;
    const action=b.dataset.action, id=b.dataset.id;
    if(action==='new-item'){state.modal='item';state.editId=null;render();$('alItemName')?.focus();}
    else if(action==='movement'){if(id)state.selectedItem=id;state.modal='movement';render();}
    else if(action==='detail'){state.selectedItem=id;state.modal='detail';render();}
    else if(action==='edit'){state.editId=id;state.modal='item';render();}
    else if(action==='close-modal')closeModal();
    else if(action==='tab'){state.tab=b.dataset.tab;state.query='';render();}
    else if(action==='more-products'){productLimit+=30;render();}
    else if(action==='more-movements'){movementLimit+=30;render();}
    else if(action==='filter'){productLimit=30;movementLimit=30;state.filter=b.dataset.filter||'all';const search=$('alSearch');state.query=search?.value||state.query;render();}
    else if(action==='export')exportCsv();
    else if(action==='export-item')exportCsv(id);
  }
  async function handleSubmit(event) {
    const form=event.target.closest('form[data-form]'); if(!form||!root()?.contains(form))return;
    event.preventDefault();try{if(form.dataset.form==='item')await saveItem(form);if(form.dataset.form==='movement')await saveMovement(form);}catch(error){toast(error.message||'No se pudo guardar el almacén.');}
  }
  function handleInput(event) {
    if(event.target.id==='alSearch') {
      state.query=event.target.value;productLimit=30;movementLimit=30;
      const list=$('alProductList');
      if(list) list.innerHTML=filteredItems().slice(0,productLimit).map(productCard).join('')||'<div class="al-empty"><strong>No hay coincidencias</strong>Prueba con otro nombre, código o ubicación.</div>';
      else if(state.tab==='kardex') {
        const field=event.target, pos=field.selectionStart;
        render(); const next=$('alSearch');
        if(next){next.focus();try{next.setSelectionRange(pos,pos)}catch(_){}}
      }
    }
  }
  function handleChange(event) {
    if(['alItemUnit','alItemCategory'].includes(event.target.id)){const field=$('alItemPackField');if(field)field.hidden=$('alItemUnit').value!=='saco'||$('alItemCategory').value!=='Alimento balanceado';}
    if(event.target.id==='alMovItem'&&state.modal==='movement'){const val=event.target.value;state.selectedItem=val;const modal=root()?.querySelector('[data-modal="movement"]');if(modal){const sc=modal.querySelector('#alMovType')?.value||'entrada';render();const newType=$('alMovType');if(newType)newType.value=sc;}}
  }
  function init() {
    const el=root(); if(!el||el.dataset.initialized==='1')return;
    el.dataset.initialized='1';el.addEventListener('click',handleClick);el.addEventListener('submit',handleSubmit);el.addEventListener('input',handleInput);el.addEventListener('change',handleChange);
    render();
  }
  window.TruchAppAlmacenRender=render;
  window.TruchAppAlmacenData={getItems:()=>allItems().map(i=>({...i,stock:itemStock(i.id),stockValue:itemValue(i.id),averageCost:itemAvgCost(i.id)})),getMovements:()=>allMovements().map(m=>({...m})),getItemKardex:id=>itemMoves(id).map(m=>({...m}))};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init); else init();
})();
