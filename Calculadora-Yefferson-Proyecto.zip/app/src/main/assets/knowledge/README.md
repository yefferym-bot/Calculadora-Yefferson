# Yefferson Knowledge Book (YKB) — v1.2.0

Biblioteca técnica modular para el componente RAG del asistente de IA de Yefferson.

## Estado de esta versión

- Archivos temáticos: **38**
- Registros técnicos: **240**
- Fuentes registradas: **56**
- Revisión bibliográfica: **octubre de 2026**
- Idioma principal: español
- Especie principal: *Oncorhynchus mykiss*

## Criterio de evidencia

**A — científica:** estudios o revisiones revisadas por pares.  
**B — oficial:** FAO, USGS, USFWS, MINAM, SANIPES, Codex, FDA u otros organismos/normas oficiales.  
**C — académica:** tesis o casos académicos, usados como contexto y no como regla universal.  
**D — técnica/educativa:** manuales técnicos o documentos educativos; se mantienen claramente identificados.

Los resultados experimentales, rangos, concentraciones, densidades y dosis se conservan con su contexto. **No deben interpretarse como valores universales.** En particular, los datos hormonales de reversión sexual permanecen etiquetados como evidencia experimental.

## Arquitectura

`pregunta → recuperación híbrida (semántica + palabras clave) → registros relevantes → Qwen3 → respuesta con procedencia`

La biblioteca se mantiene separada de:

- memoria personal del usuario;
- historial de conversación;
- herramientas/calculadoras;
- lógica de la aplicación Android.

## Regla de mantenimiento

No borrar versiones anteriores. Cada auditoría mayor aumenta la versión (1.0.0 → 1.1.0 → 1.2.0). Los archivos individuales también pueden versionarse si se amplía un tema concreto.

## Fuentes y trazabilidad

`fuentes.json` contiene los identificadores y metadatos de las referencias. Cada registro temático incluye un arreglo `fuentes` con los IDs utilizados.

La versión 1.1.0 incorpora, entre otras mejoras, DOI/PMID verificables, el perfil USGS actualizado en 2026, estudios recientes sobre RAS y estudios experimentales sobre temperatura embrionaria, envejecimiento postovulatorio, densidad y reversión sexual.

## Importante

Esta biblioteca es una base de conocimiento técnico para apoyo a consultas. No reemplaza diagnóstico veterinario, regulación sanitaria, validación experimental ni procedimientos autorizados.

## v1.2.0 — Corrección de recuperación RAG

Se añade `rag_index.json`, un índice plano que reúne los 240 registros de los 38 archivos temáticos. El índice incluye módulo, archivo de origen, título, tema, subtema, contenido, palabras clave, alias de búsqueda y procedencia.

La búsqueda recomendada es híbrida: coincidencia de título/tema/subtema y palabras clave + similitud semántica sobre el campo `busqueda`. Los archivos temáticos siguen siendo la fuente de contenido; `rag_index.json` funciona como capa de recuperación.

Esto permite que una consulta como «truchas comen menos y hay mortalidad, 13 °C, oxígeno, TAN y nitrito» recupere conjuntamente alimentación y calidad de agua, además de sanidad cuando corresponda. No se deben convertir valores experimentales en límites universales ni diagnosticar enfermedades sin evidencia suficiente.
