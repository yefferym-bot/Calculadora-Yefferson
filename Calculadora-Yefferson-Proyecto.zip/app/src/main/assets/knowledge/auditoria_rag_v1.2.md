# Auditoría de recuperación RAG — Yefferson Knowledge Book v1.2.0

Fecha: 2026-10-08

## Problema detectado
La recuperación de prueba desde la raíz podía devolver `README.md`, `manifest.json`, `fuentes.json` y la auditoría en lugar de los archivos JSON temáticos anidados. El contenido técnico existía, pero el mecanismo de descubrimiento podía perderlo.

## Corrección
Se añadió `rag_index.json` en la raíz. Es un índice plano de los **240 registros** distribuidos en **38 archivos temáticos**. Cada entrada conserva el registro original y añade: `archivo_fuente`, `modulo`, `busqueda`, `palabras_clave` y `prioridad_retrieval`.

## Enrutamiento por módulos
El índice incorpora alias de búsqueda para términos frecuentes de cada módulo: alimentación/biomasa/FCR; temperatura/oxígeno/DO/TAN/NH3/nitrito; sanidad/mortalidad/bacterias/parásitos/Saprolegnia; incubación/ovas; reproducción/neomachos/reversión sexual; RAS; procesamiento/HACCP; producción/costos/registros, etc.

## Regla de uso
1. Buscar primero en `rag_index.json`.
2. Recuperar pocos registros relevantes (3–8).
3. Mantener `fuentes`, `tipo_evidencia`, `alerta` y `nota_evidencia`.
4. Consultar el JSON temático original cuando se necesite el contexto completo.
5. No diagnosticar ni aplicar dosis/límites solo por coincidencia textual.

## Resultado esperado
Las preguntas que mezclen variables deben recuperar más de un módulo. Por ejemplo, una consulta sobre mortalidad + baja alimentación + 13 °C + O2 + TAN + nitrito debe recuperar alimentación, temperatura, oxígeno, amoníaco y nitrito, y después sanidad como diagnóstico diferencial.

La corrección no elimina ni sustituye los archivos v1.1.0; agrega una capa de recuperación compatible con la estructura existente.
