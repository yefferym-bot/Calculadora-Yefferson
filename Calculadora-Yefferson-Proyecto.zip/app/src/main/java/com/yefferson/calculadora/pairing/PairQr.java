package com.yefferson.calculadora.pairing;

import org.json.*;
import java.io.IOException;
import java.net.*;
import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.util.*;

/** Bounded local invitation, never a credential that grants membership. */
public final class PairQr {
    private static final String PREFIX="TRUCHAPP:LOCAL:1:";
    public final String endpoint,fingerprint,token;public final long expires;
    private PairQr(String e,String f,String t,long x){endpoint=e;fingerprint=f;token=t;expires=x;}
    public static PairQr create(String endpoint,String fingerprint,String token,long expires,long now) throws Exception {
        endpoint(endpoint);PairRecords.fingerprint(fingerprint);
        if(token==null||!token.matches("[0-9a-f]{64}"))throw new IOException("El QR no contiene una invitación válida");
        if(expires<=now||expires-now>300000L)throw new IOException("El QR venció o la fecha no coincide. Genera otro QR en el administrador");
        return new PairQr(endpoint,fingerprint,token,expires);
    }
    public static PairQr parse(String raw,long now) throws Exception {
        if(raw==null||raw.length()>2048||!raw.startsWith(PREFIX))throw new IOException("Este QR no es una invitación local de TruchApp");
        JSONTokener decoder=new JSONTokener(raw.substring(PREFIX.length()));Object decoded=decoder.nextValue();if(!(decoded instanceof JSONObject)||decoder.nextClean()!=0)throw new IOException("Contenido del QR inválido");JSONObject value=(JSONObject)decoded;
        if(value.length()!=6||value.getInt("v")!=1||!"local".equals(value.getString("kind")))throw new IOException("Versión de QR incompatible");
        return create(value.getString("endpoint"),value.getString("fingerprint"),value.getString("token"),value.getLong("expires"),now);
    }
    public String text() throws JSONException {return PREFIX+new JSONObject().put("v",1).put("kind","local").put("endpoint",endpoint).put("fingerprint",fingerprint).put("token",token).put("expires",expires).toString();}
    public BitMatrix matrix() throws Exception {Map<EncodeHintType,Object> hints=new EnumMap<>(EncodeHintType.class);hints.put(EncodeHintType.MARGIN,4);hints.put(EncodeHintType.ERROR_CORRECTION,ErrorCorrectionLevel.M);return new QRCodeWriter().encode(text(),BarcodeFormat.QR_CODE,640,640,hints);}
    private static void endpoint(String value) throws Exception {
        if(value==null||!value.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}:[0-9]{1,5}"))throw new IOException("Dirección del QR inválida");
        int split=value.lastIndexOf(':');String host=value.substring(0,split);for(String part:host.split("\\."))if(Integer.parseInt(part)>255)throw new IOException("IP del QR inválida");
        InetAddress ip=InetAddress.getByName(host);int port=Integer.parseInt(value.substring(split+1));
        if(!ip.isSiteLocalAddress()||ip.isLoopbackAddress()||ip.isMulticastAddress()||port<1024||port>65535)throw new IOException("El QR debe señalar una dirección privada local");
    }
}
