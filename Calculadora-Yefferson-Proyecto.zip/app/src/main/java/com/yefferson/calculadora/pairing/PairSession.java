package com.yefferson.calculadora.pairing;

import org.json.JSONObject;
import java.io.IOException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.ThreadLocalRandom;
import javax.net.ssl.SSLSocket;

/** Testable, transport-independent pairing state machine; Android owns policy and persistence. */
public final class PairSession implements Runnable {
    public interface Host {
        String name();boolean known(String fingerprint,String remoteRole) throws Exception;boolean invitationOpen();
        default String invitationToken(){return "";}
        default void checkInvitationToken(String token) throws Exception {}
        default boolean denied(String fingerprint) throws Exception {return false;}
        void verifying(PairSession session);JSONObject approve(PairSession session) throws Exception;
        void accept(PairSession session,JSONObject grant) throws Exception;void connected(PairSession session);
        void revoked(PairSession session) throws Exception;void ended(PairSession session,Exception error);
    }
    public final String id=UUID.randomUUID().toString(),role;
    public volatile String peer="",peerName="",code="",state="connecting";
    public volatile JSONObject selection=new JSONObject();
    private final SSLSocket socket;private final Host host;private volatile PairWire wire;private PairRuntime runtime;private volatile PairOutbound outbound;
    private volatile boolean confirmed,closed,rejected;private final AtomicBoolean closing=new AtomicBoolean();
    private volatile long receivedAt,nextPing;private volatile String failureReason;
    private long controlAt;private double tokens=10;
    public PairSession(SSLSocket socket,String role,Host host){this.socket=socket;this.role=role;this.host=host;}
    public void confirm(JSONObject selection){if(!"verify".equals(state)||closed)return;this.selection=selection;confirmed=true;state="waiting";}
    /** Outgoing collaborator intent is a request, never an administrator grant. */
    public void submitRequest(){if("collaborator".equals(role))confirm(new JSONObject());}
    public void reject(){rejected=true;finish("admin".equals(role)?"rejected":"withdrawn");}
    void attach(PairRuntime runtime){this.runtime=runtime;}
    public boolean isClosed(){return closed;}
    public boolean isCancelled(){return closed||rejected;}
    public void close(){if(!closing.compareAndSet(false,true))return;closed=true;if(outbound!=null)outbound.close();try{socket.close();}catch(Exception ignored){}}
    public void fail(String reason){if(!closed){failureReason=reason;close();}}
    private void finish(String type){try{if(wire!=null&&wire.offer(PairWire.message(type),this::close))return;}catch(Exception ignored){}close();}
    public void revoke(){finish("revoked");}
    public void unlink(){finish("unlink");}
    public void ping(){if(!"connected".equals(state)||closed)return;try{wire.offer(PairWire.message("ping"),null);}catch(Exception e){close();}}
    public void tick(long now){if(closed)return;PairWire current=wire;if(current!=null&&current.expiredFrame(now)){fail("El mensaje local no se completó a tiempo");return;}if(!"connected".equals(state))return;if(now-receivedAt>45000000000L){fail("El otro teléfono dejó de responder. Vuelve a conectar");return;}if(now>=nextPing){nextPing=now+ThreadLocalRandom.current().nextLong(10000,16001)*1000000L;if(now-receivedAt>8000000000L)ping();}}
    private JSONObject receive() throws Exception {JSONObject value=wire.receive();receivedAt=System.nanoTime();return value;}
    private void control(JSONObject value) throws IOException {long now=System.nanoTime();tokens=Math.min(10,tokens+(now-controlAt)/1000000000.0*5);controlAt=now;if(value.length()!=1||tokens<1)throw new IOException("Demasiados mensajes de este equipo");tokens--;}
    @Override public void run(){Exception failure=null;try{
        socket.setTcpNoDelay(true);socket.setSoTimeout(15000);
        if(runtime!=null){runtime.beforeTls(this);try{socket.startHandshake();}finally{runtime.afterTls();}outbound=runtime.outbound(socket,()->fail("El envío a este equipo se interrumpió"));}else socket.startHandshake();
        wire=new PairWire(socket,outbound);wire.limit(1024);
        String local=PairWire.fingerprint((X509Certificate)socket.getSession().getLocalCertificates()[0]);
        peer=PairWire.fingerprint((X509Certificate)socket.getSession().getPeerCertificates()[0]);
        if(local.equals(peer))throw new IOException("No puedes vincular este dispositivo consigo mismo");
        if(runtime!=null)runtime.claim(this);
        String remoteRole="admin".equals(role)?"collaborator":"admin";
        boolean known=host.known(peer,remoteRole),denied="admin".equals(role)&&host.denied(peer);
        byte[] bytes=new byte[32];new SecureRandom().nextBytes(bytes);String nonce=PairWire.hex(bytes);
        // Both commitments are exchanged before revealing either nonce (prevents adaptive SAS grinding).
        wire.send(PairWire.message("commit").put("version",1).put("digest",PairWire.commitment(role,local,nonce)));
        JSONObject commitment=receive();PairWire.expect(commitment,"commit");
        if(commitment.optInt("version")!=1||!commitment.optString("digest").matches("[0-9a-f]{64}"))throw new IOException("Versión local incompatible");
        wire.send(PairWire.message("hello").put("role",role).put("nonce",nonce).put("name",host.name()).put("known",known).put("revoked",denied).put("requests",true).put("invitation",host.invitationToken()).put("qr",true));
        JSONObject hello=receive();PairWire.expect(hello,"hello");String remoteNonce=hello.optString("nonce");
        if(!remoteRole.equals(hello.optString("role"))||!remoteNonce.matches("[0-9a-f]{64}")||!commitment.getString("digest").equals(PairWire.commitment(remoteRole,peer,remoteNonce)))throw new IOException("Identidad o verificación local inválida");
        if("collaborator".equals(role)&&!host.invitationToken().isEmpty()&&!hello.optBoolean("qr"))throw new IOException("Actualiza TruchApp en el administrador para vincular con QR");
        if("admin".equals(role)&&!hello.optString("invitation").isEmpty())host.checkInvitationToken(hello.optString("invitation"));
        peerName=hello.optString("name","Equipo").trim();if(peerName.isEmpty()||peerName.length()>40)throw new IOException("Nombre de equipo inválido");
        if("collaborator".equals(role)&&known&&hello.optBoolean("revoked")){host.revoked(this);throw new IOException("El administrador retiró el acceso de este equipo");}
        if(denied)throw new IOException("El acceso fue retirado; activa Recibir solicitudes para autorizarlo de nuevo");
        if(!(known&&hello.optBoolean("known"))){
            if(!hello.optBoolean("requests"))throw new IOException("Actualiza TruchApp en ambos teléfonos para vincular mediante solicitudes");
            if("admin".equals(role)&&!host.invitationOpen())throw new IOException("El administrador debe activar Recibir solicitudes");
            code="admin".equals(role)?PairWire.verification(local,peer,nonce,remoteNonce):PairWire.verification(peer,local,remoteNonce,nonce);
            state="verify";if(runtime!=null)runtime.interactive(this);host.verifying(this);
            socket.setSoTimeout(400);long deadline=System.nanoTime()+120000000000L;boolean sent=false,remoteConfirmed=false;
            while(!closed&&System.nanoTime()<deadline){
                if(confirmed&&!sent&&!rejected){wire.send(PairWire.message("confirm"));sent=true;}
                if(sent&&remoteConfirmed&&!rejected)break;
                try{JSONObject confirmation=receive();if(confirmation.length()==1&&"collaborator".equals(role)&&"rejected".equals(confirmation.optString("type")))throw new IOException("El administrador rechazó tu solicitud de vinculación");if(confirmation.length()==1&&"admin".equals(role)&&"withdrawn".equals(confirmation.optString("type")))throw new IOException("El colaborador canceló su solicitud de vinculación");PairWire.expect(confirmation,"confirm");if(confirmation.length()!=1||remoteConfirmed)throw new IOException("Confirmación duplicada o inválida");remoteConfirmed=true;}catch(java.net.SocketTimeoutException waiting){}
            }
            if(closed||rejected||!sent||!remoteConfirmed)throw new IOException("Solicitud cancelada o vencida");
            if("admin".equals(role)&&!host.invitationOpen())throw new IOException("La recepción de solicitudes venció; actívala de nuevo");
        }
        if(closed||rejected)throw new IOException("Solicitud cancelada");state="saving";socket.setSoTimeout(15000);
        if("admin".equals(role)){
            JSONObject grant=host.approve(this);wire.send(PairWire.message("grant").put("grant",grant));PairWire.expect(receive(),"saved");wire.send(PairWire.message("ready"));
        }else{
            wire.limit(PairWire.MAX_FRAME);JSONObject grant=receive();PairWire.expect(grant,"grant");wire.limit(1024);if(closed||rejected)throw new IOException("Solicitud cancelada");host.accept(this,grant.getJSONObject("grant"));
            wire.send(PairWire.message("saved"));PairWire.expect(receive(),"ready");
        }
        if(closed)throw new IOException("Conexión cancelada");receivedAt=controlAt=System.nanoTime();nextPing=receivedAt+ThreadLocalRandom.current().nextLong(10000,16001)*1000000L;socket.setSoTimeout(55000);if(runtime!=null)runtime.interactive(this);state="connected";host.connected(this);
        while(!closed){
            JSONObject message=receive();control(message);String type=message.optString("type");
            if("ping".equals(type))wire.offer(PairWire.message("pong"),null);
            else if("pong".equals(type))continue;
            else if(("revoked".equals(type)&&"collaborator".equals(role))||("unlink".equals(type)&&"admin".equals(role))){host.revoked(this);break;}
            else throw new IOException("Acción no admitida por el emparejamiento local");
        }
    }catch(Exception e){if(!closed)failure=e;}finally{if(failure==null&&failureReason!=null)failure=new IOException(failureReason);close();state="disconnected";host.ended(this,failure);}}
}
