package com.yefferson.calculadora.ai.knowledge;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Embedded Yefferson Knowledge Book (YKB) retrieval boundary.
 * Loads only local assets; it never changes UI, calculator, memory or reminders.
 */
public final class KnowledgeManager {
    private static final String INDEX_ASSET = "knowledge/rag_index.json";
    private static final int DEFAULT_LIMIT = 3;
    private static final int MAX_CONTENT_CHARS = 520;
    private static final int MAX_CONTEXT_CHARS = 2600;

    private final Context context;
    private volatile boolean loaded = false;
    private volatile String version = "";
    private final List<Record> records = new ArrayList<>();
    private final List<String> aliasPairs = new ArrayList<>();

    private static final Set<String> STOPWORDS = new HashSet<>();
    static {
        Collections.addAll(STOPWORDS,
                "para", "que", "con", "como", "este", "esta", "estos", "estas", "una", "uno",
                "unos", "unas", "del", "las", "los", "por", "sin", "sobre", "entre", "desde",
                "donde", "cuando", "debo", "deberia", "debería", "puedo", "puede", "tengo", "tiene",
                "hay", "son", "está", "esta", "están", "y", "o", "a", "en", "mi", "mis", "me",
                "un", "al", "lo", "es", "se", "qué", "que", "cómo", "como", "porqué", "porque",
                "del", "los", "las", "muy", "más", "mas", "tambien", "también", "de", "kg", "g", "c");
    }

    public KnowledgeManager(Context context) {
        this.context = context.getApplicationContext();
    }

    /** Loads the embedded index once. Call from the AI executor, not the UI thread. */
    public synchronized boolean load() {
        if (loaded) return true;
        records.clear();
        aliasPairs.clear();
        try (InputStream in = context.getAssets().open(INDEX_ASSET);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder json = new StringBuilder();
            char[] buffer = new char[8192];
            int n;
            while ((n = reader.read(buffer)) != -1) json.append(buffer, 0, n);

            JSONObject root = new JSONObject(json.toString());
            version = root.optString("version", "1.2.0");
            JSONObject aliases = root.optJSONObject("alias_modulo");
            if (aliases != null) {
                Iterator<String> keys = aliases.keys();
                while (keys.hasNext()) {
                    String module = keys.next();
                    JSONArray values = aliases.optJSONArray(module);
                    if (values == null) continue;
                    for (int i = 0; i < values.length(); i++) {
                        String alias = normalize(values.optString(i, ""));
                        if (!alias.isEmpty()) aliasPairs.add(module + "=" + alias);
                    }
                }
            }
            JSONArray arr = root.optJSONArray("registros");
            if (arr == null) return false;

            for (int i = 0; i < arr.length(); i++) {
                JSONObject x = arr.optJSONObject(i);
                if (x == null) continue;
                records.add(new Record(
                        x.optString("id", ""),
                        x.optString("titulo", ""),
                        x.optString("contenido", ""),
                        x.optString("tema", ""),
                        x.optString("subtema", ""),
                        x.optString("modulo", ""),
                        x.optString("archivo_fuente", ""),
                        x.optString("tipo_evidencia", ""),
                        x.optString("aplicacion", ""),
                        x.optJSONArray("fuentes"),
                        x.optJSONArray("palabras_clave"),
                        x.optString("busqueda", "")
                ));
            }
            loaded = !records.isEmpty();
            return loaded;
        } catch (Exception ignored) {
            loaded = false;
            version = "";
            records.clear();
            return false;
        }
    }

    public boolean isLoaded() { return loaded; }
    public String getVersion() { return version; }
    public int size() { return records.size(); }

    /**
     * Returns a compact, source-aware knowledge context for the local model.
     * Retrieval is hybrid: module alias matching + title/topic/keyword/content overlap.
     */
    public String searchContext(String question, int requestedLimit) {
        if (!loaded && !load()) return "";
        String q = normalize(question);
        if (q.isEmpty()) return "";
        List<String> tokens = tokenize(q);
        if (tokens.isEmpty()) return "";

        final List<String> preferredModules = detectPreferredModules(q);
        List<Scored> ranked = new ArrayList<>();
        for (Record r : records) {
            int score = r.score(q, tokens, preferredModules);
            if (score > 0) ranked.add(new Scored(r, score));
        }

        if (ranked.isEmpty()) return "";
        ranked.sort((a, b) -> {
            int byScore = Integer.compare(b.score, a.score);
            if (byScore != 0) return byScore;
            return a.record.title.compareToIgnoreCase(b.record.title);
        });

        int limit = Math.max(1, Math.min(DEFAULT_LIMIT + 2, requestedLimit <= 0 ? DEFAULT_LIMIT : requestedLimit));
        StringBuilder out = new StringBuilder();
        int used = 0;
        Set<String> seenRecords = new HashSet<>();
        Set<String> usedModules = new HashSet<>();
        // First pass: cover detected domains (e.g. feeding + water + health) so a
        // mixed real-world question does not get dominated by one module.
        for (String preferred : preferredModules) {
            for (Scored item : ranked) {
                if (!preferred.equals(item.record.modulo) || usedModules.contains(preferred)) continue;
                String key = item.record.modulo + "|" + item.record.id;
                if (!seenRecords.add(key)) continue;
                String block = item.record.toPromptBlock();
                if (out.length() + block.length() + 2 > MAX_CONTEXT_CHARS) break;
                if (used > 0) out.append("\n\n");
                out.append(block);
                used++;
                usedModules.add(preferred);
                break;
            }
            if (used >= limit) return out.toString();
        }

        for (Scored item : ranked) {
            Record r = item.record;
            String key = r.modulo + "|" + r.id;
            if (!seenRecords.add(key)) continue;

            String block = r.toPromptBlock();
            if (out.length() + block.length() + 2 > MAX_CONTEXT_CHARS) break;
            if (used > 0) out.append("\n\n");
            out.append(block);
            used++;
            if (used >= limit) break;
        }
        return out.toString();
    }

    private List<String> detectPreferredModules(String q) {
        final java.util.Map<String, Integer> strength = new java.util.HashMap<>();
        for (String pair : aliasPairs) {
            int sep = pair.indexOf('=');
            if (sep <= 0) continue;
            String module = pair.substring(0, sep);
            String alias = pair.substring(sep + 1);
            if (!q.contains(alias)) continue;
            int weight = alias.split("\\s+").length >= 2 ? 5 : (alias.length() >= 6 ? 2 : 1);
            strength.put(module, strength.getOrDefault(module, 0) + weight);
        }
        // Natural-language cues that are common in real field reports but are not
        // always written with the exact terminology of the indexed records.
        if (q.contains("muerto") || q.contains("muertos") || q.contains("pez muerto") || q.contains("peces muertos")) {
            strength.put("07_enfermedades", strength.getOrDefault("07_enfermedades", 0) + 6);
        }
        List<String> modules = new ArrayList<>(strength.keySet());
        modules.sort((a, b) -> Integer.compare(strength.get(b), strength.get(a)));
        return modules;
    }

    public String getStateJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("loaded", loaded);
            o.put("version", version);
            o.put("records", records.size());
            o.put("embedded", true);
            return o.toString();
        } catch (Exception ignored) {
            return "{\"embedded\":true,\"loaded\":false}";
        }
    }

    private static String normalize(String s) {
        if (s == null) return "";
        return java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT)
                .replace('α', 'a')
                .replaceAll("[^a-z0-9]+", " ")
                .trim();
    }

    private static List<String> tokenize(String s) {
        List<String> out = new ArrayList<>();
        for (String t : s.split("\\s+")) {
            if (t.length() < 3 || STOPWORDS.contains(t) || t.matches("\\d+(?:[.,]\\d+)?")) continue;
            out.add(t);
        }
        return out;
    }

    private static final class Scored {
        final Record record;
        final int score;
        Scored(Record record, int score) { this.record = record; this.score = score; }
    }

    private static final class Record {
        final String id, title, content, tema, subtema, modulo, archivo, evidence, application;
        final List<String> fuentes = new ArrayList<>();
        final List<String> keywords = new ArrayList<>();

        Record(String id, String title, String content, String tema, String subtema,
               String modulo, String archivo, String evidence, String application,
               JSONArray sources, JSONArray keywords, String search) {
            this.id = id;
            this.title = title;
            this.content = content;
            this.tema = tema;
            this.subtema = subtema;
            this.modulo = modulo;
            this.archivo = archivo;
            this.evidence = evidence;
            this.application = application;
            if (sources != null) for (int i = 0; i < sources.length(); i++) fuentes.add(sources.optString(i, ""));
            if (keywords != null) for (int i = 0; i < keywords.length(); i++) keywords.add(normalize(keywords.optString(i, "")));
        }

        int score(String query, List<String> tokens, List<String> preferredModules) {
            int score = 0;
            String nTitle = normalize(title);
            String nTopic = normalize(tema + " " + subtema);
            String nContent = normalize(content + " " + application);
            String nSearch = normalize(search);

            for (String token : tokens) {
                if (nTitle.contains(token)) score += 5;
                if (nTopic.contains(token)) score += 4;
                if (nContent.contains(token)) score += 2;
                for (String kw : keywords) {
                    if (kw.equals(token) || kw.contains(token) || token.contains(kw)) {
                        score += 3;
                        break;
                    }
                }
            }
            if (preferredModules.contains(modulo)) score += 12;
            if (!modulo.isEmpty() && query.contains(normalize(modulo.replace('_', ' ')))) score += 2;
            if ("A".equalsIgnoreCase(evidence) || "B".equalsIgnoreCase(evidence)) score += 1;
            return score;
        }


        private static String joinSources(List<String> values) {
            StringBuilder b = new StringBuilder();
            for (String v : values) {
                if (b.length() > 0) b.append(", ");
                b.append(v);
            }
            return b.toString();
        }
        String toPromptBlock() {
            String body = content == null ? "" : content.trim();
            if (body.length() > MAX_CONTENT_CHARS) body = body.substring(0, MAX_CONTENT_CHARS - 1).trim() + "…";
            String src = fuentes.isEmpty() ? "sin fuente registrada" : joinSources(fuentes);
            return "[YKB] " + title + "\n" +
                    "Módulo: " + modulo + " | Archivo: " + archivo + " | Evidencia: " + evidence + "\n" +
                    "Fuente(s): " + src + "\n" +
                    "Contenido: " + body;
        }
    }
}
