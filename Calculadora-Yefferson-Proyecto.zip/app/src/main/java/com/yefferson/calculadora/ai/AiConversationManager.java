package com.yefferson.calculadora.ai;

import java.util.ArrayList;
import java.util.List;

/**
 * Conversation-only state for the local model. It does not touch UI or the app's
 * persistent personal-memory store. The native engine can therefore reuse the
 * same conversation without rebuilding it in MainActivity.
 */
public final class AiConversationManager {
    public static final class MessageBatch {
        public final String[] roles;
        public final String[] contents;

        MessageBatch(String[] roles, String[] contents) {
            this.roles = roles;
            this.contents = contents;
        }
    }

    private static final class Turn {
        final String role;
        final String content;

        Turn(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }

    // Keep a bounded rolling window so long chats cannot consume the whole
    // llama.cpp context. The limit is based on characters as a practical
    // pre-tokenization guard; the native layer also enforces the final token budget.
    private static final int MAX_MESSAGES = 8;
    private static final int MAX_HISTORY_CHARS = 2200;
    private final List<Turn> turns = new ArrayList<>();

    public synchronized MessageBatch addUserAndSnapshot(String user) {
        turns.add(new Turn("user", user == null ? "" : user));
        trim();
        return snapshot();
    }

    public synchronized void addAssistant(String assistant) {
        if (assistant == null || assistant.trim().isEmpty()) return;
        turns.add(new Turn("assistant", assistant));
        trim();
    }

    public synchronized void rollbackLastUser() {
        if (!turns.isEmpty() && "user".equals(turns.get(turns.size() - 1).role)) {
            turns.remove(turns.size() - 1);
        }
    }

    public synchronized MessageBatch snapshot() {
        String[] roles = new String[turns.size()];
        String[] contents = new String[turns.size()];
        for (int i = 0; i < turns.size(); i++) {
            roles[i] = turns.get(i).role;
            contents[i] = turns.get(i).content;
        }
        return new MessageBatch(roles, contents);
    }

    public synchronized void clear() {
        turns.clear();
    }

    private void trim() {
        while (turns.size() > MAX_MESSAGES || totalChars() > MAX_HISTORY_CHARS) {
            if (turns.size() <= 1) break; // Never remove the current user turn.

            // Remove the oldest complete pair where possible.
            turns.remove(0);
            if (!turns.isEmpty() && "assistant".equals(turns.get(0).role)) {
                turns.remove(0);
            }
        }
    }

    private int totalChars() {
        int total = 0;
        for (Turn t : turns) total += t.content == null ? 0 : t.content.length();
        return total;
    }
}
