package com.yefferson.calculadora.data.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;

/** One independently addressable production record; large histories are not preference blobs. */
@Entity(tableName="farm_records", primaryKeys={"owner","path","recordId"}, indices={
    @Index(value={"kind","lotId","date","position"}), @Index(value={"kind","date","position"}), @Index(value={"owner","path","position"})})
public class FarmRecord {
    @NonNull public String owner="", path="", recordId="", kind="", lotId="", centerId="", date="", json="";
    public long position;
}
