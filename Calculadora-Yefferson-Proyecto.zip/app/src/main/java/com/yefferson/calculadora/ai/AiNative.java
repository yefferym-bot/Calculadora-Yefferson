package com.yefferson.calculadora.ai;

/**
 * JNI boundary for the local AI engine.
 * This class is intentionally isolated so native AI changes do not touch the UI layer.
 */
public final class AiNative {
    static {
        try {
            System.loadLibrary("yefferson_ai");
        } catch (UnsatisfiedLinkError ignored) {
            // The app can still open without the native library; AI will report not ready.
        }
    }

    private AiNative() {}

    public static native void init();
    public static native boolean loadModel(String path, int contextSize, int threads);
    public static native boolean isReady();
    public static native String generateConversation(
            String systemPrompt,
            String[] roles,
            String[] contents,
            int maxTokens,
            boolean thinking);
    public static native void clearConversation();
    public static native void release();
}
