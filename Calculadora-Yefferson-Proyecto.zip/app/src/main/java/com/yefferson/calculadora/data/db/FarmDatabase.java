package com.yefferson.calculadora.data.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory;

@Database(entities={FarmRecord.class,FarmDocument.class,FarmAudit.class},version=1,exportSchema=true)
public abstract class FarmDatabase extends RoomDatabase {
    public abstract FarmDao data();

    public static FarmDatabase open(Context context,String name) {
        // Never let Android's default corruption handler delete the original database.
        SupportSQLiteOpenHelper.Factory protectingFactory = configuration -> {
            SupportSQLiteOpenHelper.Callback original=configuration.callback;
            SupportSQLiteOpenHelper.Callback callback=new SupportSQLiteOpenHelper.Callback(original.version) {
                @Override public void onCreate(@NonNull SupportSQLiteDatabase db){ original.onCreate(db); }
                @Override public void onUpgrade(@NonNull SupportSQLiteDatabase db,int from,int to){ original.onUpgrade(db,from,to); }
                @Override public void onDowngrade(@NonNull SupportSQLiteDatabase db,int from,int to){ original.onDowngrade(db,from,to); }
                @Override public void onConfigure(@NonNull SupportSQLiteDatabase db){ original.onConfigure(db); db.execSQL("PRAGMA synchronous=FULL"); }
                @Override public void onOpen(@NonNull SupportSQLiteDatabase db){ original.onOpen(db); }
                @Override public void onCorruption(@NonNull SupportSQLiteDatabase db){
                    throw new SQLiteDatabaseCorruptException("No se puede leer la base. El archivo original se conserva; restaura una copia verificada.");
                }
            };
            return new FrameworkSQLiteOpenHelperFactory().create(SupportSQLiteOpenHelper.Configuration.builder(configuration.context)
                .name(configuration.name).callback(callback).build());
        };
        return Room.databaseBuilder(context.getApplicationContext(),FarmDatabase.class,name)
            .openHelperFactory(protectingFactory).setJournalMode(JournalMode.WRITE_AHEAD_LOGGING).build();
        // No destructive migration fallback: future schemas require explicit, tested migrations.
    }
}
