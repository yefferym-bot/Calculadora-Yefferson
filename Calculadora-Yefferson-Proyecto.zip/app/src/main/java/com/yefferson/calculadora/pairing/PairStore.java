package com.yefferson.calculadora.pairing;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.io.IOException;

/** Device-local trust store excluded from the application's transferable Room backups. */
public final class PairStore {
    private final SharedPreferences preferences;
    public PairStore(Context context){preferences=context.getSharedPreferences("truchapp_local_pairing_v1",Context.MODE_PRIVATE);}
    public synchronized JSONArray all() throws Exception {
        JSONObject root=new JSONObject(preferences.getString("links","{\"schema\":1,\"peers\":[]}"));
        if(root.optInt("schema")!=1||root.optJSONArray("peers")==null)throw new IOException("No se pueden leer las vinculaciones locales; se conservan sin cambios");
        return root.getJSONArray("peers");
    }
    public synchronized JSONObject find(String fingerprint) throws Exception {JSONArray peers=all();for(int i=0;i<peers.length();i++){JSONObject p=peers.getJSONObject(i);if(fingerprint.equals(p.optString("fingerprint")))return p;}return null;}
    public synchronized void put(JSONObject peer) throws Exception {
        PairRecords.fingerprint(peer.getString("fingerprint"));JSONArray peers=all(),next=new JSONArray();boolean replaced=false;int active=0;
        for(int i=0;i<peers.length();i++){JSONObject old=peers.getJSONObject(i);if(old.getString("fingerprint").equals(peer.getString("fingerprint"))){next.put(peer);replaced=true;}else{next.put(old);if(!old.optBoolean("revoked"))active++;}}
        if(!peer.optBoolean("revoked")&&active>=PairRuntime.MAX_CONNECTIONS)throw new IOException("Puedes mantener hasta 20 equipos vinculados; retira uno antes de añadir otro");
        if(!replaced){if(peers.length()>=100)throw new IOException("Se alcanzó el límite de equipos guardados");next.put(peer);}
        if(!preferences.edit().putString("links",new JSONObject().put("schema",1).put("peers",next).toString()).commit())throw new IOException("No se pudo guardar la vinculación. Vuelve a intentarlo");
    }
    public synchronized void revoke(String fingerprint) throws Exception {JSONObject p=find(fingerprint);if(p!=null){p.put("revoked",true);p.put("lots",new JSONArray());p.put("lotIds",new JSONArray());put(p);}}
    public synchronized void clear() throws Exception {if(!preferences.edit().clear().commit())throw new IOException("No se pudieron retirar las vinculaciones");}
}
