package com.yefferson.calculadora.pairing;

import android.app.*;
import android.content.*;
import android.os.*;
import com.yefferson.calculadora.MainActivity;
import com.yefferson.calculadora.data.db.FarmRepository;

/** User-visible owner of LAN sockets. No Activity or WebView is retained by the service. */
public final class LocalPairingService extends Service {
    private static final String CHANNEL="truchapp_local_connection";
    private static final String STOP="com.yefferson.calculadora.LOCAL_SERVER_STOP";
    private static final int NOTIFICATION=7201;
    private LocalPairingController controller;
    private final Handler keepAlive=new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock cpu;
    private android.net.wifi.WifiManager.WifiLock radio;
    private final Runnable renew=new Runnable(){public void run(){if(cpu!=null){cpu.acquire(90000);keepAlive.postDelayed(this,30000);}}};
    public static void start(Context context){Intent intent=new Intent(context,LocalPairingService.class);if(Build.VERSION.SDK_INT>=26)context.startForegroundService(intent);else context.startService(intent);}
    public static void stop(Context context){context.stopService(new Intent(context,LocalPairingService.class));}
    @Override public void onCreate(){
        super.onCreate();
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Conexión local de TruchApp",NotificationManager.IMPORTANCE_LOW));
        int flags=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),flags);
        PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,LocalPairingService.class).setAction(STOP),flags);
        Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Notification notification=builder.setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("TruchApp · Conexión local activa")
            .setContentText("Servidor o reconexión en segundo plano. Toca para ver el estado.").setContentIntent(open).setOngoing(true)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Apagar conexión",stop).build()).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION,notification,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);else startForeground(NOTIFICATION,notification);
        controller=LocalPairingController.get(this,FarmRepository.get(this));
        // A bounded, renewed lease supports a user-activated server with its screen off.
        PowerManager power=(PowerManager)getSystemService(POWER_SERVICE);if(power!=null){cpu=power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"TruchApp:localConnection");cpu.setReferenceCounted(false);keepAlive.post(renew);}
        android.net.wifi.WifiManager wifi=(android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);if(wifi!=null)try{radio=wifi.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF,"TruchApp:localConnection");radio.setReferenceCounted(false);radio.acquire();}catch(Exception ignored){radio=null;}
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&STOP.equals(intent.getAction())){controller.userStop("Conexión local apagada por el usuario.");stopSelf();return START_NOT_STICKY;}
        controller.serviceReady();return START_STICKY;
    }
    @Override public void onDestroy(){keepAlive.removeCallbacks(renew);if(cpu!=null&&cpu.isHeld())cpu.release();cpu=null;if(radio!=null&&radio.isHeld())radio.release();radio=null;if(controller!=null)controller.serviceEnded();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onTaskRemoved(Intent intent){/* Keep an explicitly activated connection after the task is dismissed. */}
}
