package com.yefferson.calculadora.pairing;

import android.content.SharedPreferences;
import android.content.Context;
import android.net.*;
import android.net.nsd.*;
import android.net.wifi.WifiManager;
import android.webkit.WebView;
import com.yefferson.calculadora.data.db.FarmRepository;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import javax.net.ssl.*;

/** Application-owned LAN pairing. The foreground service owns transport, the Activity only observes. */
public final class LocalPairingController {
    private static final String TYPE="_truchapp._tcp.";
    private static LocalPairingController instance;
    public static synchronized LocalPairingController get(Context context,FarmRepository repository){if(instance==null||instance.closed)instance=new LocalPairingController(context.getApplicationContext(),repository);return instance;}
    private final Context context;private final FarmRepository repository;private final PairStore store;private final SharedPreferences continuity;
    private final PairContinuity reconnect=new PairContinuity();
    private volatile boolean enabled,serviceAlive;private volatile Socket connectingSocket;private volatile String desiredMode="",networkKey="";
    private long nextDiscovery,maintenanceAt;private final AtomicBoolean maintenancePosted=new AtomicBoolean();
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Set<String> disconnectedPeers=Collections.newSetFromMap(new ConcurrentHashMap<String,Boolean>());
    private static final AtomicInteger THREAD_SEQUENCE=new AtomicInteger();
    private static ThreadFactory threads(String group){return work->new Thread(()->{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);work.run();},"TruchApp-"+group+"-"+THREAD_SEQUENCE.incrementAndGet());}
    private final ThreadPoolExecutor commands=new ThreadPoolExecutor(1,1,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(32),threads("commands"));
    private final ThreadPoolExecutor listener=new ThreadPoolExecutor(1,1,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(1),threads("listen"));
    private final ThreadPoolExecutor cleanup=new ThreadPoolExecutor(1,1,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(4),threads("close"),new ThreadPoolExecutor.DiscardOldestPolicy());
    private final PairRuntime runtime=new PairRuntime(threads("io"));
    private final PairLimits.Admission admission=new PairLimits.Admission();private final PairLimits.Retry retry=new PairLimits.Retry();
    private final android.os.Handler events=new android.os.Handler(android.os.Looper.getMainLooper());private final AtomicBoolean eventPosted=new AtomicBoolean();
    private final Map<String,PairSession> sessions=new ConcurrentHashMap<>();
    private final Map<String,NsdServiceInfo> services=new ConcurrentHashMap<>();
    private final Set<String> resolving=Collections.newSetFromMap(new ConcurrentHashMap<String,Boolean>());
    private volatile WebView web;private PairIdentity identity;private SSLContext tls;
    private volatile boolean foreground=false,closed,searching;private volatile long invitationUntil,invitationDeadline,searchEpoch,resourceEpoch;private final AtomicLong epoch=new AtomicLong();
    private volatile String activeMode="",endpoint="",notice="";
    private SSLServerSocket server;private NsdManager.RegistrationListener registration;private NsdManager.DiscoveryListener discovery;
    private WifiManager.MulticastLock multicast;private final NsdManager nsd;
    private final PairCatalog catalogCache=new PairCatalog();private volatile String clientTarget="";

    private LocalPairingController(Context context,FarmRepository repository){
        this.context=context;this.repository=repository;this.store=new PairStore(context);
        continuity=context.getSharedPreferences("truchapp_local_continuity_v1",Context.MODE_PRIVATE);
        nsd=(NsdManager)context.getSystemService(Context.NSD_SERVICE);
        commands.allowCoreThreadTimeOut(true);cleanup.allowCoreThreadTimeOut(true);listener.allowCoreThreadTimeOut(true);
    }
    public void attach(WebView web){this.web=web;}
    public void detach(WebView value){if(web==value){web=null;foreground=false;}}
    public void foreground(){foreground=true;}
    public void pause(){foreground=false;}
    public void userStop(String text){
        enabled=false;desiredMode="";reconnect.stop();long stopped=epoch.incrementAndGet();Socket pending=connectingSocket;if(pending!=null)try{pending.close();}catch(Exception ignored){}
        continuity.edit().remove("enabled_mode").remove("auto_admin").apply();
        try{cleanup.execute(()->{synchronized(this){if(resourceEpoch<stopped)stop(text);}if(!enabled)LocalPairingService.stop(context);emit();});}catch(RejectedExecutionException ignored){}
    }
    public void close(){if(closed)return;userStop("");closed=true;web=null;events.removeCallbacksAndMessages(null);commands.shutdownNow();listener.shutdownNow();runtime.close();cleanup.shutdown();}
    public synchronized void reset(){userStop("Vinculaciones retiradas.");stop("Vinculaciones retiradas.");try{store.clear();continuity.edit().clear().commit();}catch(Exception e){notice=message(e);}emit();}
    private void enable(String role) throws Exception {
        require(role);if(!enabled||!serviceAlive){desiredMode=role;enabled=true;
            if(!continuity.edit().putString("enabled_mode",role).commit()){enabled=false;desiredMode="";throw new IOException("No se pudo guardar el estado de la conexión local");}
            try{LocalPairingService.start(context);}catch(Exception failure){enabled=false;desiredMode="";continuity.edit().remove("enabled_mode").apply();throw new IOException("Abre TruchApp y activa de nuevo la conexión para permitir el servicio en segundo plano",failure);}
        }
    }
    public void serviceReady(){serviceAlive=true;try{commands.execute(()->{try{
        if(!enabled){String saved=continuity.getString("enabled_mode","");if(saved.isEmpty()||!saved.equals(mode())){LocalPairingService.stop(context);return;}desiredMode=saved;enabled=true;}
        if("collaborator".equals(desiredMode)&&reconnect.pin().isEmpty()){String pin=continuity.getString("auto_admin","");JSONObject peer=pin.isEmpty()?null:store.find(pin);if(peer!=null&&!peer.optBoolean("revoked")&&"admin".equals(peer.optString("role")))reconnect.arm(pin);else if(!foreground){userStop("Vincula este teléfono para activar la reconexión automática.");return;}}
        watchNetwork();maintain();
    }catch(Exception failure){notice=message(failure);emit();}});}catch(RejectedExecutionException ignored){}events.removeCallbacks(pulse);events.post(pulse);}
    public void serviceEnded(){serviceAlive=false;events.removeCallbacks(pulse);unwatchNetwork();long ended=epoch.incrementAndGet();Socket pending=connectingSocket;if(pending!=null)try{pending.close();}catch(Exception ignored){}try{cleanup.execute(()->{synchronized(this){if(resourceEpoch<ended)stop("Servicio local detenido. Actívalo para continuar.");}emit();});}catch(RejectedExecutionException ignored){}}
    private final Runnable pulse=new Runnable(){public void run(){if(!serviceAlive)return;queueMaintenance();events.postDelayed(this,3000);}};
    private void queueMaintenance(){if(!enabled||!serviceAlive||!maintenancePosted.compareAndSet(false,true))return;try{commands.execute(()->{try{maintain();}catch(Exception failure){notice=message(failure);emit();}finally{maintenancePosted.set(false);}});}catch(RejectedExecutionException busy){maintenancePosted.set(false);}}
    private void watchNetwork(){if(networkCallback!=null)return;ConnectivityManager manager=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);if(manager==null)return;networkCallback=new ConnectivityManager.NetworkCallback(){public void onAvailable(Network network){queueMaintenance();}public void onLost(Network network){queueMaintenance();}public void onLinkPropertiesChanged(Network network,LinkProperties link){queueMaintenance();}};try{manager.registerNetworkCallback(new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(),networkCallback);}catch(Exception ignored){networkCallback=null;}}
    private void unwatchNetwork(){if(networkCallback==null)return;try{((ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE)).unregisterNetworkCallback(networkCallback);}catch(Exception ignored){}networkCallback=null;}
    private void maintain() throws Exception {
        if(!enabled||!serviceAlive||closed)return;
        if(!desiredMode.equals(mode())){userStop("Modo de trabajo actualizado. Conexión local apagada.");return;}
        long now=System.nanoTime();String address="";try{address=localAddress().getHostAddress();}catch(Exception unavailable){}
        String key=address+"|"+wifiNetworkKey();
        if(networkKey.isEmpty())networkKey=key;
        if(!key.equals(networkKey)){networkKey=key;synchronized(this){stop("Red actualizada. Recuperando la conexión local…");}reconnect.networkChanged(now,ThreadLocalRandom.current().nextDouble());nextDiscovery=0;maintenanceAt=0;}
        if(address.isEmpty()){notice="Esperando la red Wi-Fi o el punto de acceso. La conexión se recuperará automáticamente.";emit();return;}
        if("admin".equals(desiredMode)){if(server==null&&now>=maintenanceAt){maintenanceAt=now+10000000000L;try{startAdmin(false);}catch(Exception e){notice=message(e);}}}
        else if(!reconnect.pin().isEmpty()&&sessions.isEmpty()&&reconnect.due(now)){
            JSONObject peer=store.find(reconnect.pin());if(peer==null||peer.optBoolean("revoked")||!"admin".equals(peer.optString("role"))){reconnect.stop();continuity.edit().remove("auto_admin").apply();notice="Reconexión desactivada: la vinculación fue retirada.";emit();return;}
            String serviceName="TruchApp-"+reconnect.pin().substring(0,10);NsdServiceInfo found=services.get(serviceName);
            if(found==null)for(Map.Entry<String,NsdServiceInfo> entry:services.entrySet())if(entry.getKey().startsWith(serviceName+" ")){serviceName=entry.getKey();found=entry.getValue();break;}
            // Give discovery a chance to resolve a changed address before trying the cached endpoint.
            if(found==null&&(!searching||now>=nextDiscovery)){nextDiscovery=now+15000000000L;try{startSearch();maintenanceAt=now+3000000000L;}catch(Exception unavailable){maintenanceAt=0;}}
            JSONObject target=null;if(found!=null)target=newSafe("service",serviceName);
            else if(now>=maintenanceAt){String saved=continuity.getString("endpoint_"+reconnect.pin(),"");if(!saved.isEmpty())target=newSafe("endpoint",saved);}
            if(target!=null){try{connect(target,reconnect.pin());}catch(Exception failure){reconnect.failed(System.nanoTime(),ThreadLocalRandom.current().nextDouble());services.remove(serviceName);nextDiscovery=0;notice="Reconectando con el administrador. Se volverá a intentar automáticamente.";}}
        }
        emit();
    }
    private String wifiNetworkKey(){ConnectivityManager manager=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);if(manager!=null)for(Network network:manager.getAllNetworks()){NetworkCapabilities caps=manager.getNetworkCapabilities(network);if(caps!=null&&caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))return network.toString();}return "hotspot";}
    private String mode() throws Exception {
        String raw=repository.read("truchapp_access_mode_v1","");
        if(raw.isEmpty())return "admin";
        JSONObject value=new JSONObject(raw);return value.optInt("schema")==1&&"admin".equals(value.optString("mode"))?"admin":"collaborator";
    }
    private String name() {
        try{String value="admin".equals(mode())?new JSONObject(repository.read("profile","{}")).optString("name"):new JSONObject(repository.read("truchapp_access_mode_v1","{}")).optJSONObject("collaborator").optString("name");String text=PairRecords.text(value,40);if(!text.isEmpty())return text;}catch(Exception ignored){}
        return "admin".equals(activeMode)?"Administrador":"Colaborador";
    }
    private void require(String required) throws Exception {if((!foreground&&!enabled)||closed)throw new IOException("Abre TruchApp para usar la conexión local");if(!required.equals(mode()))throw new IOException("Cambia primero al modo "+("admin".equals(required)?"Administrador":"Colaborador"));}
    private synchronized void prepare(String required) throws Exception {
        require(required);if(!activeMode.isEmpty()&&(!activeMode.equals(required)||resourceEpoch!=epoch.get()))stop("");activeMode=required;resourceEpoch=epoch.get();
        if(identity==null){
            long generation=epoch.get();PairIdentity candidate;SSLContext checked;
            try{candidate=new PairIdentity(store);checked=candidate.context();PairTls.checkLocal(checked);}
            catch(Exception failure){throw new PairFailure.LocalIdentityException(failure);}
            require(required);if(generation!=epoch.get())throw new IOException("La conexión local fue cancelada. Vuelve a activarla.");
            candidate.remember(store);identity=candidate;tls=checked;
        }
    }
    public void request(String id,String command,String raw){
        if(closed)return;
        if(id==null||id.length()>80||command==null||command.length()>32||(raw!=null&&raw.length()>32768)){reply(id==null?"":id,false,newSafe("error","Solicitud local demasiado grande"));return;}
        if("stop".equals(command))userStop("Conexión local apagada por el usuario.");
        try{commands.execute(()->{try{
            JSONObject input=new JSONObject(raw==null||raw.isEmpty()?"{}":raw);
            if(!activeMode.isEmpty()&&!activeMode.equals(mode()))synchronized(this){userStop("Modo de trabajo actualizado.");}
            switch(command){
                case "status":{if(enabled)queueMaintenance();break;}
                case "invite":enable("admin");disconnectedPeers.clear();startAdmin(true);break;
                case "listen":enable("admin");disconnectedPeers.clear();startAdmin(false);break;
                case "search":enable("collaborator");resumeKnownAdmin();startSearch();break;
                case "connect":enable("collaborator");connect(input,"");break;
                case "confirm":confirm(input);break;
                case "reject":{synchronized(this){PairSession s=session(input);require(s.role);if(!"verify".equals(s.state)&&!"waiting".equals(s.state))throw new IOException("La solicitud ya no está pendiente");if("collaborator".equals(s.role)){reconnect.stop();continuity.edit().remove("auto_admin").apply();}s.reject();notice="admin".equals(s.role)?"Solicitud rechazada.":"Solicitud cancelada.";}break;}
                case "update":update(input);break;
                case "revoke":revoke(input);break;
                case "disconnect":disconnect(input);break;
                case "stop":break;
                default:throw new IOException("Acción local no reconocida");
            }
            reply(id,true,snapshot());if(!"status".equals(command))emit();
        }catch(Exception e){notice=message(e);reply(id,false,newSafe("error",notice));emit();}});}catch(RejectedExecutionException busy){reply(id,false,newSafe("error","La conexión local está ocupada. Vuelve a intentar"));}
    }
    private void resumeKnownAdmin() throws Exception {if(!reconnect.pin().isEmpty())return;String preferred=continuity.getString("auto_admin","");JSONArray saved=store.all();JSONObject selected=null;for(int i=0;i<saved.length();i++){JSONObject peer=saved.getJSONObject(i);if(!peer.optBoolean("revoked")&&"admin".equals(peer.optString("role"))){if(selected==null||preferred.equals(peer.optString("fingerprint")))selected=peer;}}if(selected!=null)reconnect.arm(selected.getString("fingerprint"));}
    private PairSession session(JSONObject input) throws Exception {PairSession s=sessions.get(input.getString("session"));if(s==null)throw new IOException("La conexión ya no está disponible");return s;}
    private void confirm(JSONObject input) throws Exception {
        PairSession s=session(input);require(s.role);
        if(!"verify".equals(s.state)||!s.code.equals(input.optString("code")))throw new IOException("La solicitud cambió o ya no está pendiente. Actualiza la lista e inténtalo de nuevo.");
        JSONObject selection=new JSONObject();
        if("admin".equals(s.role)){PairRecords.permission(input.optString("permission"));JSONArray lots=PairRecords.assign(catalog(),input.optJSONArray("lotIds"));selection.put("lotIds",PairRecords.ids(lots)).put("permission",input.getString("permission"));}
        s.confirm(selection);notice="Solicitud aprobada. Completando vinculación…";
    }
    private JSONArray catalog() throws Exception {return catalogCache.read(new PairCatalog.Source(){public String stamp(){return repository.revisionStamp();}public String lots(){return repository.read("truchapp_lotes_v1","[]");}});}
    private void disconnect(JSONObject input) throws Exception {String current=mode();require(current);String fingerprint=input.getString("fingerprint");PairRecords.fingerprint(fingerprint);if("collaborator".equals(current)){reconnect.stop();continuity.edit().remove("auto_admin").apply();}else disconnectedPeers.add(fingerprint);for(PairSession session:sessions.values())if(fingerprint.equals(session.peer))session.close();notice="Equipo desconectado. Su vinculación se conserva.";}

    private synchronized void update(JSONObject input) throws Exception {
        require("admin");String fingerprint=input.getString("fingerprint");JSONObject peer=store.find(fingerprint);
        if(peer==null||peer.optBoolean("revoked")||!"collaborator".equals(peer.optString("role")))throw new IOException("El colaborador no está vinculado");
        JSONArray selected=PairRecords.assign(catalog(),input.optJSONArray("lotIds"));peer.put("lotIds",PairRecords.ids(selected)).put("permission",PairRecords.permission(input.optString("permission")));store.put(peer);
        for(PairSession s:sessions.values())if(fingerprint.equals(s.peer))s.close();notice="Permisos guardados. El colaborador los actualizará al reconectarse.";
    }
    private synchronized void revoke(JSONObject input) throws Exception {
        String fingerprint=input.getString("fingerprint");PairRecords.fingerprint(fingerprint);String current=mode();require(current);
        JSONObject peer=store.find(fingerprint);if(peer==null)throw new IOException("Equipo no encontrado");
        String remote="admin".equals(current)?"collaborator":"admin";if(!remote.equals(peer.optString("role")))throw new IOException("El equipo no corresponde al modo actual");
        store.revoke(fingerprint);if("collaborator".equals(current)){reconnect.stop();continuity.edit().remove("auto_admin").apply();}for(PairSession s:sessions.values())if(fingerprint.equals(s.peer)){if("admin".equals(current))s.revoke();else s.unlink();}
        notice="Acceso retirado. El otro equipo lo verá al conectarse de nuevo.";
    }
    private synchronized void startAdmin(boolean invite) throws Exception {
        prepare("admin");InetAddress local=localAddress();
        if(server!=null&&!server.getInetAddress().equals(local)){stop("");prepare("admin");}
        if(server==null){
            SSLServerSocket created=(SSLServerSocket)PairContinuity.bind(tls.getServerSocketFactory(),local,continuity.getInt("server_port",PairContinuity.DEFAULT_PORT));
            created.setEnabledProtocols(new String[]{"TLSv1.2"});created.setEnabledCipherSuites(PairIdentity.suites(created.getSupportedCipherSuites()));created.setNeedClientAuth(true);
            continuity.edit().putInt("server_port",created.getLocalPort()).apply();server=created;endpoint=local.getHostAddress()+":"+server.getLocalPort();long generation=epoch.get();
            try{register();listener.execute(()->accept(created,generation));}catch(Exception e){stop("");throw e;}
        }
        if(invite){invitationUntil=System.currentTimeMillis()+300000L;invitationDeadline=System.nanoTime()+300000000000L;}
        notice=invite?"Recepción de solicitudes abierta durante 5 minutos. Busca este equipo desde el colaborador.":"Disponible para equipos ya vinculados.";
    }
    private void accept(SSLServerSocket listener,long generation){
        while(!closed&&enabled&&generation==epoch.get()){SSLSocket socket=null;try{
            socket=(SSLSocket)listener.accept();
            if(runtime.size()>=PairRuntime.MAX_CONNECTIONS||!admission.allow(System.nanoTime())){socket.close();notice="Capacidad local ocupada. Se admiten hasta 20 colaboradores a la vez.";emit();continue;}
            if(generation!=epoch.get()){socket.close();break;}
            socket.setEnabledProtocols(new String[]{"TLSv1.2"});socket.setEnabledCipherSuites(PairIdentity.suites(socket.getSupportedCipherSuites()));launch(socket,"admin",generation,"");
        }catch(Exception e){if(socket!=null)try{socket.close();}catch(Exception ignored){}if(generation!=epoch.get()||listener.isClosed())break;notice="No se pudo aceptar una conexión local.";emit();}}
    }
    private void register() throws Exception {
        if(nsd==null)throw new IOException("El dispositivo no ofrece búsqueda de red local");
        NsdServiceInfo info=new NsdServiceInfo();info.setServiceName("TruchApp-"+identity.fingerprint.substring(0,10));info.setServiceType(TYPE);info.setPort(server.getLocalPort());
        long generation=epoch.get();registration=new NsdManager.RegistrationListener(){
            public void onServiceRegistered(NsdServiceInfo service){if(generation==epoch.get())emit();}
            public void onRegistrationFailed(NsdServiceInfo service,int error){if(generation==epoch.get()){notice="La búsqueda automática no está disponible. Usa la dirección local.";emit();}}
            public void onServiceUnregistered(NsdServiceInfo service){}
            public void onUnregistrationFailed(NsdServiceInfo service,int error){}
        };nsd.registerService(info,NsdManager.PROTOCOL_DNS_SD,registration);lockMulticast();
    }
    private synchronized void startSearch() throws Exception {
        prepare("collaborator");if(nsd==null)throw new IOException("La búsqueda local no está disponible; usa una dirección local");
        stopDiscovery();services.clear();resolving.clear();searching=true;long generation=epoch.get(),searchGeneration=searchEpoch;
        discovery=new NsdManager.DiscoveryListener(){
            public void onDiscoveryStarted(String type){emit();}
            public void onServiceFound(NsdServiceInfo service){
                if(generation!=epoch.get()||searchGeneration!=searchEpoch||!searching||!service.getServiceName().startsWith("TruchApp-")||!service.getServiceType().contains("_truchapp._tcp"))return;
                String key=service.getServiceName();if(resolving.size()>=12||!resolving.add(key))return;
                nsd.resolveService(service,new NsdManager.ResolveListener(){
                    public void onResolveFailed(NsdServiceInfo value,int error){resolving.remove(key);}
                    public void onServiceResolved(NsdServiceInfo value){resolving.remove(key);if(generation==epoch.get()&&searchGeneration==searchEpoch&&searching&&value.getHost()!=null&&privateAddress(value.getHost())){services.put(key,value);queueMaintenance();emit();}}
                });
            }
            public void onServiceLost(NsdServiceInfo service){if(generation==epoch.get()&&searchGeneration==searchEpoch){services.remove(service.getServiceName());emit();}}
            public void onDiscoveryStopped(String type){}
            public void onStartDiscoveryFailed(String type,int error){if(generation==epoch.get()&&searchGeneration==searchEpoch){searching=false;notice="No se pudo buscar. Puedes usar la dirección local del administrador.";emit();}}
            public void onStopDiscoveryFailed(String type,int error){}
        };
        try{nsd.discoverServices(TYPE,NsdManager.PROTOCOL_DNS_SD,discovery);lockMulticast();notice="Buscando administradores en la misma red Wi-Fi…";}catch(Exception e){searching=false;discovery=null;throw e;}
    }
    private void connect(JSONObject input,String expectedPin) throws Exception {
        prepare("collaborator");if(!sessions.isEmpty())throw new IOException("Cancela la conexión actual antes de abrir otra");
        InetAddress address;int port;
        if(input.has("service")){NsdServiceInfo info=services.get(input.getString("service"));if(info==null)throw new IOException("Equipo no disponible; vuelve a buscar");address=info.getHost();port=info.getPort();}
        else{String raw=input.optString("endpoint").trim();if(!raw.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}:[0-9]{1,5}"))throw new IOException("Usa la dirección IP:puerto que muestra el administrador");int split=raw.lastIndexOf(':');String host=raw.substring(0,split);for(String part:host.split("\\."))if(Integer.parseInt(part)>255)throw new IOException("Dirección local inválida");address=InetAddress.getByName(host);port=Integer.parseInt(raw.substring(split+1));}
        if(address==null||!privateAddress(address)||port<1024||port>65535)throw new IOException("La dirección debe pertenecer a una red local");
        if(expectedPin.isEmpty()){reconnect.stop();continuity.edit().remove("auto_admin").apply();}
        String target=address.getHostAddress()+":"+port;long remaining=expectedPin.isEmpty()?retry.remaining(target,System.nanoTime()):0;if(remaining>0)throw new IOException("Espera "+((remaining+999)/1000)+" segundos antes de reconectar");clientTarget=target;
        long generation=epoch.get();Socket raw=new Socket();connectingSocket=raw;
        try{
            ConnectivityManager manager=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if(manager!=null)for(Network network:manager.getAllNetworks()){NetworkCapabilities caps=manager.getNetworkCapabilities(network);if(caps!=null&&caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)){network.bindSocket(raw);break;}}
            raw.connect(new InetSocketAddress(address,port),8000);
            SSLSocket socket=(SSLSocket)tls.getSocketFactory().createSocket(raw,address.getHostAddress(),port,true);socket.setEnabledProtocols(new String[]{"TLSv1.2"});socket.setEnabledCipherSuites(PairIdentity.suites(socket.getSupportedCipherSuites()));socket.setUseClientMode(true);
            synchronized(this){if(!enabled||generation!=epoch.get()){socket.close();throw new IOException("Conexión cancelada");}launch(socket,"collaborator",generation,expectedPin);}
            notice="Conectando con el administrador…";
        }catch(Exception e){retry.failed(target,System.nanoTime(),ThreadLocalRandom.current().nextDouble());try{raw.close();}catch(Exception ignored){}throw e;}finally{if(connectingSocket==raw)connectingSocket=null;}
    }
    private void launch(SSLSocket socket,String role,long generation,String expectedPin) throws Exception {
        final String sessionTarget=clientTarget;
        PairSession session=new PairSession(socket,role,new PairSession.Host(){
            private void guard(PairSession s) throws Exception {require(role);if(generation!=epoch.get()||!sessions.containsKey(s.id)||s.isCancelled())throw new IOException("La conexión local fue cancelada");}
            public String name(){return LocalPairingController.this.name();}
            public boolean known(String fingerprint,String remoteRole) throws Exception {synchronized(LocalPairingController.this){if(generation!=epoch.get())throw new IOException("Conexión cancelada");if(!expectedPin.isEmpty()&&!expectedPin.equals(fingerprint))throw new IOException("El equipo encontrado no es el administrador vinculado");if(disconnectedPeers.contains(fingerprint))throw new IOException("Equipo desconectado manualmente. Activa la reconexión para admitirlo de nuevo.");JSONObject peer=store.find(fingerprint);if(!expectedPin.isEmpty()&&(peer==null||peer.optBoolean("revoked")))throw new IOException("La vinculación ya no está autorizada");return peer!=null&&!peer.optBoolean("revoked")&&remoteRole.equals(peer.optString("role"));}}
            public boolean invitationOpen(){return generation==epoch.get()&&enabled&&System.nanoTime()<invitationDeadline;}
            public boolean denied(String fingerprint) throws Exception {synchronized(LocalPairingController.this){if(!expectedPin.isEmpty()&&!expectedPin.equals(fingerprint))throw new IOException("El equipo encontrado no es el administrador vinculado");if(disconnectedPeers.contains(fingerprint))throw new IOException("Equipo desconectado manualmente. Activa la reconexión para admitirlo de nuevo.");JSONObject peer=store.find(fingerprint);if(!expectedPin.isEmpty()&&(peer==null||peer.optBoolean("revoked")))throw new IOException("La vinculación ya no está autorizada");return peer!=null&&peer.optBoolean("revoked")&&!invitationOpen();}}
            public void verifying(PairSession s){if("collaborator".equals(role)){if(!expectedPin.isEmpty()){s.fail("El administrador ya no reconoce esta vinculación. Envía una solicitud manual para autorizarla de nuevo.");reconnect.stop();continuity.edit().remove("auto_admin").apply();return;}s.submitRequest();notice="Solicitud enviada. Esperando aprobación del administrador.";}else notice="Nueva solicitud de vinculación pendiente de aprobación.";emit();}
            public JSONObject approve(PairSession s) throws Exception {synchronized(LocalPairingController.this){
                guard(s);JSONObject old=store.find(s.peer),selection=s.code.isEmpty()?old:s.selection;
                if(selection==null||selection.optBoolean("revoked"))throw new IOException("El acceso del colaborador fue retirado");
                // If a previously assigned lot was deleted, drop it before building the refreshed catalog.
                JSONArray available=catalog(),ids=selection.optJSONArray("lotIds");if(s.code.isEmpty()&&ids!=null){Set<String> valid=new HashSet<>();for(int i=0;i<available.length();i++)valid.add(available.getJSONObject(i).getString("id"));JSONArray filtered=new JSONArray();for(int i=0;i<ids.length();i++)if(valid.contains(ids.getString(i)))filtered.put(ids.getString(i));ids=filtered;}
                JSONArray lots=PairRecords.assign(available,ids);String permission=PairRecords.permission(selection.optString("permission"));
                JSONObject peer=new JSONObject().put("fingerprint",s.peer).put("name",s.peerName).put("role","collaborator").put("revoked",false).put("lotIds",PairRecords.ids(lots)).put("permission",permission).put("pairedAt",old==null?System.currentTimeMillis():old.optLong("pairedAt",System.currentTimeMillis()));store.put(peer);
                return new JSONObject().put("version",1).put("lots",lots).put("permission",permission);
            }}
            public void accept(PairSession s,JSONObject grant) throws Exception {synchronized(LocalPairingController.this){guard(s);if(grant.optInt("version")!=1)throw new IOException("Asignación incompatible");JSONArray lots=PairRecords.received(grant.optJSONArray("lots"));String permission=PairRecords.permission(grant.optString("permission"));JSONObject old=store.find(s.peer);JSONObject peer=new JSONObject().put("fingerprint",s.peer).put("name",s.peerName).put("role","admin").put("revoked",false).put("lots",lots).put("permission",permission).put("pairedAt",old==null?System.currentTimeMillis():old.optLong("pairedAt",System.currentTimeMillis()));store.put(peer);}}
            public void connected(PairSession s){if(generation!=epoch.get())return;if("collaborator".equals(role)){retry.reset();reconnect.arm(s.peer);continuity.edit().putString("auto_admin",s.peer).putString("endpoint_"+s.peer,sessionTarget).apply();}notice="Equipo vinculado y conectado por red local.";emit();}
            public void revoked(PairSession s) throws Exception {synchronized(LocalPairingController.this){guard(s);store.revoke(s.peer);if("collaborator".equals(role)){reconnect.stop();continuity.edit().remove("auto_admin").apply();}notice="La vinculación fue retirada.";}emit();}
            public void ended(PairSession s,Exception error){sessions.remove(s.id);if(generation==epoch.get()&&"collaborator".equals(role)&&!reconnect.pin().isEmpty()){reconnect.failed(System.nanoTime(),ThreadLocalRandom.current().nextDouble());nextDiscovery=0;}if(error!=null&&generation==epoch.get()){notice=message(error);if("collaborator".equals(role))retry.failed(sessionTarget,System.nanoTime(),ThreadLocalRandom.current().nextDouble());}emit();}
        });sessions.put(session.id,session);try{runtime.start(session);}catch(Exception e){sessions.remove(session.id);session.close();throw e;}
    }
    private static boolean privateAddress(InetAddress address){return !address.isLoopbackAddress()&&!address.isAnyLocalAddress()&&!address.isMulticastAddress()&&(address.isSiteLocalAddress()||address.isLinkLocalAddress()||(address instanceof Inet6Address&&(address.getAddress()[0]&0xfe)==0xfc));}
    private InetAddress localAddress() throws Exception {
        ConnectivityManager manager=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(manager!=null)for(Network network:manager.getAllNetworks()){NetworkCapabilities caps=manager.getNetworkCapabilities(network);LinkProperties link=manager.getLinkProperties(network);if(caps!=null&&caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)&&link!=null)for(LinkAddress address:link.getLinkAddresses())if(address.getAddress() instanceof Inet4Address&&privateAddress(address.getAddress()))return address.getAddress();}
        // Hotspot interfaces may not appear as an upstream Wi-Fi Network.
        Enumeration<NetworkInterface> interfaces=NetworkInterface.getNetworkInterfaces();while(interfaces.hasMoreElements()){NetworkInterface item=interfaces.nextElement();String n=item.getName();if(!item.isUp()||!(n.startsWith("wlan")||n.startsWith("swlan")||n.startsWith("ap")))continue;Enumeration<InetAddress> addresses=item.getInetAddresses();while(addresses.hasMoreElements()){InetAddress address=addresses.nextElement();if(address instanceof Inet4Address&&privateAddress(address))return address;}}
        throw new IOException("Conecta ambos teléfonos a la misma Wi-Fi o activa una zona Wi-Fi y conecta el otro teléfono");
    }
    private void lockMulticast(){if(multicast!=null)return;WifiManager wifi=(WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);if(wifi!=null){multicast=wifi.createMulticastLock("TruchApp-local");multicast.setReferenceCounted(false);multicast.acquire();}}
    private void stopDiscovery(){searchEpoch++;searching=false;if(discovery!=null){try{nsd.stopServiceDiscovery(discovery);}catch(Exception ignored){}discovery=null;}resolving.clear();}
    private synchronized void stop(String text){
        epoch.incrementAndGet();invitationUntil=0;invitationDeadline=0;stopDiscovery();services.clear();
        if(registration!=null){try{nsd.unregisterService(registration);}catch(Exception ignored){}registration=null;}
        if(server!=null){try{server.close();}catch(Exception ignored){}server=null;}
        runtime.stopAll();for(PairSession s:sessions.values())s.close();sessions.clear();endpoint="";activeMode="";retry.reset();clientTarget="";
        if(multicast!=null){try{if(multicast.isHeld())multicast.release();}catch(Exception ignored){}multicast=null;}notice=text;
    }
    private synchronized JSONObject snapshot() throws Exception {
        String current=mode();JSONArray links=new JSONArray(),saved=store.all();for(int i=0;i<saved.length();i++){JSONObject peer=saved.getJSONObject(i);if(("admin".equals(current)?"collaborator":"admin").equals(peer.optString("role")))links.put(peer);}
        JSONArray found=new JSONArray();for(Map.Entry<String,NsdServiceInfo> item:services.entrySet())found.put(new JSONObject().put("id",item.getKey()).put("name",item.getValue().getServiceName()));
        JSONArray pending=new JSONArray();for(PairSession s:sessions.values())if(!s.isClosed())pending.put(new JSONObject().put("id",s.id).put("name",s.peerName).put("fingerprint",s.peer).put("code",s.code).put("state",s.state));
        JSONObject out=new JSONObject().put("supported",true).put("enabled",enabled&&serviceAlive).put("reconnecting",enabled&&!reconnect.pin().isEmpty()&&runtime.connected()==0).put("serverName",identity==null?"":"TruchApp-"+identity.fingerprint.substring(0,10)).put("preferredPort",continuity.getInt("server_port",PairContinuity.DEFAULT_PORT)).put("mode",current).put("listening",server!=null).put("searching",searching).put("endpoint",endpoint).put("invitationUntil",invitationUntil).put("notice",notice).put("peers",links).put("services",found).put("sessions",pending).put("maxConnections",PairRuntime.MAX_CONNECTIONS).put("connectedCount",runtime.connected()).put("capacityUsed",runtime.size()).put("retryAfterMs",Math.max(retry.remaining(System.nanoTime()),reconnect.remaining(System.nanoTime())));
        if("admin".equals(current))out.put("availableLots",catalog());return out;
    }
    private void emit(){if(web==null||closed||!eventPosted.compareAndSet(false,true))return;events.postDelayed(()->{eventPosted.set(false);WebView value=web;if(value!=null&&!closed)value.evaluateJavascript("window.dispatchEvent(new Event('truchapp-local-pair-changed'))",null);},120);}
    private void reply(String id,boolean ok,JSONObject value){
        String raw=value.toString();List<String> parts=new ArrayList<>();for(int from=0;from<raw.length();){int end=Math.min(raw.length(),from+32768);if(end<raw.length()&&Character.isHighSurrogate(raw.charAt(end-1)))end--;parts.add(raw.substring(from,end));from=end;}if(parts.isEmpty())parts.add("");int count=parts.size();
        for(int i=0;i<count;i++){String script="window.TruchAppLocalPairReceive&&window.TruchAppLocalPairReceive("+JSONObject.quote(id)+","+ok+","+i+","+count+","+JSONObject.quote(parts.get(i))+")";events.post(()->{WebView valueWeb=web;if(valueWeb!=null)valueWeb.evaluateJavascript(script,null);});}
    }
    private static JSONObject newSafe(String key,String value){JSONObject out=new JSONObject();try{out.put(key,value);}catch(Exception ignored){}return out;}
    private static String message(Exception error){return PairFailure.message(error);}
}
