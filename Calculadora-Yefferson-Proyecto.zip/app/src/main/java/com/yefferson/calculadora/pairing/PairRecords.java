package com.yefferson.calculadora.pairing;

import org.json.*;
import java.io.IOException;
import java.util.*;

/** Allowlisted assignment catalog; never serializes a lot's measurements, costs, history or notes. */
public final class PairRecords {
    public static final int MAX_LOTS=100;
    public static String text(String value,int max){String v=value==null?"":value.trim().replaceAll("[\\p{Cntrl}]","");return v.length()>max?v.substring(0,max):v;}
    public static void fingerprint(String value) throws IOException {if(value==null||!value.matches("[0-9a-f]{64}"))throw new IOException("Identidad de equipo inválida");}
    public static String permission(String value) throws IOException {if(!"view".equals(value)&&!"record".equals(value))throw new IOException("Permiso inválido");return value;}
    public static JSONArray catalog(JSONArray source) throws Exception {
        JSONArray out=new JSONArray();Set<String> seen=new HashSet<>();
        for(int i=0;i<source.length()&&out.length()<500;i++){
            JSONObject lot=source.optJSONObject(i);if(lot==null)continue;Object raw=lot.opt("id");if(!(raw instanceof String))continue;String id=(String)raw;
            if(id.isEmpty()||id.length()>180||!id.equals(text(id,180))||!seen.add(id))continue;
            out.put(new JSONObject().put("id",id).put("code",text(lot.optString("code","Lote"),80)).put("stage",text(lot.optString("stage"),40)).put("unit",text(lot.optString("unit"),40)));
        }return out;
    }
    public static JSONArray assign(JSONArray available,JSONArray ids) throws Exception {
        if(ids==null||ids.length()>MAX_LOTS)throw new IOException("Elige hasta "+MAX_LOTS+" lotes");
        Map<String,JSONObject> index=new HashMap<>();for(int i=0;i<available.length();i++){JSONObject lot=available.getJSONObject(i);index.put(lot.getString("id"),lot);}
        Set<String> seen=new HashSet<>();JSONArray out=new JSONArray();
        for(int i=0;i<ids.length();i++){Object raw=ids.get(i);if(!(raw instanceof String)||!index.containsKey(raw)||!seen.add((String)raw))throw new IOException("La asignación contiene un lote inexistente o repetido");out.put(index.get((String)raw));}return out;
    }
    public static JSONArray received(JSONArray source) throws Exception {
        if(source==null||source.length()>MAX_LOTS)throw new IOException("Catálogo de lotes inválido");
        JSONArray out=catalog(source);if(out.length()!=source.length())throw new IOException("Catálogo de lotes inválido");return out;
    }
    public static JSONArray ids(JSONArray catalog) throws Exception {JSONArray out=new JSONArray();for(int i=0;i<catalog.length();i++)out.put(catalog.getJSONObject(i).getString("id"));return out;}
}
