package com.yefferson.calculadora.pairing;
import android.content.Context;import android.net.wifi.WifiManager;import org.json.*;
/** Radio state comes from Android, never an optimistic UI value or a pairing flag. */
public final class PairWifi {
    public static JSONObject status(Context context){JSONObject out=new JSONObject();try{WifiManager wifi=(WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);int state=wifi==null?WifiManager.WIFI_STATE_UNKNOWN:wifi.getWifiState();out.put("supported",wifi!=null).put("enabled",state==WifiManager.WIFI_STATE_ENABLED).put("state",state==WifiManager.WIFI_STATE_ENABLED?"enabled":state==WifiManager.WIFI_STATE_DISABLED?"disabled":state==WifiManager.WIFI_STATE_ENABLING?"enabling":state==WifiManager.WIFI_STATE_DISABLING?"disabling":"unknown");}catch(Exception ignored){try{out.put("supported",false).put("enabled",false).put("state","unknown");}catch(JSONException impossible){}}return out;}
}
