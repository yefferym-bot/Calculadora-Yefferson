package com.yefferson.calculadora.pairing;

import org.json.JSONArray;

/** Cache only allowlisted metadata; never retain production histories to serve repeated peer snapshots. */
public final class PairCatalog {
    public interface Source {String stamp() throws Exception;String lots() throws Exception;}
    private String stamp;private JSONArray catalog;
    public synchronized JSONArray read(Source source) throws Exception {
        String before=source.stamp();if(catalog!=null&&before.equals(stamp))return catalog;
        JSONArray value=PairRecords.catalog(new JSONArray(source.lots()));
        if(before.equals(source.stamp())){stamp=before;catalog=value;}else{stamp=null;catalog=null;}
        return value;
    }
}
