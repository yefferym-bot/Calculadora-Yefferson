package com.yefferson.calculadora.pairing;

import android.Manifest;import android.app.Activity;import android.content.*;import android.content.pm.PackageManager;import android.net.wifi.WifiManager;import android.os.Build;import android.provider.Settings;import android.webkit.WebView;
import com.google.zxing.integration.android.*;import org.json.*;

/** Activity-only system panels and camera launch. No QR is trusted by the WebView. */
public final class PairDeviceUi {
    private static final int CAMERA_PERMISSION=7300,SCAN=7301;
    private final Activity activity;private final WebView web;private final LocalPairingController pairing;
    private String pending="",result="";private boolean watching,closed;
    private final BroadcastReceiver receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){pairing.deviceChanged();}};
    public PairDeviceUi(Activity a,WebView w,LocalPairingController p){activity=a;web=w;pairing=p;}
    public boolean request(String id,String command,String raw){
        if(!"wifi".equals(command)&&!"scan".equals(command))return false;
        if(id==null||id.length()>80||raw==null||raw.length()>2048)return true;
        activity.runOnUiThread(()->{if(closed)return;try{
            if(activity.isFinishing()||activity.isDestroyed())throw new Exception("Abre TruchApp para usar esta opción");
            if("wifi".equals(command)){
                boolean wanted=new JSONObject(raw).getBoolean("enabled");
                if(Build.VERSION.SDK_INT>=29){Intent panel=new Intent(Settings.Panel.ACTION_WIFI);try{activity.startActivity(panel);}catch(ActivityNotFoundException missing){activity.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));}}
                else {WifiManager wifi=(WifiManager)activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);if(wifi==null||!wifi.setWifiEnabled(wanted))throw new Exception("No se pudo cambiar el Wi-Fi. Usa los ajustes del teléfono");}
                pairing.request(id,"status","{}");pairing.deviceChanged();
            }else{
                if(!pending.isEmpty())throw new Exception("Ya hay un escaneo en curso");pending=id;
                if(activity.checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)activity.requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION);else scan();
            }
        }catch(Exception e){if(id.equals(pending))pending="";error(id,e.getMessage());}});return true;
    }
    private void scan(){new IntentIntegrator(activity).setCaptureActivity(PairQrCaptureActivity.class).setDesiredBarcodeFormats(IntentIntegrator.QR_CODE).setRequestCode(SCAN).setPrompt("Escanea el QR que muestra tu administrador").setBeepEnabled(false).setBarcodeImageEnabled(false).setOrientationLocked(true).setTimeout(60000).initiateScan();}
    public boolean permission(int code,int[] grants){if(code!=CAMERA_PERMISSION)return false;if(!pending.isEmpty()){if(grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)try{scan();}catch(Exception e){error(pending,"No se pudo abrir la cámara");pending="";}else{error(pending,"Permite el acceso a la cámara para escanear el QR. También puedes buscar al administrador");pending="";}}return true;}
    public boolean result(int requestCode,int resultCode,Intent data){
        if(requestCode!=SCAN)return false;if(pending.isEmpty())return true;
        IntentResult scan=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
        // Custom request code is supported by the explicit result-code overload.
        if(scan==null)scan=IntentIntegrator.parseActivityResult(resultCode,data);
        if(scan==null||scan.getContents()==null){error(pending,"Escaneo cancelado. Puedes volver a intentarlo");pending="";}else result=scan.getContents();return true;
    }
    public void resume(){
        if(closed)return;if(!watching){IntentFilter filter=new IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION);if(Build.VERSION.SDK_INT>=33)activity.registerReceiver(receiver,filter,Context.RECEIVER_EXPORTED);else activity.registerReceiver(receiver,filter);watching=true;}
        pairing.deviceChanged();if(!result.isEmpty()&&!pending.isEmpty()){String id=pending,qr=result;pending="";result="";try{if(qr.length()>2048)throw new Exception("El QR es demasiado grande");pairing.request(id,"connect-qr",new JSONObject().put("qr",qr).toString());}catch(Exception e){error(id,e.getMessage());}}
    }
    public void pause(){if(watching){try{activity.unregisterReceiver(receiver);}catch(Exception ignored){}watching=false;}}
    public void close(){closed=true;pause();pending="";result="";}
    private void error(String id,String message){if(closed)return;String json;try{json=new JSONObject().put("error",message==null?"No se pudo completar la acción":message).toString();}catch(Exception e){return;}web.evaluateJavascript("window.TruchAppLocalPairReceive&&window.TruchAppLocalPairReceive("+JSONObject.quote(id)+",false,0,1,"+JSONObject.quote(json)+")",null);}
}
