package com.yefferson.calculadora.data.db;

import android.content.Context;
import android.database.Cursor;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** The single authoritative store for the five modules. All cross-module writes share a transaction. */
public final class FarmRepository {
    private static FarmRepository instance;
    public static synchronized FarmRepository get(Context context){if(instance==null)instance=new FarmRepository(context.getApplicationContext());return instance;}
    private final Context context;
    private final AtomicFile pointer;
    private FarmDatabase database;
    private String name;
    private final Map<String,String> cache=new HashMap<>();
    public Runnable onCommitted;
    private String maintenanceWarning="";
    private void committed(){if(onCommitted!=null)try{onCommitted.run();}catch(Exception e){maintenanceWarning="No se pudo programar una copia local. Puedes crearla desde Estado y recuperación.";}}

    public FarmRepository(Context context){this.context=context;pointer=new AtomicFile(new File(context.getFilesDir(),"farm-database.active"));}
    public synchronized FarmDatabase database(){
        if(database==null){
            name="truchapp-data.db";
            if(pointer.getBaseFile().exists())try(InputStream in=pointer.openRead()){
                byte[] b=new byte[160];int n=in.read(b);String selected=new String(b,0,Math.max(n,0),StandardCharsets.UTF_8);
                if(!selected.matches("truchapp-[a-zA-Z0-9-]+\\.db"))throw new IOException("Puntero de recuperación inválido");name=selected;
            }catch(Exception e){throw new IllegalStateException("No se pudo leer el estado del almacenamiento. Se conserva el original.",e);}
            database=FarmDatabase.open(context,name);
        }return database;
    }
    private FarmDao dao(){return database().data();}
    private long revision(){FarmDocument d=dao().document("__system/revision");return d==null?0:Long.parseLong(d.template);}
    private void meta(String key,String value){FarmDocument d=new FarmDocument();d.key="__system/"+key;d.template=value;dao().document(d);}
    public synchronized boolean ready(){return dao().document("__system/initialized")!=null;}
    public synchronized String read(String key,String fallback){
        if(!ready())return fallback;
        if(cache.containsKey(key))return cache.get(key);
        FarmDocument d=dao().document(key);if(d==null)return fallback;
        try{String raw=DocumentCodec.decode(d,dao().records(key));DocumentCodec.validate(key,raw);if(raw.length()<2*1024*1024)cache.put(key,raw);return raw;}
        catch(Exception e){throw new IllegalStateException("No se pudo leer "+key+". Se conserva el original.",e);}
    }
    public synchronized JSONObject snapshot() throws JSONException {
        JSONObject web=new JSONObject();for(FarmDocument d:dao().documents())if(!d.key.startsWith("__system/"))web.put(d.key,read(d.key,null));return web;
    }
    public synchronized JSONObject bootstrap(JSONObject web,JSONObject nativeData) throws Exception {
        if(!ready()){
            // Preserve the old sources; never clear localStorage or the original preferences.
            JSONObject source=new JSONObject(web.toString());
            String[][] aliases={{"production_lots",DocumentCodec.LOTS},{"activities","activities"},{"profile","profile"},{"memories","memories"},{"reminders","reminders"}};
            for(String[] pair:aliases){String raw=nativeData.optString(pair[0],"");
                if(raw.isEmpty())continue;
                boolean take=!source.has(pair[1]);
                if(pair[1].equals(DocumentCodec.LOTS)){Object n=new JSONTokener(raw).nextValue();if(!(n instanceof JSONArray))throw new JSONException("Lotes nativos inválidos");take=((JSONArray)n).length()>0||take;}
                if(take)source.put(pair[1],raw);
            }
            // Interrupted old Agenda transactions contain the last consistent pre-write state.
            if(source.has("truchapp_agenda_transaction_v1")){
                JSONObject journal=new JSONObject(source.getString("truchapp_agenda_transaction_v1")),previous=journal.getJSONObject("local");
                Iterator<String> it=previous.keys();while(it.hasNext()){String k=it.next();if(previous.isNull(k))source.remove(k);else source.put(k,previous.getString(k));}
                source.remove("truchapp_agenda_transaction_v1");
            }
            write(source,revision(),"migration-1","Migración verificada",false);
        }
        return new JSONObject().put("revision",revision()).put("web",snapshot()).put("health",health());
    }
    public synchronized JSONObject write(JSONObject patch,long expected,String operation,String label,boolean replace) throws Exception {
        String fingerprint=DocumentCodec.hash(patch.toString()+"|"+replace);
        FarmAudit prior=dao().receipt(operation);
        if(prior!=null){if(!prior.fingerprint.equals(fingerprint))throw new JSONException("La operación ya existe con otro contenido");return new JSONObject().put("revision",revision()).put("replayed",true);}
        if(expected>=0&&revision()!=expected)throw new JSONException("Los datos cambiaron. Vuelve a abrir la pantalla antes de guardar.");
        JSONObject changes=new JSONObject(patch.toString());
        if(replace)for(FarmDocument d:dao().documents())if(!d.key.startsWith("__system/")&&!changes.has(d.key))changes.put(d.key,JSONObject.NULL);
        Map<String,DocumentCodec.Encoded> encoded=new LinkedHashMap<>();
        Iterator<String> it=changes.keys();while(it.hasNext()){
            String key=it.next();if(key.length()>180||key.startsWith("__system/"))throw new JSONException("Clave no permitida");
            if(!changes.isNull(key)){Object raw=changes.get(key);if(!(raw instanceof String))throw new JSONException("Valor de almacenamiento inválido");encoded.put(key,DocumentCodec.encode(key,(String)raw));}
            else encoded.put(key,null);
        }
        long nextRevision=revision()+1;boolean capture=!operation.equals("migration-1");JSONArray inverse=capture?new JSONArray():null,forward=capture?new JSONArray():null;
        database().runInTransaction(()->{
            try{
                for(Map.Entry<String,DocumentCodec.Encoded> entry:encoded.entrySet())applyDocument(entry.getKey(),entry.getValue(),inverse,forward);
                meta("revision",String.valueOf(nextRevision));meta("initialized","1");
                FarmAudit audit=new FarmAudit();audit.operationId=operation;audit.label=label;audit.createdAt=System.currentTimeMillis();audit.revision=nextRevision;audit.inverse=inverse==null?"[]":inverse.toString();audit.forward=forward==null?"[]":forward.toString();audit.fingerprint=fingerprint;dao().audit(audit);
                dao().pruneAudit(System.currentTimeMillis()-30L*86400000L);
            }catch(Exception e){throw new IllegalStateException(e.getMessage(),e);}
        });
        for(String key:encoded.keySet()){if(changes.isNull(key)||changes.getString(key).length()>=2*1024*1024)cache.remove(key);else cache.put(key,changes.getString(key));}
        committed();
        return new JSONObject().put("revision",nextRevision).put("changedRows",forward==null?0:forward.length());
    }
    private static JSONObject docJson(FarmDocument d) throws JSONException {return new JSONObject().put("key",d.key).put("template",d.template).put("format",d.format);}
    private void applyDocument(String key,DocumentCodec.Encoded next,JSONArray inverse,JSONArray forward) throws Exception {
        FarmDocument old=dao().document(key);
        String before=old==null?null:docJson(old).toString(),after=next==null?null:docJson(next.document).toString();
        if(!Objects.equals(before,after)){
            if(inverse!=null){inverse.put(new JSONObject().put("type","document").put("key",key).put("value",before==null?JSONObject.NULL:before));forward.put(new JSONObject().put("type","document").put("key",key).put("value",after==null?JSONObject.NULL:after));}
            if(next==null)dao().deleteDocument(key);else dao().document(next.document);
        }
        Map<String,FarmRecord> previous=new HashMap<>();for(FarmRecord r:dao().records(key))previous.put(r.path+"\u0000"+r.recordId,r);
        if(next!=null){rank(next.rows,previous);for(FarmRecord r:next.rows){
            FarmRecord oldRow=previous.remove(r.path+"\u0000"+r.recordId);
            String oldJson=oldRow==null?null:DocumentCodec.rowJson(oldRow).toString(),newJson=DocumentCodec.rowJson(r).toString();
            if(!Objects.equals(oldJson,newJson)){recordChange(oldRow,r,inverse,forward);dao().record(r);}
        }}
        for(FarmRecord r:previous.values()){recordChange(r,null,inverse,forward);dao().deleteRecord(r.owner,r.path,r.recordId);}
    }
    /** Stable spaced ranks keep a new newest measurement from rewriting every historical row. */
    private static void rank(List<FarmRecord> rows,Map<String,FarmRecord> previous){
        Map<String,List<FarmRecord>> groups=new HashMap<>();for(FarmRecord r:rows){if(!groups.containsKey(r.path))groups.put(r.path,new ArrayList<>());groups.get(r.path).add(r);}
        for(List<FarmRecord> group:groups.values()){
            Collections.sort(group,(a,b)->Long.compare(a.position,b.position));long last=Long.MIN_VALUE/4;boolean rebalance=false;
            for(int i=0;i<group.size();i++){
                FarmRecord r=group.get(i),old=previous.get(r.path+"\u0000"+r.recordId);long pos;
                if(old!=null)pos=old.position;
                else{long upper=Long.MAX_VALUE/4;for(int j=i+1;j<group.size();j++){FarmRecord n=group.get(j),v=previous.get(n.path+"\u0000"+n.recordId);if(v!=null){upper=v.position;break;}}
                    pos=last==Long.MIN_VALUE/4?(upper==Long.MAX_VALUE/4?0:upper-1024):Math.min(last+1024,upper-1);
                }
                if(pos<=last||pos>Long.MAX_VALUE/4){rebalance=true;break;}r.position=pos;last=pos;
            }
            if(rebalance)for(int i=0;i<group.size();i++)group.get(i).position=(long)i*1024;
        }
    }
    private static void recordChange(FarmRecord before,FarmRecord after,JSONArray inverse,JSONArray forward) throws JSONException {
        if(inverse==null)return;
        FarmRecord r=before!=null?before:after;
        JSONObject a=new JSONObject().put("type","record").put("owner",r.owner).put("path",r.path).put("id",r.recordId);
        JSONObject b=new JSONObject(a.toString());a.put("value",before==null?JSONObject.NULL:DocumentCodec.rowJson(before).toString());b.put("value",after==null?JSONObject.NULL:DocumentCodec.rowJson(after).toString());inverse.put(a);forward.put(b);
    }
    public synchronized JSONObject undo(String id,long expected) throws Exception {
        if(revision()!=expected)throw new JSONException("Los datos cambiaron; actualiza la lista de recuperación");
        FarmAudit audit=dao().receipt(id);if(audit==null||audit.undone||id.equals("migration-1"))throw new JSONException("La operación ya no está disponible");
        JSONArray forward=new JSONArray(audit.forward),inverse=new JSONArray(audit.inverse);
        database().runInTransaction(()->{try{
            for(int i=0;i<forward.length();i++){
                JSONObject entry=forward.getJSONObject(i);String actual=null;
                if(entry.getString("type").equals("document")){FarmDocument d=dao().document(entry.getString("key"));if(d!=null)actual=docJson(d).toString();}
                else{FarmRecord r=dao().record(entry.getString("owner"),entry.getString("path"),entry.getString("id"));if(r!=null)actual=DocumentCodec.rowJson(r).toString();}
                String wanted=entry.isNull("value")?null:entry.getString("value");if(!Objects.equals(actual,wanted))throw new JSONException("Existen cambios posteriores relacionados. Usa un respaldo o revisa los registros antes de deshacer.");
            }
            for(int i=0;i<inverse.length();i++){
                JSONObject e=inverse.getJSONObject(i);
                if(e.getString("type").equals("document")){
                    String key=e.getString("key");if(e.isNull("value"))dao().deleteDocument(key);else{JSONObject v=new JSONObject(e.getString("value"));FarmDocument d=new FarmDocument();d.key=key;d.template=v.getString("template");d.format=v.getString("format");dao().document(d);}
                }else if(e.isNull("value"))dao().deleteRecord(e.getString("owner"),e.getString("path"),e.getString("id"));else dao().record(DocumentCodec.rowFrom(new JSONObject(e.getString("value"))));
            }
            dao().markUndone(id);meta("revision",String.valueOf(expected+1));
        }catch(Exception e){throw new IllegalStateException(e.getMessage(),e);}});
        cache.clear();committed();return new JSONObject().put("revision",revision()).put("web",snapshot());
    }
    public synchronized JSONArray recent() throws JSONException {JSONArray a=new JSONArray();for(FarmAudit r:dao().recent())a.put(new JSONObject().put("id",r.operationId).put("label",r.label).put("date",r.createdAt).put("changes",new JSONArray(r.forward).length()));return a;}
    public synchronized JSONObject receipt(String id) throws JSONException {FarmAudit r=dao().receipt(id);return new JSONObject().put("found",r!=null).put("revision",revision()).put("operationRevision",r==null?0:r.revision);}
    public synchronized JSONObject page(JSONObject query) throws Exception {
        String kind=query.getString("kind"),lot=query.optString("lotId",""),start=query.optString("start",""),requestedEnd=query.optString("end",""),end=requestedEnd.isEmpty()?"\uffff":requestedEnd;int limit=Math.max(1,Math.min(100,query.optInt("limit",30))),offset=Math.max(0,query.optInt("offset",0));
        List<FarmRecord> page=lot.isEmpty()?dao().pageAll(kind,start,end,limit,offset):dao().pageLot(kind,lot,start,end,limit,offset);
        JSONArray result=new JSONArray();for(FarmRecord r:page){
            FarmDocument d=new FarmDocument();d.format="json";d.template=r.json;
            String prefix=r.path+"/@"+DocumentCodec.hash(r.recordId).substring(0,20)+"/%";
            result.put(new JSONTokener(DocumentCodec.decode(d,dao().nested(r.owner,prefix))).nextValue());
        }return new JSONObject().put("rows",result).put("total",lot.isEmpty()?dao().countRange(kind,start,end):dao().countLotRange(kind,lot,start,end)).put("offset",offset).put("revision",revision());
    }
    public synchronized JSONObject health() throws JSONException {
        JSONObject h=new JSONObject().put("revision",revision()).put("initialized",ready()).put("schema",1).put("engine","Room / SQLite");
        for(String kind:new String[]{"lots","water","daily","samples","tasks","products","movements","agenda"})h.put(kind,dao().count(kind,""));
        File f=context.getDatabasePath(name);h.put("bytes",f.length()+new File(f+"-wal").length()).put("maintenanceWarning",maintenanceWarning);return h;
    }
    public synchronized void verify() throws Exception {
        try(Cursor c=database().getOpenHelper().getReadableDatabase().query("PRAGMA quick_check")){
            if(!c.moveToFirst()||!"ok".equals(c.getString(0)))throw new IOException("La comprobación de integridad detectó un problema. Se conserva la base original.");
        }
        // A valid SQLite file alone does not guarantee valid production documents.
        cache.clear();snapshot();
    }
    public synchronized String stagedName(){return "truchapp-stage-"+UUID.randomUUID().toString()+".db";}
    public synchronized FarmDatabase createStage(String name){return FarmDatabase.open(context,name);}
    public synchronized void activate(FarmDatabase staged,String stagedName) throws Exception {
        try(Cursor c=staged.getOpenHelper().getReadableDatabase().query("PRAGMA quick_check")){if(!c.moveToFirst()||!"ok".equals(c.getString(0)))throw new IOException("Respaldo incompleto");}
        FileOutputStream out=null;try{out=pointer.startWrite();out.write(stagedName.getBytes(StandardCharsets.UTF_8));pointer.finishWrite(out);}catch(Exception e){if(out!=null)pointer.failWrite(out);throw e;}
        FarmDatabase previous=database;database=staged;name=stagedName;cache.clear();if(previous!=null)previous.close();
        // The previous generation is retained. No in-use database files are copied or renamed.
    }
}
