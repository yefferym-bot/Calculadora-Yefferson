package com.yefferson.calculadora.data;

import android.app.Activity;
import android.webkit.WebView;
import com.yefferson.calculadora.data.db.*;
import org.json.*;
import java.io.File;
import java.util.concurrent.*;

/** Asynchronous WebView transport. Expensive I/O and recovery never execute on Android's UI thread. */
public final class StorageController {
    private final Activity activity;private final LocalStore store;private final FarmRepository repository;private final RecoveryVault vault;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();private volatile WebView web;
    private DatabaseArchive.Stage pending;
    public StorageController(Activity activity,LocalStore store){
        this.activity=activity;this.store=store;repository=FarmRepository.get(activity);vault=new RecoveryVault(activity,repository);
        android.content.Context app=activity.getApplicationContext();repository.onCommitted=()->RecoveryWorker.afterCommit(app);
    }
    public void attach(WebView web){this.web=web;}
    public void close(){web=null;executor.shutdown();}
    public FarmRepository repository(){return repository;}
    public void request(String id,String command,String raw){
        executor.execute(()->{try{JSONObject input=raw==null||raw.isEmpty()?new JSONObject():new JSONObject(raw),result;
            switch(command){
                case "bootstrap":{
                    boolean migrated=!repository.ready();result=repository.bootstrap(input.optJSONObject("web")==null?new JSONObject():input.getJSONObject("web"),store.exportLegacyBackupData());store.enableDatabase(repository);
                    try{RecoveryWorker.schedule(activity);}catch(Exception e){result.put("backupWarning","No se pudo programar la copia automática. Puedes crear una copia manual.");}
                    if(migrated)try{vault.checkpoint("migration",true);}catch(Exception e){result.put("backupWarning","No se pudo crear la primera copia local: "+e.getMessage());}
                    result.put("recovery",vault.summary());break;
                }
                case "commit":result=repository.write(input.getJSONObject("patch"),input.getLong("revision"),input.getString("operation"),input.optString("label","Preferencias"),false);break;
                case "snapshot":result=new JSONObject().put("web",repository.snapshot()).put("revision",repository.health().getLong("revision"));break;
                case "page":result=repository.page(input);break;
                case "health":result=repository.health().put("recovery",vault.summary());break;
                case "verify":repository.verify();result=repository.health().put("verified",true).put("recovery",vault.summary());break;
                case "checkpoint":result=vault.checkpoint("manual",true);break;
                case "recoveries":result=new JSONObject().put("copies",vault.list());break;
                case "operations":result=new JSONObject().put("operations",repository.recent());break;
                case "receipt":result=repository.receipt(input.getString("operation"));break;
                case "undo":vault.checkpoint("before-undo",true);result=repository.undo(input.getString("id"),input.getLong("revision"));break;
                case "stageRecovery":setPending(vault.stage(input.getString("id")));result=pending.metadata;break;
                case "applyRestore":result=applyPending();break;
                default:throw new IllegalArgumentException("Operación de datos no reconocida");
            }
            respond(id,true,result.toString());
        }catch(Exception e){respond(id,false,new JSONObjectSafe("error",message(e)).toString());}});
    }
    /** Small compatibility writes; called on WebView's Java bridge thread, never its UI thread. */
    public String commitSync(String raw){try{
        JSONObject input=new JSONObject(raw),result=repository.write(input.getJSONObject("patch"),input.getLong("revision"),input.getString("operation"),input.optString("label","Preferencias"),false);
        return new JSONObject().put("ok",true).put("result",result).toString();
    }catch(Exception e){return new JSONObjectSafe("error",message(e)).toString();}}
    public synchronized JSONObject stageFile(File file,char[] password) throws Exception {setPending(DatabaseArchive.stage(activity,repository,file,password));return pending.metadata;}
    public synchronized JSONObject stageLegacy(JSONObject payload) throws Exception {setPending(DatabaseArchive.legacy(activity,repository,payload));return pending.metadata;}
    private synchronized void setPending(DatabaseArchive.Stage next){DatabaseArchive.discard(activity,pending);pending=next;}
    private synchronized JSONObject applyPending() throws Exception {
        if(pending==null)throw new IllegalStateException("Selecciona y verifica primero un respaldo");
        // If the current generation is unreadable, it is retained untouched; activate a new generation.
        boolean readable=false;try{readable=repository.ready();if(readable)repository.verify();}catch(Exception ignored){readable=false;}
        if(readable)vault.checkpoint("before-import",true);
        String oldReminders=store.getReminders();DatabaseArchive.Stage stage=pending;repository.activate(stage.database,stage.name);pending=null;store.enableDatabase(repository);
        String warning="";
        try{if(stage.metadata.has("nativeReminders"))store.saveReminders(stage.metadata.getString("nativeReminders"));else store.saveReminders(repository.read("reminders","[]"));}
        catch(Exception e){warning="Los datos se restauraron. Revisa los recordatorios de Agenda.";}
        // MainActivity reconciles the old and new alarms after the successful callback.
        return new JSONObject().put("restored",true).put("oldReminders",oldReminders).put("warning",warning).put("revision",repository.health().getLong("revision"));
    }
    private void respond(String id,boolean ok,String raw){
        // Chunk the transport so a long history does not exceed WebView IPC message limits.
        java.util.List<String> parts=new java.util.ArrayList<>();for(int from=0;from<raw.length();){int end=Math.min(raw.length(),from+49152);if(end<raw.length()&&Character.isHighSurrogate(raw.charAt(end-1)))end--;parts.add(raw.substring(from,end));from=end;}if(parts.isEmpty())parts.add("");int count=parts.size();
        for(int i=0;i<count;i++){
            String part=parts.get(i);final String script="window.TruchAppStorageReceive&&window.TruchAppStorageReceive("+JSONObject.quote(id)+","+ok+","+i+","+count+","+JSONObject.quote(part)+")";
            activity.runOnUiThread(()->{WebView target=web;if(target!=null)target.evaluateJavascript(script,null);});
        }
    }
    private static String message(Exception e){String m=e.getMessage();return m==null?"No se pudo completar la operación. Se conservan los datos anteriores.":m;}
    private static class JSONObjectSafe extends JSONObject {JSONObjectSafe(String key,String value){try{put(key,value);}catch(JSONException ignored){}}}
}
