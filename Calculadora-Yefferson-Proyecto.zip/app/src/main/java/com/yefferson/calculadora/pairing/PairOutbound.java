package com.yefferson.calculadora.pairing;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Per-peer FIFO with byte/frame budgets and fair one-frame turns on a shared bounded writer pool. */
public final class PairOutbound implements PairWire.Sender,AutoCloseable {
    public static final int MAX_FRAMES=8,MAX_BYTES=512*1024;
    private final PairRuntime runtime;private final DataOutputStream output;private final Runnable abort;
    private final ArrayDeque<Packet> queue=new ArrayDeque<>();private Packet writing;
    private boolean scheduled,closed;private int count,bytes;
    private static final class Packet {
        final byte[] data;final int size;final Runnable completion;final AtomicBoolean done=new AtomicBoolean();final CountDownLatch finished=new CountDownLatch(1);
        volatile Exception error;ScheduledFuture<?> expiry,watchdog;
        Packet(byte[] data,Runnable completion){this.data=data;size=data.length+4;this.completion=completion;}
    }
    public PairOutbound(PairRuntime runtime,OutputStream output,Runnable abort){this.runtime=runtime;this.output=new DataOutputStream(new BufferedOutputStream(output,16384));this.abort=abort;}
    private Packet enqueue(byte[] data,Runnable completion) throws IOException {
        Packet packet=new Packet(data,completion);
        synchronized(this){
            if(closed||count>=MAX_FRAMES||bytes+packet.size>MAX_BYTES||!runtime.reserve(packet.size))throw new IOException("La cola de este equipo está ocupada. Reconecta e inténtalo de nuevo");
            count++;bytes+=packet.size;queue.add(packet);
            try{packet.expiry=runtime.timers.schedule(()->{if(!packet.done.get())fail(new IOException("El envío pendiente no se completó a tiempo"));},runtime.queueMillis,TimeUnit.MILLISECONDS);if(!scheduled)schedule();}
            catch(RejectedExecutionException error){fail(new IOException("La conexión local se está cerrando",error));}
        }
        return packet;
    }
    private void schedule(){scheduled=true;runtime.writers.execute(this::writeOne);}
    private void writeOne(){
        Packet packet;
        synchronized(this){if(closed){scheduled=false;return;}packet=queue.poll();if(packet==null){scheduled=false;return;}writing=packet;}
        try{
            packet.watchdog=runtime.timers.schedule(()->{if(!packet.done.get())fail(new IOException("El otro equipo no está recibiendo datos"));},runtime.writeMillis,TimeUnit.MILLISECONDS);
            output.writeInt(packet.data.length);for(int from=0;from<packet.data.length;from+=16384)output.write(packet.data,from,Math.min(16384,packet.data.length-from));output.flush();finish(packet,null);
        }catch(Exception error){fail(error);}
        finally{
            synchronized(this){writing=null;scheduled=false;if(!closed&&!queue.isEmpty())try{schedule();}catch(RejectedExecutionException error){fail(new IOException("Conexión cerrada",error));}}
        }
    }
    private void finish(Packet packet,Exception error){
        if(!packet.done.compareAndSet(false,true))return;
        if(packet.expiry!=null)packet.expiry.cancel(false);if(packet.watchdog!=null)packet.watchdog.cancel(false);
        synchronized(this){count--;bytes-=packet.size;}runtime.releaseBytes(packet.size);packet.error=error;packet.finished.countDown();
        if(packet.completion!=null)try{packet.completion.run();}catch(Exception ignored){}
    }
    private void fail(Exception error){
        List<Packet> pending;
        synchronized(this){if(closed)return;closed=true;pending=new ArrayList<>(queue);queue.clear();if(writing!=null)pending.add(writing);}
        // Abort outside the monitor: closing the socket unblocks the particular slow writer.
        try{abort.run();}catch(Exception ignored){}
        for(Packet packet:pending)finish(packet,error);
    }
    @Override public void send(byte[] data) throws Exception {
        Packet packet=enqueue(data,null);
        try{if(!packet.finished.await(runtime.queueMillis+1000,TimeUnit.MILLISECONDS)){fail(new IOException("Tiempo de envío agotado"));throw new IOException("Tiempo de envío agotado");}}
        catch(InterruptedException interrupted){Thread.currentThread().interrupt();fail(new InterruptedIOException("Envío cancelado"));throw interrupted;}
        if(packet.error!=null)throw packet.error;
    }
    @Override public boolean offer(byte[] data,Runnable completion){try{enqueue(data,completion);return true;}catch(Exception ignored){return false;}}
    @Override public void close(){fail(new IOException("Conexión cerrada"));}
    public synchronized int queuedFrames(){return count;}
}
