package com.yefferson.calculadora.pairing;

/** Monotonic admission and manual retry gates. No sleeping, automatic approval or repeated writes. */
public final class PairLimits {
    public static final class Admission {
        private double tokens=40;private long at;
        public synchronized boolean allow(long now){if(at!=0)tokens=Math.min(40,tokens+Math.max(0,now-at)/1000000000.0*2);at=now;if(tokens<1)return false;tokens--;return true;}
    }
    public static final class Retry {
        private String target="";private int failures;private long until;
        public synchronized long remaining(String key,long now){if(!target.equals(key))return 0;return Math.max(0,(until-now+999999L)/1000000L);}
        public synchronized void failed(String key,long now,double random){if(!target.equals(key)){failures=0;target=key;}failures=Math.min(6,failures+1);long maximum=Math.min(30000,1000L<<failures);long delay=(long)(maximum*(0.5+Math.max(0,Math.min(1,random))*0.5));until=now+delay*1000000L;}
        public synchronized void reset(){target="";failures=0;until=0;}
        public synchronized long remaining(long now){return remaining(target,now);}
    }
}
