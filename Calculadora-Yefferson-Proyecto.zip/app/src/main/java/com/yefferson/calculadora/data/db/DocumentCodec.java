package com.yefferson.calculadora.data.db;

import org.json.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Lossless compatibility boundary: legacy documents become independently indexed rows. */
public final class DocumentCodec {
    public static final String LOTS="truchapp_lotes_v1", WATER="truchapp_lotes_water_quality_v1",
        FARMS="truchapp_lotes_water_farms_v1", STOCK="truchapp_almacen_kardex_v1", BOOK="truchapp_agenda_workbook_v1";
    private static final String ROWS="$truchappRows";
    public static class Encoded {
        public FarmDocument document=new FarmDocument();
        public List<FarmRecord> rows=new ArrayList<>();
    }
    public static String stringify(Object value) throws JSONException {
        String wrapped=new JSONArray().put(value).toString();
        return wrapped.substring(1,wrapped.length()-1);
    }
    public static String hash(String value) {
        try {
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder s=new StringBuilder();for(byte b:digest)s.append(String.format(Locale.US,"%02x",b&255));return s.toString();
        } catch(Exception e){throw new IllegalStateException(e);}
    }
    public static boolean critical(String key){
        return key.equals(LOTS)||key.equals(WATER)||key.equals(FARMS)||key.equals(STOCK)||key.equals(BOOK)||key.equals("activities")||key.equals("truchapp_finance_v1")||key.equals("truchapp_inicio_control_v1");
    }
    private static Object parse(String raw) throws JSONException {
        JSONTokener token=new JSONTokener(raw);Object value=token.nextValue();if(token.nextClean()!=0)throw new JSONException("Contenido adicional después del JSON");return value;
    }
    public static void validate(String key,String raw) throws JSONException {
        if(raw==null)return;
        if(key.startsWith("__system/"))throw new JSONException("Clave interna no permitida");
        if(!critical(key))return;
        Object value=parse(raw);
        if(key.equals(LOTS)||key.equals(WATER)||key.equals(FARMS)||key.equals("activities")) {
            if(!(value instanceof JSONArray))throw new JSONException("Formato inválido en "+key+". Se conserva el original.");
            JSONArray a=(JSONArray)value;for(int i=0;i<a.length();i++)if(!(a.get(i) instanceof JSONObject))throw new JSONException("Registro inválido en "+key);
        } else if(!(value instanceof JSONObject))throw new JSONException("Se esperaba un objeto en "+key);
        if(key.equals(STOCK)){
            JSONObject o=(JSONObject)value;if(!(o.opt("items") instanceof JSONArray)||!(o.opt("movements") instanceof JSONArray))throw new JSONException("El almacén no contiene productos y movimientos válidos");
            objectArray(o,"items");objectArray(o,"movements");objectArray(o,"feedArchive");objectArray(o,"feedArchivedLots");
        }
        if(key.equals(BOOK)){
            JSONObject o=(JSONObject)value;if(o.optInt("schema")!=2||!(o.opt("records") instanceof JSONArray))throw new JSONException("Versión de Agenda no compatible");
            objectArray(o,"records");
        }
        if(key.equals(LOTS))for(int i=0;i<((JSONArray)value).length();i++){
            JSONObject lot=((JSONArray)value).getJSONObject(i);objectArray(lot,"history");
            if(lot.has("detailState")&&!lot.isNull("detailState")){
                if(!(lot.get("detailState") instanceof JSONObject))throw new JSONException("Detalle de lote inválido");
                JSONObject detail=lot.getJSONObject("detailState");for(String field:new String[]{"samples","daily","water","volumeHistory"})objectArray(detail,field);
            }
        }
    }
    private static void objectArray(JSONObject object,String field) throws JSONException {
        if(!object.has(field)||object.isNull(field))return;Object v=object.get(field);if(!(v instanceof JSONArray))throw new JSONException("Historial inválido: "+field);
        JSONArray a=(JSONArray)v;for(int i=0;i<a.length();i++)if(!(a.get(i) instanceof JSONObject))throw new JSONException("Registro inválido: "+field);
    }
    public static Encoded encode(String key,String raw) throws JSONException {
        validate(key,raw);Encoded out=new Encoded();out.document.key=key;
        String trimmed=raw.trim();if(!trimmed.startsWith("{")&&!trimmed.startsWith("[")){out.document.template=raw;return out;}
        Object value;
        try {value=parse(raw);out.document.format="json";}
        catch(Exception e){out.document.template=raw;return out;}
        out.document.template=stringify(split(value,key,"","",out.rows));return out;
    }
    private static Object split(Object value,String owner,String path,String lot,List<FarmRecord> rows) throws JSONException {
        if(value instanceof JSONArray){
            JSONArray array=(JSONArray)value;boolean objects=true;
            for(int i=0;i<array.length();i++)if(!(array.get(i) instanceof JSONObject)){objects=false;break;}
            if(!objects)return value;
            Set<String> ids=new HashSet<>();
            for(int i=0;i<array.length();i++){
                JSONObject object=array.getJSONObject(i);
                String id=object.has("id")?String.valueOf(object.get("id")):"legacy-"+i;
                if(id.isEmpty()||!ids.add(id))throw new JSONException("Identificador duplicado en "+owner+path+": "+id);
                String rowLot=owner.equals(LOTS)&&path.isEmpty()?id:object.optString("lotId",lot);
                FarmRecord row=new FarmRecord();row.owner=owner;row.path=path;row.recordId=id;row.position=i;
                row.lotId=rowLot;row.centerId=object.optString("farmId",object.optString("centerId",""));
                row.date=object.optString("date",object.optString("measuredDate",object.optString("d","")));
                row.kind=kind(owner,path);row.json=stringify(split(object,owner,path+"/@"+hash(id).substring(0,20),rowLot,rows));rows.add(row);
            }
            return new JSONObject().put(ROWS,path);
        }
        if(value instanceof JSONObject){
            JSONObject object=(JSONObject)value;if(object.has(ROWS))throw new JSONException("Campo reservado en el respaldo");
            JSONObject result=new JSONObject();Iterator<String> it=object.keys();
            while(it.hasNext()){String key=it.next();result.put(key,split(object.get(key),owner,path+"/"+key.replace("~","~0").replace("/","~1"),lot,rows));}return result;
        }
        return value;
    }
    private static String kind(String owner,String path){
        if(path.endsWith("/daily"))return "daily";
        if(path.endsWith("/samples"))return "samples";
        if(path.endsWith("/history"))return "history";
        if(owner.equals(LOTS)&&path.isEmpty())return "lots";
        if(owner.equals(WATER)&&path.isEmpty())return "water";
        if(owner.equals(FARMS)&&path.isEmpty())return "centers";
        if(owner.equals("activities")&&path.isEmpty())return "tasks";
        if(owner.equals(BOOK)&&path.equals("/records"))return "agenda";
        if(owner.equals(STOCK)&&path.equals("/items"))return "products";
        if(owner.equals(STOCK)&&path.equals("/movements"))return "movements";
        return "nested";
    }
    public static String decode(FarmDocument doc,List<FarmRecord> rows) throws JSONException {
        if(doc.format.equals("text"))return doc.template;
        Map<String,List<FarmRecord>> byPath=new HashMap<>();
        for(FarmRecord r:rows){if(!byPath.containsKey(r.path))byPath.put(r.path,new ArrayList<>());byPath.get(r.path).add(r);}
        for(List<FarmRecord> group:byPath.values())Collections.sort(group,(a,b)->Long.compare(a.position,b.position));
        return stringify(join(new JSONTokener(doc.template).nextValue(),byPath,new HashSet<>()));
    }
    private static Object join(Object value,Map<String,List<FarmRecord>> rows,Set<String> visiting) throws JSONException {
        if(value instanceof JSONObject){
            JSONObject object=(JSONObject)value;
            if(object.has(ROWS)){
                String path=object.getString(ROWS);if(!visiting.add(path))throw new JSONException("Referencia circular");
                JSONArray a=new JSONArray();for(FarmRecord row:(rows.containsKey(path)?rows.get(path):Collections.<FarmRecord>emptyList()))a.put(join(new JSONTokener(row.json).nextValue(),rows,visiting));visiting.remove(path);return a;
            }
            JSONObject result=new JSONObject();Iterator<String> it=object.keys();while(it.hasNext()){String key=it.next();result.put(key,join(object.get(key),rows,visiting));}return result;
        }
        return value;
    }
    public static JSONObject rowJson(FarmRecord r) throws JSONException {
        return new JSONObject().put("owner",r.owner).put("path",r.path).put("recordId",r.recordId).put("kind",r.kind).put("lotId",r.lotId).put("centerId",r.centerId).put("date",r.date).put("position",r.position).put("json",r.json);
    }
    public static FarmRecord rowFrom(JSONObject o) throws JSONException {
        FarmRecord r=new FarmRecord();r.owner=o.getString("owner");r.path=o.getString("path");r.recordId=o.getString("recordId");r.kind=o.getString("kind");r.lotId=o.getString("lotId");r.centerId=o.getString("centerId");r.date=o.getString("date");r.position=o.getLong("position");r.json=o.getString("json");return r;
    }
}
