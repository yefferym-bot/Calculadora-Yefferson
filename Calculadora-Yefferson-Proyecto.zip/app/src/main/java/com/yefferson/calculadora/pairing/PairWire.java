package com.yefferson.calculadora.pairing;

import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLSocket;

/** Bounded frames over mutual TLS. No production-data commands exist in protocol 1. */
public final class PairWire {
    public static final int MAX_FRAME=262144;
    public interface Sender {void send(byte[] data) throws Exception;boolean offer(byte[] data,Runnable completion);}
    private final InputStream input;private final Sender output;private int inboundLimit=MAX_FRAME;
    private final byte[] header=new byte[4];private int headerRead,frameRead;private byte[] frame;private volatile long frameStarted;
    public PairWire(SSLSocket socket) throws Exception {this(socket,null);}
    public PairWire(SSLSocket socket,Sender sender) throws Exception {
        input=socket.getInputStream();
        if(sender!=null)output=sender;else{DataOutputStream stream=new DataOutputStream(socket.getOutputStream());output=new Sender(){
            public synchronized void send(byte[] data) throws Exception {stream.writeInt(data.length);stream.write(data);stream.flush();}
            public boolean offer(byte[] data,Runnable completion){try{send(data);if(completion!=null)completion.run();return true;}catch(Exception e){return false;}}
        };}
    }
    private byte[] encode(JSONObject value) throws Exception {
        byte[] bytes=value.toString().getBytes(StandardCharsets.UTF_8);
        if(bytes.length<2||bytes.length>MAX_FRAME)throw new IOException("Mensaje local demasiado grande");
        return bytes;
    }
    public void send(JSONObject value) throws Exception {output.send(encode(value));}
    public boolean offer(JSONObject value,Runnable completion){try{return output.offer(encode(value),completion);}catch(Exception error){return false;}}
    public void limit(int max){if(max<2||max>MAX_FRAME)throw new IllegalArgumentException();inboundLimit=max;}
    public JSONObject receive() throws Exception {
        while(headerRead<4){deadline();int n=input.read(header,headerRead,4-headerRead);if(n<0)throw new EOFException("El otro equipo cerró la conexión");if(n>0&&frameStarted==0)frameStarted=System.nanoTime();headerRead+=n;}
        if(frame==null){int size=((header[0]&255)<<24)|((header[1]&255)<<16)|((header[2]&255)<<8)|(header[3]&255);if(size<2||size>inboundLimit)throw new IOException("Tamaño de mensaje local inválido");frame=new byte[size];}
        while(frameRead<frame.length){deadline();int n=input.read(frame,frameRead,frame.length-frameRead);if(n<0)throw new EOFException("Mensaje local incompleto");frameRead+=n;}
        byte[] bytes=frame;frame=null;headerRead=frameRead=0;frameStarted=0;
        String text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(bytes)).toString();validateJson(text);return new JSONObject(text);
    }
    /** Reject deep/lenient JSON before Android's recursive parser can exhaust a worker stack. */
    private static void validateJson(String raw) throws IOException {
        String text=raw.trim();if(!text.startsWith("{")||!text.endsWith("}"))throw new IOException("Mensaje local inválido");
        int depth=0;boolean quoted=false,escaped=false,ended=false;
        for(int i=0;i<text.length();i++){
            char c=text.charAt(i);
            if(quoted){if(c<32)throw new IOException("Texto local inválido");if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='\"')quoted=false;continue;}
            if(ended){if(!Character.isWhitespace(c))throw new IOException("Contenido adicional en mensaje local");continue;}
            if(c=='\"'){quoted=true;continue;}
            if(c=='{'||c=='['){if(++depth>12)throw new IOException("Mensaje local demasiado anidado");}
            else if(c=='}'||c==']'){if(--depth<0)throw new IOException("Mensaje local inválido");if(depth==0)ended=true;}
            else if(!Character.isWhitespace(c)&&"0123456789eE+-.truefalsenull:,".indexOf(c)<0)throw new IOException("Sintaxis de mensaje local inválida");
        }
        if(quoted||depth!=0)throw new IOException("Mensaje local incompleto");
    }
    private void deadline() throws IOException {if(frameStarted!=0&&System.nanoTime()-frameStarted>15000000000L)throw new IOException("El mensaje local no se completó a tiempo");}
    public boolean expiredFrame(long now){long started=frameStarted;return started!=0&&now-started>15000000000L;}
    public static String hash(byte[] bytes) throws Exception {return hex(MessageDigest.getInstance("SHA-256").digest(bytes));}
    public static String hash(String text) throws Exception {return hash(text.getBytes(StandardCharsets.UTF_8));}
    public static String fingerprint(X509Certificate cert) throws Exception {return hash(cert.getEncoded());}
    public static String hex(byte[] bytes){StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();}
    public static String commitment(String role,String fingerprint,String nonce) throws Exception {return hash("TruchApp-local-v1|"+role+"|"+fingerprint+"|"+nonce);}
    public static String verification(String admin,String collaborator,String adminNonce,String collaboratorNonce) throws Exception {
        String digest=hash("TruchApp-SAS-v1|"+admin+"|"+collaborator+"|"+adminNonce+"|"+collaboratorNonce);
        String value=String.format(java.util.Locale.ROOT,"%08d",Long.parseLong(digest.substring(0,12),16)%100000000L);
        return value.substring(0,4)+" "+value.substring(4);
    }
    public static JSONObject message(String type) throws Exception {return new JSONObject().put("type",type);}
    public static void expect(JSONObject value,String type) throws IOException {if(!type.equals(value.optString("type")))throw new IOException("Respuesta local inesperada");}
}
