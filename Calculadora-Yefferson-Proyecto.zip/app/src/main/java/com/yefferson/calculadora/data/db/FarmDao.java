package com.yefferson.calculadora.data.db;
import androidx.room.*;
import java.util.List;

@Dao
public interface FarmDao {
    @Query("SELECT * FROM farm_documents ORDER BY `key`") List<FarmDocument> documents();
    @Query("SELECT * FROM farm_documents WHERE `key`=:key") FarmDocument document(String key);
    @Insert(onConflict=OnConflictStrategy.REPLACE) void document(FarmDocument document);
    @Query("DELETE FROM farm_documents WHERE `key`=:key") void deleteDocument(String key);
    @Query("SELECT * FROM farm_records WHERE owner=:owner ORDER BY path,position") List<FarmRecord> records(String owner);
    @Query("SELECT * FROM farm_records WHERE owner=:owner AND path=:path AND recordId=:id") FarmRecord record(String owner,String path,String id);
    @Query("SELECT * FROM farm_records ORDER BY owner,path,position") List<FarmRecord> allRecords();
    @Query("SELECT * FROM farm_records WHERE owner=:owner AND path LIKE :prefix ORDER BY path,position") List<FarmRecord> nested(String owner,String prefix);
    @Insert(onConflict=OnConflictStrategy.REPLACE) void record(FarmRecord record);
    @Insert(onConflict=OnConflictStrategy.ABORT) void importRecord(FarmRecord record);
    @Query("DELETE FROM farm_records WHERE owner=:owner AND path=:path AND recordId=:id") void deleteRecord(String owner,String path,String id);
    @Query("DELETE FROM farm_records WHERE owner=:owner") void deleteOwner(String owner);
    @Query("SELECT * FROM farm_records WHERE kind=:kind AND lotId=:lot AND date>=:start AND date<=:end ORDER BY date DESC,position ASC LIMIT :limit OFFSET :offset")
    List<FarmRecord> pageLot(String kind,String lot,String start,String end,int limit,int offset);
    @Query("SELECT * FROM farm_records WHERE kind=:kind AND date>=:start AND date<=:end ORDER BY date DESC,position ASC LIMIT :limit OFFSET :offset")
    List<FarmRecord> pageAll(String kind,String start,String end,int limit,int offset);
    @Query("SELECT COUNT(*) FROM farm_records WHERE kind=:kind AND lotId=:lot AND date>=:start AND date<=:end") long countLotRange(String kind,String lot,String start,String end);
    @Query("SELECT COUNT(*) FROM farm_records WHERE kind=:kind AND date>=:start AND date<=:end") long countRange(String kind,String start,String end);
    @Query("SELECT COUNT(*) FROM farm_records WHERE kind=:kind AND (:lot='' OR lotId=:lot)") long count(String kind,String lot);
    @Query("SELECT * FROM farm_audit WHERE operationId=:id") FarmAudit receipt(String id);
    @Insert(onConflict=OnConflictStrategy.ABORT) void audit(FarmAudit operation);
    @Query("UPDATE farm_audit SET undone=1 WHERE operationId=:id") void markUndone(String id);
    @Query("SELECT * FROM farm_audit WHERE undone=0 AND label!='Preferencias' AND operationId!='migration-1' ORDER BY createdAt DESC LIMIT 30") List<FarmAudit> recent();
    @Query("DELETE FROM farm_audit WHERE createdAt<:cutoff") void pruneAudit(long cutoff);
}
