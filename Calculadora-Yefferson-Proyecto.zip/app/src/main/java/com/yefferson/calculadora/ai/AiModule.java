package com.yefferson.calculadora.ai;

import android.content.Context;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Public AI facade used by the Activity. Keeps model/native concerns inside the AI module. */
public final class AiModule implements AiNativeController {
    // AI-only tuning: keep replies fast on mobile and disable Qwen3 reasoning for normal chat.
    private static final int DEFAULT_MAX_GENERATION_TOKENS = 192;
    public interface Listener {
        void onStateChanged();
        void onResponse(String requestId, String response);
    }

    private final ExecutorService executor;
    private final Listener listener;
    private final AtomicBoolean initialized = new AtomicBoolean(false);
    private final AiModelManager models;

    public AiModule(Context context, Listener listener) {
        this.executor = Executors.newFixedThreadPool(2);
        this.listener = listener;
        this.models = new AiModelManager(context, executor, listener::onStateChanged);
    }

    public void initialize() {
        if (!initialized.compareAndSet(false, true)) return;
        executor.execute(() -> {
            try {
                AiNative.init();
                if (models.hasUsableModel()) {
                    models.setLoadingStatus("Cargando IA local…");
                    boolean ok = loadModel(models.getModelFile().getAbsolutePath(), models.getModelContext(), models.getModelThreads());
                    if (ok) models.setLoadingStatus("IA local lista");
                    else models.setLoadingStatus("Error al cargar IA");
                } else {
                    models.setLoadingStatus("Modelo no descargado");
                }
            } catch (Throwable t) {
                models.setLoadingStatus("Error al iniciar IA");
            }
            listener.onStateChanged();
        });
    }

    public void downloadModel() {
        models.download(this);
    }

    public String getStateJson() {
        return models.toJson(this);
    }

    public void ask(String system, String user, int maxTokens, String requestId) {
        executor.execute(() -> {
            String result;
            try {
                if (!isReady()) {
                    result = "La IA local aún no está lista. Abre la pestaña IA y descarga el modelo primero.";
                } else {
                    String safeSystem = system == null ? "" : system;
                    String safeUser = user == null ? "" : user;
                    // Qwen3 supports /no_think in the user message. Putting it at the end
                    // is especially useful for small local models because it prevents the
                    // long hidden-reasoning block that would otherwise consume generation time.
                    if (!safeUser.contains("/no_think")) {
                        safeUser = safeUser + "\n/no_think";
                    }
                    int requested = maxTokens > 0 ? maxTokens : DEFAULT_MAX_GENERATION_TOKENS;
                    int capped = Math.min(Math.max(64, requested), DEFAULT_MAX_GENERATION_TOKENS);
                    result = AiNative.generate(safeSystem, safeUser, capped);
                    result = cleanResponse(result);
                }
            } catch (Throwable t) {
                result = "La IA local encontró un error al generar la respuesta.";
            }
            listener.onResponse(requestId, result == null ? "" : result);
        });
    }

    /** Removes Qwen-style visible reasoning tags if a model ignores /no_think. */
    private static String cleanResponse(String text) {
        if (text == null) return "";
        String result = text.trim();
        if (result.startsWith("ERROR: ")) return result.substring(7).trim();

        int open = result.indexOf("<think>");
        int close = result.indexOf("</think>");
        if (open >= 0 && close >= open) {
            result = result.substring(close + "</think>".length()).trim();
        } else if (open >= 0) {
            // Never expose an unfinished reasoning block to the user.
            result = result.substring(0, open).trim();
        } else if (close >= 0) {
            result = result.substring(close + "</think>".length()).trim();
        }
        return result;
    }

    @Override
    public boolean isReady() {
        try {
            return AiNative.isReady();
        } catch (Throwable ignored) {
            return false;
        }
    }

    @Override
    public boolean loadModel(String path, int contextSize, int threads) {
        try {
            return AiNative.loadModel(path, contextSize, threads);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public void release() {
        try {
            executor.execute(() -> {
                try { AiNative.release(); } catch (Throwable ignored) { }
            });
        } catch (Throwable ignored) {
            try { AiNative.release(); } catch (Throwable ignoredAgain) { }
        }
        executor.shutdown();
    }
}
