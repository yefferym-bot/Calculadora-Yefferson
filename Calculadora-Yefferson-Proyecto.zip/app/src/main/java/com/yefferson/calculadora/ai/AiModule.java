package com.yefferson.calculadora.ai;

import android.content.Context;

import com.yefferson.calculadora.ai.knowledge.KnowledgeManager;

import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Public AI facade. Conversation, model and native inference stay inside the AI module. */
public final class AiModule implements AiNativeController {
    private static final int FAST_MAX_TOKENS = 192;
    private static final int THINK_MAX_TOKENS = 320;
    private static final int CACHE_ENTRIES = 8;

    public interface Listener {
        void onStateChanged();
        void onResponse(String requestId, String response);
    }

    private final ExecutorService executor;
    private final Listener listener;
    private final AtomicBoolean initialized = new AtomicBoolean(false);
    private final AiModelManager models;
    private final AiConversationManager conversation = new AiConversationManager();
    private final KnowledgeManager knowledge;

    // Exact-repeat cache: a repeated prompt can be answered instantly without another
    // full inference. The key includes the current local context assembled by the UI.
    private final Map<String, String> responseCache = new LinkedHashMap<String, String>(CACHE_ENTRIES, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
            return size() > CACHE_ENTRIES;
        }
    };

    public AiModule(Context context, Listener listener) {
        // Native inference is serialized deliberately; llama.cpp keeps one model/context.
        this.executor = Executors.newSingleThreadExecutor();
        this.listener = listener;
        this.models = new AiModelManager(context, executor, listener::onStateChanged);
        this.knowledge = new KnowledgeManager(context);
    }

    public void initialize() {
        if (!initialized.compareAndSet(false, true)) return;
        executor.execute(() -> {
            try {
                knowledge.load();
                AiNative.init();
                if (models.hasUsableModel()) {
                    models.setLoadingStatus("Cargando IA local…");
                    boolean ok = loadModel(models.getModelFile().getAbsolutePath(), models.getModelContext(), models.getModelThreads());
                    if (ok) models.setLoadingStatus("IA local lista");
                    else models.setLoadingStatus("Error al cargar IA");
                } else {
                    models.setLoadingStatus("Modelo no descargado");
                }
            } catch (Throwable t) {
                models.setLoadingStatus("Error al iniciar IA");
            }
            listener.onStateChanged();
        });
    }

    public void downloadModel() {
        models.download(this);
    }

    public String getStateJson() {
        try {
            JSONObject state = new JSONObject(models.toJson(this));
            state.put("ykb", new JSONObject(knowledge.getStateJson()));
            return state.toString();
        } catch (Exception ignored) {
            return models.toJson(this);
        }
    }

    public String getKnowledgeStateJson() {
        return knowledge.getStateJson();
    }

    /** Fast local search used by IA2; it does not run neural inference. */
    public String searchKnowledgeJson(String query, int limit) {
        return knowledge.searchJson(query, limit);
    }

    public void ask(String system, String user, int maxTokens, String requestId) {
        executor.execute(() -> {
            String result;
            try {
                if (!isReady()) {
                    result = "La IA local aún no está lista. Abre la pestaña IA y descarga el modelo primero.";
                } else {
                    String safeSystem = system == null ? "" : system;
                    String safeUser = user == null ? "" : user.trim();
                    if (safeUser.isEmpty()) {
                        listener.onResponse(requestId, "");
                        return;
                    }

                    final String questionOnly = extractQuestion(safeUser);
                    final String ykbContext = knowledge.searchContext(questionOnly, 3);
                    final String augmentedUser = appendKnowledgeContext(safeUser, ykbContext);
                    final boolean thinking = shouldThink(augmentedUser);
                    final String effectiveUser = thinking ? augmentedUser : ensureNoThink(augmentedUser);
                    final String effectiveSystem = safeSystem + "\n\n[REGLAS_YKB] Si se proporciona contexto [YKB], úsalo como fuente técnica prioritaria. No inventes datos, dosis, límites o diagnósticos que no estén sustentados por el contexto. Conserva la advertencia y el nivel de evidencia de las fuentes. [/REGLAS_YKB]";
                    final String cacheKey = normalizeForCache(effectiveSystem + "\n" + effectiveUser);
                    String cached;
                    synchronized (responseCache) {
                        cached = responseCache.get(cacheKey);
                    }
                    if (cached != null) {
                        conversation.addUserAndSnapshot(effectiveUser);
                        conversation.addAssistant(cached);
                        // The native context was not advanced by this cache hit, so force a
                        // safe rebuild before the next non-cached generation.
                        try { AiNative.clearConversation(); } catch (Throwable ignored) { }
                        listener.onResponse(requestId, cached);
                        return;
                    }

                    AiConversationManager.MessageBatch batch = conversation.addUserAndSnapshot(effectiveUser);
                    int requested = maxTokens > 0 ? maxTokens : FAST_MAX_TOKENS;
                    int capped = thinking
                            ? Math.min(Math.max(96, requested), THINK_MAX_TOKENS)
                            : Math.min(Math.max(64, requested), FAST_MAX_TOKENS);

                    String rawResult = AiNative.generateConversation(
                            effectiveSystem,
                            batch.roles,
                            batch.contents,
                            capped,
                            thinking);
                    boolean nativeError = rawResult != null && rawResult.startsWith("ERROR:");
                    result = cleanResponse(rawResult);
                    if (nativeError || result.startsWith("La IA local encontró")) {
                        conversation.rollbackLastUser();
                    } else {
                        conversation.addAssistant(result);
                        synchronized (responseCache) {
                            responseCache.put(cacheKey, result);
                        }
                    }
                }
            } catch (Throwable t) {
                conversation.rollbackLastUser();
                result = "La IA local encontró un error al generar la respuesta.";
            }
            listener.onResponse(requestId, result == null ? "" : result);
        });
    }

    /** Clears only the live AI conversation; persistent personal memory is handled elsewhere. */
    public void clearConversation() {
        executor.execute(() -> {
            conversation.clear();
            synchronized (responseCache) { responseCache.clear(); }
            try { AiNative.clearConversation(); } catch (Throwable ignored) { }
        });
    }


    private static String extractQuestion(String user) {
        if (user == null) return "";
        int marker = user.indexOf("[CONTEXTO_LOCAL]");
        if (marker >= 0) return user.substring(0, marker).trim();
        return user.trim();
    }

    private static String appendKnowledgeContext(String user, String context) {
        if (context == null || context.trim().isEmpty()) return user;
        return user + "\n\n[BIBLIOTECA_YKB]\n" + context.trim() + "\n[/BIBLIOTECA_YKB]";
    }

    private static String ensureNoThink(String user) {
        return user.contains("/no_think") ? user : user + "\n/no_think";
    }

    /**
     * Qwen3 is allowed to think only for questions that benefit from deeper reasoning.
     * Normal greetings and short factual requests remain in fast non-thinking mode.
     */
    private static boolean shouldThink(String user) {
        String q = user;
        int marker = q.indexOf("[CONTEXTO_LOCAL]");
        if (marker >= 0) q = q.substring(0, marker);
        q = q.toLowerCase(Locale.ROOT).trim();
        int words = q.isEmpty() ? 0 : q.split("\\s+").length;
        return words >= 18 || q.matches(".*\\b(por qué|por que|porque|explica las causas|explica las diferencias|explica|explicar|analiza|analizar|análisis|analisis|compara|comparar|evalua|evalúa|diagnostica|diagnóstico|prioriza|priorizar|optimiza|optimizar|interpreta resultados|interpretar resultados|teniendo en cuenta|considerando|con base en|a partir de estos datos|segun los datos|según los datos|en funcion de|en función de|relacion entre|relación entre|varios factores|causas posibles|estima y justifica|plan de accion|plan de acción|plan|paso a paso|razona|razonar|diseña|diseñar|calcula detalladamente|justifica|justificar|estrategia)\\b.*");
    }

    private static String normalizeForCache(String text) {
        return text == null ? "" : text.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    /** Removes visible Qwen-style reasoning tags if the model emits them. */
    private static String cleanResponse(String text) {
        if (text == null) return "";
        String result = text.trim();
        if (result.startsWith("ERROR: ")) return result.substring(7).trim();
        int open = result.indexOf("<think>");
        int close = result.indexOf("</think>");
        if (open >= 0 && close >= open) {
            result = result.substring(close + "</think>".length()).trim();
        } else if (open >= 0) {
            result = result.substring(0, open).trim();
        } else if (close >= 0) {
            result = result.substring(close + "</think>".length()).trim();
        }
        return result;
    }

    @Override public boolean isReady() {
        try { return AiNative.isReady(); } catch (Throwable ignored) { return false; }
    }

    @Override public boolean loadModel(String path, int contextSize, int threads) {
        try {
            conversation.clear();
            synchronized (responseCache) { responseCache.clear(); }
            return AiNative.loadModel(path, contextSize, threads);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public void release() {
        try {
            executor.execute(() -> {
                try { AiNative.release(); } catch (Throwable ignored) { }
                conversation.clear();
            });
        } catch (Throwable ignored) {
            try { AiNative.release(); } catch (Throwable ignoredAgain) { }
        }
        executor.shutdown();
    }
}
