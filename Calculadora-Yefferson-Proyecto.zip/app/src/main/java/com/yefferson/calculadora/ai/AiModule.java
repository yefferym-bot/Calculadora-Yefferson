package com.yefferson.calculadora.ai;

import android.content.Context;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Public AI facade used by the Activity. Keeps model/native concerns inside the AI module. */
public final class AiModule implements AiNativeController {
    public interface Listener {
        void onStateChanged();
        void onResponse(String requestId, String response);
    }

    private final ExecutorService executor;
    private final Listener listener;
    private final AtomicBoolean initialized = new AtomicBoolean(false);
    private final AiModelManager models;

    public AiModule(Context context, Listener listener) {
        this.executor = Executors.newFixedThreadPool(2);
        this.listener = listener;
        this.models = new AiModelManager(context, executor, listener::onStateChanged);
    }

    public void initialize() {
        if (!initialized.compareAndSet(false, true)) return;
        executor.execute(() -> {
            try {
                AiNative.init();
                if (models.hasUsableModel()) {
                    models.setLoadingStatus("Cargando IA local…");
                    boolean ok = loadModel(models.getModelFile().getAbsolutePath(), models.getModelContext(), models.getModelThreads());
                    if (ok) models.setLoadingStatus("IA local lista");
                    else models.setLoadingStatus("Error al cargar IA");
                } else {
                    models.setLoadingStatus("Modelo no descargado");
                }
            } catch (Throwable t) {
                models.setLoadingStatus("Error al iniciar IA");
            }
            listener.onStateChanged();
        });
    }

    public void downloadModel() {
        models.download(this);
    }

    public String getStateJson() {
        return models.toJson(this);
    }

    public void ask(String system, String user, int maxTokens, String requestId) {
        executor.execute(() -> {
            String result;
            try {
                if (!isReady()) {
                    result = "La IA local aún no está lista. Abre la pestaña IA y descarga el modelo primero.";
                } else {
                    result = AiNative.generate(system == null ? "" : system,
                            user == null ? "" : user,
                            Math.max(64, maxTokens));
                    if (result != null && result.startsWith("ERROR: ")) result = result.substring(7);
                }
            } catch (Throwable t) {
                result = "La IA local encontró un error al generar la respuesta.";
            }
            listener.onResponse(requestId, result == null ? "" : result);
        });
    }

    @Override
    public boolean isReady() {
        try {
            return AiNative.isReady();
        } catch (Throwable ignored) {
            return false;
        }
    }

    @Override
    public boolean loadModel(String path, int contextSize, int threads) {
        try {
            return AiNative.loadModel(path, contextSize, threads);
        } catch (Throwable ignored) {
            return false;
        }
    }

    public void release() {
        try {
            executor.execute(() -> {
                try { AiNative.release(); } catch (Throwable ignored) { }
            });
        } catch (Throwable ignored) {
            try { AiNative.release(); } catch (Throwable ignoredAgain) { }
        }
        executor.shutdown();
    }
}
