package com.yefferson.calculadora.pairing;

import android.content.Context;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Durable per-administrator cache/outbox, isolated from the collaborator's private farm. */
public final class PairShared {
    public interface Source {JSONObject read(String lot) throws Exception;JSONObject apply(String peer,String op,JSONObject request) throws Exception;JSONArray list(JSONArray ids) throws Exception;}
    private final File dir;private long lastCreated;private final Map<String,Transfer> transfers=new HashMap<>();
    private static final class Transfer {String lot,ticket,hash,op;int length;long until;String data;StringBuilder input;}
    public PairShared(Context context){dir=new File(context.getFilesDir(),"pair-production-v1");}
    private File file(String prefix,String owner,String id) throws Exception {PairRecords.fingerprint(owner);if(!dir.exists()&&!dir.mkdirs())throw new IOException("No se pudo abrir la carpeta de registros compartidos");return new File(dir,prefix+"-"+owner+"-"+PairWire.hash(id)+".json");}
    private static JSONObject read(File file) throws Exception {if(!file.exists()&&!new File(file.getPath()+".bak").exists())return null;try(InputStream in=new AtomicFile(file).openRead()){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>=0){if(out.size()+n>PairProduction.MAX_DOCUMENT+65536)throw new IOException("Documento compartido demasiado grande");out.write(b,0,n);}return new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));}}
    private static void write(File file,JSONObject value) throws Exception {byte[] bytes=value.toString().getBytes(StandardCharsets.UTF_8);if(bytes.length>PairProduction.MAX_DOCUMENT+65536)throw new IOException("El lote supera el tamaño de transferencia local");AtomicFile atomic=new AtomicFile(file);FileOutputStream out=null;try{out=atomic.startWrite();out.write(bytes);atomic.finishWrite(out);}catch(Exception e){if(out!=null)atomic.failWrite(out);throw e;}}
    private static String body(JSONObject value) throws Exception {String text=PairProduction.canonical(value);if(text.getBytes(StandardCharsets.UTF_8).length>PairProduction.MAX_DOCUMENT)throw new IOException("El historial supera 3 MB. Conserva los datos y revisa el lote desde el administrador");return text;}
    public synchronized JSONObject server(String peer,String method,JSONObject args,Source source,JSONArray allowed) throws Exception {
        long now=System.currentTimeMillis();transfers.entrySet().removeIf(e->e.getValue().until<now);
        if("list".equals(method))return new JSONObject().put("lots",source.list(allowed));
        String lot=args.getString("lotId");if("read".equals(method)){String text=body(source.read(lot));Transfer t=new Transfer();t.lot=lot;t.ticket=UUID.randomUUID().toString();t.hash=PairWire.hash(text);t.data=text;t.length=text.length();t.until=now+120000;reserve(peer,t);return metadata(t);}
        if("begin".equals(method)){Transfer t=new Transfer();t.lot=lot;t.ticket=args.getString("ticket");t.op=args.getString("operation");t.hash=args.getString("hash");t.length=args.getInt("length");t.input=new StringBuilder();t.until=now+120000;if(!t.ticket.matches("[a-zA-Z0-9-]{20,80}")||!t.op.matches("[a-zA-Z0-9-]{20,80}")||!t.hash.matches("[0-9a-f]{64}")||t.length<2||t.length>PairProduction.MAX_DOCUMENT)throw new IOException("Envío compartido no válido");reserve(peer,t);return metadata(t);}
        Transfer t=transfers.get(peer);if(t==null||!t.lot.equals(lot)||!t.ticket.equals(args.optString("ticket")))throw new IOException("El envío venció; se reintentará sin duplicar registros");t.until=now+120000;
        if("part".equals(method)&&t.data!=null){int offset=args.getInt("offset");if(offset<0||offset>t.length)throw new IOException("Posición de lectura inválida");int end=Math.min(t.length,offset+PairProduction.CHUNK);if(end<t.length&&Character.isHighSurrogate(t.data.charAt(end-1)))end--;return new JSONObject().put("text",t.data.substring(offset,end)).put("offset",offset);}
        if("chunk".equals(method)&&t.input!=null){String text=args.getString("text");if(text.length()>PairProduction.CHUNK||args.getInt("offset")!=t.input.length()||t.input.length()+text.length()>t.length)throw new IOException("Fragmento compartido no válido");t.input.append(text);return new JSONObject().put("offset",t.input.length());}
        if("commit".equals(method)&&t.input!=null){String text=t.input.toString();if(text.getBytes(StandardCharsets.UTF_8).length>PairProduction.MAX_DOCUMENT||text.length()!=t.length||!PairWire.hash(text).equals(t.hash))throw new IOException("El envío no está completo o cambió");PairWire.validateDocument(text,24);JSONObject request=new JSONObject(text);if(!lot.equals(request.optString("lotId")))throw new IOException("El envío corresponde a otro lote");JSONObject result=source.apply(peer,t.op,request);transfers.remove(peer);return result;}
        throw new IOException("Acción compartida no reconocida");
    }
    private void reserve(String peer,Transfer t) throws Exception {int total=t.length;for(Map.Entry<String,Transfer> e:transfers.entrySet())if(!e.getKey().equals(peer))total+=e.getValue().length;if(total>12*1024*1024)throw new IOException("BUSY: Hay otros equipos transfiriendo historiales grandes. Vuelve a intentar en un momento");transfers.put(peer,t);}
    private static JSONObject metadata(Transfer t) throws Exception {return new JSONObject().put("ticket",t.ticket).put("hash",t.hash).put("length",t.length);}
    public synchronized void ended(String peer){transfers.remove(peer);}
    public JSONObject cached(String owner,String lot) throws Exception {JSONObject cache=read(file("cache",owner,lot));for(Map.Entry<File,JSONObject> e:jobs(owner))if(lot.equals(e.getValue().optString("lotId"))){JSONObject document=e.getValue().getJSONObject("request").getJSONObject("document");cache=new JSONObject().put("document",document).put("hash",PairProduction.hash(document)).put("updated",e.getValue().optLong("created")).put("pending",true);}if(cache==null)throw new IOException("Conecta al administrador para descargar este lote por primera vez");return cache;}
    private JSONObject cache(String owner,String lot,JSONObject document,boolean pending) throws Exception {JSONObject result=new JSONObject().put("document",document).put("hash",PairProduction.hash(document)).put("updated",System.currentTimeMillis()).put("pending",pending);write(file("cache",owner,lot),result);return result;}
    public JSONObject fetch(PairSession session,String lot) throws Exception {
        if(hasPending(session.peer,lot))return cached(session.peer,lot);
        JSONObject args=new JSONObject().put("lotId",lot),meta=session.call("read",args);int length=meta.getInt("length");if(length<2||length>PairProduction.MAX_DOCUMENT)throw new IOException("Tamaño de lote compartido no válido");StringBuilder text=new StringBuilder();
        while(text.length()<length){JSONObject part=session.call("part",new JSONObject().put("lotId",lot).put("ticket",meta.getString("ticket")).put("offset",text.length()));String chunk=part.getString("text");if(part.getInt("offset")!=text.length()||chunk.isEmpty()||chunk.length()>PairProduction.CHUNK||text.length()+chunk.length()>length)throw new IOException("La ficha no se recibió completa");text.append(chunk);}
        if(!PairWire.hash(text.toString()).equals(meta.getString("hash")))throw new IOException("La ficha recibida no coincide con su versión");PairWire.validateDocument(text.toString(),24);return cache(session.peer,lot,new JSONObject(text.toString()),false);
    }
    public JSONObject stage(String owner,String lot,String expected,JSONObject document) throws Exception {
        JSONObject before=cached(owner,lot);if(!before.getString("hash").equals(expected))throw new IOException("La copia local cambió. Vuelve a abrir la ficha");
        PairProduction.validate(before.getJSONObject("document"),document);String operation=UUID.randomUUID().toString();JSONObject request=new JSONObject().put("lotId",lot).put("baseHash",expected).put("document",document);body(request);
        long total=0;int count=0;for(File f:queue()){total+=f.length();count++;JSONObject saved=read(f);if(saved!=null)lastCreated=Math.max(lastCreated,saved.optLong("created"));}if(count>=100||total+request.toString().length()*2L>24*1024*1024)throw new IOException("La cola local está llena. Conecta al administrador antes de añadir registros");
        long created=Math.max(System.currentTimeMillis(),lastCreated+1);lastCreated=created;JSONObject job=new JSONObject().put("owner",owner).put("lotId",lot).put("operation",operation).put("created",created).put("request",request).put("error","");
        // Queue first: an interrupted cache update can be reconstructed from the durable queue.
        write(file("out",owner,System.currentTimeMillis()+"-"+operation),job);return cache(owner,lot,document,true);
    }
    public JSONObject index(String owner,JSONArray lots) throws Exception {File f=file("index",owner,"index");if(lots!=null)write(f,new JSONObject().put("lots",lots).put("updated",System.currentTimeMillis()));JSONObject v=read(f);return v==null?new JSONObject().put("lots",new JSONArray()):v;}
    public synchronized JSONObject local(String owner,String method,JSONObject args) throws Exception {
        // WebView's own IPC is in-process; hash the assembled body natively, including on older WebViews.
        if("begin".equals(method))args.put("hash",new String(new char[64]).replace('\0','0'));
        if("commit".equals(method)){Transfer t=transfers.get(owner);if(t!=null&&t.input!=null)t.hash=PairWire.hash(t.input.toString());}
        return server(owner,method,args,new Source(){public JSONObject read(String id)throws Exception{return cached(owner,id);}public JSONArray list(JSONArray ids){return new JSONArray();}public JSONObject apply(String peer,String op,JSONObject request)throws Exception{return stage(owner,request.getString("lotId"),request.getString("baseHash"),request.getJSONObject("document"));}},new JSONArray());
    }
    private File[] queue(){File[] files=dir.listFiles(f->f.getName().startsWith("out-")&&(f.getName().endsWith(".json")||f.getName().endsWith(".json.bak")));if(files==null)return new File[0];java.util.SortedMap<String,File> bases=new java.util.TreeMap<>();for(File f:files){String name=f.getName().replaceAll("\\.bak$", "");bases.put(name,new File(dir,name));}return bases.values().toArray(new File[0]);}
    private List<Map.Entry<File,JSONObject>> jobs(String owner) throws Exception {List<Map.Entry<File,JSONObject>> jobs=new ArrayList<>();for(File f:queue()){JSONObject j=read(f);if(j!=null&&owner.equals(j.optString("owner")))jobs.add(new AbstractMap.SimpleEntry<>(f,j));}jobs.sort(Comparator.comparingLong(e->e.getValue().optLong("created")));return jobs;}
    public boolean hasPending(String owner,String lot) throws Exception {for(Map.Entry<File,JSONObject> e:jobs(owner))if(lot.equals(e.getValue().optString("lotId")))return true;return false;}
    public JSONObject status(String owner) throws Exception {JSONArray pending=new JSONArray();for(Map.Entry<File,JSONObject> e:jobs(owner)){JSONObject j=e.getValue();pending.put(new JSONObject().put("lotId",j.optString("lotId")).put("operation",j.optString("operation")).put("created",j.optLong("created")).put("error",j.optString("error")));}return new JSONObject().put("pending",pending);}
    public void flush(PairSession session,java.util.function.Predicate<String> writable) throws Exception {
        Set<String> blocked=new HashSet<>();for(Map.Entry<File,JSONObject> e:jobs(session.peer)){JSONObject job=e.getValue();String lot=job.getString("lotId");if(blocked.contains(lot))continue;
            if(!job.optString("error").isEmpty()){blocked.add(lot);continue;}
            if(!writable.test(lot)){job.put("error","Acceso retirado o solo consulta. El borrador se conserva.");write(e.getKey(),job);blocked.add(lot);continue;}
            try{if(System.currentTimeMillis()-job.getLong("created")>7L*86400000L)throw new IOException("El envío tiene más de siete días. Revisa el borrador antes de volver a registrarlo");
                String text=body(job.getJSONObject("request")),ticket=UUID.randomUUID().toString();session.call("begin",new JSONObject().put("lotId",lot).put("operation",job.getString("operation")).put("ticket",ticket).put("hash",PairWire.hash(text)).put("length",text.length()));
                for(int offset=0;offset<text.length();){int end=Math.min(text.length(),offset+PairProduction.CHUNK);if(end<text.length()&&Character.isHighSurrogate(text.charAt(end-1)))end--;JSONObject sent=session.call("chunk",new JSONObject().put("lotId",lot).put("ticket",ticket).put("offset",offset).put("text",text.substring(offset,end)));if(sent.getInt("offset")!=end)throw new IOException("El administrador no confirmó el fragmento");offset=end;}
                session.call("commit",new JSONObject().put("lotId",lot).put("ticket",ticket));new AtomicFile(e.getKey()).delete();
                if(!hasPending(session.peer,lot))cache(session.peer,lot,job.getJSONObject("request").getJSONObject("document"),false);
            }catch(Exception error){if(error instanceof PairSession.DataRejected&&!error.getMessage().startsWith("BUSY:")||error.getMessage()!=null&&(error.getMessage().startsWith("CONFLICT:")||error.getMessage().contains("siete días")||error.getMessage().contains("Acceso")||error.getMessage().contains("permiso"))){job.put("error",PairRecords.text(error.getMessage(),500));write(e.getKey(),job);blocked.add(lot);}else throw error;}
        }
    }
    /** Explicit user reset archives the draft and pending jobs before loading the current version. */
    public void archive(String owner,String lot) throws Exception {JSONObject draft=cached(owner,lot);write(file("archive",owner,lot),draft);for(Map.Entry<File,JSONObject> e:jobs(owner))if(lot.equals(e.getValue().optString("lotId"))){File to=new File(dir,"archived-"+e.getKey().getName());if(!e.getKey().renameTo(to))throw new IOException("No se pudo conservar el borrador anterior");}new AtomicFile(file("cache",owner,lot)).delete();}
    public JSONObject archived(String owner,String lot) throws Exception {JSONObject v=read(file("archive",owner,lot));if(v==null)throw new IOException("No hay un borrador anterior para este lote");return v;}
}
