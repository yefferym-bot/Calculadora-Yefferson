package com.yefferson.calculadora.pairing;
/** Private scanner Activity. Camera lifecycle and decoding are owned by ZXing. */
public final class PairQrCaptureActivity extends com.journeyapps.barcodescanner.CaptureActivity {}
