package com.yefferson.calculadora.data.db;
import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName="farm_documents")
public class FarmDocument {
    @PrimaryKey @NonNull public String key="";
    @NonNull public String template="", format="text";
}
