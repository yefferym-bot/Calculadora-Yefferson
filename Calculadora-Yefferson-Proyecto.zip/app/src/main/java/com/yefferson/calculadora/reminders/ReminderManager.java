package com.yefferson.calculadora.reminders;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;

import com.yefferson.calculadora.ReminderReceiver;
import com.yefferson.calculadora.data.LocalStore;

import org.json.JSONArray;
import org.json.JSONObject;

/** Reminder/notification boundary. */
public final class ReminderManager {
    private static final String CHANNEL_ID = "yefferson_reminders";
    private final Context context;
    private final LocalStore store;

    public ReminderManager(Context context, LocalStore store) {
        this.context = context.getApplicationContext();
        this.store = store;
        createNotificationChannel();
    }

    public void requestNotificationPermission(android.app.Activity activity) {
        if (Build.VERSION.SDK_INT >= 33 &&
                activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
    }

    public void saveReminder(long id, String title, long whenMillis) {
        try {
            JSONArray arr = new JSONArray(store.getReminders());
            JSONObject x = new JSONObject();
            x.put("id", id);
            x.put("title", title);
            x.put("when", whenMillis);
            arr.put(x);
            store.saveReminders(arr.toString());
        } catch (Exception ignored) {
        }
        scheduleReminder(id, title, whenMillis);
    }

    public void scheduleReminder(long id, String title, long whenMillis) {
        if (whenMillis <= System.currentTimeMillis()) return;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, (int) id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi);
    }


    public void restoreScheduledReminders() {
        try {
            JSONArray arr = new JSONArray(store.getReminders());
            for (int i = 0; i < arr.length(); i++) {
                JSONObject x = arr.getJSONObject(i);
                long when = x.optLong("when", 0L);
                long id = x.optLong("id", i + 1L);
                if (when <= System.currentTimeMillis()) continue;
                scheduleReminder(id, x.optString("title", "Actividad programada"), when);
            }
        } catch (Exception ignored) {
        }
    }

    public Intent notificationSettingsIntent() {
        Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
        intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
        return intent;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    "Recordatorios Yefferson",
                    NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Avisos de actividades programadas");
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
}
