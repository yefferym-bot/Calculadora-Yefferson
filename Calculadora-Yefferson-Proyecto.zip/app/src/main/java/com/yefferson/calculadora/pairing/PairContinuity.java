package com.yefferson.calculadora.pairing;

import java.io.IOException;
import java.net.*;
import javax.net.ServerSocketFactory;

/** Connection policy independent of Activity lifecycle; clocks are monotonic. */
public final class PairContinuity {
    public static final int DEFAULT_PORT=55000;
    private String fingerprint="";private boolean enabled;private int failures;private long next;
    public synchronized void arm(String pin){if(pin==null||!pin.matches("[0-9a-f]{64}"))throw new IllegalArgumentException("Identidad inválida");fingerprint=pin;enabled=true;failures=0;next=0;}
    public synchronized void stop(){enabled=false;fingerprint="";failures=0;next=0;}
    public synchronized String pin(){return enabled?fingerprint:"";}
    public synchronized boolean accepts(String peer){return enabled&&fingerprint.equals(peer);}
    public synchronized boolean due(long now){return enabled&&now>=next;}
    public synchronized long remaining(long now){return enabled?Math.max(0,(next-now+999999L)/1000000L):0;}
    public synchronized void failed(long now,double random){if(!enabled)return;failures=Math.min(5,failures+1);long maximum=Math.min(30000,1000L<<failures);next=now+(long)(maximum*(0.5+Math.max(0,Math.min(1,random))*0.5))*1000000L;}
    public synchronized void connected(){failures=0;next=0;}
    public synchronized void networkChanged(long now,double random){if(enabled)next=now+(long)(500+2500*Math.max(0,Math.min(1,random)))*1000000L;}
    /** Reuse the selected port. A conflict falls back once and the caller remembers the new port. */
    public static java.net.ServerSocket bind(ServerSocketFactory factory,InetAddress local,int preferred) throws IOException {
        int saved=preferred>=1024&&preferred<=65535?preferred:DEFAULT_PORT;
        int[] ports=saved==DEFAULT_PORT?new int[]{saved,0}:new int[]{saved,DEFAULT_PORT,0};
        IOException last=null;
        for(int port:ports){java.net.ServerSocket socket=factory.createServerSocket();try{socket.setReuseAddress(true);socket.bind(new InetSocketAddress(local,port),PairRuntime.MAX_CONNECTIONS);return socket;}catch(IOException failure){try{socket.close();}catch(IOException ignored){}if(!(failure instanceof BindException))throw failure;last=failure;}}
        throw last==null?new IOException("No se pudo abrir el servidor local"):last;
    }
}
