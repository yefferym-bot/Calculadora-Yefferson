package com.yefferson.calculadora.pairing;

import android.content.Context;
import android.net.*;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import java.io.IOException;
import java.net.*;
import java.util.*;

/** Fresh LAN routes, including hotspot/OEM fallbacks. Never binds the whole process. */
public final class PairNetwork {
    private PairNetwork() {}
    public static final class Route {
        public final InetAddress local;final Network network;final int prefix;
        Route(InetAddress local,Network network,int prefix){this.local=local;this.network=network;this.prefix=prefix;}
        boolean reaches(InetAddress peer){
            byte[] a=local.getAddress(),b=peer.getAddress();if(a.length!=4||b.length!=4||prefix<1||prefix>32)return false;
            for(int bit=0;bit<prefix;bit++)if(((a[bit/8]^b[bit/8])&(128>>(bit%8)))!=0)return false;
            return true;
        }
    }
    public static boolean privateAddress(InetAddress address){return address!=null&&!address.isLoopbackAddress()&&!address.isAnyLocalAddress()&&!address.isMulticastAddress()&&(address.isSiteLocalAddress()||address.isLinkLocalAddress()||(address instanceof Inet6Address&&(address.getAddress()[0]&0xfe)==0xfc));}
    private static void add(List<Route> routes,InetAddress local,Network network,int prefix){
        if(!(local instanceof Inet4Address)||!privateAddress(local))return;
        for(Route r:routes)if(r.local.equals(local)&&Objects.equals(r.network,network))return;
        routes.add(new Route(local,network,prefix));
    }
    public static List<Route> routes(Context context){
        List<Route> result=new ArrayList<>();
        // Some older OEM ConnectivityManager implementations return null during transitions.
        try{
            ConnectivityManager manager=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network[] networks=manager==null?null:manager.getAllNetworks();
            if(networks!=null)for(Network network:networks){if(network==null)continue;try{
                NetworkCapabilities caps=manager.getNetworkCapabilities(network);LinkProperties link=manager.getLinkProperties(network);
                if(caps==null||!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)||caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)||link==null)continue;
                List<LinkAddress> addresses=link.getLinkAddresses();if(addresses!=null)for(LinkAddress address:addresses)if(address!=null)add(result,address.getAddress(),network,address.getPrefixLength());
            }catch(RuntimeException transientNetwork){}}
        }catch(RuntimeException transientService){}
        // A hotspot is not necessarily exposed as an upstream Android Network.
        try{
            Enumeration<NetworkInterface> interfaces=NetworkInterface.getNetworkInterfaces();
            while(interfaces!=null&&interfaces.hasMoreElements()){
                NetworkInterface item=interfaces.nextElement();String name=item.getName();
                if(name==null||!item.isUp()||!(name.startsWith("wlan")||name.startsWith("swlan")||name.startsWith("ap")||name.startsWith("softap")))continue;
                List<InterfaceAddress> addresses=item.getInterfaceAddresses();if(addresses!=null)for(InterfaceAddress address:addresses)if(address!=null)add(result,address.getAddress(),null,address.getNetworkPrefixLength());
            }
        }catch(Exception transientInterfaces){}
        // Legacy Samsung devices may expose the station IP while the Network array is absent.
        try{
            WifiManager wifi=(WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo info=wifi==null||wifi.getWifiState()!=WifiManager.WIFI_STATE_ENABLED?null:wifi.getConnectionInfo();
            int ip=info==null?0:info.getIpAddress();
            if(ip!=0){InetAddress local=InetAddress.getByAddress(new byte[]{(byte)ip,(byte)(ip>>8),(byte)(ip>>16),(byte)(ip>>24)});
                NetworkInterface nic=NetworkInterface.getByInetAddress(local);
                if(nic!=null&&nic.isUp())for(InterfaceAddress address:nic.getInterfaceAddresses())if(local.equals(address.getAddress()))add(result,local,null,address.getNetworkPrefixLength());
            }
        }catch(Exception transientWifi){}
        result.sort(Comparator.comparing((Route r)->r.local.getHostAddress()).thenComparing(r->r.network==null?"~":r.network.toString()));
        return result;
    }
    public static InetAddress local(List<Route> routes,String preferred) throws IOException {
        for(Route route:routes)if(route.local.getHostAddress().equals(preferred))return route.local;
        if(!routes.isEmpty())return routes.get(0).local;
        throw new IOException("Conecta ambos teléfonos a la misma Wi-Fi o activa una zona Wi-Fi y conecta el otro teléfono");
    }
    public interface Attempt {Socket open();void pending(Socket socket) throws IOException;}
    public static Socket connect(Context context,InetAddress peer,int port,int timeout,Attempt attempt) throws IOException {
        if(!privateAddress(peer))throw new IOException("La dirección debe pertenecer a una red local");
        List<Route> routes=routes(context);
        routes.sort(Comparator.comparingInt((Route r)->r.reaches(peer)?0:1).thenComparingInt(r->r.network==null?1:0));
        if(routes.isEmpty())throw new IOException("La red Wi-Fi todavía no tiene una dirección local. Se volverá a intentar al recuperarla");
        long until=System.nanoTime()+timeout*1000000L;IOException last=null;Set<String> direct=new HashSet<>();
        for(Route route:routes){
            // Prefer the matching Wi-Fi Network. Never reuse a socket after failed binding.
            if(route.network!=null){Socket socket=attempt.open();try{
                attempt.pending(socket);route.network.bindSocket(socket);
                socket.connect(new InetSocketAddress(peer,port),remaining(until));return socket;
            }catch(IOException failure){last=failure;close(socket);}catch(RuntimeException failure){last=new IOException("La red Wi-Fi cambió durante la conexión",failure);close(socket);}}
            // If netd has already retired a handle (ENONET), a fresh socket explicitly
            // bound to the current same-subnet LAN IP can still reach a local hotspot.
            if(route.reaches(peer)&&direct.add(route.local.getHostAddress())){
                Socket socket=attempt.open();try{attempt.pending(socket);socket.bind(new InetSocketAddress(route.local,0));socket.connect(new InetSocketAddress(peer,port),remaining(until));return socket;}
                catch(IOException failure){last=failure;close(socket);}
            }
            if(System.nanoTime()>=until)break;
        }
        throw last==null?new IOException("No hay una ruta Wi-Fi disponible hacia el administrador"):last;
    }
    private static int remaining(long until) throws SocketTimeoutException {long ms=(until-System.nanoTime()+999999L)/1000000L;if(ms<=0)throw new SocketTimeoutException("Tiempo de conexión local agotado");return (int)Math.min(ms,Integer.MAX_VALUE);}
    private static void close(Socket socket){try{socket.close();}catch(IOException ignored){}}
}
