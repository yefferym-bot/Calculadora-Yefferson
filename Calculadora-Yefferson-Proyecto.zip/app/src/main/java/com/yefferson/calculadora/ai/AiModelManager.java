package com.yefferson.calculadora.ai;

import android.app.ActivityManager;
import android.content.Context;
import android.os.StatFs;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** Handles model selection, local storage and download. No UI code lives here. */
public final class AiModelManager {
    public interface Listener {
        void onStateChanged();
    }

    private static final long MIN_MODEL_SIZE = 1_000_000L;
    private final Context context;
    private final ExecutorService executor;
    private final Listener listener;
    private final AtomicBoolean downloading = new AtomicBoolean(false);
    private final AtomicInteger progress = new AtomicInteger(0);

    private volatile String modelStatus = "Sin modelo";
    private volatile String modelError = "";
    private File modelFile;
    private int modelContext = 2048;
    private int modelThreads = 4;

    public AiModelManager(Context context, ExecutorService executor, Listener listener) {
        this.context = context.getApplicationContext();
        this.executor = executor;
        this.listener = listener;
        chooseModel();
    }

    public synchronized void chooseModel() {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        if (am != null) am.getMemoryInfo(info);
        long gb = info.totalMem / (1024L * 1024L * 1024L);

        File dir = new File(context.getFilesDir(), "models");
        if (!dir.exists()) dir.mkdirs();

        if (gb >= 6) {
            modelFile = new File(dir, "Qwen3-1.7B-Q4_K_M.gguf");
            // 2048 tokens are enough for the current local prompt/memory payload and reduce CPU/RAM work.
            modelContext = 2048;
            modelThreads = Math.max(4, Math.min(Runtime.getRuntime().availableProcessors(), 6));
        } else {
            modelFile = new File(dir, "Qwen3-0.6B-Q8_0.gguf");
            modelContext = 2048;
            modelThreads = Math.max(3, Math.min(Runtime.getRuntime().availableProcessors(), 4));
        }
    }

    public File getModelFile() { return modelFile; }
    public int getModelContext() { return modelContext; }
    public int getModelThreads() { return modelThreads; }
    public boolean isDownloading() { return downloading.get(); }
    public int getProgress() { return progress.get(); }
    public String getStatus() { return modelStatus; }
    public String getError() { return modelError; }

    public long getRamGb() {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        if (am != null) am.getMemoryInfo(info);
        return info.totalMem / (1024L * 1024L * 1024L);
    }

    public boolean hasUsableModel() {
        return modelFile != null && modelFile.exists() && modelFile.length() > MIN_MODEL_SIZE;
    }

    public void setLoadingStatus(String status) {
        modelStatus = status;
        listener.onStateChanged();
    }

    public String getModelUrl() {
        if (modelFile != null && modelFile.getName().contains("1.7B")) {
            return "https://huggingface.co/ggml-org/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf";
        }
        return "https://huggingface.co/ggml-org/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q8_0.gguf";
    }

    public boolean enoughStorage(long expectedBytes) {
        StatFs fs = new StatFs(context.getFilesDir().getAbsolutePath());
        long free = fs.getAvailableBytes();
        return free > expectedBytes + (400L * 1024L * 1024L);
    }

    public void download(AiNativeController controller) {
        if (modelFile == null) chooseModel();
        if (downloading.get() || controller.isReady()) return;

        downloading.set(true);
        progress.set(0);
        modelError = "";
        modelStatus = "Descargando modelo…";
        listener.onStateChanged();

        executor.execute(() -> {
            File part = new File(modelFile.getAbsolutePath() + ".part");
            HttpURLConnection conn = null;
            try {
                URL url = new URL(getModelUrl());
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(20_000);
                conn.setReadTimeout(30_000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("User-Agent", "TruchApp/3.0");

                long existing = part.exists() ? part.length() : 0L;
                if (existing > 0) conn.setRequestProperty("Range", "bytes=" + existing + "-");

                int code = conn.getResponseCode();
                boolean partial = code == HttpURLConnection.HTTP_PARTIAL;
                if (code != HttpURLConnection.HTTP_OK && !partial) throw new IOException("HTTP " + code);

                long total = conn.getContentLengthLong();
                if (partial) total += existing;
                if (total <= 0) {
                    total = modelFile.getName().contains("1.7B")
                            ? (long) (1.28 * 1024 * 1024 * 1024)
                            : 805L * 1024 * 1024;
                }
                if (!enoughStorage(total)) throw new IOException("No hay espacio suficiente para descargar la IA.");

                FileOutputStream fos = new FileOutputStream(part, partial);
                try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream())) {
                    byte[] buffer = new byte[1024 * 1024];
                    long done = partial ? existing : 0L;
                    int n;
                    int last = -1;
                    while ((n = in.read(buffer)) != -1) {
                        fos.write(buffer, 0, n);
                        done += n;
                        int p = (int) Math.min(100, (done * 100L) / Math.max(1L, total));
                        if (p != last) {
                            progress.set(p);
                            last = p;
                            listener.onStateChanged();
                        }
                    }
                } finally {
                    fos.close();
                }

                if (!part.renameTo(modelFile)) {
                    if (modelFile.exists() && !modelFile.delete()) {
                        throw new IOException("No se pudo reemplazar el modelo.");
                    }
                    if (!part.renameTo(modelFile)) throw new IOException("No se pudo guardar el modelo.");
                }

                modelStatus = "Modelo descargado. Cargando IA local…";
                listener.onStateChanged();
                boolean ok = controller.loadModel(modelFile.getAbsolutePath(), modelContext, modelThreads);
                modelStatus = ok ? "IA local lista" : "Error al cargar IA";
                if (!ok) modelError = "El modelo se descargó pero no pudo abrirse en este teléfono.";
            } catch (Exception e) {
                modelError = e.getMessage() == null ? "Error desconocido" : e.getMessage();
                modelStatus = "Error de descarga";
            } finally {
                downloading.set(false);
                if ("IA local lista".equals(modelStatus)) progress.set(100);
                listener.onStateChanged();
                if (conn != null) conn.disconnect();
            }
        });
    }

    public String toJson(AiNativeController controller) {
        try {
            JSONObject o = new JSONObject();
            o.put("status", modelStatus);
            o.put("progress", progress.get());
            o.put("downloading", downloading.get());
            o.put("ready", controller.isReady());
            o.put("model", modelFile == null ? "" : modelFile.getName());
            o.put("error", modelError);
            o.put("ramGb", getRamGb());
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }
}

/** Small boundary so the model manager does not depend on MainActivity. */
interface AiNativeController {
    boolean isReady();
    boolean loadModel(String path, int contextSize, int threads);
}
