package com.yefferson.calculadora.data;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** Local offline backups, independent from AI/model downloads and app databases. */
public final class BackupManager {
    public static final int REQ_SAVE = 4811;
    public static final int REQ_OPEN = 4812;
    private static final int MAX_BYTES = 16 * 1024 * 1024;
    private static final String FORMAT = "truchapp-backup";
    private static final int VERSION = 1;

    private final Activity activity;
    private final LocalStore store;
    private final WebView webView;
    private volatile String pendingExport;
    private volatile JSONObject pendingImport;
    private final File safetyFile;

    public BackupManager(Activity activity, LocalStore store, WebView webView) {
        this.activity = activity;
        this.store = store;
        this.webView = webView;
        this.safetyFile = new File(activity.getFilesDir(), "truchapp_before_import.truchapp");
    }

    public void startExport(String webJson) {
        try {
            JSONObject web = validateWeb(new JSONObject(webJson));
            String content = makeEnvelope(web, store.exportBackupData()).toString();
            checkSize(content);
            pendingExport = content;
            activity.runOnUiThread(() -> {
                try {
                    String date = new SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(new Date());
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/octet-stream");
                    intent.putExtra(Intent.EXTRA_TITLE, "TruchAPP_Respaldo_" + date + ".truchapp");
                    activity.startActivityForResult(intent, REQ_SAVE);
                } catch (Exception e) {
                    pendingExport = null;
                    emit("onExportResult", false, "No se pudo abrir el selector de archivos.");
                }
            });
        } catch (Exception e) {
            emit("onExportResult", false, "No se pudo preparar el respaldo: " + safeMessage(e));
        }
    }

    public void startImport() {
        pendingImport = null;
        activity.runOnUiThread(() -> {
            try {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                activity.startActivityForResult(intent, REQ_OPEN);
            } catch (Exception e) {
                emit("onImportError", "No se pudo abrir el selector de archivos.");
            }
        });
    }

    public boolean onResult(int request, int result, Intent data) {
        if (request != REQ_SAVE && request != REQ_OPEN) return false;
        if (result != Activity.RESULT_OK || data == null || data.getData() == null) {
            if (request == REQ_SAVE) { pendingExport = null; emit("onExportResult", false, "Exportación cancelada."); }
            else emit("onImportError", "Selección cancelada. No se modificaron datos.");
            return true;
        }
        final Uri uri = data.getData();
        if (request == REQ_SAVE) {
            final String content = pendingExport;
            pendingExport = null;
            if (content == null) { emit("onExportResult", false, "El respaldo ya no está disponible. Vuelve a intentarlo."); return true; }
            new Thread(() -> {
                try (OutputStream raw = activity.getContentResolver().openOutputStream(uri, "w")) {
                    if (raw == null) throw new Exception("No se pudo escribir el archivo");
                    try (GZIPOutputStream zipped = new GZIPOutputStream(raw)) {
                        zipped.write(content.getBytes(StandardCharsets.UTF_8));
                        zipped.finish();
                    }
                    emit("onExportResult", true, "Archivo guardado correctamente. Guárdalo en un lugar seguro.");
                } catch (Exception e) { emit("onExportResult", false, "No se pudo guardar: " + safeMessage(e)); }
            }, "TruchAPP-Export").start();
        } else {
            new Thread(() -> {
                try (InputStream raw = activity.getContentResolver().openInputStream(uri)) {
                    if (raw == null) throw new Exception("No se pudo leer el archivo");
                    JSONObject payload = validateEnvelope(readZip(raw));
                    pendingImport = payload;
                    String metadata = new JSONObject()
                            .put("createdAt", payload.optLong("createdAt", 0))
                            .put("entries", payload.getJSONObject("web").length())
                            .put("nativeEntries", payload.getJSONObject("native").length())
                            .toString();
                    emit("onImportSelected", metadata);
                } catch (Exception e) {
                    pendingImport = null;
                    emit("onImportError", "Respaldo inválido o dañado: " + safeMessage(e));
                }
            }, "TruchAPP-Import").start();
        }
        return true;
    }

    /** Called by the local WebView after the user previews and confirms restoration. */
    public String getImportWebData() {
        JSONObject current = pendingImport;
        return current == null ? "" : current.optJSONObject("web").toString();
    }

    /** Save a recovery copy BEFORE localStorage is replaced; remains in private app storage. */
    public boolean preserveCurrent(String oldWebJson) {
        try {
            if (pendingImport == null) return false;
            JSONObject oldWeb = validateWeb(new JSONObject(oldWebJson));
            String envelope = makeEnvelope(oldWeb, store.exportBackupData()).toString();
            checkSize(envelope);
            File tmp = new File(safetyFile.getAbsolutePath() + ".tmp");
            try (GZIPOutputStream out = new GZIPOutputStream(new FileOutputStream(tmp))) {
                out.write(envelope.getBytes(StandardCharsets.UTF_8));
            }
            if (!tmp.renameTo(safetyFile)) {
                if (safetyFile.exists() && !safetyFile.delete()) throw new Exception("No se pudo reemplazar la copia anterior");
                if (!tmp.renameTo(safetyFile)) throw new Exception("No se pudo guardar la copia de recuperación");
            }
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean applyNativeImport() {
        JSONObject pending = pendingImport;
        if (pending == null) return false;
        try {
            boolean ok = store.restoreBackupData(pending.getJSONObject("native"));
            if (ok) pendingImport = null;
            return ok;
        } catch (Exception e) { return false; }
    }

    public boolean hasSafetyCopy() { return safetyFile.isFile(); }

    public void selectSafetyCopy() {
        new Thread(() -> {
            try (InputStream stream = new FileInputStream(safetyFile)) {
                JSONObject payload = validateEnvelope(readZip(stream));
                pendingImport = payload;
                String metadata = new JSONObject()
                        .put("createdAt", payload.optLong("createdAt", 0))
                        .put("entries", payload.getJSONObject("web").length())
                        .put("nativeEntries", payload.getJSONObject("native").length())
                        .toString();
                emit("onImportSelected", metadata);
            } catch (Exception e) { emit("onImportError", "No se pudo recuperar la copia anterior: " + safeMessage(e)); }
        }, "TruchAPP-Recovery").start();
    }

    private static JSONObject validateWeb(JSONObject web) throws Exception {
        if (web.length() > 500) throw new Exception("Demasiadas entradas");
        java.util.Iterator<String> it = web.keys();
        while (it.hasNext()) {
            String key = it.next();
            if (key.length() > 180 || !(web.opt(key) instanceof String)) throw new Exception("Datos web no compatibles");
        }
        return web;
    }

    private static JSONObject makeEnvelope(JSONObject web, JSONObject nativeData) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("createdAt", System.currentTimeMillis());
        payload.put("web", web);
        payload.put("native", nativeData);
        String payloadText = payload.toString();
        JSONObject result = new JSONObject();
        result.put("format", FORMAT);
        result.put("version", VERSION);
        result.put("checksum", sha256(payloadText));
        result.put("payload", payloadText);
        return result;
    }

    private static JSONObject validateEnvelope(String json) throws Exception {
        JSONObject envelope = new JSONObject(json);
        if (!FORMAT.equals(envelope.optString("format")) || envelope.optInt("version") != VERSION) {
            throw new Exception("Formato o versión no compatible");
        }
        String raw = envelope.getString("payload");
        if (!sha256(raw).equals(envelope.optString("checksum"))) throw new Exception("No pasó la verificación de integridad");
        JSONObject payload = new JSONObject(raw);
        validateWeb(payload.getJSONObject("web"));
        JSONObject nativeData = payload.getJSONObject("native");
        if (!LocalStore.isBackupDataValid(nativeData)) throw new Exception("Datos nativos no compatibles");
        return payload;
    }

    private static String readZip(InputStream in) throws Exception {
        try (GZIPInputStream zip = new GZIPInputStream(in); ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
            byte[] block = new byte[8192]; int n;
            while ((n = zip.read(block)) != -1) {
                if (buf.size() + n > MAX_BYTES) throw new Exception("Archivo demasiado grande (máximo 16 MB)");
                buf.write(block, 0, n);
            }
            return new String(buf.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static void checkSize(String json) throws Exception {
        if (json.getBytes(StandardCharsets.UTF_8).length > MAX_BYTES) throw new Exception("Los datos superan 16 MB");
    }

    private static String sha256(String input) throws Exception {
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(input.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(64);
        for (byte b : hash) sb.append(String.format(Locale.US, "%02x", b & 0xff));
        return sb.toString();
    }

    private static String safeMessage(Exception e) {
        String s = e.getMessage();
        return s == null || s.length() > 140 ? "Comprueba el archivo o el espacio disponible" : s;
    }

    private void emit(String event, Object... arguments) {
        StringBuilder js = new StringBuilder("window.TruchAppBackup&&window.TruchAppBackup.").append(event).append('(');
        for (int i = 0; i < arguments.length; i++) {
            if (i != 0) js.append(',');
            Object arg = arguments[i];
            if (arg instanceof Boolean || arg instanceof Number) js.append(arg);
            else js.append(JSONObject.quote(String.valueOf(arg)));
        }
        js.append(')');
        activity.runOnUiThread(() -> webView.evaluateJavascript(js.toString(), null));
    }
}
