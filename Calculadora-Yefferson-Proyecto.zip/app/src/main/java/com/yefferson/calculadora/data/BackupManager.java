package com.yefferson.calculadora.data;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Offline encrypted backups; compatibility for old plaintext backups is import-only. */
public final class BackupManager {
    public static final int REQ_SAVE = 4811;
    public static final int REQ_OPEN = 4812;
    private static final int MAX_BYTES = 16 * 1024 * 1024;
    private static final int MAX_FILE_BYTES = MAX_BYTES + (1024 * 1024);
    private static final String FORMAT = "truchapp-backup";
    private static final int VERSION = 1; // JSON envelope version inside v2 encrypted container.
    private static final byte[] RECOVERY_MAGIC = "TRUREC02".getBytes(StandardCharsets.US_ASCII);
    private static final String RECOVERY_KEY_ALIAS = "truchapp_internal_recovery_v2";

    private final Activity activity;
    private final LocalStore store;
    private final WebView webView;
    private volatile byte[] pendingExport;
    private volatile byte[] pendingEncryptedImport;
    private volatile JSONObject pendingImport;
    private final File safetyFile;
    private final Object safetyLock = new Object();

    public BackupManager(Activity activity, LocalStore store, WebView webView) {
        this.activity = activity;
        this.store = store;
        this.webView = webView;
        this.safetyFile = new File(activity.getFilesDir(), "truchapp_before_import.truchapp");
        new Thread(this::secureLegacyRecovery, "TruchAPP-SecureOldRecovery").start();
    }

    public void startExport(String webJson, String password) {
        if (password == null || password.length() < 12 || password.length() > 256) {
            emit("onExportResult", false, "La contraseña debe tener al menos 12 caracteres (máximo 256).");
            return;
        }
        final char[] chars = password.toCharArray();
        new Thread(() -> {
            try {
                JSONObject web = validateWeb(new JSONObject(webJson));
                String content = makeEnvelope(web, store.exportBackupData()).toString();
                checkSize(content);
                byte[] encrypted = BackupCrypto.encrypt(zip(content), chars);
                if (encrypted.length > MAX_FILE_BYTES) throw new Exception("El respaldo supera el límite permitido");
                pendingExport = encrypted;
                activity.runOnUiThread(() -> {
                    try {
                        String date = new SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(new Date());
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/octet-stream");
                        intent.putExtra(Intent.EXTRA_TITLE, "TruchAPP_Respaldo_" + date + ".truchapp");
                        activity.startActivityForResult(intent, REQ_SAVE);
                    } catch (Exception e) {
                        pendingExport = null;
                        emit("onExportResult", false, "No se pudo abrir el selector de archivos.");
                    }
                });
            } catch (Exception e) {
                pendingExport = null;
                emit("onExportResult", false, "No se pudo cifrar el respaldo: " + safeMessage(e));
            } finally { Arrays.fill(chars, '\0'); }
        }, "TruchAPP-Encrypt").start();
    }

    public void startImport() {
        pendingImport = null;
        pendingEncryptedImport = null;
        activity.runOnUiThread(() -> {
            try {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                activity.startActivityForResult(intent, REQ_OPEN);
            } catch (Exception e) { emit("onImportError", "No se pudo abrir el selector de archivos."); }
        });
    }

    public boolean onResult(int request, int result, Intent data) {
        if (request != REQ_SAVE && request != REQ_OPEN) return false;
        if (result != Activity.RESULT_OK || data == null || data.getData() == null) {
            if (request == REQ_SAVE) { pendingExport = null; emit("onExportResult", false, "Exportación cancelada."); }
            else emit("onImportError", "Selección cancelada. No se modificaron datos.");
            return true;
        }
        final Uri uri = data.getData();
        if (request == REQ_SAVE) {
            final byte[] content = pendingExport;
            pendingExport = null;
            if (content == null) { emit("onExportResult", false, "El respaldo ya no está disponible. Vuelve a intentarlo."); return true; }
            new Thread(() -> {
                try (OutputStream raw = activity.getContentResolver().openOutputStream(uri, "w")) {
                    if (raw == null) throw new Exception("No se pudo escribir el archivo");
                    raw.write(content);
                    raw.flush();
                    emit("onExportResult", true, "Respaldo CIFRADO guardado. Recuerda tu contraseña para restaurarlo.");
                } catch (Exception e) { emit("onExportResult", false, "No se pudo guardar: " + safeMessage(e)); }
            }, "TruchAPP-Export").start();
        } else {
            new Thread(() -> {
                try (InputStream raw = activity.getContentResolver().openInputStream(uri)) {
                    if (raw == null) throw new Exception("No se pudo leer el archivo");
                    byte[] file = readBounded(raw, MAX_FILE_BYTES);
                    if (BackupCrypto.isEncrypted(file)) {
                        pendingEncryptedImport = file;
                        emit("onImportPasswordRequired");
                    } else if (isGzip(file)) { // Pre-4.8.8 files: importable, never export plaintext again.
                        JSONObject payload = validateEnvelope(readZip(new ByteArrayInputStream(file)));
                        pendingImport = payload;
                        emitSelected(payload, false);
                    } else {
                        throw new Exception("Formato de respaldo no reconocido");
                    }
                } catch (Exception e) {
                    pendingImport = null;
                    pendingEncryptedImport = null;
                    emit("onImportError", "Respaldo inválido o dañado: " + safeMessage(e));
                }
            }, "TruchAPP-Import").start();
        }
        return true;
    }

    /** Password supplied only in memory after the encrypted file is chosen; never persisted. */
    public void unlockImport(String password) {
        byte[] bytes = pendingEncryptedImport;
        if (bytes == null) { emit("onImportError", "Selecciona primero el respaldo cifrado."); return; }
        if (password == null || password.length() == 0) { emit("onImportError", "Escribe la contraseña del respaldo."); return; }
        final char[] chars = password.toCharArray();
        new Thread(() -> {
            try {
                byte[] unsealed = BackupCrypto.decrypt(bytes, chars);
                JSONObject payload = validateEnvelope(readZip(new ByteArrayInputStream(unsealed)));
                Arrays.fill(unsealed, (byte) 0);
                pendingImport = payload;
                pendingEncryptedImport = null;
                emitSelected(payload, true);
            } catch (Exception e) {
                pendingImport = null;
                emit("onImportError", "Contraseña incorrecta o archivo cifrado modificado. No se alteraron los datos.");
            } finally { Arrays.fill(chars, '\0'); }
        }, "TruchAPP-Decrypt").start();
    }

    private void emitSelected(JSONObject payload, boolean encrypted) throws Exception {
        String metadata = new JSONObject()
                .put("createdAt", payload.optLong("createdAt", 0))
                .put("entries", payload.getJSONObject("web").length())
                .put("nativeEntries", payload.getJSONObject("native").length())
                .put("encrypted", encrypted)
                .toString();
        emit("onImportSelected", metadata);
    }

    public String getImportWebData() {
        JSONObject current = pendingImport;
        JSONObject web = current == null ? null : current.optJSONObject("web");
        return web == null ? "" : web.toString();
    }

    /** Upgrade pre-4.8.8 private recovery files to device-key encryption, without user interaction. */
    private void secureLegacyRecovery() {
        synchronized (safetyLock) {
            if (!safetyFile.isFile()) return;
            try (InputStream stream = new FileInputStream(safetyFile)) {
                byte[] content = readBounded(stream, MAX_FILE_BYTES);
                if (!isGzip(content)) return;
                validateEnvelope(readZip(new ByteArrayInputStream(content)));
                writeRecoveryAtomic(encryptLocalRecovery(content));
            } catch (Exception ignored) {
                // Preserve older copy if the device KeyStore cannot encrypt it yet.
            }
        }
    }

    /** Encrypts safety copy under device-only Android Keystore key, before replacing any user data. */
    public boolean preserveCurrent(String oldWebJson) {
        synchronized (safetyLock) {
            try {
                if (pendingImport == null) return false;
                JSONObject oldWeb = validateWeb(new JSONObject(oldWebJson));
                String envelope = makeEnvelope(oldWeb, store.exportBackupData()).toString();
                checkSize(envelope);
                writeRecoveryAtomic(encryptLocalRecovery(zip(envelope)));
                return true;
            } catch (Exception e) { return false; }
        }
    }

    private void writeRecoveryAtomic(byte[] encrypted) throws Exception {
        File tmp = new File(safetyFile.getAbsolutePath() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(encrypted);
            out.getFD().sync();
        }
        if (!tmp.renameTo(safetyFile)) {
            if (safetyFile.exists() && !safetyFile.delete()) throw new Exception("No se pudo reemplazar la copia anterior");
            if (!tmp.renameTo(safetyFile)) throw new Exception("No se pudo guardar la copia de recuperación");
        }
    }

    public boolean applyNativeImport() {
        JSONObject pending = pendingImport;
        if (pending == null) return false;
        try {
            boolean ok = store.restoreBackupData(pending.getJSONObject("native"));
            if (ok) pendingImport = null;
            return ok;
        } catch (Exception e) { return false; }
    }

    public boolean hasSafetyCopy() { return safetyFile.isFile(); }

    public void selectSafetyCopy() {
        new Thread(() -> {
            synchronized (safetyLock) {
                try (InputStream stream = new FileInputStream(safetyFile)) {
                    byte[] file = readBounded(stream, MAX_FILE_BYTES);
                    byte[] compressed;
                    if (startsWith(file, RECOVERY_MAGIC)) compressed = decryptLocalRecovery(file);
                    else if (isGzip(file)) compressed = file; // old private recovery copy
                    else throw new Exception("Formato de recuperación no compatible");
                    JSONObject payload = validateEnvelope(readZip(new ByteArrayInputStream(compressed)));
                    pendingEncryptedImport = null;
                    pendingImport = payload;
                    emitSelected(payload, startsWith(file, RECOVERY_MAGIC));
                } catch (Exception e) { emit("onImportError", "No se pudo recuperar la copia anterior: " + safeMessage(e)); }
            }
        }, "TruchAPP-Recovery").start();
    }

    private SecretKey recoveryKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(RECOVERY_KEY_ALIAS)) {
            KeyStore.Entry entry = ks.getEntry(RECOVERY_KEY_ALIAS, null);
            if (entry instanceof KeyStore.SecretKeyEntry) return ((KeyStore.SecretKeyEntry) entry).getSecretKey();
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(RECOVERY_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return generator.generateKey();
    }

    private byte[] encryptLocalRecovery(byte[] compressed) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, recoveryKey());
        cipher.updateAAD(RECOVERY_MAGIC);
        byte[] nonce = cipher.getIV();
        byte[] encrypted = cipher.doFinal(compressed);
        ByteArrayOutputStream out = new ByteArrayOutputStream(RECOVERY_MAGIC.length + nonce.length + encrypted.length);
        out.write(RECOVERY_MAGIC);out.write(nonce);out.write(encrypted);
        return out.toByteArray();
    }

    private byte[] decryptLocalRecovery(byte[] file) throws Exception {
        if (file.length < RECOVERY_MAGIC.length + 12 + 16) throw new Exception("Copia incompleta");
        byte[] nonce = Arrays.copyOfRange(file, RECOVERY_MAGIC.length, RECOVERY_MAGIC.length + 12);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, recoveryKey(), new GCMParameterSpec(128, nonce));
        cipher.updateAAD(RECOVERY_MAGIC);
        return cipher.doFinal(file, RECOVERY_MAGIC.length + 12, file.length - RECOVERY_MAGIC.length - 12);
    }

    private static boolean startsWith(byte[] input, byte[] prefix) {
        if (input.length < prefix.length) return false;
        for (int i = 0; i < prefix.length; i++) if (input[i] != prefix[i]) return false;
        return true;
    }

    private static boolean isGzip(byte[] input) {
        return input.length >= 2 && (input[0] & 0xff) == 0x1f && (input[1] & 0xff) == 0x8b;
    }

    private static byte[] readBounded(InputStream input, int limit) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] block = new byte[8192]; int n;
        while ((n = input.read(block)) != -1) {
            if (out.size() + n > limit) throw new Exception("Archivo demasiado grande");
            out.write(block, 0, n);
        }
        return out.toByteArray();
    }

    private static byte[] zip(String raw) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (GZIPOutputStream zip = new GZIPOutputStream(out)) {
            zip.write(raw.getBytes(StandardCharsets.UTF_8));
        }
        return out.toByteArray();
    }

    private static JSONObject validateWeb(JSONObject web) throws Exception {
        if (web.length() > 500) throw new Exception("Demasiadas entradas");
        java.util.Iterator<String> it = web.keys();
        while (it.hasNext()) {
            String key = it.next();
            if (key.length() > 180 || !(web.opt(key) instanceof String)) throw new Exception("Datos web no compatibles");
        }
        return web;
    }

    private static JSONObject makeEnvelope(JSONObject web, JSONObject nativeData) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("createdAt", System.currentTimeMillis());
        payload.put("web", web);
        payload.put("native", nativeData);
        String payloadText = payload.toString();
        JSONObject result = new JSONObject();
        result.put("format", FORMAT);
        result.put("version", VERSION);
        result.put("checksum", sha256(payloadText));
        result.put("payload", payloadText);
        return result;
    }

    private static JSONObject validateEnvelope(String json) throws Exception {
        JSONObject envelope = new JSONObject(json);
        if (!FORMAT.equals(envelope.optString("format")) || envelope.optInt("version") != VERSION) {
            throw new Exception("Formato o versión no compatible");
        }
        String raw = envelope.getString("payload");
        if (!sha256(raw).equals(envelope.optString("checksum"))) throw new Exception("No pasó la verificación de integridad");
        JSONObject payload = new JSONObject(raw);
        validateWeb(payload.getJSONObject("web"));
        JSONObject nativeData = payload.getJSONObject("native");
        if (!LocalStore.isBackupDataValid(nativeData)) throw new Exception("Datos nativos no compatibles");
        return payload;
    }

    private static String readZip(InputStream in) throws Exception {
        try (GZIPInputStream zip = new GZIPInputStream(in); ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
            byte[] block = new byte[8192]; int n;
            while ((n = zip.read(block)) != -1) {
                if (buf.size() + n > MAX_BYTES) throw new Exception("Archivo demasiado grande (máximo 16 MB)");
                buf.write(block, 0, n);
            }
            return new String(buf.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static void checkSize(String json) throws Exception {
        if (json.getBytes(StandardCharsets.UTF_8).length > MAX_BYTES) throw new Exception("Los datos superan 16 MB");
    }

    private static String sha256(String input) throws Exception {
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(input.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(64);
        for (byte b : hash) sb.append(String.format(Locale.US, "%02x", b & 0xff));
        return sb.toString();
    }

    private static String safeMessage(Exception e) {
        String s = e.getMessage();
        return s == null || s.length() > 140 ? "Comprueba el archivo o el espacio disponible" : s;
    }

    private void emit(String event, Object... arguments) {
        StringBuilder js = new StringBuilder("window.TruchAppBackup&&window.TruchAppBackup.").append(event).append('(');
        for (int i = 0; i < arguments.length; i++) {
            if (i != 0) js.append(',');
            Object arg = arguments[i];
            if (arg instanceof Boolean || arg instanceof Number) js.append(arg);
            else js.append(JSONObject.quote(String.valueOf(arg)));
        }
        js.append(')');
        activity.runOnUiThread(() -> webView.evaluateJavascript(js.toString(), null));
    }
}
