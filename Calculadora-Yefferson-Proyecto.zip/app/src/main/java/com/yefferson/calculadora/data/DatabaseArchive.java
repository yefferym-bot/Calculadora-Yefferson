package com.yefferson.calculadora.data;

import android.content.Context;
import android.database.Cursor;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.JsonReader;
import android.util.JsonWriter;
import com.yefferson.calculadora.data.db.*;
import org.json.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Streaming authenticated archives: no whole-database byte[] or 16 MiB export ceiling. */
public final class DatabaseArchive {
    private static final byte[] PORTABLE="TRUDBP03".getBytes(StandardCharsets.US_ASCII), LOCAL="TRUDBL03".getBytes(StandardCharsets.US_ASCII);
    private static final String KEY="truchapp_database_recovery_v1";
    public static final long MAX_FILE=1024L*1024*1024; // A bounded input, not an in-memory allocation.
    public static class Stage {public FarmDatabase database;public String name;public JSONObject metadata;}
    private DatabaseArchive(){}
    public static boolean modern(File file) throws IOException {try(InputStream in=new FileInputStream(file)){byte[] b=new byte[8];return in.read(b)==8&&(Arrays.equals(b,PORTABLE)||Arrays.equals(b,LOCAL));}}
    private static SecretKey localKey() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(store.containsAlias(KEY))return ((KeyStore.SecretKeyEntry)store.getEntry(KEY,null)).getSecretKey();
        KeyGenerator generator=KeyGenerator.getInstance("AES","AndroidKeyStore");generator.init(new KeyGenParameterSpec.Builder(KEY,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());return generator.generateKey();
    }
    public static void write(Context context,FarmRepository repository,File file,char[] password) throws Exception {
        synchronized(repository){
            FarmDatabase db=repository.database();if(!repository.ready())throw new IOException("El almacenamiento aún no está preparado");
            byte[] magic=password==null?LOCAL:PORTABLE,salt=new byte[16];new SecureRandom().nextBytes(salt);
            byte[] rawKey=password==null?null:BackupCrypto.deriveKey(password,salt);
            SecretKey key=rawKey==null?localKey():new SecretKeySpec(rawKey,"AES");Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key);cipher.updateAAD(magic);
            try(FileOutputStream output=new FileOutputStream(file)){
                output.write(magic);output.write(salt);output.write(cipher.getIV());
                // Closing JsonWriter finalizes gzip and GCM before the file can be advertised as complete.
                try(JsonWriter writer=new JsonWriter(new OutputStreamWriter(new GZIPOutputStream(new CipherOutputStream(output,cipher)),StandardCharsets.UTF_8))){
                    writer.beginObject().name("format").value("truchapp-database").name("schema").value(1).name("createdAt").value(System.currentTimeMillis());
                    writer.name("nativeReminders").value(context.getSharedPreferences("yefferson_ai",Context.MODE_PRIVATE).getString("reminders","[]"));
                    writer.name("documents").beginArray();
                    for(FarmDocument document:db.data().documents()){
                        writer.beginObject().name("key").value(document.key).name("template").value(document.template).name("format").value(document.format).endObject();
                    }
                    writer.endArray().name("records").beginArray();long count=0;
                    try(Cursor cursor=db.getOpenHelper().getReadableDatabase().query("SELECT owner,path,recordId,kind,lotId,centerId,date,position,json FROM farm_records ORDER BY owner,path,position")){
                        while(cursor.moveToNext()){
                            writer.beginObject();String[] names={"owner","path","recordId","kind","lotId","centerId","date"};for(int i=0;i<names.length;i++)writer.name(names[i]).value(cursor.getString(i));writer.name("position").value(cursor.getLong(7)).name("json").value(cursor.getString(8)).endObject();count++;
                        }
                    }
                    writer.endArray().name("recordCount").value(count).endObject();
                }
            }finally{if(rawKey!=null)Arrays.fill(rawKey,(byte)0);}
            // Sync after encryption is closed, then publish with a rename by the caller.
            try(RandomAccessFile sync=new RandomAccessFile(file,"rw")){sync.getFD().sync();}
        }
    }
    private static JSONObject object(JsonReader reader) throws Exception {
        JSONObject o=new JSONObject();reader.beginObject();while(reader.hasNext()){String key=reader.nextName();if(key.equals("position"))o.put(key,reader.nextLong());else o.put(key,reader.nextString());}reader.endObject();return o;
    }
    public static Stage stage(Context context,FarmRepository repository,File file,char[] password) throws Exception {
        if(file.length()>MAX_FILE)throw new IOException("El archivo supera 1 GiB");
        Stage stage=new Stage();stage.name=repository.stagedName();stage.database=repository.createStage(stage.name);
        try(InputStream input=new BufferedInputStream(new FileInputStream(file))){
            byte[] magic=new byte[8],salt=new byte[16],nonce=new byte[12];new DataInputStream(input).readFully(magic);new DataInputStream(input).readFully(salt);new DataInputStream(input).readFully(nonce);
            boolean portable=Arrays.equals(magic,PORTABLE);if(!portable&&!Arrays.equals(magic,LOCAL))throw new IOException("Formato no compatible");if(portable&&(password==null||password.length==0))throw new IOException("Escribe la contraseña");
            byte[] rawKey=portable?BackupCrypto.deriveKey(password,salt):null;
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,portable?new SecretKeySpec(rawKey,"AES"):localKey(),new GCMParameterSpec(128,nonce));cipher.updateAAD(magic);
            try(CipherInputStream decrypted=new CipherInputStream(input,cipher);GZIPInputStream zip=new GZIPInputStream(decrypted);JsonReader reader=new JsonReader(new InputStreamReader(zip,StandardCharsets.UTF_8))){
                JSONObject metadata=new JSONObject();long[] count={0},expected={-1};boolean[] valid={false,false};
                stage.database.runInTransaction(()->{try{
                    reader.beginObject();while(reader.hasNext()){
                        String name=reader.nextName();
                        switch(name){
                            case "format":if(!reader.nextString().equals("truchapp-database"))throw new IOException("Formato no reconocido");valid[0]=true;break;
                            case "schema":if(reader.nextInt()!=1)throw new IOException("Versión de base no compatible");valid[1]=true;break;
                            case "createdAt":metadata.put("createdAt",reader.nextLong());break;
                            case "nativeReminders":metadata.put("nativeReminders",reader.nextString());break;
                            case "documents":reader.beginArray();while(reader.hasNext()){
                                JSONObject o=object(reader);FarmDocument d=new FarmDocument();d.key=o.getString("key");d.template=o.getString("template");d.format=o.getString("format");
                                if(stage.database.data().document(d.key)!=null)throw new IOException("Documento duplicado");stage.database.data().document(d);
                            }reader.endArray();break;
                            case "records":reader.beginArray();while(reader.hasNext()){stage.database.data().importRecord(DocumentCodec.rowFrom(object(reader)));count[0]++;}reader.endArray();break;
                            case "recordCount":expected[0]=reader.nextLong();break;
                            default:throw new IOException("Campo de respaldo no compatible");
                        }
                    }reader.endObject();
                    if(!valid[0]||!valid[1]||expected[0]!=count[0])throw new IOException("El respaldo está incompleto");
                    // Consume to authenticated EOF. Nothing becomes active if the GCM tag fails.
                    if(reader.peek()!=android.util.JsonToken.END_DOCUMENT)throw new IOException("Contenido adicional inesperado");while(zip.read()!=-1){}while(decrypted.read()!=-1){}
                    validateStage(stage.database,metadata);
                }catch(Exception e){throw new IllegalStateException("No se pudo validar el respaldo: "+e.getMessage(),e);}});
                stage.metadata=metadata.put("encrypted",true).put("database",true).put("records",count[0]);return stage;
            }finally{if(rawKey!=null)Arrays.fill(rawKey,(byte)0);}
        }catch(Exception e){discard(context,stage);throw e;}
    }
    public static void validateStage(FarmDatabase db,JSONObject metadata) throws Exception {
        Set<String> keys=new HashSet<>();JSONObject web=new JSONObject();
        for(FarmDocument doc:db.data().documents()){
            keys.add(doc.key);if(doc.key.startsWith("__system/"))continue;
            String raw=DocumentCodec.decode(doc,db.data().records(doc.key));DocumentCodec.validate(doc.key,raw);web.put(doc.key,raw);
        }
        try(Cursor c=db.getOpenHelper().getReadableDatabase().query("SELECT DISTINCT owner FROM farm_records")){while(c.moveToNext())if(!keys.contains(c.getString(0)))throw new IOException("Hay registros sin documento de origen");}
        JSONObject counts=new JSONObject();for(String kind:new String[]{"lots","water","daily","samples","tasks","products","movements","agenda"})counts.put(kind,db.data().count(kind,""));metadata.put("counts",counts);
        // Reject broken product references; deleted production lots can legitimately remain in history.
        String stock=web.optString(DocumentCodec.STOCK,"");if(!stock.isEmpty()){
            JSONObject s=new JSONObject(stock);Set<String> products=new HashSet<>();JSONArray items=s.getJSONArray("items"),movements=s.getJSONArray("movements");for(int i=0;i<items.length();i++)products.add(items.getJSONObject(i).optString("id"));
            for(int i=0;i<movements.length();i++)if(!products.contains(movements.getJSONObject(i).optString("itemId")))throw new IOException("Movimiento de almacén sin producto asociado");
        }
        if(db.data().document("__system/initialized")==null)throw new IOException("Falta la confirmación de almacenamiento");
    }
    public static Stage legacy(Context context,FarmRepository repository,JSONObject payload) throws Exception {
        Stage stage=new Stage();stage.name=repository.stagedName();stage.database=repository.createStage(stage.name);
        try{
            JSONObject web=new JSONObject(payload.getJSONObject("web").toString()),nativeData=payload.getJSONObject("native");
            String[][] keys={{"production_lots",DocumentCodec.LOTS},{"activities","activities"},{"profile","profile"},{"memories","memories"},{"reminders","reminders"}};
            for(String[] pair:keys)if(nativeData.has(pair[0])){
                String raw=nativeData.getString(pair[0]);boolean take=!web.has(pair[1]);
                if(pair[1].equals(DocumentCodec.LOTS)&&new JSONArray(raw).length()>0)take=true;
                if(take)web.put(pair[1],raw);
            }
            stage.database.runInTransaction(()->{try{
                Iterator<String> it=web.keys();while(it.hasNext()){String key=it.next();DocumentCodec.Encoded d=DocumentCodec.encode(key,web.getString(key));stage.database.data().document(d.document);for(FarmRecord r:d.rows)stage.database.data().record(r);}
                for(String[] pair:new String[][]{{"__system/revision","1"},{"__system/initialized","1"}}){FarmDocument d=new FarmDocument();d.key=pair[0];d.template=pair[1];stage.database.data().document(d);}
                stage.metadata=new JSONObject().put("createdAt",payload.optLong("createdAt",0)).put("database",true).put("encrypted",true);validateStage(stage.database,stage.metadata);
            }catch(Exception e){throw new IllegalStateException(e.getMessage(),e);}});return stage;
        }catch(Exception e){discard(context,stage);throw e;}
    }
    public static void discard(Context context,Stage stage){if(stage==null)return;try{stage.database.close();context.deleteDatabase(stage.name);}catch(Exception ignored){}}
}
