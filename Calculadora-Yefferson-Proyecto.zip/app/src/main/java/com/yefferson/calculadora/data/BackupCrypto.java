package com.yefferson.calculadora.data;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/** Versioned portable offline backup encryption. No hard-coded secret or third-party library. */
public final class BackupCrypto {
    // v2 file: MAGIC (8 bytes) | 16-byte random salt | 12-byte random GCM nonce | authenticated ciphertext.
    private static final byte[] MAGIC = "TRUCHEN2".getBytes(StandardCharsets.US_ASCII);
    private static final int SALT_BYTES = 16;
    private static final int NONCE_BYTES = 12;
    private static final int AUTH_TAG_BITS = 128;
    private static final int ROUNDS = 600_000;
    private static final SecureRandom RANDOM = new SecureRandom();

    private BackupCrypto() { }

    public static boolean isEncrypted(byte[] bytes) {
        if (bytes == null || bytes.length < MAGIC.length + SALT_BYTES + NONCE_BYTES + 16) return false;
        for (int i = 0; i < MAGIC.length; i++) if (bytes[i] != MAGIC[i]) return false;
        return true;
    }

    public static byte[] encrypt(byte[] compressedEnvelope, char[] password) throws Exception {
        requirePassword(password);
        byte[] salt = new byte[SALT_BYTES];
        byte[] nonce = new byte[NONCE_BYTES];
        RANDOM.nextBytes(salt);
        RANDOM.nextBytes(nonce);
        byte[] key = deriveKey(password, salt);
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(AUTH_TAG_BITS, nonce));
            cipher.updateAAD(MAGIC);
            byte[] ciphertext = cipher.doFinal(compressedEnvelope);
            ByteArrayOutputStream out = new ByteArrayOutputStream(MAGIC.length + salt.length + nonce.length + ciphertext.length);
            out.write(MAGIC);out.write(salt);out.write(nonce);out.write(ciphertext);
            return out.toByteArray();
        } finally { Arrays.fill(key, (byte) 0); }
    }

    public static byte[] decrypt(byte[] file, char[] password) throws Exception {
        if (!isEncrypted(file)) throw new GeneralSecurityException("Formato cifrado incompatible");
        if (password == null || password.length == 0) throw new GeneralSecurityException("Se necesita la contraseña");
        byte[] salt = Arrays.copyOfRange(file, MAGIC.length, MAGIC.length + SALT_BYTES);
        byte[] nonce = Arrays.copyOfRange(file, MAGIC.length + SALT_BYTES, MAGIC.length + SALT_BYTES + NONCE_BYTES);
        byte[] key = deriveKey(password, salt);
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(AUTH_TAG_BITS, nonce));
            cipher.updateAAD(MAGIC);
            return cipher.doFinal(file, MAGIC.length + SALT_BYTES + NONCE_BYTES, file.length - MAGIC.length - SALT_BYTES - NONCE_BYTES);
        } finally { Arrays.fill(key, (byte) 0); }
    }

    private static void requirePassword(char[] password) {
        if (password == null || password.length < 12 || password.length > 256) {
            throw new IllegalArgumentException("Usa una contraseña de entre 12 y 256 caracteres");
        }
    }

    private static byte[] deriveKey(char[] password, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ROUNDS, 256);
        try {
            // Uses Android platform implementation where available (Android 8+).
            try {
                return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            } catch (java.security.NoSuchAlgorithmException absentOnOlderAndroid) {
                // API 23–25: same PBKDF2-HMAC-SHA256 bytes, using platform HmacSHA256.
                return pbkdf2Fallback(password, salt, ROUNDS);
            }
        } finally { spec.clearPassword(); }
    }

    private static byte[] pbkdf2Fallback(char[] password, byte[] salt, int rounds) throws Exception {
        byte[] passwordBytes = new String(password).getBytes(StandardCharsets.UTF_8);
        byte[] last = new byte[4];
        last[3] = 1; // block index 1, big endian
        byte[] firstBlock = new byte[salt.length + 4];
        System.arraycopy(salt, 0, firstBlock, 0, salt.length);
        System.arraycopy(last, 0, firstBlock, salt.length, 4);
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(passwordBytes, "HmacSHA256"));
            byte[] u = mac.doFinal(firstBlock);
            byte[] result = u.clone();
            for (int i = 1; i < rounds; i++) {
                u = mac.doFinal(u);
                for (int j = 0; j < 32; j++) result[j] ^= u[j];
            }
            Arrays.fill(u, (byte) 0);
            return result;
        } finally { Arrays.fill(passwordBytes, (byte) 0); Arrays.fill(firstBlock, (byte) 0); }
    }
}
