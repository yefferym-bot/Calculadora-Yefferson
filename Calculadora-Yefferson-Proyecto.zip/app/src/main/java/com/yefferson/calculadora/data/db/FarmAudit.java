package com.yefferson.calculadora.data.db;
import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** An operation receipt plus the inverse patch; retries are idempotent and deletion is reversible. */
@Entity(tableName="farm_audit", indices={@Index("createdAt")})
public class FarmAudit {
    @PrimaryKey @NonNull public String operationId="";
    @NonNull public String label="", inverse="", forward="", fingerprint="";
    public long createdAt, revision;
    public boolean undone;
}
