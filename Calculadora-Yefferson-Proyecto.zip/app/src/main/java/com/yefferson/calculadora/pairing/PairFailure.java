package com.yefferson.calculadora.pairing;

import java.net.*;
import java.security.*;
import java.security.cert.*;
import java.util.*;
import javax.net.ssl.*;

/** Bounded diagnostics, shown only for connection repair; never include keys or production records. */
public final class PairFailure {
    private PairFailure() {}
    public static final class LocalIdentityException extends Exception {
        public LocalIdentityException(Exception cause){super("No se pudo comprobar la identidad cifrada de este teléfono",cause);}
    }
    public static String message(Exception error){
        List<Throwable> causes=new ArrayList<>();Throwable current=error;
        while(current!=null&&causes.size()<12&&!causes.contains(current)){causes.add(current);current=current.getCause();}
        boolean local=has(causes,LocalIdentityException.class);
        String code,summary;
        if(has(causes,CertificateExpiredException.class)||has(causes,CertificateNotYetValidException.class)){
            code="TLS-DATE";summary="Un certificado está fuera de su periodo de validez. Revisa la fecha y hora de ambos teléfonos.";
        }else if(local){code="TLS-LOCAL";summary="No se pudo usar la identidad cifrada de este teléfono. Este fallo ocurre antes de vincular al otro equipo.";
        }else if(has(causes,CertificateException.class)){code="TLS-CERT";summary="No se pudo validar el certificado del otro teléfono.";
        }else if(has(causes,GeneralSecurityException.class)){code="TLS-KEY";summary="No se pudo usar una clave de seguridad para la conexión.";
        }else if(has(causes,SSLHandshakeException.class)){code="TLS-HANDSHAKE";summary="Los teléfonos no pudieron completar la negociación del cifrado.";
        }else if(has(causes,SSLException.class)){code="TLS-CONNECTION";summary="La conexión cifrada se interrumpió.";
        }else if(has(causes,ConnectException.class)){return "[TCP-CONNECT] El administrador no está aceptando la conexión en esa dirección. Reactiva la vinculación, mantén TruchApp visible y usa la dirección completa actual.";
        }else if(has(causes,SocketTimeoutException.class)){return "[NET-TIMEOUT] El otro teléfono no respondió. Comprueba la red y vuelve a conectar.";
        }else{return clean(error.getMessage()==null?"No se pudo completar la conexión local.":error.getMessage(),220);}
        Throwable detail=causes.get(causes.size()-1);
        return "["+code+"] "+summary+" Detalle: "+detail.getClass().getSimpleName()+": "+clean(detail.getMessage()==null?"Sin detalle del sistema":detail.getMessage(),240);
    }
    private static boolean has(List<Throwable> causes,Class<?> type){for(Throwable cause:causes)if(type.isInstance(cause))return true;return false;}
    private static String clean(String value,int limit){value=value.replaceAll("[\\p{Cntrl}\\p{Cf}]"," ").replaceAll("\\s+"," ").trim();return value.length()>limit?value.substring(0,limit)+"…":value;}
}
