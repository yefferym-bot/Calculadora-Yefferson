package com.yefferson.calculadora.data;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.*;
import com.yefferson.calculadora.data.db.FarmRepository;
import java.util.concurrent.TimeUnit;

public class RecoveryWorker extends Worker {
    public RecoveryWorker(@NonNull Context context,@NonNull WorkerParameters parameters){super(context,parameters);}
    @NonNull @Override public Result doWork(){
        try{FarmRepository repository=FarmRepository.get(getApplicationContext());if(repository.ready())new RecoveryVault(getApplicationContext(),repository).checkpoint("auto",false);return Result.success();}
        catch(Exception error){return getRunAttemptCount()<3?Result.retry():Result.failure();}
    }
    public static void schedule(Context context){
        WorkManager work=WorkManager.getInstance(context);
        work.enqueueUniquePeriodicWork("farm-recovery-daily",ExistingPeriodicWorkPolicy.KEEP,new PeriodicWorkRequest.Builder(RecoveryWorker.class,24,TimeUnit.HOURS).build());
    }
    public static void afterCommit(Context context){
        WorkManager.getInstance(context).enqueueUniqueWork("farm-recovery-pending",ExistingWorkPolicy.KEEP,new OneTimeWorkRequest.Builder(RecoveryWorker.class).setInitialDelay(5,TimeUnit.MINUTES).build());
    }
}
