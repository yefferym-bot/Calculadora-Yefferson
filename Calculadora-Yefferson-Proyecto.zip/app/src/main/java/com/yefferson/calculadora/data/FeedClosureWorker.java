package com.yefferson.calculadora.data;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.*;
import com.yefferson.calculadora.data.db.FarmRepository;
import java.util.concurrent.TimeUnit;

/** Durable catch-up; Android may delay background work during Doze or while powered off. */
public final class FeedClosureWorker extends Worker {
    public FeedClosureWorker(@NonNull Context context,@NonNull WorkerParameters parameters){super(context,parameters);}
    @NonNull @Override public Result doWork(){
        try{FarmRepository repository=FarmRepository.get(getApplicationContext());if(repository.ready())repository.closeFeedDays();return Result.success();}
        catch(Exception error){return getRunAttemptCount()<3?Result.retry():Result.failure();}
    }
    public static void schedule(Context context){
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("farm-food-day-close-v1",ExistingPeriodicWorkPolicy.KEEP,
            new PeriodicWorkRequest.Builder(FeedClosureWorker.class,15,TimeUnit.MINUTES).build());
    }
}
