package com.yefferson.calculadora.data.db;

import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** Compact ledger of automatic FOOD defaults; never an observation of fasting or losses. */
public final class FeedDayClosure {
    private FeedDayClosure() {}
    private static boolean valid(String value){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);f.setLenient(false);return value.matches("\\d{4}-\\d{2}-\\d{2}")&&value.equals(f.format(f.parse(value)));}catch(Exception invalid){return false;}}
    public static String yesterday(long now,TimeZone zone){
        Calendar day=Calendar.getInstance(zone);day.setTimeInMillis(now);day.add(Calendar.DAY_OF_MONTH,-1);
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);format.setTimeZone(zone);return format.format(day.getTime());
    }
    public static JSONObject advance(JSONObject previous,long now,TimeZone zone) throws JSONException {
        String through=yesterday(now,zone),old=previous==null?"":previous.optString("through");
        if(previous!=null&&previous.optInt("version")==1&&"missing-food-zero".equals(previous.optString("policy"))&&valid(old)&&old.compareTo(through)>=0)
            return new JSONObject(previous.toString());
        return new JSONObject().put("version",1).put("policy","missing-food-zero").put("through",through).put("timeZone",zone.getID()).put("appliedAt",now);
    }
}
