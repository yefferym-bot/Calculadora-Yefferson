package com.yefferson.calculadora.pairing;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.*;
import java.net.Socket;
import java.util.*;
import javax.net.ssl.*;
import javax.security.auth.x500.X500Principal;

/** Device-only signing key. First trust requires human SAS confirmation; later trust pins its certificate. */
public final class PairIdentity {
    private static final String ALIAS="truchapp-local-device-v1";
    private final KeyStore keys;private final X509Certificate cert;public final String fingerprint;
    public PairIdentity() throws Exception {
        keys=KeyStore.getInstance("AndroidKeyStore");keys.load(null);
        if(!keys.containsAlias(ALIAS)){
            KeyPairGenerator generator=KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA,"AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_SIGN|KeyProperties.PURPOSE_VERIFY)
                .setKeySize(2048).setDigests(KeyProperties.DIGEST_NONE,KeyProperties.DIGEST_SHA256,KeyProperties.DIGEST_SHA384,KeyProperties.DIGEST_SHA512)
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1,KeyProperties.SIGNATURE_PADDING_RSA_PSS)
                .setCertificateSubject(new X500Principal("CN=TruchApp local device"))
                .setCertificateSerialNumber(new BigInteger(120,new SecureRandom()).add(BigInteger.ONE))
                .setCertificateNotBefore(new Date(1577836800000L)).setCertificateNotAfter(new Date(2524608000000L)).build());
            generator.generateKeyPair();
        }
        cert=(X509Certificate)keys.getCertificate(ALIAS);fingerprint=PairWire.fingerprint(cert);
    }
    public SSLContext context() throws Exception {
        final PrivateKey key=(PrivateKey)keys.getKey(ALIAS,null);
        X509KeyManager manager=new X509KeyManager(){
            public String[] getClientAliases(String type,Principal[] issuers){return "RSA".equals(type)?new String[]{ALIAS}:null;}
            public String chooseClientAlias(String[] types,Principal[] issuers,Socket socket){for(String type:types)if("RSA".equals(type))return ALIAS;return null;}
            public String[] getServerAliases(String type,Principal[] issuers){return "RSA".equals(type)?new String[]{ALIAS}:null;}
            public String chooseServerAlias(String type,Principal[] issuers,Socket socket){return "RSA".equals(type)?ALIAS:null;}
            public X509Certificate[] getCertificateChain(String alias){return ALIAS.equals(alias)?new X509Certificate[]{cert}:null;}
            public PrivateKey getPrivateKey(String alias){return ALIAS.equals(alias)?key:null;}
        };
        // This trust manager is scoped ONLY to the pairing socket. It does not modify HTTPS/WebView trust.
        // A valid self-signed certificate establishes encryption; PairSession establishes peer authorization.
        X509TrustManager trust=new X509TrustManager(){
            public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
            private void check(X509Certificate[] chain) throws CertificateException {try{if(chain==null||chain.length!=1)throw new CertificateException("Certificado local inválido");chain[0].checkValidity();PublicKey publicKey=chain[0].getPublicKey();if(!(publicKey instanceof java.security.interfaces.RSAPublicKey)||((java.security.interfaces.RSAPublicKey)publicKey).getModulus().bitLength()<2048)throw new CertificateException("Clave local insuficiente");chain[0].verify(publicKey);}catch(Exception e){throw new CertificateException("Identidad local no válida",e);}}
            public void checkClientTrusted(X509Certificate[] chain,String auth) throws CertificateException{check(chain);}
            public void checkServerTrusted(X509Certificate[] chain,String auth) throws CertificateException{check(chain);}
        };
        SSLContext context=SSLContext.getInstance("TLSv1.2");context.init(new KeyManager[]{manager},new TrustManager[]{trust},new SecureRandom());return context;
    }
    public static String[] suites(String[] supported){List<String> out=new ArrayList<>();for(String suite:supported)if(suite.equals("TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256")||suite.equals("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"))out.add(suite);if(out.isEmpty())throw new IllegalStateException("El dispositivo no admite el cifrado local requerido");return out.toArray(new String[0]);}
}
