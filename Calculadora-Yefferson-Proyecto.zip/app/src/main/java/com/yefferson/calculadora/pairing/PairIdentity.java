package com.yefferson.calculadora.pairing;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.*;
import java.net.Socket;
import java.util.*;
import javax.net.ssl.*;
import javax.security.auth.x500.X500Principal;

/** Device-only signing key. First trust requires human SAS confirmation; later trust pins its certificate. */
public final class PairIdentity {
    private static final String ALIAS="truchapp-local-device-v1";
    private final KeyStore keys;private final X509Certificate cert;public final String fingerprint;
    public PairIdentity() throws Exception {
        keys=KeyStore.getInstance("AndroidKeyStore");keys.load(null);
        if(!keys.containsAlias(ALIAS)){
            KeyPairGenerator generator=KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA,"AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_SIGN|KeyProperties.PURPOSE_VERIFY)
                .setKeySize(2048).setDigests(KeyProperties.DIGEST_NONE,KeyProperties.DIGEST_SHA256,KeyProperties.DIGEST_SHA384,KeyProperties.DIGEST_SHA512)
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1,KeyProperties.SIGNATURE_PADDING_RSA_PSS)
                .setCertificateSubject(new X500Principal("CN=TruchApp local device"))
                .setCertificateSerialNumber(new BigInteger(120,new SecureRandom()).add(BigInteger.ONE))
                .setCertificateNotBefore(new Date(1577836800000L)).setCertificateNotAfter(new Date(2524608000000L)).build());
            generator.generateKeyPair();
        }
        cert=(X509Certificate)keys.getCertificate(ALIAS);fingerprint=PairWire.fingerprint(cert);
    }
    public SSLContext context() throws Exception {
        return PairTls.context((PrivateKey)keys.getKey(ALIAS,null),cert);
    }
    public static String[] suites(String[] supported){return PairTls.suites(supported);}
}
