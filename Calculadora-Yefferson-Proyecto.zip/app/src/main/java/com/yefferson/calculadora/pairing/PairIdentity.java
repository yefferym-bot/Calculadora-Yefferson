package com.yefferson.calculadora.pairing;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.*;
import java.util.*;
import javax.net.ssl.*;
import javax.security.auth.x500.X500Principal;

/** Device-only signing key. First trust requires human SAS confirmation; later trust pins its certificate. */
public final class PairIdentity {
    private final String alias;
    private final KeyStore keys;private final X509Certificate cert;public final String fingerprint;
    public PairIdentity(PairStore store) throws Exception {
        keys=KeyStore.getInstance("AndroidKeyStore");keys.load(null);
        String remembered=store.identityAlias();boolean hasPeers=store.all().length()>0;
        alias=PairIdentityChoice.select(remembered,hasPeers);
        if(!keys.containsAlias(alias)){
            if(hasPeers||remembered!=null)throw new java.io.IOException("No se encuentra la clave de las vinculaciones existentes. Se conservan sin reemplazar su identidad");
            KeyPairGenerator generator=KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA,"AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_SIGN|KeyProperties.PURPOSE_VERIFY)
                .setKeySize(2048).setDigests(KeyProperties.DIGEST_NONE,KeyProperties.DIGEST_SHA256,KeyProperties.DIGEST_SHA384,KeyProperties.DIGEST_SHA512)
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1,KeyProperties.SIGNATURE_PADDING_RSA_PSS)
                // Conscrypt delegates RSA-PSS's already-padded block as a raw private RSA operation.
                // This authorizes KM_PAD_NONE for signing; it does not add encryption/decryption purposes.
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setCertificateSubject(new X500Principal("CN=TruchApp local device"))
                .setCertificateSerialNumber(new BigInteger(120,new SecureRandom()).add(BigInteger.ONE))
                .setCertificateNotBefore(new Date(1577836800000L)).setCertificateNotAfter(new Date(2524608000000L)).build());
            generator.generateKeyPair();
        }
        cert=(X509Certificate)keys.getCertificate(alias);fingerprint=PairWire.fingerprint(cert);
    }
    public SSLContext context() throws Exception {
        PrivateKey key=(PrivateKey)keys.getKey(alias,null);
        SSLContext context=PairTls.context(key,cert);
        if(PairIdentityChoice.CURRENT.equals(alias))PairTls.checkRawRsa(key,cert);
        return context;
    }
    public void remember(PairStore store) throws Exception {store.rememberIdentity(alias);}
    public static String[] suites(String[] supported){return PairTls.suites(supported);}
}
