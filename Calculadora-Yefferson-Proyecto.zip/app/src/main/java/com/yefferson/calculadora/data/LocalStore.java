package com.yefferson.calculadora.data;

import android.content.Context;
import org.json.JSONObject;

/** Device-local persistence boundary for profile, memories, activities and reminders. */
public final class LocalStore {
    private static final String PREFS = "yefferson_ai";
    private static final String KEY_MEMORIES = "memories";
    private static final String KEY_PROFILE = "profile";
    private static final String KEY_ACTIVITIES = "activities";
    private static final String KEY_LOTS = "production_lots";
    private static final String KEY_REMINDERS = "reminders";

    private final android.content.SharedPreferences prefs;

    public LocalStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String getProfile() { return get(KEY_PROFILE, "{}"); }
    public void saveProfile(String json) { put(KEY_PROFILE, json == null ? "{}" : json); }
    public String getMemories() { return get(KEY_MEMORIES, "[]"); }
    public void saveMemories(String json) { put(KEY_MEMORIES, json == null ? "[]" : json); }
    public String getActivities() { return get(KEY_ACTIVITIES, "[]"); }
    public void saveActivities(String json) { put(KEY_ACTIVITIES, json == null ? "[]" : json); }
    /** Production lots are persisted separately so clearing personal AI memory does not erase farm data. */
    public String getLots() { return get(KEY_LOTS, "[]"); }
    public void saveLots(String json) { put(KEY_LOTS, json == null ? "[]" : json); }
    public String getReminders() { return get(KEY_REMINDERS, "[]"); }
    public void saveReminders(String json) { put(KEY_REMINDERS, json == null ? "[]" : json); }

    /** Backup only application-owned primitive preferences, never Android tokens or model files. */
    public JSONObject exportBackupData() throws Exception {
        JSONObject o = new JSONObject();
        for (String k : new String[]{KEY_MEMORIES, KEY_PROFILE, KEY_ACTIVITIES, KEY_LOTS, KEY_REMINDERS}) {
            if (prefs.contains(k)) o.put(k, prefs.getString(k, ""));
        }
        return o;
    }

    public static boolean isBackupDataValid(JSONObject o) {
        java.util.Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String key = it.next();
            if (!(KEY_MEMORIES.equals(key) || KEY_PROFILE.equals(key) || KEY_ACTIVITIES.equals(key)
                    || KEY_LOTS.equals(key) || KEY_REMINDERS.equals(key))) return false;
            if (!(o.opt(key) instanceof String)) return false;
        }
        return true;
    }

    /** Single transaction: either all native backup fields are restored, or none. */
    public boolean restoreBackupData(JSONObject o) {
        if (!isBackupDataValid(o)) return false;
        android.content.SharedPreferences.Editor editor = prefs.edit();
        for (String k : new String[]{KEY_MEMORIES, KEY_PROFILE, KEY_ACTIVITIES, KEY_LOTS, KEY_REMINDERS}) {
            if (o.has(k)) editor.putString(k, o.optString(k));
            else editor.remove(k);
        }
        return editor.commit();
    }

    public void clearPersonalData() {
        prefs.edit().remove(KEY_PROFILE).remove(KEY_MEMORIES).remove(KEY_ACTIVITIES).remove(KEY_REMINDERS).apply();
    }

    private String get(String key, String def) { return prefs.getString(key, def); }
    private void put(String key, String value) { prefs.edit().putString(key, value).apply(); }
}
