package com.yefferson.calculadora.data;

import android.content.Context;

/** Device-local persistence boundary for profile, memories, activities and reminders. */
public final class LocalStore {
    private static final String PREFS = "yefferson_ai";
    private static final String KEY_MEMORIES = "memories";
    private static final String KEY_PROFILE = "profile";
    private static final String KEY_ACTIVITIES = "activities";
    private static final String KEY_LOTS = "production_lots";
    private static final String KEY_REMINDERS = "reminders";

    private final android.content.SharedPreferences prefs;

    public LocalStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String getProfile() { return get(KEY_PROFILE, "{}"); }
    public void saveProfile(String json) { put(KEY_PROFILE, json == null ? "{}" : json); }
    public String getMemories() { return get(KEY_MEMORIES, "[]"); }
    public void saveMemories(String json) { put(KEY_MEMORIES, json == null ? "[]" : json); }
    public String getActivities() { return get(KEY_ACTIVITIES, "[]"); }
    public void saveActivities(String json) { put(KEY_ACTIVITIES, json == null ? "[]" : json); }
    /** Production lots are persisted separately so clearing personal AI memory does not erase farm data. */
    public String getLots() { return get(KEY_LOTS, "[]"); }
    public void saveLots(String json) { put(KEY_LOTS, json == null ? "[]" : json); }
    public String getReminders() { return get(KEY_REMINDERS, "[]"); }
    public void saveReminders(String json) { put(KEY_REMINDERS, json == null ? "[]" : json); }

    public void clearPersonalData() {
        prefs.edit().remove(KEY_PROFILE).remove(KEY_MEMORIES).remove(KEY_ACTIVITIES).remove(KEY_REMINDERS).apply();
    }

    private String get(String key, String def) { return prefs.getString(key, def); }
    private void put(String key, String value) { prefs.edit().putString(key, value).apply(); }
}
