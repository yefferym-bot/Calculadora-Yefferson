package com.yefferson.calculadora;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final String PREFS = "yefferson_ai";
    private static final String KEY_MEMORIES = "memories";
    private static final String KEY_PROFILE = "profile";
    private static final String KEY_ACTIVITIES = "activities";
    private static final String KEY_REMINDERS = "reminders";
    private static final String CHANNEL_ID = "yefferson_reminders";

    private WebView webView;
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final AtomicBoolean downloading = new AtomicBoolean(false);
    private final AtomicInteger progress = new AtomicInteger(0);
    private volatile String modelStatus = "Sin modelo";
    private volatile String modelError = "";
    private File modelFile;
    private int modelContext = 2048;
    private int modelThreads = 4;

    static {
        try {
            System.loadLibrary("yefferson_ai");
        } catch (UnsatisfiedLinkError ignored) {
        }
    }

    private native void nativeInit();
    private native boolean nativeLoadModel(String path, int contextSize, int threads);
    private native boolean nativeIsReady();
    private native String nativeGenerate(String systemPrompt, String userPrompt, int maxTokens);
    private native void nativeRelease();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.BLACK);
        window.setNavigationBarColor(Color.BLACK);

        createNotificationChannel();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidAI");

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);

        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0,
                        insets.getSystemWindowInsetBottom());
                return insets;
            });
        }

        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");

        executor.execute(() -> {
            nativeInit();
            chooseModel();
            if (modelFile.exists() && modelFile.length() > 1_000_000) {
                modelStatus = "Cargando IA local…";
                boolean ok = nativeLoadModel(modelFile.getAbsolutePath(), modelContext, modelThreads);
                modelStatus = ok ? "IA local lista" : "Error al cargar IA";
                if (!ok) modelError = "No se pudo abrir el modelo descargado.";
            } else {
                modelStatus = "Modelo no descargado";
            }
            notifyJsStatus();
        });
    }

    private void chooseModel() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(info);
        long gb = info.totalMem / (1024L * 1024L * 1024L);
        File dir = new File(getFilesDir(), "models");
        if (!dir.exists()) dir.mkdirs();
        if (gb >= 6) {
            modelFile = new File(dir, "Qwen3-1.7B-Q4_K_M.gguf");
            modelContext = 3072;
            modelThreads = Math.max(4, Math.min(Runtime.getRuntime().availableProcessors(), 6));
        } else {
            modelFile = new File(dir, "Qwen3-0.6B-Q8_0.gguf");
            modelContext = 2048;
            modelThreads = Math.max(3, Math.min(Runtime.getRuntime().availableProcessors(), 4));
        }
    }

    private String modelUrl() {
        if (modelFile.getName().contains("1.7B")) {
            return "https://huggingface.co/ggml-org/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf";
        }
        return "https://huggingface.co/ggml-org/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q8_0.gguf";
    }

    private void notifyJsStatus() {
        runOnUiThread(() -> {
            if (webView == null) return;
            String status = JSONObject.quote(getModelStateJson());
            webView.evaluateJavascript("window.onNativeAIStatus && window.onNativeAIStatus(" + status + ")", null);
        });
    }

    private String getModelStateJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("status", modelStatus);
            o.put("progress", progress.get());
            o.put("downloading", downloading.get());
            o.put("ready", nativeIsReady());
            o.put("model", modelFile == null ? "" : modelFile.getName());
            o.put("error", modelError);
            o.put("ramGb", getRamGb());
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    private long getRamGb() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(info);
        return info.totalMem / (1024L * 1024L * 1024L);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Recordatorios Yefferson", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Avisos de actividades programadas");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(ch);
        }
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
    }

    private boolean enoughStorage(long expectedBytes) {
        StatFs fs = new StatFs(getFilesDir().getAbsolutePath());
        long free = fs.getAvailableBytes();
        return free > expectedBytes + (400L * 1024L * 1024L);
    }

    private void downloadModel() {
        if (modelFile == null) chooseModel();
        if (downloading.get()) return;
        if (nativeIsReady()) return;
        runOnUiThread(this::askNotificationPermission);
        downloading.set(true);
        progress.set(0);
        modelError = "";
        modelStatus = "Descargando modelo…";
        notifyJsStatus();

        executor.execute(() -> {
            File part = new File(modelFile.getAbsolutePath() + ".part");
            HttpURLConnection conn = null;
            try {
                URL url = new URL(modelUrl());
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(20_000);
                conn.setReadTimeout(30_000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("User-Agent", "Calculadora-Yefferson/2.0");
                long existing = part.exists() ? part.length() : 0L;
                if (existing > 0) conn.setRequestProperty("Range", "bytes=" + existing + "-");
                int code = conn.getResponseCode();
                boolean partial = code == HttpURLConnection.HTTP_PARTIAL;
                if (code != HttpURLConnection.HTTP_OK && !partial) throw new IOException("HTTP " + code);
                long total = conn.getContentLengthLong();
                if (partial) total += existing;
                if (total <= 0) total = modelFile.getName().contains("1.7B") ? (long)(1.28 * 1024 * 1024 * 1024) : (805L * 1024 * 1024);
                if (!enoughStorage(total)) throw new IOException("No hay espacio suficiente para descargar la IA.");

                FileOutputStream fos = new FileOutputStream(part, partial);
                try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream())) {
                    byte[] buffer = new byte[1024 * 1024];
                    long done = partial ? existing : 0L;
                    int n;
                    int last = -1;
                    while ((n = in.read(buffer)) != -1) {
                        fos.write(buffer, 0, n);
                        done += n;
                        int p = (int) Math.min(100, (done * 100L) / Math.max(1L, total));
                        if (p != last) { progress.set(p); last = p; notifyJsStatus(); }
                    }
                } finally { fos.close(); }

                if (!part.renameTo(modelFile)) {
                    if (modelFile.exists() && !modelFile.delete()) throw new IOException("No se pudo reemplazar el modelo.");
                    if (!part.renameTo(modelFile)) throw new IOException("No se pudo guardar el modelo.");
                }
                modelStatus = "Cargando IA local…";
                notifyJsStatus();
                boolean ok = nativeLoadModel(modelFile.getAbsolutePath(), modelContext, modelThreads);
                modelStatus = ok ? "IA local lista" : "Error al cargar IA";
                if (!ok) modelError = "El modelo se descargó pero no pudo abrirse en este teléfono.";
            } catch (Exception e) {
                modelError = e.getMessage() == null ? "Error desconocido" : e.getMessage();
                modelStatus = "Error de descarga";
            } finally {
                downloading.set(false);
                progress.set(modelStatus.equals("IA local lista") ? 100 : progress.get());
                notifyJsStatus();
            }
        });
    }

    private void scheduleReminderInternal(long id, String title, long whenMillis) {
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(this, (int) id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi);
    }

    private void saveReminder(long id, String title, long whenMillis) {
        try {
            JSONArray arr = new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_REMINDERS, "[]"));
            JSONObject x = new JSONObject();
            x.put("id", id); x.put("title", title); x.put("when", whenMillis);
            arr.put(x);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_REMINDERS, arr.toString()).apply();
        } catch (Exception ignored) {}
        scheduleReminderInternal(id, title, whenMillis);
    }

    private String getPrefs(String key, String def) { return getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, def); }
    private void setPrefs(String key, String value) { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(key, value).apply(); }

    public class AndroidBridge {
        @JavascriptInterface public String getModelState() { return getModelStateJson(); }
        @JavascriptInterface public void downloadModel() { MainActivity.this.downloadModel(); }
        @JavascriptInterface public String getProfile() { return getPrefs(KEY_PROFILE, "{}"); }
        @JavascriptInterface public void saveProfile(String json) { setPrefs(KEY_PROFILE, json == null ? "{}" : json); }
        @JavascriptInterface public String getMemories() { return getPrefs(KEY_MEMORIES, "[]"); }
        @JavascriptInterface public void saveMemories(String json) { setPrefs(KEY_MEMORIES, json == null ? "[]" : json); }
        @JavascriptInterface public String getActivities() { return getPrefs(KEY_ACTIVITIES, "[]"); }
        @JavascriptInterface public void saveActivities(String json) { setPrefs(KEY_ACTIVITIES, json == null ? "[]" : json); }
        @JavascriptInterface public void clearPersonalData() {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .remove(KEY_PROFILE).remove(KEY_MEMORIES).remove(KEY_ACTIVITIES).remove(KEY_REMINDERS).apply();
        }

        @JavascriptInterface public void scheduleReminder(long id, String title, long whenMillis) {
            if (whenMillis <= System.currentTimeMillis()) return;
            runOnUiThread(MainActivity.this::askNotificationPermission);
            saveReminder(id, title, whenMillis);
        }

        @JavascriptInterface public void askAI(final String system, final String user, final int maxTokens, final String requestId) {
            executor.execute(() -> {
                String result;
                if (!nativeIsReady()) {
                    result = "La IA local aún no está lista. Abre la pestaña IA y descarga el modelo primero.";
                } else {
                    result = nativeGenerate(system == null ? "" : system, user == null ? "" : user, Math.max(64, maxTokens));
                    if (result.startsWith("ERROR: ")) result = result.substring(7);
                }
                final String safe = JSONObject.quote(result);
                runOnUiThread(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript("window.onNativeAIResponse && window.onNativeAIResponse(" + JSONObject.quote(requestId) + "," + safe + ")", null);
                    }
                });
            });
        }

        @JavascriptInterface public void requestNotificationPermission() { askNotificationPermission(); }

        @JavascriptInterface public void openAppNotificationSettings() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                startActivity(intent);
            });
        }
    }

    @Override
    public void onDestroy() {
        try { nativeRelease(); } catch (Throwable ignored) {}
        executor.shutdownNow();
        if (webView != null) {
            webView.stopLoading(); webView.loadUrl("about:blank"); webView.removeAllViews(); webView.destroy(); webView = null;
        }
        super.onDestroy();
    }
}
