package com.yefferson.calculadora;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.DecimalFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView display;
    private String input = "0";
    private String operator = "";
    private double firstValue = 0.0;
    private boolean freshInput = true;
    private boolean justCalculated = false;

    private static final int BLACK = Color.rgb(0, 0, 0);
    private static final int DARK_BUTTON = Color.rgb(32, 36, 44);
    private static final int ORANGE = Color.rgb(255, 122, 0);
    private static final int BLUE = Color.rgb(25, 118, 255);
    private static final int WHITE = Color.WHITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(BLACK);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BLACK);
        root.setPadding(dp(20), dp(18), dp(20), dp(14));

        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        titleParams.setMargins(0, 0, 0, dp(4));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView title1 = new TextView(this);
        title1.setText("Calculadora");
        title1.setTextColor(WHITE);
        title1.setTextSize(25);
        title1.setTypeface(Typeface.DEFAULT, Typeface.BOLD);

        TextView title2 = new TextView(this);
        title2.setText(" Yefferson");
        title2.setTextColor(BLUE);
        title2.setTextSize(25);
        title2.setTypeface(Typeface.DEFAULT, Typeface.BOLD);

        titleRow.addView(title1, new LinearLayout.LayoutParams(-2, -2));
        titleRow.addView(title2, new LinearLayout.LayoutParams(-2, -2));
        root.addView(titleRow, titleParams);

        display = new TextView(this);
        display.setText(input);
        display.setTextColor(WHITE);
        display.setTextSize(58);
        display.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        display.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        display.setSingleLine(true);
        display.setIncludeFontPadding(false);
        display.setPadding(0, dp(10), dp(3), dp(12));
        LinearLayout.LayoutParams displayParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        displayParams.setMargins(0, 0, 0, dp(14));
        root.addView(display, displayParams);

        String[][] keys = {
                {"AC", "⌫", "%", "÷"},
                {"7", "8", "9", "×"},
                {"4", "5", "6", "−"},
                {"1", "2", "3", "+"},
                {"±", "0", ".", "="}
        };

        LinearLayout keypad = new LinearLayout(this);
        keypad.setOrientation(LinearLayout.VERTICAL);
        keypad.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams keypadParams = new LinearLayout.LayoutParams(-1, 0, 3.6f);
        root.addView(keypad, keypadParams);

        for (String[] row : keys) {
            LinearLayout rowLayout = new LinearLayout(this);
            rowLayout.setOrientation(LinearLayout.HORIZONTAL);
            rowLayout.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, 0, 1f);
            keypad.addView(rowLayout, rowParams);

            for (String key : row) {
                Button button = makeButton(key);
                LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(0, -1, 1f);
                buttonParams.setMargins(dp(5), dp(5), dp(5), dp(5));
                rowLayout.addView(button, buttonParams);
            }
        }

        setContentView(root);
    }

    private Button makeButton(String key) {
        Button button = new Button(this);
        button.setText(key);
        button.setTextSize(key.equals("AC") || key.equals("⌫") ? 18 : 27);
        button.setTextColor(WHITE);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setPadding(0, 0, 0, 0);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setStateListAnimator(null);
        button.setBackground(roundedBackground(colorForKey(key), dp(28)));
        button.setOnClickListener(v -> handleKey(key));
        return button;
    }

    private GradientDrawable roundedBackground(int color, int radius) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(radius);
        return bg;
    }

    private int colorForKey(String key) {
        if (key.equals("=") ) return BLUE;
        if (key.equals("÷") || key.equals("×") || key.equals("−") || key.equals("+")) return ORANGE;
        return DARK_BUTTON;
    }

    private void handleKey(String key) {
        try {
            switch (key) {
                case "AC":
                    clearAll();
                    break;
                case "⌫":
                    backspace();
                    break;
                case ".":
                    decimal();
                    break;
                case "±":
                    toggleSign();
                    break;
                case "%":
                    input = format(Double.parseDouble(input) / 100.0);
                    freshInput = false;
                    justCalculated = false;
                    break;
                case "÷":
                case "×":
                case "−":
                case "+":
                    chooseOperator(key);
                    break;
                case "=":
                    calculate();
                    break;
                default:
                    digit(key);
                    break;
            }
        } catch (Exception e) {
            input = "Error";
            operator = "";
            freshInput = true;
            justCalculated = true;
        }
        display.setText(input);
    }

    private void clearAll() {
        input = "0";
        operator = "";
        firstValue = 0.0;
        freshInput = true;
        justCalculated = false;
    }

    private void backspace() {
        if (freshInput || justCalculated || input.equals("Error")) {
            input = "0";
            freshInput = false;
            justCalculated = false;
            return;
        }
        if (input.length() <= 1 || (input.length() == 2 && input.startsWith("-"))) {
            input = "0";
        } else {
            input = input.substring(0, input.length() - 1);
        }
    }

    private void decimal() {
        if (justCalculated) {
            input = "0.";
            justCalculated = false;
            freshInput = false;
            return;
        }
        if (freshInput) {
            input = "0.";
            freshInput = false;
            return;
        }
        if (!input.contains(".")) input += ".";
    }

    private void toggleSign() {
        if (input.equals("0") || input.equals("0.")) return;
        input = input.startsWith("-") ? input.substring(1) : "-" + input;
        freshInput = false;
        justCalculated = false;
    }

    private void chooseOperator(String newOperator) {
        if (!operator.isEmpty() && !freshInput) {
            calculate();
        }
        firstValue = parse(input);
        operator = newOperator;
        freshInput = true;
        justCalculated = false;
    }

    private void calculate() {
        if (operator.isEmpty()) return;
        double secondValue = parse(input);
        double result;
        switch (operator) {
            case "+": result = firstValue + secondValue; break;
            case "−": result = firstValue - secondValue; break;
            case "×": result = firstValue * secondValue; break;
            case "÷":
                if (secondValue == 0.0) throw new ArithmeticException("division by zero");
                result = firstValue / secondValue;
                break;
            default: return;
        }
        input = format(result);
        firstValue = result;
        operator = "";
        freshInput = true;
        justCalculated = true;
    }

    private void digit(String digit) {
        if (justCalculated || freshInput || input.equals("0") || input.equals("Error")) {
            input = digit;
            freshInput = false;
            justCalculated = false;
        } else if (input.length() < 14) {
            input += digit;
        }
    }

    private double parse(String value) {
        return Double.parseDouble(value);
    }

    private String format(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return "Error";
        DecimalFormat df = (DecimalFormat) DecimalFormat.getInstance(Locale.US);
        df.applyPattern("0.##########");
        return df.format(value);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
