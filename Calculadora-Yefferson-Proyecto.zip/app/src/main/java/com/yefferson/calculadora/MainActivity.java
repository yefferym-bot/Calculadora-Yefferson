package com.yefferson.calculadora;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.yefferson.calculadora.ai.AiModule;
import com.yefferson.calculadora.data.LocalStore;
import com.yefferson.calculadora.reminders.ReminderManager;
import com.yefferson.calculadora.ui.WebViewHost;

import org.json.JSONObject;


/**
 * Application composition root.
 * UI, AI, persistence and reminders are delegated to their own modules.
 */
public class MainActivity extends Activity {
    private WebView webView;
    private LocalStore store;
    private ReminderManager reminders;
    private AiModule ai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        store = new LocalStore(this);
        reminders = new ReminderManager(this, store);
        ai = new AiModule(this, new AiModule.Listener() {
            @Override
            public void onStateChanged() {
                notifyJsStatus();
            }

            @Override
            public void onResponse(String requestId, String response) {
                final String safeId = JSONObject.quote(requestId == null ? "" : requestId);
                final String safe = JSONObject.quote(response == null ? "" : response);
                runOnUiThread(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript(
                                "window.onNativeAIResponse && window.onNativeAIResponse(" + safeId + "," + safe + ")",
                                null);
                    }
                });
            }
        });

        webView = new WebViewHost().create(this, new AndroidBridge());
        ai.initialize();
    }

    private void notifyJsStatus() {
        runOnUiThread(() -> {
            if (webView == null) return;
            String status = JSONObject.quote(ai.getStateJson());
            webView.evaluateJavascript(
                    "window.onNativeAIStatus && window.onNativeAIStatus(" + status + ")",
                    null);
        });
    }

    public class AndroidBridge {
        @JavascriptInterface public String getModelState() { return ai.getStateJson(); }
        @JavascriptInterface public void downloadModel() { ai.downloadModel(); }

        @JavascriptInterface public String getProfile() { return store.getProfile(); }
        @JavascriptInterface public void saveProfile(String json) { store.saveProfile(json); }
        @JavascriptInterface public String getMemories() { return store.getMemories(); }
        @JavascriptInterface public void saveMemories(String json) { store.saveMemories(json); }
        @JavascriptInterface public String getActivities() { return store.getActivities(); }
        @JavascriptInterface public void saveActivities(String json) { store.saveActivities(json); }
        @JavascriptInterface public void clearPersonalData() { store.clearPersonalData(); ai.clearConversation(); }
        @JavascriptInterface public void clearAIConversation() { ai.clearConversation(); }

        @JavascriptInterface public void scheduleReminder(long id, String title, long whenMillis) {
            if (whenMillis <= System.currentTimeMillis()) return;
            runOnUiThread(() -> reminders.requestNotificationPermission(MainActivity.this));
            reminders.saveReminder(id, title, whenMillis);
        }

        @JavascriptInterface
        public void askAI(String system, String user, int maxTokens, String requestId) {
            ai.ask(system, user, maxTokens, requestId);
        }

        @JavascriptInterface public void requestNotificationPermission() {
            reminders.requestNotificationPermission(MainActivity.this);
        }

        @JavascriptInterface public void openAppNotificationSettings() {
            startActivity(reminders.notificationSettingsIntent());
        }
    }

    @Override
    protected void onDestroy() {
        if (ai != null) ai.release();
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
