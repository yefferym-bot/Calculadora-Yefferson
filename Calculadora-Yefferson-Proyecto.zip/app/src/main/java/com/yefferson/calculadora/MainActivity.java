package com.yefferson.calculadora;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import com.yefferson.calculadora.data.BackupManager;
import com.yefferson.calculadora.data.StorageController;
import com.yefferson.calculadora.pairing.LocalPairingController;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.yefferson.calculadora.ai.AiModule;
import com.yefferson.calculadora.data.LocalStore;
import com.yefferson.calculadora.reminders.ReminderManager;
import com.yefferson.calculadora.ui.WebViewHost;

import org.json.JSONObject;


/**
 * Application composition root.
 * UI, AI, persistence and reminders are delegated to their own modules.
 */
public class MainActivity extends Activity {
    private WebView webView;
    private LocalStore store;
    private ReminderManager reminders;
    private AiModule ai;
    private BackupManager backups;
    private StorageController storage;
    private LocalPairingController pairing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        store = new LocalStore(this);
        storage = new StorageController(this,store);
        reminders = new ReminderManager(this, store);
        ai = new AiModule(this, new AiModule.Listener() {
            @Override
            public void onStateChanged() {
                notifyJsStatus();
            }

            @Override
            public void onResponse(String requestId, String response) {
                final String safeId = JSONObject.quote(requestId == null ? "" : requestId);
                final String safe = JSONObject.quote(response == null ? "" : response);
                runOnUiThread(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript(
                                "window.onNativeAIResponse && window.onNativeAIResponse(" + safeId + "," + safe + ")",
                                null);
                    }
                });
            }
        });

        webView = new WebViewHost().create(this, new AndroidBridge());
        storage.attach(webView);
        pairing = LocalPairingController.get(this, storage.repository());
        pairing.attach(webView);
        backups = new BackupManager(this, store, webView,storage);
        ai.initialize();
    }

    private void notifyJsStatus() {
        runOnUiThread(() -> {
            if (webView == null) return;
            String status = JSONObject.quote(ai.getStateJson());
            webView.evaluateJavascript(
                    "window.onNativeAIStatus && window.onNativeAIStatus(" + status + ")",
                    null);
        });
    }

    public class AndroidBridge {
        @JavascriptInterface public void localPairRequest(String id,String command,String payload){if(pairing!=null)pairing.request(id,command,payload);}
        @JavascriptInterface public void farmRequest(String id,String command,String payload){storage.request(id,command,payload);}
        @JavascriptInterface public String farmCommitSync(String payload){return storage.commitSync(payload);}
        @JavascriptInterface public void reconcileStorageReminders(String old){runOnUiThread(()->reminders.reconcileAfterImport(old));}
        @JavascriptInterface public void exportAppBackup(String snapshot, String password) { if (backups != null) backups.startExport(snapshot, password); }
        @JavascriptInterface public void unlockAppBackup(String password) { if (backups != null) backups.unlockImport(password); }
        @JavascriptInterface public void chooseAppBackup() { if (backups != null) backups.startImport(); }
        @JavascriptInterface public String readImportedWebData() { return backups == null ? "" : backups.getImportWebData(); }
        @JavascriptInterface public boolean saveRecoveryCopy(String oldWeb) { return backups != null && backups.preserveCurrent(oldWeb); }
        @JavascriptInterface public boolean restoreNativeBackup() {
            if (backups == null) return false;
            String oldReminders = store.getReminders();
            boolean ok = backups.applyNativeImport();
            if (ok) runOnUiThread(() -> reminders.reconcileAfterImport(oldReminders));
            return ok;
        }
        @JavascriptInterface public boolean hasRecoveryCopy() { return backups != null && backups.hasSafetyCopy(); }
        @JavascriptInterface public void chooseRecoveryCopy() { if (backups != null) backups.selectSafetyCopy(); }
        @JavascriptInterface public String getModelState() { return ai.getStateJson(); }
        @JavascriptInterface public String getKnowledgeState() { return ai.getKnowledgeStateJson(); }
        @JavascriptInterface public String searchKnowledge(String query, int limit) { return ai.searchKnowledgeJson(query, limit); }
        @JavascriptInterface public void downloadModel() { ai.downloadModel(); }

        @JavascriptInterface public String getProfile() { return store.getProfile(); }
        @JavascriptInterface public void saveProfile(String json) { store.saveProfile(json); }
        @JavascriptInterface public String getMemories() { return store.getMemories(); }
        @JavascriptInterface public void saveMemories(String json) { store.saveMemories(json); }
        @JavascriptInterface public String getActivities() { return store.getActivities(); }
        @JavascriptInterface public void saveActivities(String json) { store.saveActivities(json); }
        @JavascriptInterface public String getLots() { return store.getLots(); }
        @JavascriptInterface public void saveLots(String json) { store.saveLots(json); }
        @JavascriptInterface public void clearPersonalData() { if(pairing!=null)pairing.reset(); store.clearPersonalData(); ai.clearConversation(); }
        @JavascriptInterface public void clearAIConversation() { ai.clearConversation(); }

        @JavascriptInterface public void scheduleReminder(long id, String title, long whenMillis) {
            if (whenMillis <= System.currentTimeMillis()) return;
            runOnUiThread(() -> reminders.requestNotificationPermission(MainActivity.this));
            reminders.saveReminder(id, title, whenMillis);
        }

        @JavascriptInterface
        public void askAI(String system, String user, int maxTokens, String requestId) {
            ai.ask(system, user, maxTokens, requestId);
        }

        @JavascriptInterface public void requestNotificationPermission() {
            reminders.requestNotificationPermission(MainActivity.this);
        }

        @JavascriptInterface public void openAppNotificationSettings() {
            startActivity(reminders.notificationSettingsIntent());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (backups != null) backups.onResult(requestCode, resultCode, data);
    }

    @Override
    protected void onResume() {super.onResume();if(pairing!=null)pairing.foreground();}

    @Override
    protected void onStop() {if(pairing!=null)pairing.pause();super.onStop();}

    @Override
    protected void onDestroy() {
        if(pairing!=null)pairing.detach(webView);
        if(backups!=null)backups.close();
        if(storage!=null)storage.close();
        if (ai != null) ai.release();
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
