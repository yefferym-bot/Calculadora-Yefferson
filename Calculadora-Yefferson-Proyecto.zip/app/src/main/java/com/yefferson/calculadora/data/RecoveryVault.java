package com.yefferson.calculadora.data;

import android.content.Context;
import com.yefferson.calculadora.data.db.FarmRepository;
import org.json.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** Device-key encrypted rotating checkpoints. Portable copies still require an external export. */
public final class RecoveryVault {
    private final Context context;private final FarmRepository repository;private final File directory;
    public RecoveryVault(Context context,FarmRepository repository){this.context=context;this.repository=repository;directory=new File(context.getNoBackupFilesDir(),"farm-recovery");}
    public synchronized JSONObject checkpoint(String reason,boolean force) throws Exception {
        synchronized(repository){
            if(!directory.exists()&&!directory.mkdirs())throw new IOException("No se pudo preparar la carpeta de recuperación");
            long now=System.currentTimeMillis();File today=new File(directory,"daily-"+new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date(now))+".trudb");
            if(!force&&today.exists()&&now-today.lastModified()<10*60000)return summary();
            File temporary=new File(directory,"checkpoint.pending");DatabaseArchive.write(context,repository,temporary,null);
            replace(temporary,today);
            File week=new File(directory,"weekly-"+(now/(7L*86400000))+".trudb"),month=new File(directory,"monthly-"+new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date(now))+".trudb");
            if(!week.exists())copy(today,week);if(!month.exists())copy(today,month);
            if(reason.startsWith("before-")||reason.equals("migration"))copy(today,new File(directory,"safety-"+now+".trudb"));
            prune("daily-",7);prune("weekly-",4);prune("monthly-",6);prune("safety-",3);pruneBudget(today,256L*1024*1024);return summary();
        }
    }
    private static void replace(File from,File to) throws IOException {
        if(!from.renameTo(to))throw new IOException("No se pudo publicar el respaldo. Se conserva la copia anterior.");
    }
    private static void copy(File source,File target) throws IOException {
        File pending=new File(target+".pending");try(InputStream in=new FileInputStream(source);FileOutputStream out=new FileOutputStream(pending)){byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);out.getFD().sync();}replace(pending,target);
    }
    private List<File> files(){File[] found=directory.listFiles(f->f.getName().endsWith(".trudb"));List<File> all=new ArrayList<>();if(found!=null)Collections.addAll(all,found);Collections.sort(all,(a,b)->Long.compare(b.lastModified(),a.lastModified()));return all;}
    private void prune(String prefix,int keep){int count=0;for(File f:files())if(f.getName().startsWith(prefix)&&++count>keep)f.delete();}
    private void pruneBudget(File newest,long budget){List<File> all=files();long total=0;File safety=null;for(File f:all){total+=f.length();if(safety==null&&f.getName().startsWith("safety-"))safety=f;}for(int i=all.size()-1;i>=0&&total>budget;i--){File f=all.get(i);if(!f.equals(newest)&&!f.equals(safety)&&f.delete())total-=f.length();}}
    public synchronized JSONArray list() throws JSONException {JSONArray a=new JSONArray();for(File f:files())a.put(new JSONObject().put("id",f.getName()).put("date",f.lastModified()).put("bytes",f.length()));return a;}
    public synchronized JSONObject summary() throws JSONException {List<File> all=files();long total=0;for(File f:all)total+=f.length();return new JSONObject().put("lastBackup",all.isEmpty()?0:all.get(0).lastModified()).put("copies",all.size()).put("bytes",total).put("external",false);}
    public synchronized DatabaseArchive.Stage stage(String id) throws Exception {
        if(!id.matches("(daily|weekly|monthly|safety)-[0-9-]+\\.trudb"))throw new IOException("Copia no válida");
        File file=new File(directory,id);if(!file.isFile())throw new IOException("La copia ya no está disponible");return DatabaseArchive.stage(context,repository,file,null);
    }
}
