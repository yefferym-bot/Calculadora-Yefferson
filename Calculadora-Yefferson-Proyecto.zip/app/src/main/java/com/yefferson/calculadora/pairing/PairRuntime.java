package com.yefferson.calculadora.pairing;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import javax.net.ssl.SSLSocket;

/** Shared bounded resources for twenty independent TLS sessions. No Android or storage dependency. */
public final class PairRuntime implements AutoCloseable {
    public static final int MAX_CONNECTIONS=20,MAX_HANDSHAKES=4,WRITE_THREADS=4;
    public static final long GLOBAL_OUTBOUND_BYTES=8L*1024*1024;
    final ThreadPoolExecutor writers;
    final ScheduledThreadPoolExecutor timers;
    final long writeMillis,queueMillis;
    private final ThreadPoolExecutor readers;
    private final Semaphore handshakes=new Semaphore(MAX_HANDSHAKES,true);
    private final ConcurrentMap<String,PairSession> active=new ConcurrentHashMap<>(),identities=new ConcurrentHashMap<>();
    private final Map<String,ScheduledFuture<?>> startup=new ConcurrentHashMap<>();
    private final AtomicLong queuedBytes=new AtomicLong(),peakBytes=new AtomicLong(),rejected=new AtomicLong();
    private final AtomicInteger peakConnections=new AtomicInteger(),tlsNow=new AtomicInteger(),peakTls=new AtomicInteger();
    private volatile boolean closed;
    public PairRuntime(ThreadFactory factory){this(factory,3000,20000);}
    public PairRuntime(ThreadFactory factory,long writeMillis,long queueMillis){
        if(writeMillis<20||queueMillis<=writeMillis)throw new IllegalArgumentException("Invalid deadlines");
        this.writeMillis=writeMillis;this.queueMillis=queueMillis;
        readers=new ThreadPoolExecutor(0,MAX_CONNECTIONS,30,TimeUnit.SECONDS,new SynchronousQueue<>(),factory,(task,pool)->{
            try{if(pool.isShutdown()||!pool.getQueue().offer(task,100,TimeUnit.MILLISECONDS))throw new RejectedExecutionException("Session worker unavailable");}
            catch(InterruptedException interrupted){Thread.currentThread().interrupt();throw new RejectedExecutionException(interrupted);}
        });
        writers=new ThreadPoolExecutor(WRITE_THREADS,WRITE_THREADS,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(MAX_CONNECTIONS),factory);writers.allowCoreThreadTimeOut(true);
        timers=new ScheduledThreadPoolExecutor(2,factory);timers.setRemoveOnCancelPolicy(true);timers.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
        timers.scheduleAtFixedRate(()->{try{long now=System.nanoTime();for(PairSession session:active.values())session.tick(now);}catch(Exception ignored){}},1,1,TimeUnit.SECONDS);
    }
    public synchronized void start(PairSession session) throws IOException {
        if(closed||active.size()>=MAX_CONNECTIONS){rejected.incrementAndGet();throw new IOException("Se alcanzó el límite de 20 conexiones simultáneas");}
        active.put(session.id,session);session.attach(this);peak(peakConnections,active.size());
        try{startup.put(session.id,timers.schedule(()->session.fail("La conexión inicial no se completó a tiempo"),45,TimeUnit.SECONDS));readers.execute(()->{try{session.run();}finally{release(session);}});}catch(RejectedExecutionException error){release(session);session.close();throw new IOException("Las conexiones anteriores aún se están cerrando. Vuelve a intentar",error);}
    }
    private synchronized void release(PairSession session){active.remove(session.id,session);if(!session.peer.isEmpty())identities.remove(session.peer,session);interactive(session);}
    public void interactive(PairSession session){ScheduledFuture<?> deadline=startup.remove(session.id);if(deadline!=null)deadline.cancel(false);}
    public void claim(PairSession session) throws IOException {
        if(closed||session.isClosed()||active.get(session.id)!=session)throw new IOException("Conexión cancelada");
        PairSession prior=identities.putIfAbsent(session.peer,session);
        if(prior!=null&&prior!=session&&!(prior.isClosed()&&identities.replace(session.peer,prior,session)))throw new IOException("Este dispositivo ya tiene una conexión abierta");
    }
    public void beforeTls(PairSession session) throws Exception {
        long deadline=System.nanoTime()+25000000000L;
        while(!closed&&!session.isClosed()&&System.nanoTime()<deadline)if(handshakes.tryAcquire(100,TimeUnit.MILLISECONDS)){int count=tlsNow.incrementAndGet();peak(peakTls,count);return;}
        throw new IOException("No se pudo iniciar el cifrado a tiempo. Vuelve a intentar");
    }
    public void afterTls(){tlsNow.decrementAndGet();handshakes.release();}
    public PairOutbound outbound(SSLSocket socket,Runnable abort) throws Exception {return new PairOutbound(this,socket.getOutputStream(),abort);}
    boolean reserve(int amount){for(;;){long prior=queuedBytes.get(),next=prior+amount;if(closed||next>GLOBAL_OUTBOUND_BYTES)return false;if(queuedBytes.compareAndSet(prior,next)){peak(peakBytes,next);return true;}}}
    void releaseBytes(int amount){queuedBytes.addAndGet(-amount);}
    private static void peak(AtomicInteger value,int count){int before;do{before=value.get();if(before>=count)return;}while(!value.compareAndSet(before,count));}
    private static void peak(AtomicLong value,long count){long before;do{before=value.get();if(before>=count)return;}while(!value.compareAndSet(before,count));}
    public int size(){return active.size();}
    public int connected(){int count=0;for(PairSession session:active.values())if(!session.isClosed()&&"connected".equals(session.state))count++;return count;}
    public long queuedBytes(){return queuedBytes.get();}
    public long peakBytes(){return peakBytes.get();}
    public int peakConnections(){return peakConnections.get();}
    public int peakHandshakes(){return peakTls.get();}
    public long rejections(){return rejected.get();}
    public void stopAll(){for(PairSession session:new ArrayList<>(active.values()))session.close();}
    @Override public void close(){closed=true;stopAll();readers.shutdownNow();writers.shutdownNow();timers.shutdownNow();}
}
