package com.yefferson.calculadora;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        try {
            JSONArray arr = new JSONArray(context.getSharedPreferences("yefferson_ai", Context.MODE_PRIVATE).getString("reminders", "[]"));
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject x = arr.getJSONObject(i);
                long when = x.optLong("when", 0);
                long id = x.optLong("id", i + 1);
                if (when <= System.currentTimeMillis()) continue;
                Intent r = new Intent(context, ReminderReceiver.class).putExtra("title", x.optString("title", "Actividad programada")).putExtra("id", id);
                PendingIntent pi = PendingIntent.getBroadcast(context, (int) id, r, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (Exception ignored) {}
    }
}
