package com.yefferson.calculadora;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.yefferson.calculadora.data.LocalStore;
import com.yefferson.calculadora.reminders.ReminderManager;

/** Thin Android entry point; reminder logic stays inside the reminders module. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        new ReminderManager(context, new LocalStore(context)).restoreScheduledReminders();
    }
}
