package com.yefferson.calculadora.pairing;

import java.io.IOException;

/** Never replace an identity that may already have been approved by a peer. */
public final class PairIdentityChoice {
    public static final String LEGACY="truchapp-local-device-v1";
    public static final String CURRENT="truchapp-local-device-v2";
    private PairIdentityChoice() {}
    public static String select(String remembered,boolean hasPeers) throws IOException {
        if(remembered==null)return hasPeers?LEGACY:CURRENT;
        if(!LEGACY.equals(remembered)&&!CURRENT.equals(remembered))throw new IOException("No se reconoce la identidad local guardada; se conserva sin cambios");
        return remembered;
    }
    public static void checkCommit(String remembered,String candidate,boolean hasPeers) throws IOException {
        if(!select(remembered,hasPeers).equals(candidate))throw new IOException("Las vinculaciones cambiaron durante la comprobación. Vuelve a activar la conexión local");
    }
}
