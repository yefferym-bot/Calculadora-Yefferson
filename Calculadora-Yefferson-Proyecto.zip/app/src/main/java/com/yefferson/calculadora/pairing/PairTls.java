package com.yefferson.calculadora.pairing;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.security.*;
import java.security.cert.*;
import java.util.*;
import java.util.concurrent.*;
import javax.net.ssl.*;

/** The same TLS identity selection and trust checks run on Android and in protocol tests. */
public final class PairTls {
    private PairTls() {}

    public static SSLContext context(final PrivateKey key, final X509Certificate cert) throws Exception {
        verifyCertificate(new X509Certificate[]{cert});
        // Check the retained key without exporting, replacing or deleting it.
        byte[] challenge=new byte[32];new SecureRandom().nextBytes(challenge);
        Signature signer=Signature.getInstance("SHA256withRSA");signer.initSign(key);signer.update(challenge);
        byte[] signed=signer.sign();Signature verifier=Signature.getInstance("SHA256withRSA");
        verifier.initVerify(cert.getPublicKey());verifier.update(challenge);
        if(!verifier.verify(signed))throw new InvalidKeyException("La clave y el certificado local no coinciden");
        X509ExtendedKeyManager manager=new X509ExtendedKeyManager(){
            private String select(String type){return "RSA".equals(type)?"device":null;}
            private String select(String[] types){if(types!=null)for(String type:types)if(select(type)!=null)return "device";return null;}
            public String[] getClientAliases(String type,Principal[] issuers){return select(type)==null?null:new String[]{"device"};}
            public String chooseClientAlias(String[] types,Principal[] issuers,Socket socket){return select(types);}
            public String chooseEngineClientAlias(String[] types,Principal[] issuers,SSLEngine engine){return select(types);}
            public String[] getServerAliases(String type,Principal[] issuers){return getClientAliases(type,issuers);}
            public String chooseServerAlias(String type,Principal[] issuers,Socket socket){return select(type);}
            public String chooseEngineServerAlias(String type,Principal[] issuers,SSLEngine engine){return select(type);}
            public X509Certificate[] getCertificateChain(String alias){return "device".equals(alias)?new X509Certificate[]{cert}:null;}
            public PrivateKey getPrivateKey(String alias){return "device".equals(alias)?key:null;}
        };
        // Scoped only to pairing. Human code/persisted certificate still authorize the peer.
        X509TrustManager trust=new X509TrustManager(){
            public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
            public void checkClientTrusted(X509Certificate[] chain,String auth) throws CertificateException{verifyCertificate(chain);}
            public void checkServerTrusted(X509Certificate[] chain,String auth) throws CertificateException{verifyCertificate(chain);}
        };
        SSLContext context=SSLContext.getInstance("TLSv1.2");
        context.init(new KeyManager[]{manager},new TrustManager[]{trust},new SecureRandom());return context;
    }

    public static void verifyCertificate(X509Certificate[] chain) throws CertificateException {
        if(chain==null||chain.length!=1||chain[0]==null)throw new CertificateException("Certificado local inválido");
        X509Certificate cert=chain[0];cert.checkValidity();PublicKey publicKey=cert.getPublicKey();
        if(!(publicKey instanceof java.security.interfaces.RSAPublicKey)||((java.security.interfaces.RSAPublicKey)publicKey).getModulus().bitLength()<2048)
            throw new CertificateException("Clave local insuficiente");
        try{cert.verify(publicKey);}catch(GeneralSecurityException e){throw new CertificateException("Firma del certificado local no válida",e);}
    }

    public static String[] suites(String[] supported){
        List<String> out=new ArrayList<>();
        for(String suite:supported)if(suite.equals("TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256")||suite.equals("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"))out.add(suite);
        if(out.isEmpty())throw new IllegalStateException("El dispositivo no admite el cifrado local requerido");return out.toArray(new String[0]);
    }

    /** Once per controller: exercise this device's actual Keystore/provider before involving a peer. */
    public static void checkLocal(SSLContext context) throws Exception {
        ExecutorService worker=Executors.newSingleThreadExecutor(task->{Thread t=new Thread(task,"TruchApp-TLS-check");t.setDaemon(true);return t;});
        try(final SSLServerSocket listener=(SSLServerSocket)context.getServerSocketFactory().createServerSocket(0,1,InetAddress.getByName("127.0.0.1"))){
        listener.setSoTimeout(5000);listener.setEnabledProtocols(new String[]{"TLSv1.2"});
        listener.setEnabledCipherSuites(suites(listener.getSupportedCipherSuites()));listener.setNeedClientAuth(true);
        Future<?> server=worker.submit(()->{try(SSLSocket socket=(SSLSocket)listener.accept()){
            socket.setSoTimeout(5000);socket.startHandshake();
            // Read one byte so closing the server cannot race the client's handshake completion.
            if(socket.getInputStream().read()!=1)throw new IOException("Autocomprobación incompleta");
            socket.getOutputStream().write(1);socket.getOutputStream().flush();
        }return null;});
        try(SSLSocket client=(SSLSocket)context.getSocketFactory().createSocket()){
            client.setEnabledProtocols(new String[]{"TLSv1.2"});client.setEnabledCipherSuites(suites(client.getSupportedCipherSuites()));client.setSoTimeout(5000);
            client.connect(new java.net.InetSocketAddress("127.0.0.1",listener.getLocalPort()),5000);client.startHandshake();
            client.getOutputStream().write(1);client.getOutputStream().flush();
            if(client.getInputStream().read()!=1)throw new IOException("Autocomprobación incompleta");
            server.get(1,TimeUnit.SECONDS);
        }catch(Exception e){
            if(server.isDone())try{server.get();}catch(ExecutionException remote){Throwable cause=remote.getCause();if(cause instanceof Exception)throw (Exception)cause;}catch(CancellationException ignored){}
            throw e;
        }finally{try{listener.close();}finally{server.cancel(true);}}
        }finally{worker.shutdownNow();}
    }
}
