package com.yefferson.calculadora.pairing;

import org.json.*;
import java.io.IOException;
import java.util.*;

/** Assigned lot documents only. No inventory, finance, profile or whole-store writes. */
public final class PairProduction {
    public static final String LOTS="truchapp_lotes_v1",WATER="truchapp_lotes_water_quality_v1";
    public static final int MAX_DOCUMENT=3*1024*1024,CHUNK=24000;
    public static String canonical(Object v) throws Exception {
        if(v instanceof JSONObject){JSONObject o=(JSONObject)v;List<String> keys=new ArrayList<>();Iterator<String> it=o.keys();while(it.hasNext())keys.add(it.next());Collections.sort(keys);StringBuilder out=new StringBuilder("{");for(String k:keys){if(out.length()>1)out.append(',');out.append(JSONObject.quote(k)).append(':').append(canonical(o.get(k)));}return out.append('}').toString();}
        if(v instanceof JSONArray){JSONArray a=(JSONArray)v;StringBuilder out=new StringBuilder("[");for(int i=0;i<a.length();i++){if(i>0)out.append(',');out.append(canonical(a.get(i)));}return out.append(']').toString();}
        return v==null||v==JSONObject.NULL?"null":v instanceof String?JSONObject.quote((String)v):v.toString();
    }
    public static String hash(JSONObject value) throws Exception {return PairWire.hash(canonical(value));}
    public static JSONObject find(JSONArray lots,String id) throws Exception {for(int i=0;i<lots.length();i++){JSONObject lot=lots.getJSONObject(i);if(id.equals(lot.optString("id")))return lot;}throw new IOException("El lote ya no existe o no está disponible");}
    public static boolean belongs(JSONObject r,JSONObject lot){return lot.optString("id").equals(r.optString("lotId"))||r.optString("lotId").isEmpty()&&lot.optString("code").equals(r.optString("lotCode"));}
    public static JSONObject snapshot(JSONArray lots,JSONArray readings,String id) throws Exception {
        JSONObject lot=find(lots,id);JSONArray water=new JSONArray();for(int i=0;i<readings.length();i++)if(belongs(readings.getJSONObject(i),lot))water.put(readings.getJSONObject(i));
        return new JSONObject().put("lot",new JSONObject(lot.toString())).put("water",water);
    }
    public static JSONArray summaries(JSONArray lots,JSONArray ids) throws Exception {
        Set<String> allowed=new HashSet<>();for(int i=0;i<ids.length();i++)allowed.add(ids.getString(i));JSONArray out=new JSONArray();
        for(int i=0;i<lots.length();i++){JSONObject lot=lots.getJSONObject(i);if(!allowed.contains(lot.optString("id")))continue;JSONObject row=new JSONObject();for(String key:new String[]{"id","code","stage","unit","origin","cageAssignment","date","initialN","n","w","l","m","discarded","alimentoConsumido","fcr","targetWeight","targetMax","listCards"})if(lot.has(key))row.put(key,lot.get(key));String today=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).format(new Date());JSONObject d=lot.optJSONObject("detailState");row.put("economicsStamp",PairWire.hash(canonical(d==null?JSONObject.NULL:new JSONObject().put("economics",d.opt("economics")).put("allocations",d.opt("feedAllocations")))));JSONArray daily=d==null?null:d.optJSONArray("daily");if(daily!=null)for(int j=0;j<daily.length();j++){JSONObject r=daily.getJSONObject(j);if(today.equals(r.optString("date")))row.put("todayFeed",r.opt("feed"));}out.put(row);}
        return out;
    }
    private static void fail(String m) throws IOException {throw new IOException(m);}
    private static double number(JSONObject row,String key,boolean integer) throws Exception {
        Object raw=row.opt(key);if(raw==null||raw==JSONObject.NULL)return 0;if(!(raw instanceof Number))throw new IOException("Cantidad no numérica: "+key);double value=((Number)raw).doubleValue();if((Double.isNaN(value)||Double.isInfinite(value))||value<0||value>1e12||integer&&value!=Math.rint(value))fail("Cantidad fuera de rango: "+key);return value;
    }
    private static void economicAmounts(JSONObject value,String[] keys) throws Exception {
        if(value==null||value.length()!=keys.length)fail("Datos económicos no válidos");
        for(String key:keys){if(!value.has(key))fail("Falta un campo económico");number(value,key,false);}
    }
    private static void economics(JSONObject detail) throws Exception {
        if(!detail.has("economics"))return;JSONObject e=detail.optJSONObject("economics");
        if(e==null||!(e.opt("version") instanceof Number))fail("Versión de costos no válida");double version=((Number)e.opt("version")).doubleValue();if(version!=1&&version!=2||e.length()!=(version==2?6:5)||!e.has("foodPrice")||version==2&&!Arrays.asList("unit","total").contains(e.optString("seedMode")))fail("Versión de costos no válida");number(e,"foodPrice",false);
        economicAmounts(e.optJSONObject("expenses"),new String[]{"alevines","sanidad","mano","energia","otros","fijos"});
        JSONObject projection=e.optJSONObject("projection");economicAmounts(projection,new String[]{"weight","survival","futureCost","salePrice"});
        if(!projection.isNull("survival")&&projection.getDouble("survival")>100||!projection.isNull("weight")&&projection.getDouble("weight")<=0)fail("Revisa el peso y la supervivencia de la proyección");
        economicAmounts(e.optJSONObject("weighted"),new String[]{"stockKg","stockPrice","newKg","newPrice"});
    }
    private static void text(JSONObject o,String k,int max) throws Exception {if(!(o.opt(k) instanceof String)||o.getString(k).length()>max)fail("Texto no válido: "+k);}
    private static void date(String value) throws Exception {try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);f.setLenient(false);if(!value.matches("\\d{4}-\\d{2}-\\d{2}")||!value.equals(f.format(f.parse(value))))fail("Fecha no válida");}catch(java.text.ParseException e){fail("Fecha no válida");}}
    private static void row(JSONObject r,String start,Set<String> ids) throws Exception {
        String id=r.optString("id"),d=r.optString("date"),time=r.optString("time");if(id.isEmpty()||id.length()>180||!ids.add(id))fail("Identificador de registro repetido o inválido");date(d);
        String today=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).format(new Date());if(d.compareTo(start)<0||d.compareTo(today)>0||!time.matches("([01]\\d|2[0-3]):[0-5]\\d")||r.optBoolean("simulated"))fail("Fecha u hora del registro no válida");
    }
    private static JSONObject previousDay(JSONObject lot,String date) throws Exception {JSONObject detail=lot.optJSONObject("detailState");JSONArray rows=detail==null?null:detail.optJSONArray("daily");if(rows!=null)for(int i=0;i<rows.length();i++)if(date.equals(rows.getJSONObject(i).optString("date")))return rows.getJSONObject(i);return null;}
    private static JSONArray entries(JSONObject day) throws Exception {if(day==null)return new JSONArray();if(day.optInt("entriesVersion")==1)return day.getJSONArray("entries");return new JSONArray().put(new JSONObject(day.toString()).put("kind","dailyTotal"));}
    private static boolean sameStockEntry(JSONObject day,JSONObject entry) throws Exception {JSONArray previous=entries(day);for(int i=0;i<previous.length();i++)if(canonical(previous.getJSONObject(i)).equals(canonical(entry)))return true;return false;}
    private static boolean reservedEntry(JSONObject e) throws Exception {JSONObject stock=e.optJSONObject("feedStock");JSONArray lines=stock==null?null:stock.optJSONArray("lines");if(lines==null||lines.length()==0)return false;for(int i=0;i<lines.length();i++)if(lines.getJSONObject(i).optString("allocationId").isEmpty())return false;return true;}
    private static boolean reservedDelta(JSONObject oldDay,JSONObject nextDay) throws Exception {
        JSONArray next=nextDay.getJSONObject("feedStock").getJSONArray("lines"),previous=oldDay==null||!oldDay.has("feedStock")?new JSONArray():oldDay.getJSONObject("feedStock").getJSONArray("lines");
        for(int i=0;i<next.length();i++){JSONObject line=next.getJSONObject(i);if(!line.optString("allocationId").isEmpty())continue;boolean found=false;for(int j=0;j<previous.length();j++)if(canonical(previous.getJSONObject(j)).equals(canonical(line)))found=true;if(!found)return false;}return true;
    }
    private static void reservedConsumption(JSONObject previous,JSONObject detail) throws Exception {
        if(!canonical(previous==null?null:previous.opt("feedAllocations")).equals(canonical(detail.opt("feedAllocations"))))fail("Las asignaciones se gestionan desde el administrador");
        JSONArray allocations=detail.optJSONArray("feedAllocations");Map<String,JSONObject> by=new HashMap<>();Map<String,Double> used=new HashMap<>();
        if(allocations!=null){if(allocations.length()>1000)fail("Demasiadas asignaciones");for(int i=0;i<allocations.length();i++){JSONObject a=allocations.getJSONObject(i);String id=a.getString("id");if(by.put(id,a)!=null||number(a,"kg",false)<=0||number(a,"kgPerUnit",false)<=0)fail("Asignación inválida");number(a,"unitCost",false);date(a.getString("date"));}}
        JSONArray days=detail.getJSONArray("daily");for(int i=0;i<days.length();i++){JSONObject day=days.getJSONObject(i);JSONArray rows=entries(day),flattened=new JSONArray();boolean reserved=false;Set<String> ids=new HashSet<>();
            for(int j=0;j<rows.length();j++){JSONObject entry=rows.getJSONObject(j),stock=entry.optJSONObject("feedStock");if(stock==null)continue;if(stock.optInt("version")!=1)fail("Versión de entrega inválida");JSONArray lines=stock.getJSONArray("lines");double sum=0;
                for(int k=0;k<lines.length();k++){JSONObject line=lines.getJSONObject(k);flattened.put(line);String allocationId=line.optString("allocationId");if(allocationId.isEmpty())continue;reserved=true;JSONObject a=by.get(allocationId);if(a==null||!ids.add(line.getString("id")))fail("Saco asignado inválido o duplicado");double kg=number(line,"kg",false);if(kg<=0)fail("Cantidad de alimento inválida");sum+=kg;
                    for(String field:new String[]{"itemId","batch","unit","kgPerUnit","unitCost"})if(!canonical(a.opt(field)).equals(canonical(line.opt(field))))fail("El costo o producto asignado no coincide");
                    if((entry.getString("date")+"T"+entry.getString("time")).compareTo(a.getString("date")+"T"+a.getString("time"))<0||!a.optString("expiry").isEmpty()&&entry.getString("date").compareTo(a.getString("expiry"))>0)fail("Consumo anterior a la asignación o alimento vencido");
                    double total=used.getOrDefault(allocationId,0d)+kg;used.put(allocationId,total);if(total>number(a,"kg",false)+1e-6)fail("El consumo supera la asignación");
                }
                if(reservedEntry(entry)&&Math.abs(sum-number(entry,"feed",false))>1e-6)fail("El alimento no coincide con el saco asignado");
            }
            if((reserved||flattened.length()>0)&&(!day.has("feedStock")||day.getJSONObject("feedStock").optInt("version")!=1||!canonical(flattened).equals(canonical(day.getJSONObject("feedStock").getJSONArray("lines")))))fail("Las líneas asignadas no coinciden con el total diario");
        }
    }
    /** A full-record grant cannot change the initial stock/date or use another lot's water IDs. */
    public static void validate(JSONObject current,JSONObject proposed) throws Exception {
        if(proposed.length()!=2)fail("Documento compartido no válido");JSONObject old=current.getJSONObject("lot"),lot=proposed.getJSONObject("lot");JSONArray water=proposed.getJSONArray("water");
        for(String key:new String[]{"id","initialN","date"})if(!canonical(old.opt(key)).equals(canonical(lot.opt(key))))fail("No puedes cambiar los datos iniciales del lote compartido");
        for(String key:new String[]{"code","stage","unit","origin"})text(lot,key,key.equals("origin")?500:180);if(lot.getString("code").trim().isEmpty())fail("Escribe el código del lote");
        JSONObject detail=lot.getJSONObject("detailState"),info=detail.getJSONObject("lot");if(detail.optInt("version")!=2||detail.optBoolean("demoScenario"))fail("Detalle compartido incompatible");
        for(String key:new String[]{"id","initialN","date","code"})if(!canonical(lot.opt(key)).equals(canonical(info.opt(key))))fail("La ficha y el detalle no coinciden");
        economics(detail);reservedConsumption(old.optJSONObject("detailState"),detail);
        String start=lot.getString("date");date(start);double initial=number(lot,"initialN",true);if(initial<=0)fail("Existencias iniciales no válidas");
        JSONArray samples=detail.getJSONArray("samples"),daily=detail.getJSONArray("daily");if(samples.length()==0||samples.length()>20000||daily.length()>20000||water.length()>20000)fail("Demasiados registros en el lote");
        double mortality=0,discard=0,food=0;boolean hasFood=false;String last="";double weight=0;Set<String> ids=new HashSet<>(),dates=new HashSet<>();
        for(int i=0;i<samples.length();i++){JSONObject r=samples.getJSONObject(i);row(r,start,ids);double w=number(r,"weight",false);String stamp=r.getString("date")+r.getString("time");if(stamp.compareTo(last)>=0){last=stamp;weight=w;}if(r.optBoolean("legacyPeriod")){mortality+=number(r,"mortality",true);discard+=number(r,"discard",true);if(!r.isNull("feed")){food+=number(r,"feed",false);hasFood=true;}}}
        JSONObject balance=detail.optJSONObject("openingBalance");double adjustment=0;if(balance!=null){mortality+=number(balance,"mortality",true);discard+=number(balance,"discard",true);adjustment=number(balance,"stockAdjustment",true);if(!balance.isNull("feed")){food+=number(balance,"feed",false);hasFood=true;}}
        for(int i=0;i<daily.length();i++){JSONObject d=daily.getJSONObject(i);row(d,start,ids);if(!dates.add(d.getString("date")))fail("Fecha diaria duplicada");
            JSONObject oldDay=previousDay(old,d.getString("date"));if(d.has("feedStock")&&(oldDay==null||!canonical(oldDay.opt("feedStock")).equals(canonical(d.get("feedStock")))))if(!reservedDelta(oldDay,d))fail("Las salidas de almacén se registran desde el administrador");
            if(d.has("entriesVersion")){if(d.optInt("entriesVersion")!=1)fail("Versión de registros diarios inválida");JSONArray entries=d.getJSONArray("entries");if(entries.length()<1||entries.length()>500)fail("El día admite hasta 500 registros");Set<String> local=new HashSet<>();double[] sums={0,0,0};boolean[] known={false,false,false};String[] keys={"feed","mortality","discard"};for(int j=0;j<entries.length();j++){JSONObject e=entries.getJSONObject(j);row(e,start,local);if(!d.getString("date").equals(e.getString("date"))||e.has("feedStock")&&!sameStockEntry(oldDay,e)&&!reservedEntry(e)||!(e.optString("kind").equals("moment")||e.optString("kind").equals("dailyTotal")))fail("Registro por momento no válido");text(e,"note",1000);text(e,"appetite",40);for(int k=0;k<3;k++)if(!e.isNull(keys[k])){sums[k]+=number(e,keys[k],k>0);known[k]=true;}}for(int k=0;k<3;k++)if(known[k]!=!d.isNull(keys[k])||known[k]&&Math.abs(number(d,keys[k],k>0)-sums[k])>1e-6)fail("Los totales diarios no coinciden con sus registros");}
            mortality+=number(d,"mortality",true);discard+=number(d,"discard",true);if(!d.isNull("feed")){food+=number(d,"feed",false);hasFood=true;}
        }
        // Preserve each stock-linked delivery, while permitting extra manual entries on the same date.
        JSONObject oldDetail=old.optJSONObject("detailState");if(oldDetail!=null){JSONArray previous=oldDetail.optJSONArray("daily");if(previous!=null)for(int i=0;i<previous.length();i++){JSONObject p=previous.getJSONObject(i);JSONArray oldEntries=entries(p);for(int j=0;j<oldEntries.length();j++){JSONObject e=oldEntries.getJSONObject(j);if(!e.has("feedStock")||reservedEntry(e))continue;JSONObject nextDay=previousDay(lot,p.getString("date"));boolean preserved=false;JSONArray nextEntries=entries(nextDay);for(int k=0;k<nextEntries.length();k++)if(canonical(nextEntries.getJSONObject(k)).equals(canonical(e)))preserved=true;if(!preserved)fail("Las entregas vinculadas se corrigen desde el administrador");}}}

        double fish=initial-adjustment-mortality-discard;if(fish<0||Math.abs(number(lot,"n",true)-fish)>1e-6||Math.abs(number(lot,"m",true)-mortality)>1e-6||Math.abs(number(lot,"discarded",true)-discard)>1e-6||Math.abs(number(lot,"w",false)-weight)>1e-6||hasFood!=!lot.isNull("alimentoConsumido")||hasFood&&Math.abs(number(lot,"alimentoConsumido",false)-food)>1e-6)fail("Los indicadores no coinciden con los registros del lote");
        Set<String> waterIds=new HashSet<>();for(int i=0;i<water.length();i++){JSONObject r=water.getJSONObject(i);if(!belongs(r,lot))fail("Una medición corresponde a otro lote");row(r,start,waterIds);}
    }
    public static JSONObject patch(JSONArray lots,JSONArray allWater,String id,JSONObject proposed) throws Exception {
        JSONObject current=snapshot(lots,allWater,id);validate(current,proposed);JSONObject lot=proposed.getJSONObject("lot");JSONArray nextLots=new JSONArray(),nextWater=new JSONArray();Set<String> occupied=new HashSet<>();
        for(int i=0;i<lots.length();i++){JSONObject old=lots.getJSONObject(i);if(!id.equals(old.optString("id"))&&old.optString("code").trim().equalsIgnoreCase(lot.optString("code").trim()))fail("Ya existe otro lote con ese código");nextLots.put(id.equals(old.optString("id"))?lot:old);}
        for(int i=0;i<allWater.length();i++){JSONObject r=allWater.getJSONObject(i);if(!belongs(r,current.getJSONObject("lot"))){nextWater.put(r);occupied.add(r.optString("id"));}}
        JSONArray water=proposed.getJSONArray("water");for(int i=0;i<water.length();i++){JSONObject r=water.getJSONObject(i);if(occupied.contains(r.optString("id")))fail("El identificador de agua pertenece a otro lote");nextWater.put(r);}
        return new JSONObject().put(LOTS,nextLots.toString()).put(WATER,nextWater.toString());
    }
}
