package com.yefferson.calculadora.data;

import android.content.Context;
import android.database.Cursor;
import com.yefferson.calculadora.data.db.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk=28,manifest=Config.NONE)
public class StorageTest {
    private Context context;private FarmRepository repository;private ExecutorService worker;
    private <T>T background(Callable<T> action) throws Exception {return worker.submit(action).get(120,TimeUnit.SECONDS);}
    private JSONObject source() throws Exception {
        JSONObject lot=new JSONObject("{id:'L',code:'Engorde',stage:'Engorde',date:'2021-01-01',initialN:1000,initialWeight:100,n:1000,w:100,m:0,discarded:0,targetWeight:250,history:[]}");
        return new JSONObject().put(DocumentCodec.LOTS,new JSONArray().put(lot).toString()).put(DocumentCodec.WATER,"[]").put("activities","[]");
    }
    private long revision() throws Exception {return repository.health().getLong("revision");}
    @Before public void setup() throws Exception {
        context=RuntimeEnvironment.getApplication();worker=Executors.newSingleThreadExecutor();
        File pointer=new File(context.getFilesDir(),"farm-database.active");pointer.delete();new File(pointer+".bak").delete();
        for(String name:context.databaseList())if(name.startsWith("truchapp-"))context.deleteDatabase(name);
        repository=new FarmRepository(context);
    }
    @After public void close() throws Exception {background(()->{repository.database().close();return null;});worker.shutdownNow();}
    @Test public void preservesMoreThanFiveHundredWaterReadings() throws Exception {background(()->{
        JSONObject data=source();JSONArray water=new JSONArray();for(int i=0;i<1200;i++)water.put(new JSONObject().put("id","W"+i).put("date","2026-10-01").put("lotId","L").put("params",new JSONObject().put("oxygen",new JSONObject().put("value",6.5))));data.put(DocumentCodec.WATER,water.toString());
        repository.bootstrap(data,new JSONObject());assertEquals(1200,repository.health().getLong("water"));assertEquals(1200,new JSONArray(repository.read(DocumentCodec.WATER,"[]")).length());return null;
    });}
    @Test public void keepsWebLotsWhenNativeCopyIsEmpty() throws Exception {background(()->{repository.bootstrap(source(),new JSONObject().put("production_lots","[]"));assertEquals(1,repository.health().getLong("lots"));return null;});}
    @Test public void invalidMigrationDoesNotActivateAnEmptyStore() throws Exception {background(()->{
        JSONObject data=source().put(DocumentCodec.WATER,"{broken");try{repository.bootstrap(data,new JSONObject());fail();}catch(Exception expected){}assertFalse(repository.ready());assertEquals("{broken",data.getString(DocumentCodec.WATER));return null;
    });}
    @Test public void rejectsDuplicateIdsWithoutReplacingTheGoodVersion() throws Exception {background(()->{
        repository.bootstrap(source(),new JSONObject());long before=revision();try{repository.write(new JSONObject().put(DocumentCodec.WATER,"[{id:'W'},{id:'W'}]"),before,"duplicate","Agua",false);fail();}catch(Exception expected){}assertEquals(before,revision());assertEquals("[]",repository.read(DocumentCodec.WATER,"[]"));return null;
    });}
    @Test public void actualDatabaseFailureRollsBackEveryRelatedDocument() throws Exception {background(()->{
        repository.bootstrap(source(),new JSONObject());String before=repository.snapshot().toString();long revision=revision();
        repository.database().getOpenHelper().getWritableDatabase().execSQL("CREATE TRIGGER fail_water BEFORE INSERT ON farm_records WHEN NEW.kind='water' BEGIN SELECT RAISE(ABORT,'simulated write failure'); END");
        JSONObject lots=new JSONArray(repository.read(DocumentCodec.LOTS,"[]")).getJSONObject(0);lots.put("n",999);
        try{repository.write(new JSONObject().put(DocumentCodec.LOTS,new JSONArray().put(lots).toString()).put(DocumentCodec.WATER,"[{id:'W',date:'2026-10-22'}]"),revision,"failure","Lote y agua",false);fail();}catch(Exception expected){}
        assertEquals(revision,revision());assertEquals(before,repository.snapshot().toString());return null;
    });}
    @Test public void retryAfterLostAcknowledgementIsIdempotent() throws Exception {background(()->{
        repository.bootstrap(source(),new JSONObject());long before=revision();JSONObject patch=new JSONObject().put(DocumentCodec.WATER,"[{id:'W',date:'2026-10-22'}]");
        repository.write(patch,before,"same-operation","Agua",false);JSONObject repeated=repository.write(patch,before,"same-operation","Agua",false);assertTrue(repeated.getBoolean("replayed"));assertEquals(1,repository.health().getLong("water"));assertEquals(before+1,revision());return null;
    });}
    @Test public void rejectsAnOldRevision() throws Exception {background(()->{
        repository.bootstrap(source(),new JSONObject());long before=revision();repository.write(new JSONObject().put("setting","1"),before,"first","Preferencias",false);try{repository.write(new JSONObject().put("setting","2"),before,"late","Preferencias",false);fail();}catch(Exception expected){}assertEquals("1",repository.read("setting",null));return null;
    });}
    @Test public void deletingAndUndoingRestoresAllLinkedChanges() throws Exception {background(()->{
        repository.bootstrap(source(),new JSONObject());String before=repository.read(DocumentCodec.LOTS,null);repository.write(new JSONObject().put(DocumentCodec.LOTS,"[]").put("costArchive","{\"L\":4}"),revision(),"delete","Eliminar lote",false);
        assertEquals(0,repository.health().getLong("lots"));repository.undo("delete",revision());assertEquals(before,repository.read(DocumentCodec.LOTS,null));assertNull(repository.read("costArchive",null));return null;
    });}
    @Test public void undoDoesNotOverwriteALaterCorrection() throws Exception {background(()->{
        repository.bootstrap(source(),new JSONObject());repository.write(new JSONObject().put("setting","1"),revision(),"first","Ajuste",false);repository.write(new JSONObject().put("setting","2"),revision(),"second","Ajuste",false);
        try{repository.undo("first",revision());fail();}catch(Exception expected){}assertEquals("2",repository.read("setting",null));return null;
    });}
    @Test public void normalizedNestedRecordsAreLosslessAndIndexed() throws Exception {background(()->{
        JSONObject data=source(),lot=new JSONArray(data.getString(DocumentCodec.LOTS)).getJSONObject(0);lot.put("detailState",new JSONObject("{samples:[{id:'S',date:'2021-01-02',weight:110,individualWeights:[100,120]}],daily:[{id:'D',date:'2021-01-02',feed:2,mortality:0,discard:null,feedStock:{lines:[{id:'F',kg:2,itemId:'P'}]}}]}"));data.put(DocumentCodec.LOTS,new JSONArray().put(lot).toString());repository.bootstrap(data,new JSONObject());
        JSONObject decoded=new JSONArray(repository.read(DocumentCodec.LOTS,"[]")).getJSONObject(0).getJSONObject("detailState");assertTrue(decoded.getJSONArray("daily").getJSONObject(0).isNull("discard"));assertEquals(120,decoded.getJSONArray("samples").getJSONObject(0).getJSONArray("individualWeights").getInt(1));
        JSONObject page=repository.page(new JSONObject().put("kind","daily").put("lotId","L"));assertEquals(2,page.getJSONArray("rows").getJSONObject(0).getJSONObject("feedStock").getJSONArray("lines").getJSONObject(0).getInt("kg"));
        try(Cursor cursor=repository.database().getOpenHelper().getReadableDatabase().query("EXPLAIN QUERY PLAN SELECT * FROM farm_records WHERE kind='daily' AND lotId='L' AND date>'2021-01-01'")){assertTrue(cursor.moveToFirst());assertTrue(cursor.getString(3).contains("INDEX"));}return null;
    });}
    @Test public void prependingOneMeasurementDoesNotRewriteTheHistory() throws Exception {background(()->{
        JSONObject data=source();JSONArray water=new JSONArray();for(int i=0;i<100;i++)water.put(new JSONObject().put("id","W"+i).put("date","2026-10-01"));data.put(DocumentCodec.WATER,water.toString());repository.bootstrap(data,new JSONObject());JSONArray next=new JSONArray().put(new JSONObject().put("id","NEW").put("date","2026-10-22"));for(int i=0;i<water.length();i++)next.put(water.get(i));
        JSONObject result=repository.write(new JSONObject().put(DocumentCodec.WATER,next.toString()),revision(),"prepend","Agua",false);assertEquals(1,result.getInt("changedRows"));return null;
    });}
    @Test public void portableArchiveAuthenticatesAndRestoresANewGeneration() throws Exception {background(()->{
        repository.bootstrap(source(),new JSONObject());File file=File.createTempFile("roundtrip",".trudb",context.getCacheDir());char[] secret="contraseña de prueba 123".toCharArray();DatabaseArchive.write(context,repository,file,secret);DatabaseArchive.Stage staged=DatabaseArchive.stage(context,repository,file,secret);
        assertEquals(1,staged.metadata.getJSONObject("counts").getInt("lots"));repository.activate(staged.database,staged.name);assertEquals(1,repository.health().getLong("lots"));FarmRepository reopened=new FarmRepository(context);assertEquals(1,reopened.health().getLong("lots"));reopened.database().close();return null;
    });}
    @Test public void damagedOrWrongPasswordArchivesCannotReplaceCurrentData() throws Exception {background(()->{
        repository.bootstrap(source(),new JSONObject());String before=repository.snapshot().toString();File file=File.createTempFile("tamper",".trudb",context.getCacheDir());char[] secret="contraseña de prueba 123".toCharArray();DatabaseArchive.write(context,repository,file,secret);
        try{DatabaseArchive.stage(context,repository,file,"contraseña equivocada 123".toCharArray());fail();}catch(Exception expected){}
        try(RandomAccessFile altered=new RandomAccessFile(file,"rw")){long at=altered.length()/2;altered.seek(at);int b=altered.read();altered.seek(at);altered.write(b^1);}
        try{DatabaseArchive.stage(context,repository,file,secret);fail();}catch(Exception expected){}assertEquals(before,repository.snapshot().toString());return null;
    });}
    @Test public void fiveYearsOfDailyDataPreserveCountsAndTotals() throws Exception {background(()->{
        JSONObject data=source(),lot=new JSONArray(data.getString(DocumentCodec.LOTS)).getJSONObject(0);JSONArray days=new JSONArray();for(int i=0;i<1826;i++)days.put(new JSONObject().put("id","D"+i).put("date",String.format(Locale.US,"%04d-%02d-%02d",2021+i/365,1+(i%365)/31,1+i%28)).put("feed",2).put("mortality",0).put("discard",JSONObject.NULL));lot.put("detailState",new JSONObject().put("daily",days));data.put(DocumentCodec.LOTS,new JSONArray().put(lot).toString());repository.bootstrap(data,new JSONObject());assertEquals(1826,repository.health().getLong("daily"));JSONArray restored=new JSONArray(repository.read(DocumentCodec.LOTS,"[]")).getJSONObject(0).getJSONObject("detailState").getJSONArray("daily");double feed=0;for(int i=0;i<restored.length();i++)feed+=restored.getJSONObject(i).getDouble("feed");assertEquals(3652,feed,0);return null;
    });}
    @Test public void scalarPreferencesRemainByteExactAfterReopening() throws Exception {background(()->{
        JSONObject data=source().put("truchapp_lotes_water_active_farm_v1","GRANJA-ABC").put("truchapp_menu_reduce_motion_v1","1");repository.bootstrap(data,new JSONObject());
        FarmRepository reopened=new FarmRepository(context);assertEquals("GRANJA-ABC",reopened.read("truchapp_lotes_water_active_farm_v1",null));assertEquals("1",reopened.read("truchapp_menu_reduce_motion_v1",null));reopened.database().close();return null;
    });}
    @Test public void importingOldBackupKeepsItsNativeProductionLots() throws Exception {background(()->{
        JSONObject before=source();repository.bootstrap(before,new JSONObject());JSONObject payload=new JSONObject().put("web",new JSONObject().put(DocumentCodec.LOTS,"[]")).put("native",new JSONObject().put("production_lots",before.getString(DocumentCodec.LOTS)));
        DatabaseArchive.Stage stage=DatabaseArchive.legacy(context,repository,payload);assertEquals(1,stage.metadata.getJSONObject("counts").getInt("lots"));DatabaseArchive.discard(context,stage);return null;
    });}
    @Test @Config(sdk=23) public void databaseAlsoWorksOnTheMinimumAndroidVersion() throws Exception {background(()->{repository.bootstrap(source(),new JSONObject());assertEquals(1,repository.health().getLong("lots"));repository.write(new JSONObject().put(DocumentCodec.WATER,"[{id:'W',date:'2026-10-22'}]"),revision(),"sdk23","Agua",false);assertEquals(1,repository.health().getLong("water"));return null;});}
    @Test public void initialMigrationCannotBeUndoneAsAUserDeletion() throws Exception {background(()->{repository.bootstrap(source(),new JSONObject());assertEquals(0,repository.recent().length());try{repository.undo("migration-1",revision());fail();}catch(Exception expected){}assertEquals(1,repository.health().getLong("lots"));return null;});}
    @Test public void corruptDatabaseHeaderIsPreservedForRecovery() throws Exception {background(()->{
        repository.bootstrap(source(),new JSONObject());repository.database().close();File original=context.getDatabasePath("truchapp-data.db");
        byte[] damaged="INVALID-HEADER!!".getBytes(java.nio.charset.StandardCharsets.US_ASCII);try(RandomAccessFile file=new RandomAccessFile(original,"rw")){file.seek(0);file.write(damaged);file.getFD().sync();}
        FarmRepository reopened=new FarmRepository(context);try{reopened.health();fail("A corrupt database must not be silently recreated");}catch(Exception expected){}
        assertTrue(original.isFile());byte[] actual=new byte[damaged.length];try(DataInputStream file=new DataInputStream(new FileInputStream(original))){file.readFully(actual);}assertArrayEquals(damaged,actual);try{reopened.database().close();}catch(Exception ignored){}return null;
    });}
}
