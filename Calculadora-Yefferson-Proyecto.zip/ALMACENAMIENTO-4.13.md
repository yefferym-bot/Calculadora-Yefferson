# TruchApp 4.13.0 — almacenamiento y recuperación

La interfaz de los cinco módulos conserva su diseño. Los registros productivos se guardan ahora en Room/SQLite, con una caché de compatibilidad para la interfaz HTML. La caché no es una copia de seguridad independiente.

## Primera apertura y actualización

- La primera apertura convierte las colecciones anteriores en registros individuales, con índices por tipo, lote y fecha. Las fuentes originales de WebView y preferencias se conservan.
- La migración se confirma en una sola transacción. Una estructura no reconocida no se reemplaza por un historial vacío.
- Se mantiene la prioridad que tenía Lotes para su copia nativa cuando contiene registros. Los demás módulos conservan sus claves y formatos de intercambio.
- El esquema Room inicial es la versión 1. Su definición se incluye en `app/schemas`. Las futuras modificaciones deben añadir migraciones explícitas y pruebas; no se utiliza una migración destructiva.
- Antes de instalar esta actualización, exporta un respaldo cifrado desde la versión instalada. Actualiza con la misma firma y el mismo identificador de aplicación.

## Guardado

Lotes, mediciones, tareas y resultados de Agenda comparten un repositorio. Las operaciones que afectan a varios documentos se confirman juntas. Los guardados de detalle, formularios de Agenda y Almacén esperan la respuesta antes de anunciar éxito. Las escrituras pequeñas conservan un adaptador síncrono confirmado para los consumidores antiguos.

Cada operación tiene un identificador y un recibo. Si una confirmación asíncrona se pierde, se consulta el recibo antes de considerar un reintento. Una revisión antigua se rechaza para evitar sobrescribir cambios posteriores. Los registros se actualizan por diferencia; añadir una medición no reescribe todas las posiciones de las anteriores.

El límite de 500 lecturas de agua fue eliminado. Los límites de visualización no recortan el historial guardado. La memoria reciente del chat conserva su comportamiento anterior; esta actualización se centra en los registros de gestión.

## Recuperación

En **Menú → Importar / Exportar → Estado y recuperación** se puede comprobar el almacenamiento, crear una copia local, revisar copias anteriores y deshacer operaciones recientes. La operación inicial de migración está excluida de las opciones de deshacer.

Las operaciones conservan una inversa durante 30 días. Deshacer comprueba sus registros afectados; si tienen correcciones posteriores, se rechaza la operación para protegerlas. Esto no es una restauración indiscriminada de toda la base.

WorkManager programa copias locales cifradas y solicita otra después de los guardados, con un pequeño retraso para agrupar cambios. Android puede diferir el trabajo en segundo plano; la pantalla muestra la fecha real de las copias existentes. Se mantienen hasta 7 diarias, 4 semanales, 6 mensuales y 3 copias de seguridad de restauraciones/migración. La limpieza aplica un presupuesto de 256 MiB, conservando la copia diaria actual y la última copia previa aunque esas dos excedan el presupuesto. La disponibilidad final depende del espacio libre y del sistema.

Las copias locales utilizan Android Keystore y pertenecen a ese dispositivo. **Exporta también una copia cifrada con contraseña fuera del teléfono.** Esa copia permite recuperar los datos tras una pérdida, desinstalación o cambio de equipo. La app no configura una cuenta de nube ni sincronización entre teléfonos.

Los nuevos respaldos portátiles utilizan AES-GCM, compresión y lectura/escritura por secuencias. Se admiten los formatos antiguos. La importación prepara una base temporal, comprueba autenticidad, estructura, cantidades y referencias de almacén, y solo después permite activarla. La generación anterior se conserva. El lector limita los archivos de entrada a 1 GiB; no es una promesa de capacidad ilimitada ni una medida de la memoria máxima disponible.

Si una base no puede leerse, el manejador de corrupción conserva el archivo. La pantalla de recuperación permite seleccionar un respaldo externo. La comprobación técnica no certifica por sí sola que las cifras ingresadas sean correctas.

## Fluidez

- Inicio agrupa las actualizaciones que llegan juntas y reutiliza cálculos cuando no cambiaron los datos ni los filtros.
- Los resúmenes de lotes se reutilizan como datos de lectura; Almacén reutiliza movimientos y saldos dentro de cada representación.
- Historiales y tablas muestran inicialmente 30 registros y permiten ampliar la lista. Los listados extensos de lotes y productos también se cargan por partes.
- El control de bajas mantiene 21 días en pantalla y permite cambiar de ventana con gestos, flechas y selector de mes.
- MAX agrupa las barras de bajas y alimentación sumando únicamente los datos registrados; informa de días sin dato. Las líneas largas conservan puntos reales representativos, incluidos mínimos y máximos. Las tablas mantienen acceso al detalle original. El FCR no se promedia entre períodos.
- Las fuentes Inter y Playfair Display se incluyen localmente con sus licencias, evitando depender de una descarga para mostrar la interfaz.
- La primera carga aún reconstruye una instantánea de compatibilidad para los módulos HTML. El tamaño total del historial sigue influyendo en memoria y tiempo de apertura. Los límites reales deben medirse en teléfonos físicos; las pruebas simuladas no garantizan una cantidad fija de años.

## Validación reproducible

Pruebas de reglas y adaptador:

```sh
node tests/feeding.test.cjs
node tests/home-decisions.test.cjs
node tests/storage.test.cjs
```

Pruebas del repositorio Room, migración, transacciones, compatibilidad Android 6, archivos cifrados y recuperación:

```sh
gradle :app:testDebugUnitTest
```

El proyecto conserva la configuración de firma del workflow. Para tareas locales de validación hay que proporcionar sus variables de configuración, aunque las pruebas no usan la firma de publicación.

La prueba `tests/storage-ui.test.cjs` utiliza Playwright/Chromium, un puente Android simulado y datos de más de cinco años; comprueba paginación, MAX, guardado, rechazo/reintento y creación de tareas. Puede indicarse un navegador con `PLAYWRIGHT_CHROMIUM_EXECUTABLE`. La prueba de UI no sustituye la instalación en un teléfono.

El archivo para GitHub sigue llamándose `Calculadora-Yefferson-Proyecto.zip`. La compilación firmada y la instalación se realizan mediante el workflow habitual.
