# TruchApp — Investigación del módulo Lotes

## Base técnica
- FAO, *Oncorhynchus mykiss*: en el primer año los peces suelen ser seleccionados y clasificados por tamaño varias veces; los muestreos de cantidad y tamaño permiten estimar crecimiento, conversión de alimento, costos y cercanía a la capacidad de carga.
- FAO, *Small-scale rainbow trout farming* (Technical Paper 561, 2011): recomienda registros de existencias y mortalidad, diario de alimentación, registro de almacén y balance mensual de producción.
- FAO, gestión de alimentación: para estimar la alimentación y evaluar su eficiencia se necesitan el número de animales, peso promedio, supervivencia/mortalidad y registros de alimento.
- Perú, NTP 032.103:2024: estandariza el método para determinar el factor de conversión alimenticia en la crianza de trucha arcoíris.

## Decisiones de diseño
El módulo Lotes registra datos reales aportados por el usuario y calcula:
- Biomasa = número de peces × peso promedio / 1000.
- Supervivencia = peces actuales / peces iniciales × 100.
- Mortalidad estimada por diferencia = peces iniciales − peces actuales.
- Ganancia de biomasa = biomasa actual − biomasa inicial, truncada a cero.
- FCR observado = alimento acumulado / ganancia de biomasa, solo cuando ambas magnitudes permiten calcularlo.

El módulo no fija una tasa universal de alimentación ni diagnostica enfermedades. Las recomendaciones de manejo deben interpretarse con etapa, sistema, temperatura, oxígeno, calidad de agua, alimento y registros propios de la granja.
