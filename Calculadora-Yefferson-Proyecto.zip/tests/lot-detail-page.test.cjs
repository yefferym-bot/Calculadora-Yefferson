/* Flujo de página, navegación y guardado con DOM simulado. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
class Element{
 constructor(tag='div'){this.tagName=tag.toUpperCase();this.dataset={};this.attrs={};this.children=[];this.listeners={};this.inert=false;this.hidden=false;this.isConnected=true;this.scrollTop=0;this.classes=new Set();this.classList={add:(...xs)=>xs.forEach(x=>this.classes.add(x)),remove:(...xs)=>xs.forEach(x=>this.classes.delete(x)),contains:x=>this.classes.has(x)};this.props={};this.style={setProperty:(k,v)=>this.props[k]=v,getPropertyValue:k=>this.props[k]||'',removeProperty:k=>delete this.props[k]};}
 set className(s){this.classes=new Set(s.split(' '));}
 setAttribute(k,v){this.attrs[k]=v;}removeAttribute(k){delete this.attrs[k];}
 append(child){this.children.push(child);child.parent=this;child.isConnected=true;}
 remove(){this.parent.children=this.parent.children.filter(e=>e!==this);this.isConnected=false;}
 addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);}
 set innerHTML(value){this.html=value;this.parts={};for(const name of ['lotLoading','lotLoadingClose','lotLoadingTitle','lotLoadingCaption','lotLoadingRetry'])this.parts['.'+name]=new Element(name.includes('Close')||name.includes('Retry')?'button':'div');this.parts['.lotLoadingRetry'].hidden=true;}
 querySelector(selector){return this.parts?.[selector]||null;}
 focus(){document.activeElement=this;}
 closest(selector){return selector==='.nav[data-target]'&&this.dataset.target?this:null;}
 getBoundingClientRect(){return{height:this.height||79};}
}
const content=new Element('main'),screen=new Element(),list=new Element(),header=new Element('header'),nav=new Element('nav'),origin=new Element('button'),body=new Element('body');
content.append(screen);screen.append(list);content.scrollTop=250;body.append(header);body.append(content);body.append(nav);
const buttons=['inicio','lotes','almacen','agenda','finanzas'].map(target=>{const b=new Element('button');b.dataset.target=target;return b;});
const document={body,activeElement:origin,listeners:{},getElementById:id=>({lotes:screen,lotesRoot:list,bottomNav:nav}[id]||null),querySelector:s=>s==='.phone>.content'?content:s==='.tn-main-header'?header:s.includes('data-target="lotes"')?buttons[1]:s.includes('data-target="almacen"')?buttons[2]:null,createElement(tag){const el=new Element(tag);if(tag==='iframe'){el.contentWindow={messages:[],postMessage(m){this.messages.push(m);}};}return el;},addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);}};
const frames=()=>screen.children.at(-1).children.filter(e=>e.tagName==='IFRAME');
let raf=[],timers=new Map(),timer=0,observer,saveCount=0,lastSave;
const window={listeners:{},addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);},TruchAppData:{readLotDetail:id=>({lot:{id,code:'Lote '+id}}),saveLotDetail(id,state){saveCount++;lastSave={id,state};return state;}},TruchAppFeeding:{snapshot:()=>({items:[],movements:[]})}};
const ctx=vm.createContext({window,document,console,Date,Math,ResizeObserver:class{constructor(fn){observer=fn;}observe(){}},setTimeout(fn){timers.set(++timer,fn);return timer;},clearTimeout:id=>timers.delete(id),requestAnimationFrame(fn){raf.push(fn);return raf.length;},cancelAnimationFrame(){}});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../app/src/main/assets/ui/lotes/lot-detail-host.js'),'utf8'),ctx);
const host=window.TruchAppLotDetailHost;
function paint(){for(let i=0;raf.length&&i<10;i++){const queue=raf;raf=[];queue.forEach(fn=>fn());}}
function message(frame,m){return window.listeners.message[0]({source:frame.contentWindow,data:m});}
function boot(id){document.activeElement=origin;host.open(id);paint();const frame=frames()[0];message(frame,{type:'truchapp-detail-ready'});const m=frame.contentWindow.messages.filter(m=>m.type==='truchapp-detail-boot').at(-1);return{frame,token:m.session,state:m.state};}
function click(target){const e={target,preventDefault(){this.prevented=true;},stopImmediatePropagation(){this.stopped=true;}};for(const fn of document.listeners.click||[])fn(e);return e;}
(async()=>{
 const a=boot('A'),page=screen.children.at(-1);
 assert.equal(page.parent,screen);assert.equal(page.attrs.role,'region');assert.equal(page.attrs['aria-modal'],undefined);
 assert(content.classList.contains('lot-detail-page-open'));assert(screen.classList.contains('lot-detail-active'));assert.equal(list.inert,true);
 assert.equal(header.inert,false);assert.equal(nav.inert,false);assert.equal(body.inert,false);assert.equal(content.style.getPropertyValue('--lot-detail-navigation-height'),'79px');
 nav.height=106;observer();assert.equal(content.style.getPropertyValue('--lot-detail-navigation-height'),'106px');
 await message(a.frame,{type:'truchapp-detail-rendered',session:a.token});assert.equal(a.frame.inert,false);
 assert.equal(click(buttons[3]).stopped,undefined);assert.equal(host.isOpen(),false);assert.equal(list.inert,false);assert.equal(content.scrollTop,250);assert.equal(page.hidden,true);
 const b=boot('B');assert.equal(b.frame,a.frame,'Se reutiliza el iframe sin recuperar datos del otro lote');assert.notEqual(a.token,b.token);
 await message(b.frame,{type:'truchapp-detail-close',session:a.token});assert.equal(host.isOpen(),true,'Una sesión antigua no cierra la actual');
 await message(b.frame,{type:'truchapp-detail-rendered',session:b.token});
 let complete;window.TruchAppStorage={runAsync:(_,save)=>new Promise(resolve=>{complete=()=>resolve(save());})};
 const saving=message(b.frame,{type:'truchapp-detail-save',session:b.token,request:1,baseRevision:0,state:b.state});
 assert.equal(header.inert,true);assert.equal(nav.inert,true);assert.equal(host.close(),false);assert.equal(click(buttons[0]).stopped,true);assert.equal(host.isOpen(),true);
 complete();await saving;assert.equal(saveCount,1);assert.equal(lastSave.id,'B');assert.equal(header.inert,false);assert.equal(nav.inert,false);
 assert.equal(b.frame.contentWindow.messages.at(-1).type,'truchapp-detail-saved');
 window.TruchAppStorage.runAsync=async()=>{throw Error('Fallo simulado');};
 await message(b.frame,{type:'truchapp-detail-save',session:b.token,request:2,baseRevision:1,state:b.state});
 assert.equal(b.frame.contentWindow.messages.at(-1).type,'truchapp-detail-failed');assert.equal(saveCount,1);assert.equal(nav.inert,false);assert.equal(header.inert,false);assert.equal(host.isOpen(),true);
 await message(b.frame,{type:'truchapp-detail-close',session:b.token});assert.equal(host.isOpen(),false);assert.equal(document.activeElement,origin);
 const c=boot('C');assert.equal(click(buttons[1]).stopped,undefined);assert.equal(host.isOpen(),false,'Lotes vuelve a la lista incluso durante la carga');
 await message(c.frame,{type:'truchapp-detail-rendered',session:c.token});assert.equal(page.hidden,true,'La carga tardía no reabre la página');
 console.log(JSON.stringify({status:'passed',checks:['página dentro de Lotes','sin semántica modal','cabecera y barra accesibles','altura del menú medida','retorno conserva scroll','cambio de módulo','iframe reutilizado con sesión nueva','sesión antigua ignorada','salida bloqueada solo durante guardado','guardado único','error recupera navegación','volver restaura foco','salir durante carga','respuesta tardía ignorada'],environment:'DOM simulado'}));
})().catch(e=>{console.error(e);process.exitCode=1;});
