#!/usr/bin/env python3
"""Inspect the actual cross-compiled JNI libraries. Does not install or run Android."""
import argparse,json,struct,subprocess
from pathlib import Path

def inspect(path,elf_class,machine,nm):
    path=Path(path)
    with path.open('rb') as stream:header=stream.read(20)
    assert len(header)==20 and header[:4]==b'\x7fELF',f'{path}: no es ELF'
    assert header[4]==elf_class and header[5]==1,f'{path}: clase ELF incorrecta'
    assert struct.unpack_from('<H',header,18)[0]==machine,f'{path}: CPU incorrecta'
    assert struct.unpack_from('<H',header,16)[0]==3,f'{path}: no es una biblioteca compartida'
    output=subprocess.check_output([nm,'--dynamic','--defined-only',str(path)],text=True)
    prefix='Java_com_yefferson_calculadora_ai_AiNative_'
    exports={line.split()[-1] for line in output.splitlines() if line.split()}
    for method in ['init','loadModel','isReady','generateConversation','clearConversation','release']:
        assert prefix+method in exports,f'{path}: falta JNI {method}'
    return {'path':str(path),'bits':32 if elf_class==1 else 64,'machine':machine,'jni_methods':6,'bytes':path.stat().st_size}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--arm32',required=True)
    parser.add_argument('--arm64',required=True)
    parser.add_argument('--nm',required=True,help='llvm-nm del NDK')
    args=parser.parse_args()
    values=[inspect(args.arm32,1,40,args.nm),inspect(args.arm64,2,183,args.nm)]
    print(json.dumps({'status':'passed','libraries':values},indent=2))
