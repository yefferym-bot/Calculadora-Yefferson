/* Controlled-clock tests of the production bridge. Android persistence is a synthetic transport. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync(require.resolve('../app/src/main/assets/ui/shared/storage.js'),'utf8');
(async()=>{
 let now=Date.parse('2026-11-14T23:59:59-05:00'),timerId=0,revision=7,commits=0,closes=0,fail=false;
 let web={truchapp_lotes_v1:'[]',activities:'[]'},cursor={version:1,policy:'missing-food-zero',through:'2026-11-13'},events=[],timers=new Map(),handlers={},docHandlers={};
 class Clock extends Date{constructor(...args){super(...(args.length?args:[now]));}static now(){return now;}}
 const document={visibilityState:'visible',documentElement:{classList:{add(){},remove(){}}},getElementById(){return null},createElement(){return{setAttribute(){},remove(){}}},body:{append(){}},addEventListener(type,fn){docHandlers[type]=fn;}};
 const window={localStorage:{length:0,getItem(){return null},setItem(){},removeItem(){},key(){return null}},document,crypto:require('node:crypto'),addEventListener(type,fn){handlers[type]=fn;},dispatchEvent(e){events.push(e);}};
 const reply=(id,ok,data)=>queueMicrotask(()=>window.TruchAppStorageReceive(id,ok,0,1,JSON.stringify(data)));
 window.AndroidAI={farmRequest(id,command,raw){try{let data,p=JSON.parse(raw);if(command==='bootstrap'||command==='snapshot')data={web,revision,feedClosure:cursor};else if(command==='closeFeedDays'){closes++;if(fail)throw Error('Disco no disponible');const d=new Clock();d.setDate(d.getDate()-1);cursor={...cursor,through:[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')};data=cursor;}else if(command==='commit'){assert.equal(p.revision,revision);commits++;web={...web,...p.patch};data={revision:++revision};}else throw Error(command);reply(id,true,data);}catch(e){reply(id,false,{error:e.message});}}};
 const setTimer=(fn,delay)=>{const id=++timerId;timers.set(id,{fn,delay});return id;},clearTimer=id=>timers.delete(id);
 vm.runInNewContext(source,{window,document,Date:Clock,structuredClone,CustomEvent:class{constructor(type,options){this.type=type;this.detail=options?.detail;}},Event:class{constructor(type){this.type=type;}},setTimeout:setTimer,clearTimeout:clearTimer,console});
 await window.TruchAppStorageBootstrap.initialize();const storage=window.TruchAppStorage;
 assert.equal(storage.feedClosure.through,'2026-11-13');assert.equal(timers.size,1);assert.equal([...timers.values()][0].delay,1100);
 const metadata=storage.feedClosure;metadata.through='broken';assert.equal(storage.feedClosure.through,'2026-11-13');
 now=Date.parse('2026-11-15T00:00:00.100-05:00');let timer=[...timers.values()][0];timers.clear();timer.fn();await new Promise(setImmediate);assert.equal(closes,1);assert.equal(storage.feedClosure.through,'2026-11-14');assert.equal(commits,0);assert.equal(storage.revision,7);assert.deepEqual(web,{truchapp_lotes_v1:'[]',activities:'[]'});assert.equal(events.filter(e=>e.type==='truchapp-feed-days-closed').length,1);
 // Sleep/power-off catch-up and concurrent observer events coalesce into one metadata request.
 now=Date.parse('2026-11-18T10:00:00-05:00');handlers.focus();handlers.pageshow();docHandlers.visibilitychange();await new Promise(setImmediate);assert.equal(closes,2);assert.equal(storage.feedClosure.through,'2026-11-17');assert.equal(commits,0);
 // A closure request does not lock or invalidate a real edit in progress.
 now=Date.parse('2026-11-19T10:00:00-05:00');const save=storage.runAsync('Registrar',()=>storage.setItem('activities','[{"id":"T"}]'));await storage.closeFeedDays();await save;assert.equal(commits,1);assert.equal(storage.revision,8);assert.equal(storage.getItem('activities'),'[{"id":"T"}]');
 now=Date.parse('2026-11-20T10:00:00-05:00');fail=true;handlers.focus();await new Promise(setImmediate);assert.equal(storage.feedClosure.through,'2026-11-18');assert([...timers.values()].some(t=>t.delay===60000));fail=false;await storage.closeFeedDays();assert.equal(storage.feedClosure.through,'2026-11-19');assert.equal(commits,1);assert.equal(storage.revision,8);
 console.log('Feed closure storage: midnight, catch-up, event coalescing, defensive copy, draft isolation and retry passed (mock Android transport).');
})().catch(error=>{console.error(error);process.exitCode=1;});
