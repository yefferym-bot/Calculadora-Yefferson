"""Garantías del modo nocturno: solo colores, sin cambios de posición ni recursos."""
import importlib.util
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('night',ROOT/'tools/generar_modo_oscuro.py')
night=importlib.util.module_from_spec(spec);spec.loader.exec_module(night)

class NightPaletteTest(unittest.TestCase):
    def test_legible_palette(self):
        def ratio(a,b):
            values=[night.luminance(night.color_rgba(night.TOKENS[k])[:3]) for k in (a,b)]
            return (max(values)+.05)/(min(values)+.05)
        for fg in ('text','muted','accent','danger','warning','success','blue'):
            for bg in ('bg','surface','raised'):
                self.assertGreaterEqual(ratio(fg,bg),4.5,(fg,bg))
        self.assertGreaterEqual(ratio('text','action'),4.5)
    def test_scope_and_no_geometry(self):
        output=night.adapt('.card{padding:9px;position:sticky;color:#183e37;background:#fff;border:1px solid #dce8e1}@media(max-width:360px){.card{width:100%;color:#66786b}}','html[data-theme=dark]')
        self.assertNotIn('padding:',output);self.assertNotIn('position:',output);self.assertNotIn('{width:',output)
        self.assertIn('@media(max-width:360px)',output);self.assertIn('html[data-theme=dark] .card',output)
        self.assertIn('border-color:#47636c',output);self.assertNotIn('border:1px',output)
    def test_assets_alpha_and_native_chart_colors(self):
        for prop,value in [('fill','url(#gradient)'),('background','url("data:image/svg+xml;base64,abcd") center / cover'),('box-shadow','0 0 10px #22c55e')]:
            self.assertEqual(night.value_for(prop,value),value)
        self.assertEqual(night.translate_color('#ffffff26','background'),'#ffffff26')
        self.assertIn('healthLight.good{background:#22c55e!important}',night.build())
    def test_legacy_color_names_are_dark_surfaces(self):
        # La calculadora, la bienvenida y los módulos antiguos usan estos nombres.
        css=night.adapt('.panel{background:var(--fondo-alto);color:var(--texto);border:1px solid var(--borde)}.primary{background:var(--i-acc);color:white}', 'html[data-theme=dark]')
        self.assertIn('background-color:var(--night-surface)',css)
        self.assertIn('color:var(--night-text)',css)
        self.assertIn('border-color:var(--night-line)',css)
        self.assertIn('background-color:var(--night-action)',css)

    def test_matches_generated_file(self):
        self.assertEqual(night.build(),night.OUTPUT.read_text())

if __name__=='__main__':unittest.main()
