/* Casos productivos y faltantes; no usa los valores de ejemplo del editor. */
const test=require('node:test'),assert=require('node:assert/strict');
const L=require('../app/src/main/assets/ui/lotes/lot-detail-data.js');
const I=require('../app/src/main/assets/ui/lotes/detail/summary-indicators.js');
const copy=v=>JSON.parse(JSON.stringify(v));
function fixture(){
 const d=L.fromLot({id:'A',code:'A',date:'2026-01-01',initialN:100,initialWeight:50,n:100,w:50,m:0,discarded:0,history:[]});
 d.samples[0].length=15;
 d.samples.push({id:'S2',date:'2026-01-11',time:'12:00',initial:false,legacyPeriod:false,weight:100,length:20,individualWeights:[80,100,120],mortality:0,discard:0,feed:null});
 for(let day=2;day<=11;day++)d.daily.push({id:'D'+day,date:'2026-01-'+String(day).padStart(2,'0'),time:'17:00',feed:1,mortality:0,discard:0});
 d.settings.volume=2;return d;
}
function query(d){const s=L.summary(d);return{...s,prev:s.samples.at(-2),period:s.periods.at(-1)||null};}
const calc=d=>I.calculate(d,query(d));
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-10,`${a} != ${b}`);
test('mismo período: K 1.25, CV 20%, SGR 6.931%, TEA 50% y densidad 5',()=>{
 const d=fixture(),before=JSON.stringify(d),m=calc(d),s=query(d);
 near(m.condition,1.25);near(m.cv,20);near(m.sgr,6.931471805599453);near(m.efficiency,50);near(m.density,5);
 near(s.period.fcr,2);assert.equal(m.feedDate,'2026-01-11');assert.equal(m.cvCount,3);
 assert.equal(JSON.stringify(d),before,'Consultar no escribe, migra ni duplica registros');
});
test('TEA no se inventa cuando faltan alimento o bajas del período',()=>{
 for(const field of ['feed','mortality','discard']){const d=fixture();d.daily[2][field]=null;assert.equal(calc(d).efficiency,null);assert.ok(calc(d).sgr>0);}
});
test('cero alimento conserva FCR cero y deja TEA sin división',()=>{
 const d=fixture();d.daily.forEach(r=>r.feed=0);const s=query(d);assert.equal(s.food,0);assert.equal(s.period.fcr,0);assert.equal(calc(d).efficiency,null);
});
test('no se mezcla la talla antigua con el último peso; la fecha sigue visible',()=>{
 const d=fixture();d.samples.at(-1).length=null;const m=calc(d);assert.equal(m.condition,null);assert.equal(m.lengthSample.date,'2026-01-01');
});
test('CV requiere al menos dos pesos del último control',()=>{
 const d=fixture();d.samples[0].individualWeights=[40,50,60];
 for(const weights of [[],[100],[0,100],[NaN,100]]){d.samples.at(-1).individualWeights=weights;assert.equal(calc(d).cv,null);}
 d.samples.at(-1).individualWeights=[100,100];assert.equal(calc(d).cv,0);
});
test('crecimiento cero o negativo se conserva sin eficiencia aparente positiva',()=>{
 const d=fixture();d.samples.at(-1).weight=50;assert.equal(calc(d).sgr,0);assert.equal(calc(d).efficiency,null);
 d.samples.at(-1).weight=40;assert.ok(calc(d).sgr<0);assert.equal(calc(d).efficiency,null);
});
test('un control, pesos cero y fechas iguales no producen NaN o infinito',()=>{
 const d=fixture();d.samples=d.samples.slice(0,1);assert.equal(calc(d).sgr,null);assert.equal(calc(d).efficiency,null);
 const e=fixture();e.samples[0].weight=0;assert.equal(calc(e).sgr,null);
 e.samples[0].weight=50;e.samples.at(-1).date=e.samples[0].date;assert.equal(calc(e).sgr,null);
});
test('volumen ausente o cero no se usa; cero peces sí es una densidad válida',()=>{
 const d=fixture();for(const volume of [null,0,-1,Infinity]){d.settings.volume=volume;assert.equal(calc(d).density,null);}
 d.settings.volume=2;d.daily[0].mortality=100;assert.equal(calc(d).density,0);
});
test('eficiencia mayor de 100 no se recorta y no sustituye por un diagnóstico',()=>{
 const d=fixture();d.daily.forEach(r=>r.feed=.1);near(calc(d).efficiency,500);
});
test('totales históricos se consultan sin repartirlos ni sumar el día inicial dos veces',()=>{
 const d=fixture();d.samples[1].legacyPeriod=true;d.samples[1].feed=10;d.daily=[];
 d.openingBalance={date:'2026-01-01',feed:2,mortality:0,discard:0};
 const before=JSON.stringify(d);near(calc(d).efficiency,50);assert.equal(query(d).food,12);assert.equal(JSON.stringify(d),before);
});
