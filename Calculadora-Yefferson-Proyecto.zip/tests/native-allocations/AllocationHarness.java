import com.yefferson.calculadora.pairing.*;import org.json.*;import java.nio.file.*;import java.util.function.Consumer;
/** Actual protocol validator/patch classes on JVM. No Android/TLS/Room installation. */
public class AllocationHarness {
 static int checks;static JSONObject copy(JSONObject o){return new JSONObject(o.toString());}static JSONObject detail(JSONObject o){return o.getJSONObject("lot").getJSONObject("detailState");}static JSONObject day(JSONObject o){return detail(o).getJSONArray("daily").getJSONObject(0);}static JSONObject line(JSONObject o){return day(o).getJSONArray("entries").getJSONObject(0).getJSONObject("feedStock").getJSONArray("lines").getJSONObject(0);}
 static void check(boolean b){if(!b)throw new AssertionError();checks++;}static void deny(JSONObject c,JSONObject p,Consumer<JSONObject> mutation)throws Exception{JSONObject v=copy(p);mutation.accept(v);boolean failed=false;try{PairProduction.validate(c,v);}catch(Exception expected){failed=true;}check(failed);}
 public static void main(String[] args)throws Exception{
  JSONObject f=new JSONObject(Files.readString(Path.of(args[0]))),c=f.getJSONObject("current"),p=f.getJSONObject("proposed");PairProduction.validate(c,p);check(true);PairProduction.validate(p,f.getJSONObject("edit"));check(true);PairProduction.validate(p,f.getJSONObject("remove"));check(true);PairProduction.validate(f.getJSONObject("directCurrent"),f.getJSONObject("directProposed"));check(true);
  deny(c,p,v->detail(v).getJSONArray("feedAllocations").getJSONObject(0).put("unitCost",1));deny(c,p,v->detail(v).put("feedAllocations",new JSONArray()));
  deny(c,p,v->line(v).put("unitCost",1));deny(c,p,v->line(v).put("allocationId","OTHER-LOT"));deny(c,p,v->line(v).remove("allocationId"));
  deny(c,p,v->{line(v).put("kg",26);day(v).getJSONObject("feedStock").getJSONArray("lines").getJSONObject(0).put("kg",26);});
  deny(c,p,v->day(v).getJSONArray("entries").getJSONObject(0).put("date","2026-11-08"));
  deny(c,p,v->day(v).remove("feedStock"));deny(c,p,v->day(v).getJSONObject("feedStock").put("version",2));
  deny(f.getJSONObject("directCurrent"),f.getJSONObject("directProposed"),v->day(v).getJSONArray("entries").getJSONObject(0).getJSONObject("feedStock").getJSONArray("lines").getJSONObject(0).put("unitCost",1));
  JSONObject old=copy(c),expired=copy(p);detail(old).getJSONArray("feedAllocations").getJSONObject(0).put("expiry","2026-11-09");detail(expired).getJSONArray("feedAllocations").getJSONObject(0).put("expiry","2026-11-09");deny(old,expired,v->{});
  JSONArray before=new JSONArray().put(c.getJSONObject("lot"));String a=PairProduction.summaries(before,new JSONArray().put("A")).getJSONObject(0).getString("economicsStamp");JSONObject changed=copy(c.getJSONObject("lot"));changed.getJSONObject("detailState").getJSONArray("feedAllocations").getJSONObject(0).put("kg",24);String b=PairProduction.summaries(new JSONArray().put(changed),new JSONArray().put("A")).getJSONObject(0).getString("economicsStamp");check(!a.equals(b));
  System.out.println("Allocation protocol production validation: "+checks+" checks passed (JVM).");
 }
}
