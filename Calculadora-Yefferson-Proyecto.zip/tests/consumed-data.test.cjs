const assert=require('node:assert/strict');
const D=require('../app/src/main/assets/ui/lotes/detail/consumed-data.js');
let checks=0;const test=(name,fn)=>{fn();checks++;console.log('FOOD DATA PASS '+name);};
const base={lot:{date:'2020-01-01'},samples:[],daily:[]};
test('approved filters and rolling calendar boundaries',()=>{
 assert.deepEqual(D.ranges,['1D','5D','1M','6M','1A','Max']);
 assert.equal(D.start('2020-01-01','2026-11-14','1D'),'2026-11-14');
 assert.equal(D.start('2020-01-01','2026-11-14','5D'),'2026-11-10');
 assert.equal(D.start('2020-01-01','2026-11-14','1M'),'2026-10-15');
 assert.equal(D.start('2020-01-01','2026-11-14','6M'),'2026-05-15');
 assert.equal(D.start('2020-01-01','2026-11-14','1A'),'2025-11-15');
 assert.equal(D.start('2026-11-12','2026-11-14','1A'),'2026-11-12');
});
test('month ends and leap years retain valid calendar dates',()=>{
 assert.equal(D.monthsBack('2024-03-31',1),'2024-02-29');
 assert.equal(D.monthsBack('2025-03-31',1),'2025-02-28');
 assert.equal(D.monthsBack('2024-02-29',12),'2023-02-28');
 assert.equal(D.start('2020-01-01','2024-03-31','1M'),'2024-03-01');
});
test('registered zero, missing food and multiple moments stay distinct',()=>{
 const state={...base,lot:{date:'2026-11-10'},daily:[{date:'2026-11-10',feed:0},{date:'2026-11-11',feed:null},{date:'2026-11-14',feed:2,entriesVersion:1,entries:[{id:'am',date:'2026-11-14',time:'07:00',feed:1},{id:'pm',date:'2026-11-14',time:'17:00',feed:1}]}]};
 const before=JSON.stringify(state),view=D.windowData(state,'2026-11-14','5D');
 assert.equal(view.total,2);assert.equal(view.known.length,2);assert.equal(view.rows[0].value,0);assert.equal(view.rows[1].value,null);assert.equal(view.rows[2].status,'missing');
 const moments=D.series(D.windowData(state,'2026-11-14','1D'));assert.equal(moments.length,2);assert.deepEqual(moments.map(p=>p.value),[1,1]);assert.deepEqual(moments.map(p=>p.x),[420,1020]);
 assert.equal(JSON.stringify(state),before,'reading never alters the daily records');
});
test('old totals are retained without fabricating a daily allocation',()=>{
 const state={...base,lot:{date:'2026-11-01'},openingBalance:{date:'2026-11-07',feed:6},daily:[{date:'2026-11-14',feed:1}]},view=D.windowData(state,'2026-11-14');
 assert.equal(view.legacyTotal,6);assert.equal(view.total,1);assert.equal(view.rows.find(r=>r.date==='2026-11-07').status,'legacy');assert.equal(view.rows.find(r=>r.date==='2026-11-07').value,null);assert.equal(view.rows.find(r=>r.date==='2026-11-08').editable,true);assert.equal(view.rows[0].editable,false);
});
test('future lots and absent data are empty, never a confirmed zero total',()=>{
 assert.equal(D.windowData({...base,lot:{date:'2026-12-01'}},'2026-11-14').rows.length,0);
 assert.equal(D.windowData(base,'2026-11-14','1D').total,null);
 const view=D.windowData({...base,daily:[{date:'2026-11-14',feed:0}]},'2026-11-14','1D');assert.equal(view.total,0);assert.equal(D.series(view)[0].value,0);
});
test('seven-day pages cover history exactly without future dates',()=>{
 const rows=D.windowData({...base,lot:{date:'2026-10-01'}},'2026-11-14').rows;let date=rows[0].date,seen=[];
 for(let i=0;i<D.page(rows,date).count;i++){const p=D.page(rows,date);assert(p.rows.length<=7);seen.push(...p.rows.map(r=>r.date));date=D.pageDate(rows,date,1);}
 assert.deepEqual(seen,rows.map(r=>r.date));assert.equal(D.page(rows,'2026-11-14').rows.at(-1).date,'2026-11-14');
});
test('line segments never join across a missing value; zero remains plotted',()=>{
 const points=[1,0,null,2,null,null,3].map((value,x)=>({date:'2026-11-'+String(x+1).padStart(2,'0'),value,x}));
 const p=D.plot(points);assert.deepEqual(p.segments.map(s=>s.map(p=>p.value)),[[1,0],[2],[3]]);
});
test('long histories bound rendered points while preserving peaks, gaps and selection',()=>{
 const points=Array.from({length:7300},(_,x)=>({x,value:x%7===0?null:x===4124?999:x%13})),chosen=6871,p=D.plot(points,chosen),flat=p.segments.flat();
 assert(flat.length<=260);assert(flat.some(r=>r.index===4124&&r.value===999));assert(flat.some(r=>r.index===chosen));
 for(const segment of p.segments)for(let i=1;i<segment.length;i++)assert(!points.slice(segment[i-1].index,segment[i].index+1).some(r=>r.value===null));
});
test('day close fills only elapsed missing food and never today or future days',()=>{
 const state={...base,lot:{date:'2026-11-12'},daily:[{date:'2026-11-12',feed:null,mortality:2,discard:null,note:'Agua turbia'}]},before=JSON.stringify(state);
 let view=D.windowData(state,'2026-11-14','Max',D.closureForToday('2026-11-14'));
 assert.deepEqual(view.rows.map(r=>r.value),[0,0,null]);assert.deepEqual(view.rows.map(r=>r.status),['automatic','automatic','missing']);
 assert.equal(view.rows[0].record.mortality,2);assert.equal(view.rows[0].record.discard,null);assert.equal(view.rows[0].record.note,'Agua turbia');assert.equal(JSON.stringify(state),before);
 view=D.windowData(state,'2026-11-15','Max',D.closureForToday('2026-11-15',{through:'2026-11-13'}));
 assert.deepEqual(view.rows.map(r=>r.value),[0,0,0,null]);assert.equal(view.rows[2].automatic,true);
});
test('real food including confirmed fasting overrides automatic defaults without duplication',()=>{
 const state={...base,lot:{date:'2026-11-12'},daily:[{date:'2026-11-12',feed:0},{date:'2026-11-13',feed:2,entriesVersion:1,entries:[{feed:1},{feed:1}]}]},view=D.windowData(state,'2026-11-14','Max',D.closureForToday('2026-11-14'));
 assert.deepEqual(view.rows.map(r=>r.status),['known','known','missing']);assert.equal(view.total,2);assert.equal(state.daily.length,2);
 state.daily[0].feed=3;assert.equal(D.windowData(state,'2026-11-14','Max',D.closureForToday('2026-11-14')).total,5);
});
test('closure excludes historical aggregate periods and does not hide an existing food entry',()=>{
 const state={...base,lot:{date:'2026-11-01'},openingBalance:{date:'2026-11-07',feed:6},daily:[{date:'2026-11-10',feed:null,entriesVersion:1,entries:[{feed:2}]}]},view=D.windowData(state,'2026-11-14','Max',D.closureForToday('2026-11-14'));
 assert(view.rows.filter(r=>r.date<='2026-11-07').every(r=>r.status==='legacy'&&r.value===null));assert.equal(view.rows.find(r=>r.date==='2026-11-08').status,'automatic');assert.equal(view.rows.find(r=>r.date==='2026-11-10').automatic,false);assert.equal(view.legacyTotal,6);
 assert.equal(D.windowData(state,'2026-11-14','Max',{version:2,policy:'missing-food-zero',through:'2026-11-13'}).rows.find(r=>r.date==='2026-11-08').value,null);
});
console.log(JSON.stringify({status:'passed',groups:checks,timezone:process.env.TZ||'system'}));
