/* Integración de eventos con DOM simulado; no sustituye revisión visual en Android. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const assets=path.resolve(__dirname,'../app/src/main/assets'),html=fs.readFileSync(path.join(assets,'ui/lotes/detail/index.html'),'utf8');
const L=require('../app/src/main/assets/ui/lotes/lot-detail-data.js'),F=require('../app/src/main/assets/ui/feeding/feeding-data.js'),D=require('../app/src/main/assets/ui/lotes/feeding/feeding-panel-data.js'),H=require('../app/src/main/assets/ui/lotes/health/health-data.js');
const elements=new Map();
class Element{
 constructor(id=''){this.id=id;this.dataset={};this.style={};this.value='';this.checked=false;this.hidden=false;this.open=false;this.listeners={};this.textContent='';this.classList={add(){},remove(){},toggle(){}};this.attributes={};}
 set value(v){this._value=String(v??'');}
 get value(){return this._value||'';}
 set innerHTML(value){this.html=value;for(const tag of value.match(/<[^>]+\bid="[^"]+"[^>]*>/g)||[]){const id=tag.match(/\bid="([^"]+)"/)[1];if(!elements.has(id))elements.set(id,new Element(id));const el=elements.get(id),v=tag.match(/\bvalue="([^"]*)"/);if(v)el.value=v[1];}}
 get innerHTML(){return this.html||'';}
 addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);}
 async emit(type,target=this){return Promise.all((this.listeners[type]||[]).map(fn=>fn({target,preventDefault(){}})));}
 setAttribute(k,v){this.attributes[k]=v;}removeAttribute(k){delete this.attributes[k];}
 replaceChildren(){this.innerHTML='';}insertAdjacentHTML(_,v){this.innerHTML+=v;}
 querySelector(selector){if(selector==='summary')return this.summary??=new Element();if(selector==='h2')return new Element();return null;}
 querySelectorAll(){return[];}
 showModal(){this.open=true;}close(){this.open=false;}focus(){document.activeElement=this;}
 scrollTo(){this.scrolled=true;}scrollIntoView(){this.scrolled=true;}
 getClientRects(){return[{}];}getBoundingClientRect(){return{left:0,top:0,right:400,bottom:800};}
 closest(selector){if(selector==='[data-lot-feed]'&&this.dataset.lotFeed)return this;return null;}
}
for(const match of html.matchAll(/\bid="([^"]+)"/g))elements.set(match[1],new Element(match[1]));
const tabs=[];for(const tag of html.match(/<button class="tab"[^>]*>/g)){const id=tag.match(/\bid="([^"]+)"/)[1],tab=elements.get(id);tab.dataset.tab=tag.match(/data-tab="([^"]+)"/)[1];tabs.push(tab);}
const panes=tabs.map(t=>elements.get('pane-'+t.dataset.tab)),nav=new Element();
const document={body:new Element(),activeElement:null,fonts:{ready:Promise.resolve()},listeners:{},getElementById:id=>elements.get(id)||null,addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);},querySelector(selector){if(selector==='[role=tablist]')return nav;return null;},querySelectorAll(selector){if(selector==='[data-tab]')return tabs;if(selector==='[role=tabpanel]')return panes;if(selector==='dialog[open]')return [...elements.values()].filter(e=>e.open&&e.id.endsWith('Dialog'));if(selector==='dialog')return [...elements.values()].filter(e=>e.id.endsWith('Dialog'));return[];}};
const window={document,matchMedia:()=>({matches:false,addEventListener(){}}),listeners:{},addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);},TruchAppFeedingData:F,TruchAppLotFeedingData:D,TruchAppHealthData:H,TruchAppHealthUI:{create:()=>({render(){},reset(){}})}};
let state,saves=0;const messages=[],stock={items:[{id:'P',name:'Pellet',category:'Alimento balanceado',unit:'kg',active:true}],movements:[{id:'I',itemId:'P',batch:'B',type:'entrada',qty:100,unitCost:4,date:'2026-01-01',expiry:'2027-12-31'}]};
const parent={postMessage(m){messages.push(m);if(m.type==='truchapp-detail-save'){saves++;state=m.state;queueMicrotask(()=>window.listeners.message[0]({source:parent,data:{type:'truchapp-detail-saved',session:m.session,request:m.request,revision:saves,state:m.state,feeding:stock}}));}}};window.parent=parent;
const context=vm.createContext({window,document,console,Date,Map,Set,Promise,JSON,Number,String,Math,setTimeout:()=>0,clearTimeout(){},requestAnimationFrame:fn=>{fn();return 1;},cancelAnimationFrame(){}});
for(const file of ['ui/feeding/feeding-ui.js','ui/lotes/feeding/feeding-panel-ui.js','ui/lotes/detail/detail.js'])vm.runInContext(fs.readFileSync(path.join(assets,file),'utf8'),context,{filename:file});
const now=new Date(),today=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-'),yesterday=D.shift(today,-1);
const raw={id:'A',code:'Lote A',stage:'Alevinaje',unit:'Jaula 1',date:yesterday,initialN:1000,initialWeight:8,n:1000,w:8,m:0,discarded:0,targetWeight:250,history:[]};state=L.fromLot(raw);state.settings.feedPlan={mode:'manual',kg:1,updated:today};
(async()=>{
 window.listeners.message[0]({source:parent,data:{type:'truchapp-detail-boot',session:'A',state,feeding:stock}});
 assert.equal(document.body.dataset.ready,'true','El detalle debe abrir sin errores.');
 await elements.get('tab-alimentacion').emit('click');
 assert.equal(elements.get('pane-alimentacion').hidden,false);
 assert.match(elements.get('lotFeedingContent').innerHTML,/Stock y días de cobertura/);
 assert.equal(elements.get('mainAction').textContent,'+ Registrar alimentación');
 const action=new Element();action.dataset.lotFeed='biometry';await elements.get('lotFeedingContent').emit('click',action);
 assert.equal(elements.get('pane-resumen').hidden,false);
 assert.equal(elements.get('biometrySection').open,true);
 elements.get('sampleDate').value=today;elements.get('sampleTime').value='10:00';elements.get('sampleWeight').value='9';
 await elements.get('sampleForm').emit('submit');
 assert.equal(saves,1);assert.equal(state.samples.length,2);assert.equal(state.samples.at(-1).weight,9);
 assert.equal(state.daily.length,0,'Biometría no crea una entrega de alimento.');
 assert.equal(elements.get('sampleForm').hidden,true,'Conserva un control biométrico por día.');
 await elements.get('tab-alimentacion').emit('click');await elements.get('mainAction').emit('click');
 assert.equal(elements.get('dailyDialog').open,true,'El botón usa el registro diario existente.');
 const target=new Element('dailyFeedMode');target.value='manual';await elements.get('dailyFeedStock').emit('change',target);
 elements.get('dailyFeed').value='0';elements.get('dailyMortality').value='0';elements.get('dailyDiscard').value='0';elements.get('dailyAppetite').value='normal';
 await elements.get('dailyForm').emit('submit');
 assert.equal(saves,2);assert.equal(state.daily.length,1);assert.equal(state.daily[0].feed,0);
 const rawB={...raw,id:'B',code:'Lote B'},b=L.fromLot(rawB);window.listeners.message[0]({source:parent,data:{type:'truchapp-detail-boot',session:'B',state:b,feeding:stock}});
 assert.equal(elements.get('biometrySection').open,false,'La vista reutilizada cierra la biometría del otro lote.');
 await elements.get('tab-alimentacion').emit('click');action.dataset.lotFeed='stock';await elements.get('lotFeedingContent').emit('click',action);
 assert(messages.some(m=>m.type==='truchapp-detail-open-stock'&&m.session==='B'));
 console.log(JSON.stringify({status:'passed',checks:['detalle abre','pestaña alimentación','biometría en resumen','biometría persiste','un control por día','registro diario compartido','cero confirmado','vista reutilizada por lote','enlace a Almacén'],environment:'DOM simulado, sin renderizado Android'}));
})().catch(error=>{console.error(error);process.exitCode=1;});
