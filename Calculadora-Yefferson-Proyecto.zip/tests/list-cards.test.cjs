const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
const Cards=require('../app/src/main/assets/ui/lotes/list-cards-data.js');
const Summary=require('../app/src/main/assets/ui/lotes/detail/summary-data.js');
const Engine=require('../app/src/main/assets/ui/lotes/lot-detail-data.js');
const source=fs.readFileSync(require.resolve('../app/src/main/assets/ui/shared/storage.js'),'utf8');
const copy=v=>JSON.parse(JSON.stringify(v));
function lot(id='A'){return{id,code:'Lote '+id,date:'2026-11-01',initialN:2000,initialWeight:5,n:2000,w:5,m:0,discarded:0,alimentoConsumido:null,history:[],targetWeight:250,unit:'Jaula'};}
function data(){return Engine.fromLot(lot());}
test('instalaciones anteriores conservan las cuatro tarjetas originales; los borradores son copias',()=>{
 const l=lot(),ids=Cards.selection(l);assert.deepEqual(ids,['fish','growth','biomass','survival']);
 ids[0]='length';assert.equal(Cards.selection(l)[0],'fish');assert.equal(l.listCards,undefined);
 for(const invalid of [[],['fish'],['fish','fish','growth','biomass'],['fish','bad','growth','biomass'],['fish','__proto__','growth','biomass']]){assert.equal(Cards.valid(invalid),false);assert.deepEqual(Cards.selection({listCards:invalid}),Cards.defaults);}
 assert.equal(Cards.catalog.length,13);
});
test('elegir y ordenar es independiente por lote y no cambia registros ni existencias',()=>{
 const lots=[lot(),lot('B')];lots[0].n=1990;lots[0].history=[{d:'2026-11-02',w:6,feedKg:2}];lots[0].customField={keep:true};
 const before=copy(lots),ids=['fcr','length','fish','cv'],updated=Cards.updateLots(lots,'A',ids);
 assert.deepEqual(lots,before);assert.deepEqual(updated[0].listCards,ids);assert.equal(updated[1],lots[1]);
 const {listCards,...production}=updated[0];assert.deepEqual(production,before[0]);ids.reverse();assert.equal(updated[0].listCards[0],'fcr');
 assert.throws(()=>Cards.updateLots(lots,'missing',Cards.defaults),/ya no está/);
 assert.throws(()=>Cards.updateLots(lots,'A',['fish']),/cuatro/);
});
test('una tarjeta sin registros mantiene ausencia; el alimento cero sí se muestra como cero',()=>{
 const d=data(),before=copy(d),m=Cards.metrics(d);
 assert.equal(m.fish.raw,2000);assert.equal(m.growth.value,'5 g');assert.equal(m.biomass.value,'10 kg');assert.equal(m.survival.raw,100);
 for(const key of ['consumed','feed','length','condition','sgr','cv','fcr','efficiency','density'])assert.equal(m[key].raw,null,key);
 assert.deepEqual(d,before);
 d.daily.push({id:'day',date:'2026-11-02',feed:0,mortality:0,discard:0});d.settings.feedPlan={mode:'manual',kg:0};
 assert.equal(Cards.metrics(d).consumed.value,'0 kg');assert.equal(Cards.metrics(d).feed.value,'0 kg');
});
test('las opciones usan la biometría, cobertura diaria, bajas y volumen del detalle',()=>{
 const d=data();d.samples.push({id:'s2',date:'2026-11-03',time:'10:00',weight:10,length:8,individualWeights:[9,10,11],legacyPeriod:false});
 d.daily=[{date:'2026-11-02',feed:1,mortality:0,discard:0},{date:'2026-11-03',feed:1,mortality:20,discard:0}];d.settings.volume=10;
 const m=Cards.metrics(d),near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} ≠ ${b}`);
 assert.equal(m.fish.raw,1980);assert.equal(m.survival.raw,99);near(m.biomass.raw,19.8);near(m.density.raw,1.98);
 near(m.condition.raw,100*10/512);near(m.cv.raw,10);near(m.sgr.raw,100*Math.log(2)/2);near(m.fcr.raw,2/9.8);near(m.efficiency.raw,490);
 d.daily[0].mortality=null;assert.equal(Cards.metrics(d).fcr.raw,null);assert.equal(Cards.metrics(d).efficiency.raw,null);
 d.daily[0].mortality=0;d.daily.forEach(r=>r.feed=0);assert.equal(Cards.metrics(d).fcr.raw,0);assert.equal(Cards.metrics(d).efficiency.raw,null);
});
test('la ración de tabla respeta vigencia, peso, apetito y límites del agua existentes',()=>{
 const d=data(),now=new Date(),day=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-'),time=now.toTimeString().slice(0,5);
 d.settings.feedPlan={mode:'table',rate:2,weightMin:1,weightMax:100,tempMin:5,tempMax:20};
 d.water=[{lotId:d.lot.id,param:'oxygen',date:day,time,value:7},{lotId:d.lot.id,param:'temperature',date:day,time,value:12}];
 const s={...Summary.summary(d),biometryAge:0};assert.equal(Summary.feedingPlan(d,s).kg,.2);
 assert.equal(Summary.feedingPlan(d,{...s,biometryAge:99}).kg,null);
 assert.equal(Summary.feedingPlan(d,{...s,weight:1000}).kg,null);
 assert.equal(Summary.feedingPlan(d,{...s,today:{appetite:'bajo'}}).kg,null);
 d.water[0].value=0;assert.equal(Summary.feedingPlan(d,s).kg,null);
 d.water[0].value=7;d.water[0].date='2000-01-01';assert.equal(Summary.feedingPlan(d,s).kg,null);
});
test('una actualización posterior del detalle conserva las preferencias',()=>{
 const l={...lot(),listCards:['length','sgr','efficiency','fish']},d=Engine.fromLot(l);d.settings.volume=10;
 assert.deepEqual(Engine.toLot(l,d).listCards,l.listCards);
 const empty=data();empty.daily=[{date:'2026-11-02',mortality:2000,discard:0,feed:null}];empty.settings.volume=10;
 const m=Cards.metrics(empty);assert.equal(m.fish.raw,0);assert.equal(m.biomass.raw,0);assert.equal(m.survival.raw,0);assert.equal(m.density.raw,0);
});
async function store(backing){
 const classes={add(){},remove(){}},document={documentElement:{classList:classes},getElementById:()=>null};
 const window={localStorage:{length:0,getItem:()=>null},dispatchEvent(){},crypto:require('node:crypto')};
 window.AndroidAI={farmRequest(id,command,raw){setTimeout(()=>{try{
  const input=JSON.parse(raw);let result;
  if(command==='bootstrap')result={web:backing.web,revision:backing.revision};
  else if(command==='commit'){
   if(backing.fail)throw Error('Disco lleno simulado');
   assert.equal(input.revision,backing.revision);backing.commits++;backing.patches.push(copy(input.patch));
   Object.assign(backing.web,input.patch);result={revision:++backing.revision};
  }else throw Error(command);
  window.TruchAppStorageReceive(id,true,0,1,JSON.stringify(result));
 }catch(e){window.TruchAppStorageReceive(id,false,0,1,JSON.stringify({error:e.message}));}},1);}};
 vm.runInNewContext(source,{window,document,console,setTimeout,clearTimeout,structuredClone,CustomEvent:class{constructor(t){this.type=t}},Event:class{}});
 await window.TruchAppStorageBootstrap.initialize();return window.TruchAppStorage;
}
test('guardado confirmado por Android persiste al recargar; fallo y doble envío no sobrescriben',async()=>{
 const key='truchapp_lotes_v1',backing={web:{[key]:JSON.stringify([lot(),lot('B')]),truchapp_lotes_water_quality_v1:'[]'},revision:1,commits:0,patches:[],fail:false};
 const s=await store(backing),before=backing.web[key],ids=['length','fcr','fish','density'];
 const work=()=>s.atomic('Actualizar lotes',()=>s.setItem(key,JSON.stringify(Cards.updateLots(s.json(key,[]),'A',ids))));
 backing.fail=true;await assert.rejects(s.runAsync('Tarjetas',work),/Disco lleno/);assert.equal(s.getItem(key),before);assert.equal(backing.web[key],before);
 backing.fail=false;const pending=s.runAsync('Tarjetas',work);await assert.rejects(s.runAsync('Tarjetas',work),/Espere|Espera/);await pending;
 assert.equal(backing.commits,1);assert.deepEqual(Object.keys(backing.patches[0]),[key]);
 const reloaded=await store(backing),lots=reloaded.json(key,[]);assert.deepEqual(Cards.selection(lots[0]),ids);assert.deepEqual(Cards.selection(lots[1]),Cards.defaults);
 const {listCards,...production}=lots[0];assert.deepEqual(production,lot());assert.equal(backing.web.truchapp_lotes_water_quality_v1,'[]');
});
