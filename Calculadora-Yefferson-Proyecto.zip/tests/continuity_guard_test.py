"""python3 -m unittest discover -s tests -p 'continuity_guard_test.py'"""
import hashlib
import importlib.util
import io
from pathlib import Path
import tempfile
import tracemalloc
import unittest
import warnings
import zipfile

SOURCE = Path(__file__).resolve().parents[1] / 'tools' / 'continuidad.py'
SPEC = importlib.util.spec_from_file_location('continuidad', SOURCE)
guard = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(guard)


class ContinuityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def make_zip(self, name, files):
        path = self.root / name
        with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            for key, data in files.items():
                archive.writestr(key, data)
        return path

    def test_digest_uses_bounded_reads(self):
        class Bounded(io.BytesIO):
            def read(self, size=-1):
                if size != guard.CHUNK:
                    raise AssertionError('Se intentó leer el archivo entero.')
                return super().read(size)
        data = b'x' * (guard.CHUNK * 3 + 31)
        self.assertEqual(guard.digest(Bounded(data)), hashlib.sha256(data).hexdigest())

    def test_package_preserves_64_mib_asset_with_bounded_memory(self):
        base = self.root / 'base.zip'
        block = b'TruchApp' * (guard.CHUNK // 8)
        with zipfile.ZipFile(base, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            with archive.open('assets/recurso-grande.bin', 'w') as stream:
                for _ in range(64):
                    stream.write(block)
            archive.writestr('ui/module.js', b'antes')
        overlay = self.root / 'changes'
        (overlay / 'ui').mkdir(parents=True)
        (overlay / 'ui/module.js').write_bytes(b'despues')
        (overlay / 'nota.md').write_bytes(b'contexto')
        tracemalloc.start()
        try:
            report = guard.package(base, overlay, self.root / 'new.zip',
                                   ['ui/module.js', 'nota.md'])
            _, peak = tracemalloc.get_traced_memory()
        finally:
            tracemalloc.stop()
        self.assertTrue(report['ok'])
        self.assertEqual(report['modified'], ['ui/module.js'])
        self.assertEqual(report['added'], ['nota.md'])
        self.assertEqual(report['identical_files'], 1)
        self.assertLess(peak, 20 * guard.CHUNK)
        before = guard.inventory(base)['files']['assets/recurso-grande.bin']
        after = guard.inventory(self.root / 'new.zip')['files']['assets/recurso-grande.bin']
        self.assertEqual(before, after)
        self.assertEqual(after['size'], 64 * guard.CHUNK)

    def test_comparison_detects_unapproved_edits(self):
        old = self.make_zip('old.zip', {'a.js': b'1', 'b.js': b'1'})
        new = self.make_zip('new.zip', {'a.js': b'2', 'b.js': b'2'})
        report = guard.compare(old, new, ['a.js'])
        self.assertFalse(report['ok'])
        self.assertEqual(report['outside_scope'], ['b.js'])

    def test_package_rejects_unapproved_overlay_before_creating_output(self):
        base = self.make_zip('base.zip', {'a.js': b'1'})
        overlay = self.root / 'changes'
        overlay.mkdir()
        (overlay / 'b.js').write_bytes(b'2')
        with self.assertRaises(ValueError):
            guard.package(base, overlay, self.root / 'out.zip', ['a.js'])
        self.assertFalse((self.root / 'out.zip').exists())

    def test_removal_requires_explicit_deletion(self):
        old = self.make_zip('old.zip', {'a.js': b'1', 'b.js': b'1'})
        new = self.make_zip('new.zip', {'a.js': b'1'})
        self.assertFalse(guard.compare(old, new, ['b.js'])['ok'])
        self.assertTrue(guard.compare(old, new, deleted=['b.js'])['ok'])

    def test_duplicate_names_are_rejected(self):
        path = self.root / 'duplicate.zip'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            with zipfile.ZipFile(path, 'w') as archive:
                archive.writestr('a.js', '1')
                archive.writestr('a.js', '2')
        with self.assertRaises(ValueError):
            guard.inventory(path)

    def test_invalid_paths_are_rejected(self):
        path = self.make_zip('bad.zip', {'../escape.js': b'1'})
        with self.assertRaises(ValueError):
            guard.inventory(path)

    def test_base_and_existing_output_are_never_overwritten(self):
        base = self.make_zip('base.zip', {'a.js': b'1'})
        before = base.read_bytes()
        overlay = self.root / 'changes'
        overlay.mkdir()
        with self.assertRaises(ValueError):
            guard.package(base, overlay, base)
        self.assertEqual(base.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
