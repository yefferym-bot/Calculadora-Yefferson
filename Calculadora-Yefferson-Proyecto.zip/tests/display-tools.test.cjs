const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const assets=path.join(__dirname,'../app/src/main/assets');
const source=name=>fs.readFileSync(path.join(assets,'ui/shared/'+name),'utf8');
class Element{
 constructor(){this.dataset={};this.attrs={};this.children=[];this.events={};this.style={};this.hidden=true;this.classList={add(){},remove(){}};}
 setAttribute(k,v){this.attrs[k]=v}addEventListener(t,f){(this.events[t]??=[]).push(f)}append(e){this.children.push(e)}
 set innerHTML(s){this.html=s;this.span=new Element();this.button=new Element()}
 querySelector(s){return s==='button'?this.button:s==='span'?this.span:null}
 getBoundingClientRect(){return{height:79}}remove(){}
}
async function fixture(child=false){
 const timers=new Map(),events={},docEvents={},phone=new Element(),list=new Element(),contrast=new Element(),compact=new Element(),expanded=new Element(),frame={contentWindow:{messages:[],postMessage(m){this.messages.push(m)}}},nav=new Element();
 compact.dataset.lotesView='compact';expanded.dataset.lotesView='expanded';
 const document={documentElement:new Element(),body:new Element(),querySelector:s=>s==='.phone'?phone:null,getElementById:id=>id==='bottomNav'?nav:null,createElement:()=>new Element(),addEventListener(t,f){(docEvents[t]??=[]).push(f)},querySelectorAll:s=>s==='[data-display-contrast]'?[contrast]:s==='[data-lotes-view]'?[compact,expanded]:s==='#lotesList'?[list]:s==='.approvedLotFrame'?[frame]:[]};
 document.documentElement.dataset.displayDocument=child?'detail':'';
 let nextTimer=0,queued=null,patches=[],revision=1;
 const web={truchapp_lotes_v1:'[{"id":"L","n":1000}]',truchapp_lotes_water_quality_v1:'[]'};
 const ctx={document,console,structuredClone,crypto:require('node:crypto'),setTimeout(fn,ms){const id=++nextTimer;timers.set(id,{fn,ms});return id},clearTimeout:id=>timers.delete(id),CustomEvent:class{constructor(type,options){this.type=type;this.detail=options?.detail}},Event:class{constructor(type){this.type=type}},addEventListener(t,f){(events[t]??=[]).push(f)},dispatchEvent(e){for(const f of [...events[e.type]||[]])f(e)},localStorage:{length:0,getItem:()=>null,setItem(){},removeItem(){}}};
 ctx.window=ctx;ctx.parent=child?{}:ctx;
 ctx.AndroidAI={farmRequest(id,command,raw){const input=JSON.parse(raw);if(command==='bootstrap')ctx.TruchAppStorageReceive(id,true,0,1,JSON.stringify({web,revision}));else if(command==='commit')queued={id,input};else throw Error(command)},farmCommitSync(raw){const input=JSON.parse(raw);patches.push(input.patch);Object.assign(web,input.patch);return JSON.stringify({ok:true,result:{revision:++revision}})}};
 vm.createContext(ctx);vm.runInContext(source('storage.js'),ctx);await ctx.TruchAppStorageBootstrap.initialize();
 vm.runInContext(source('display-preferences.js'),ctx);vm.runInContext(source('save-feedback.js'),ctx);
 function flush(){let done=false;while(!done){const entry=[...timers].find(([,t])=>t.ms===0);if(!entry){done=true;continue}timers.delete(entry[0]);entry[1].fn();}}
 flush();
 return{ctx,web,phone,list,contrast,compact,expanded,frame,patches,timers,flush,
  click(target){for(const f of docEvents.click||[])f({target:{closest:s=>s===target?{}:null}})},
  ack(ok=true){assert.ok(queued);const{id,input}=queued;queued=null;if(ok){patches.push(input.patch);Object.assign(web,input.patch);ctx.TruchAppStorageReceive(id,true,0,1,JSON.stringify({revision:++revision}));}else ctx.TruchAppStorageReceive(id,false,0,1,JSON.stringify({error:'Disco lleno simulado'}));},
  get toast(){return phone.children.find(e=>e.id==='truchappSaveFeedback')}
 };
}
(async()=>{const passed=[];async function test(name,fn){await fn();passed.push(name)}
 await test('predeterminado conserva la vista ampliada y el contraste habitual',async()=>{const f=await fixture();assert.equal(f.list.dataset.view,'expanded');assert.equal(f.ctx.document.documentElement.dataset.highContrast,'false');assert.equal(f.expanded.attrs['aria-pressed'],'true');assert.equal(f.toast,undefined);});
 await test('preferencias de vista y contraste no escriben registros de producción',async()=>{const f=await fixture(),before=f.web.truchapp_lotes_v1;f.ctx.TruchAppDisplay.set({highContrast:true,lotView:'compact'});f.flush();assert.equal(f.list.dataset.view,'compact');assert.equal(f.contrast.attrs['aria-pressed'],'true');assert.equal(f.web.truchapp_lotes_v1,before);assert.deepEqual(Object.keys(f.patches[0]),['truchapp_display_preferences_v1']);assert.equal(f.toast,undefined);assert.equal(f.ctx.TruchAppDisplay.read().highContrast,true);});
 await test('el aviso espera la confirmación real y se oculta solo después',async()=>{const f=await fixture(),s=f.ctx.TruchAppStorage;const saving=s.runAsync('Guardar lote',()=>s.setItem('truchapp_lotes_v1','[{"id":"L","n":990}]'));f.flush();assert.equal(f.toast,undefined);f.ack();await saving;f.flush();assert.equal(f.toast.hidden,false);assert.equal(f.toast.span.textContent,'Cambios guardados');assert.equal(f.toast.style.bottom,'91px');const hide=[...f.timers.values()].find(t=>t.ms===4000);hide.fn();assert.equal(f.toast.hidden,true);});
 await test('un fallo revierte datos y nunca muestra una confirmación de éxito',async()=>{const f=await fixture(),s=f.ctx.TruchAppStorage,before=f.web.truchapp_lotes_v1;const saving=s.runAsync('Guardar',()=>s.setItem('truchapp_lotes_v1','[{"id":"L","n":1}]'));f.ack(false);await assert.rejects(saving,/Disco lleno/);f.flush();assert.equal(s.getItem('truchapp_lotes_v1'),before);assert.equal(f.web.truchapp_lotes_v1,before);assert.equal(f.toast,undefined);});
 await test('un commit sin cambios y una preferencia visual permanecen silenciosos',async()=>{const f=await fixture();f.ctx.dispatchEvent({type:'truchapp-storage-committed'});f.ctx.TruchAppDisplay.set({lotView:'compact'});f.flush();assert.equal(f.toast,undefined);});
 await test('el detalle conserva su propio aviso con Deshacer, sin duplicación',async()=>{const f=await fixture(),s=f.ctx.TruchAppStorage;f.ctx.TruchAppLotDetailHost={isOpen:()=>true};const saving=s.runAsync('Detalle',()=>s.setItem('truchapp_lotes_v1','[{"id":"L","n":980}]'));f.ack();await saving;f.flush();assert.equal(f.toast,undefined);});
 await test('el contraste solo acepta mensajes de su padre en el documento de detalle',async()=>{const f=await fixture(true);f.ctx.dispatchEvent({type:'message',source:{},data:{type:'truchapp-display-preferences',highContrast:true}});assert.equal(f.ctx.document.documentElement.dataset.highContrast,'false');f.ctx.dispatchEvent({type:'message',source:f.ctx.parent,data:{type:'truchapp-display-preferences',highContrast:true}});assert.equal(f.ctx.document.documentElement.dataset.highContrast,'true');assert.equal(f.patches.length,0);});
 await test('el acceso al respaldo abre el panel existente sin exportar automáticamente',async()=>{const f=await fixture();let opened=0;f.ctx.TruchAppMenu={openBackup(){opened++}};f.click('[data-display-backup]');assert.equal(opened,1);assert.equal(f.patches.length,0);});
 console.log(JSON.stringify({status:'passed',cases:passed.length,tests:passed},null,2));
})().catch(error=>{console.error(error);process.exitCode=1});
