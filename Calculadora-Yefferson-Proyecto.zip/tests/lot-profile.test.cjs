const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../app/src/main/assets/ui/lotes/lot-detail-data.js');
const copy=v=>JSON.parse(JSON.stringify(v));
function raw(){return{id:'stable-A',code:'Lote A',stage:'Alevinaje',unit:'Jaula',origin:'Proveedor',date:'2026-11-01',initialN:1000,initialWeight:8,n:995,w:9,m:5,discarded:0,targetWeight:250,alimentoConsumido:2,listCards:['fish','growth','biomass','survival'],custom:{keep:true},history:[{d:'2026-11-02',w:9,m:5,discard:0,feedKg:2,x:'Control anterior'}]};}
test('un lote anterior sin jaula abre sin inventar una asignación ni escribir el original',()=>{
 const lot=raw(),before=copy(lot),d=L.fromLot(lot);
 assert.equal(d.lot.cageAssignment,'');assert.deepEqual(lot,before);
 assert.equal(d.lot.date,lot.date);assert.equal(d.lot.initialN,lot.initialN);
});
test('editar la ficha persiste por la ruta del detalle y conserva identidad, historial y producción',()=>{
 const lot=raw(),d=L.fromLot(lot),baseline=L.toLot(lot,d),before=copy(d);
 Object.assign(d.lot,{code:'Lote nuevo',stage:'Engorde',unit:'Tanque',origin:'Otro proveedor',cageAssignment:'Jaula 03'});
 const saved=L.toLot(lot,d),reopened=L.fromLot(saved);
 for(const key of ['code','stage','unit','origin','cageAssignment'])assert.equal(reopened.lot[key],d.lot[key]);
 for(const key of ['id','date','initialN','initialWeight','n','w','l','m','discarded','alimentoConsumido','fcr','targetWeight','history','listCards','custom'])assert.deepEqual(saved[key],baseline[key],key);
 for(const key of ['samples','daily','settings','water','legacyArchive','openingBalance'])assert.deepEqual(reopened[key],before[key],key);
});
test('una asignación puede limpiarse y sigue vacía después de otra actualización',()=>{
 let lot=raw(),d=L.fromLot(lot);d.lot.cageAssignment='Jaula 04';lot=L.toLot(lot,d);
 d=L.fromLot(lot);d.lot.cageAssignment='';lot=L.toLot(lot,d);d=L.fromLot(lot);d.settings.volume=20;
 assert.equal(L.fromLot(L.toLot(lot,d)).lot.cageAssignment,'');
});
test('un detailState existente conserva su jaula si todavía no existe el campo raíz',()=>{
 const lot=raw();lot.detailState=L.fromLot(lot);lot.detailState.lot.cageAssignment='Jaula antigua';
 assert.equal(L.fromLot(lot).lot.cageAssignment,'Jaula antigua');
});
test('textos inválidos y otro lote se rechazan; etiquetas antiguas largas se conservan',()=>{
 const lot=raw(),d=L.fromLot(lot);
 d.lot.code=' ';assert.throws(()=>L.validate(d,lot),/ficha/);
 d.lot.code='Lote A';d.lot.cageAssignment={text:'Jaula'};assert.throws(()=>L.validate(d,lot),/ficha/);
 d.lot.cageAssignment='X'.repeat(101);assert.throws(()=>L.validate(d,lot),/ficha/);
 d.lot.cageAssignment='';d.lot.id='other';assert.throws(()=>L.validate(d,lot),/corresponde/);
 lot.code='A'.repeat(120);assert.doesNotThrow(()=>L.validate(L.fromLot(lot),lot));
});
