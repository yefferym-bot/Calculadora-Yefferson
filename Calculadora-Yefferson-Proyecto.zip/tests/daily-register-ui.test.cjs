/* Integración real de la vista con Chromium y un puente Android sintético aislado. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('playwright');
(async()=>{
 const root=path.resolve(__dirname,'../app/src/main/assets');
 const server=http.createServer((req,res)=>{
  const p=path.resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]));
  if(!p.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
  fs.readFile(p,(e,b)=>{if(e){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.ttf':'font/ttf'})[path.extname(p)]||'application/octet-stream');res.end(b);});
 });await new Promise(r=>server.listen(0,'127.0.0.1',r));
 let browser;
 try{
  browser=await chromium.launch({headless:true,...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE?{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE,args:['--no-sandbox','--no-zygote','--single-process','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']}: {})});
  const page=await browser.newPage({viewport:{width:390,height:844},locale:'es-PE',timezoneId:'America/Lima'}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript(()=>{
   const raw=localStorage;for(const k of ['truchapp_intro_v4_1_profile_done','truchapp_welcome_design_20261022_done','truchapp_onboarding_white_apk_v1_done'])raw.setItem(k,'1');
   const make=(id,code)=>({id,code,stage:'Alevinaje',unit:'Jaula',origin:'Proveedor de prueba',date:'2026-11-07',initialN:10000,initialWeight:8,n:9986,w:8,m:14,discarded:0,targetWeight:250,alimentoConsumido:null,history:[],custom:{keep:true}});
   const a=make('A','Lote 1'),b={...make('B','Lote 2'),listCards:['fcr','length','fish','growth']};
   let data=JSON.parse(raw.getItem('__lc_native')||'null')||{profile:JSON.stringify({name:'Prueba',role:'Acuicultor'}),activities:'[]',truchapp_lotes_v1:JSON.stringify([a,b]),truchapp_lotes_water_quality_v1:'[]'};
   for(const k of ['truchapp_intro_v4_1_profile_done','truchapp_welcome_design_20261022_done','truchapp_onboarding_white_apk_v1_done'])data[k]='1';
   let revision=1;window.__commits=[];window.__data=()=>data;
   const apply=p=>{if(window.__fail)throw Error('Fallo simulado de escritura');if(p.revision!==revision)throw Error('Conflicto simulado');for(const[k,v]of Object.entries(p.patch))v===null?delete data[k]:data[k]=v;revision++;window.__commits.push(p);raw.setItem('__lc_native',JSON.stringify(data));return{revision};};
   const reply=(id,ok,r)=>{const s=JSON.stringify(r),n=Math.ceil(s.length/20000)||1;for(let i=0;i<n;i++)setTimeout(()=>window.TruchAppStorageReceive(id,ok,i,n,s.slice(i*20000,(i+1)*20000)),5);};
   window.AndroidAI={farmRequest(id,c,s){try{const p=JSON.parse(s);let r;if(c==='bootstrap'||c==='snapshot')r={web:data,revision};else if(c==='commit')r=apply(p);else if(c==='health')r={engine:'Prueba',bytes:1000,lots:2,daily:0,water:0,recovery:{lastBackup:0}};else r={revision};reply(id,true,r);}catch(e){reply(id,false,{error:e.message});}},farmCommitSync(s){try{return JSON.stringify({ok:true,result:apply(JSON.parse(s))});}catch(e){return JSON.stringify({error:e.message});}},getLots(){return data.truchapp_lotes_v1;},getActivities(){return data.activities;},getProfile(){return data.profile;},getMemories(){return'[]';},getModelState(){return JSON.stringify({state:'not_downloaded',ready:false});},getKnowledgeState(){return'{}';},scheduleReminder(){},requestNotificationPermission(){},clearPersonalData(){},askAI(){}};
  });
  const url='http://127.0.0.1:'+server.address().port+'/index.html',frame=page.frameLocator('.approvedLotFrame');
  async function launch(){await page.goto(url,{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.TruchAppData&&window.TruchAppStorage);await page.locator('#farmBoot').waitFor({state:'detached'});await page.locator('.nav[data-target="lotes"]').click();}
  const read=()=>page.evaluate(()=>JSON.parse(window.__data().truchapp_lotes_v1));
  const water=()=>page.evaluate(()=>JSON.parse(window.__data().truchapp_lotes_water_quality_v1));
  let initialWrites=0;const writes=async()=>await page.evaluate(()=>window.__commits.length)-initialWrites;
  const screenshot=async name=>{if(process.env.TRUCHAPP_QA_SCREENSHOTS){fs.mkdirSync(process.env.TRUCHAPP_QA_SCREENSHOTS,{recursive:true});await page.screenshot({path:path.join(process.env.TRUCHAPP_QA_SCREENSHOTS,name+'.png')});}};
  async function open(id='A'){await page.locator('.registerLoteBtn[data-lote-id="'+id+'"]').click();await frame.locator('#dailyDialog').waitFor({state:'visible'});await page.waitForFunction(()=>!document.querySelector('.approvedLotFrame').inert);await page.locator('.lotLoading').evaluate(el=>Promise.all(el.getAnimations().map(a=>a.finished.catch(()=>{}))));}
  async function close(){await frame.locator('#dailyDialog .close').click();await frame.locator('#closeDetail').click();}
  async function edit(date){await frame.locator('#dailyDate').fill(date);await frame.locator('#dailyDate').dispatchEvent('change');}
  await launch();initialWrites=await writes();const initial=await read(),originalB=initial[1];await open();
  assert.equal(await writes(),0);assert.equal(await frame.locator('#dailyTitle').innerText(),'Registro diario - Lote 1');
  assert.equal(await frame.locator('#dailyContext').innerText(),'Complete su registro diario');
  assert.equal(await frame.locator('#dailyFeedStock,#dailyFeedMode,.dailyHint').count(),0);
  assert.equal(await frame.locator('#dailyWaterFields input').count(),4);
  for(const id of ['dailyFeed','dailyMortality','dailyDiscard']){assert.equal(await frame.locator('#'+id).getAttribute('type'),'number');assert.equal(await frame.locator('#'+id).inputValue(),'');assert.equal(await frame.locator('#'+id).isEditable(),true);}
  assert.equal(await frame.locator('#dailyNote').evaluate(el=>getComputedStyle(el).color),'rgb(0, 0, 0)');
  await screenshot('daily-390-top');
  for(const width of [390,320]){
   await page.setViewportSize({width,height:width===390?844:700});
   const size=await frame.locator('#dailyDialog').evaluate(el=>({w:el.clientWidth,s:el.scrollWidth}));assert(size.s<=size.w+1,JSON.stringify(size));
   const alignment=await frame.locator('.dailyHeader').evaluate(el=>{const a=el.querySelector('h2').getBoundingClientRect(),b=el.querySelector('button').getBoundingClientRect();return Math.abs(a.y+a.height/2-b.y-b.height/2);});assert(alignment<1,'Cierre centrado respecto al título');
   await frame.locator('#dailyFormBody').evaluate(el=>el.scrollTop=el.scrollHeight);await frame.locator('#saveDaily').scrollIntoViewIfNeeded();await screenshot('daily-'+width+'-footer');assert(await frame.locator('#saveDaily').isVisible());
  }
  await page.setViewportSize({width:390,height:844});
  await frame.locator('#dailyWaterAdd').click();await frame.locator('#dailyWaterParam').selectOption('nitrite');
  assert.equal(await frame.locator('#dailyWaterFields input').count(),5);
  assert.equal(await frame.locator('#dailyWaterParam option[value="nitrite"]').count(),0);
  await frame.locator('#dailyWater-nitrite').fill('0.03');await close();assert.equal(await writes(),0,'Cancelar parámetros no escribe');await open();assert.equal(await frame.locator('#dailyWaterFields input').count(),4);
  await frame.locator('#dailyWater-temperature').fill('12.5');await frame.locator('#dailyWater-oxygen').fill('7.2');await frame.locator('#dailyWater-ph').fill('15');
  await frame.locator('#saveDaily').click();assert.match(await frame.locator('#dailyError').innerText(),/pH/);assert.equal(await writes(),0);
  await frame.locator('#dailyWater-ph').fill('7.4');await frame.locator('#dailyWater-tan').fill('0');
  await frame.locator('#dailyWaterAdd').click();await frame.locator('#dailyWaterParam').selectOption('nitrite');await frame.locator('#dailyWater-nitrite').fill('0.02');
  const date=await frame.locator('#dailyDate').inputValue();
  await frame.locator('#saveDaily').evaluate(el=>{el.dispatchEvent(new MouseEvent('click',{bubbles:true}));el.dispatchEvent(new MouseEvent('click',{bubbles:true}));});await frame.locator('#dailyDialog').waitFor({state:'hidden'});
  let rows=await water(),saved=await read();assert.equal(await writes(),1,'Guardado atómico y doble envío único');assert.equal(saved[0].detailState.daily.length,1);assert.equal(saved[0].detailState.daily[0].feed,null);assert.equal(saved[0].detailState.daily[0].mortality,null);assert.equal(saved[0].n,initial[0].n);assert.equal(rows.length,5);assert.equal(rows.find(r=>r.params.tan).params.tan.value,0);assert.deepEqual(saved[1],originalB);
  const ids=rows.map(r=>r.id).sort();
  await frame.locator('#closeDetail').click();await open();await edit(date);assert.equal(await frame.locator('#dailyWater-temperature').inputValue(),'12.5');assert.equal(await frame.locator('#dailyWater-nitrite').inputValue(),'0.02');
  await frame.locator('#dailyWater-temperature').fill('13.1');await frame.locator('#dailyFeed').fill('1.25');await frame.locator('#dailyMortality').fill('0');await frame.locator('#dailyDiscard').fill('0');await frame.locator('#dailyNote').fill('Medición de prueba');
  await page.evaluate(()=>window.__fail=true);await frame.locator('#saveDaily').click();await frame.locator('#dailyError').filter({hasText:'Fallo simulado'}).waitFor();assert.equal(await writes(),1);assert.equal(await frame.locator('#dailyWater-temperature').inputValue(),'13.1');assert.equal((await water()).find(r=>r.params.temperature).params.temperature.value,12.5);
  await page.evaluate(()=>window.__fail=false);await frame.locator('#saveDaily').click();await frame.locator('#dailyDialog').waitFor({state:'hidden'});rows=await water();saved=await read();assert.equal(await writes(),2);assert.equal(rows.length,5);assert.deepEqual(rows.map(r=>r.id).sort(),ids);assert.equal(rows.find(r=>r.params.temperature).params.temperature.value,13.1);assert.equal(saved[0].detailState.daily.length,1);assert.equal(saved[0].detailState.daily[0].feed,1.25);assert.equal(saved[0].alimentoConsumido,1.25);assert.equal(saved[0].n,initial[0].n);
  await frame.locator('#closeDetail').click();await open();await frame.locator('#dailyWater-tan').fill('');await frame.locator('[data-daily-remove="nitrite"]').click();await frame.locator('#saveDaily').click();await frame.locator('#dailyDialog').waitFor({state:'hidden'});rows=await water();assert.equal(rows.length,3,'Borrar o quitar elimina solo las mediciones diarias asociadas');assert(!rows.some(r=>r.params.tan||r.params.nitrite));
  await frame.locator('#closeDetail').click();await open('B');assert.equal(await frame.locator('#dailyTitle').innerText(),'Registro diario - Lote 2');assert.equal(await frame.locator('#dailyWater-temperature').inputValue(),'');await close();
  await page.locator('#tnMenuOpen').click();await page.locator('#tnMenuDrawer [data-display-contrast]').click();await page.locator('#tnMenuDrawer [data-display-contrast]').click();await page.locator('#tnMenuClose').click();await open();
  assert.equal(await frame.locator('html').getAttribute('data-theme'),'dark');await screenshot('daily-dark-top');await frame.locator('#dailyFormBody').evaluate(el=>el.scrollTop=el.scrollHeight);await frame.locator('#saveDaily').scrollIntoViewIfNeeded();await screenshot('daily-dark-footer');
  const contrast=await frame.locator('#dailyNote').evaluate(el=>{const lum=c=>{const v=c.match(/[\d.]+/g).slice(0,3).map(Number).map(n=>(n/=255)<=.04045?n/12.92:((n+.055)/1.055)**2.4);return .2126*v[0]+.7152*v[1]+.0722*v[2];};const s=getComputedStyle(el),a=lum(s.color),b=lum(s.backgroundColor);return(Math.max(a,b)+.05)/(Math.min(a,b)+.05);});assert(contrast>=4.5);
  await close();await launch();await open();assert.equal(await frame.locator('#dailyWater-temperature').inputValue(),'13.1','Persiste tras recargar');await close();
  // Registro antiguo vinculado: conservar sus entregas y costo al modificar otros campos.
  const L=require('../app/src/main/assets/ui/lotes/lot-detail-data.js'),all=await read();let a=all[0],detail=L.fromLot(a,await water()),day=detail.daily[0];day.feedStock={version:1,lines:[{id:'legacy-line',itemId:'P',itemName:'Alimento de prueba',batch:'B',kg:1.25,kgPerUnit:1,unitCost:4}]};all[0]=L.toLot(a,detail);
  await page.evaluate(all=>{const data=window.__data();data.truchapp_lotes_v1=JSON.stringify(all);localStorage.setItem('__lc_native',JSON.stringify(data));},all);
  await launch();await open();const legacyBefore=await read();await frame.locator('#dailyFeed').fill('2');await frame.locator('#saveDaily').click();assert.match(await frame.locator('#dailyError').innerText(),/entrega vinculada/);assert.deepEqual(await read(),legacyBefore);
  await frame.locator('#dailyFeed').fill('1.25');await frame.locator('#dailyNote').fill('Observación actualizada');await frame.locator('#saveDaily').click();await frame.locator('#dailyDialog').waitFor({state:'hidden'});assert.deepEqual((await read())[0].detailState.daily[0].feedStock,day.feedStock);assert.deepEqual((await read())[1],originalB);
  assert.deepEqual(errors,[]);console.log(JSON.stringify({status:'passed',checks:['diseño aprobado sin bloque de almacén','campos numéricos sin valor implícito','Observaciones negro','cuatro parámetros iniciales','añadir parámetro sin duplicar','cancelar no escribe','validación de pH','solo agua sin inventar alimento ni bajas','guardado único atómico','corregir después de reabrir sin duplicados','fallo revierte ambos historiales y conserva borrador','quitar medición asociada','aislamiento entre lotes','320/390 sin desbordamiento','cierre alineado','controles finales accesibles','modo oscuro legible','persistencia tras recargar','entregas antiguas conservadas']}));
 }finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;});
