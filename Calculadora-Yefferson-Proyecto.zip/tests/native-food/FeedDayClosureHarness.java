import com.yefferson.calculadora.data.db.FeedDayClosure;
import org.json.JSONObject;
import java.time.Instant;
import java.util.TimeZone;

/** Runs production closure logic on a JVM with org.json; no Android/Room simulation. */
public final class FeedDayClosureHarness {
    static int checks;
    static long at(String instant){return Instant.parse(instant).toEpochMilli();}
    static void eq(Object want,Object got){if(!want.equals(got))throw new AssertionError(want+" != "+got);checks++;}
    public static void main(String[] args) throws Exception {
        TimeZone lima=TimeZone.getTimeZone("America/Lima"),ny=TimeZone.getTimeZone("America/New_York");
        eq("2026-11-13",FeedDayClosure.yesterday(at("2026-11-15T04:59:59Z"),lima));
        eq("2026-11-14",FeedDayClosure.yesterday(at("2026-11-15T05:00:00Z"),lima));
        eq("2026-11-14",FeedDayClosure.yesterday(at("2026-11-15T04:59:59Z"),TimeZone.getTimeZone("UTC")));
        eq("2024-02-29",FeedDayClosure.yesterday(at("2024-03-01T17:00:00Z"),lima));
        eq("2026-03-08",FeedDayClosure.yesterday(at("2026-03-09T04:01:00Z"),ny));
        eq("2026-11-01",FeedDayClosure.yesterday(at("2026-11-02T05:01:00Z"),ny));
        JSONObject first=FeedDayClosure.advance(null,at("2026-11-15T05:00:00Z"),lima);
        eq("missing-food-zero",first.getString("policy"));eq("America/Lima",first.getString("timeZone"));
        JSONObject same=FeedDayClosure.advance(first,at("2026-11-15T20:00:00Z"),lima);
        eq(first.toString(),same.toString());
        JSONObject catchup=FeedDayClosure.advance(first,at("2026-11-19T05:00:00Z"),lima);
        eq("2026-11-18",catchup.getString("through"));eq("2026-11-14",first.getString("through"));
        eq(catchup.toString(),FeedDayClosure.advance(catchup,at("2026-11-15T20:00:00Z"),lima).toString());
        JSONObject broken=new JSONObject(first.toString()).put("through","2026-99-99");
        eq("2026-11-14",FeedDayClosure.advance(broken,at("2026-11-15T20:00:00Z"),lima).getString("through"));
        eq(1,FeedDayClosure.advance(new JSONObject().put("version",7),at("2026-11-15T20:00:00Z"),lima).getInt("version"));
        System.out.println("FeedDayClosure production helper: "+checks+" checks passed (JVM, no Room/device).");
    }
}
