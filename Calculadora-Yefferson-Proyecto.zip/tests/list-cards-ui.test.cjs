/* Integración real de la vista con Chromium y un puente Android sintético aislado. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('playwright');
(async()=>{
 const root=path.resolve(__dirname,'../app/src/main/assets');
 const server=http.createServer((req,res)=>{
  const p=path.resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]));
  if(!p.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
  fs.readFile(p,(e,b)=>{if(e){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.ttf':'font/ttf'})[path.extname(p)]||'application/octet-stream');res.end(b);});
 });await new Promise(r=>server.listen(0,'127.0.0.1',r));
 let browser;
 try{
  browser=await chromium.launch({headless:true,...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE?{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE,args:['--no-sandbox','--no-zygote','--single-process','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']}: {})});
  const page=await browser.newPage({viewport:{width:390,height:844}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript(()=>{
   const raw=localStorage;for(const k of ['truchapp_intro_v4_1_profile_done','truchapp_welcome_design_20261022_done','truchapp_onboarding_white_apk_v1_done'])raw.setItem(k,'1');
   const make=(id,code)=>({id,code,stage:'Alevinaje',unit:'Jaula',origin:'Proveedor de prueba',date:'2026-11-07',initialN:10000,initialWeight:8,n:9986,w:8,m:14,discarded:0,targetWeight:250,alimentoConsumido:null,history:[],custom:{keep:true}});
   const a=make('A','Lote 1'),b={...make('B','Lote 2'),listCards:['fcr','length','fish','growth']};
   let data=JSON.parse(raw.getItem('__lc_native')||'null')||{profile:JSON.stringify({name:'Prueba',role:'Acuicultor'}),activities:'[]',truchapp_lotes_v1:JSON.stringify([a,b]),truchapp_lotes_water_quality_v1:'[]'};
   for(const k of ['truchapp_intro_v4_1_profile_done','truchapp_welcome_design_20261022_done','truchapp_onboarding_white_apk_v1_done'])data[k]='1';
   let revision=1;window.__commits=[];window.__data=()=>data;
   const apply=p=>{if(window.__fail)throw Error('Fallo simulado de escritura');if(p.revision!==revision)throw Error('Conflicto simulado');for(const[k,v]of Object.entries(p.patch))v===null?delete data[k]:data[k]=v;revision++;window.__commits.push(p);raw.setItem('__lc_native',JSON.stringify(data));return{revision};};
   const reply=(id,ok,r)=>{const s=JSON.stringify(r),n=Math.ceil(s.length/20000)||1;for(let i=0;i<n;i++)setTimeout(()=>window.TruchAppStorageReceive(id,ok,i,n,s.slice(i*20000,(i+1)*20000)),5);};
   window.AndroidAI={farmRequest(id,c,s){try{const p=JSON.parse(s);let r;if(c==='bootstrap'||c==='snapshot')r={web:data,revision};else if(c==='commit')r=apply(p);else if(c==='health')r={engine:'Prueba',bytes:1000,lots:2,daily:0,water:0,recovery:{lastBackup:0}};else r={revision};reply(id,true,r);}catch(e){reply(id,false,{error:e.message});}},farmCommitSync(s){try{return JSON.stringify({ok:true,result:apply(JSON.parse(s))});}catch(e){return JSON.stringify({error:e.message});}},getLots(){return data.truchapp_lotes_v1;},getActivities(){return data.activities;},getProfile(){return data.profile;},getMemories(){return'[]';},getModelState(){return JSON.stringify({state:'not_downloaded',ready:false});},getKnowledgeState(){return'{}';},scheduleReminder(){},requestNotificationPermission(){},clearPersonalData(){},askAI(){}};
  });
  const url='http://127.0.0.1:'+server.address().port+'/index.html';
  async function launch(){await page.goto(url,{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.TruchAppData&&window.TruchAppStorage);await page.locator('#farmBoot').waitFor({state:'detached'});await page.locator('.nav[data-target="lotes"]').click();}
  const read=()=>page.evaluate(()=>JSON.parse(window.__data().truchapp_lotes_v1));
  const writes=()=>page.evaluate(()=>window.__commits.length);
  const editor=page.locator('#lotCardsEditor');
  async function open(id='A'){
   await page.locator('.editLotCardsBtn[data-lote-id="'+id+'"]').click();await editor.waitFor({state:'visible'});
   await page.waitForFunction(()=>!document.getElementById('lotCardsEditor').inert);
  }
  const close=async()=>{await page.locator('#lc-cancel').click();await editor.waitFor({state:'detached'});};
  const fill=async()=>{for(const id of ['consumed','feed','length','fcr'])await page.locator('[data-add="'+id+'"]').click();};
  async function checkGrid(count){
   const tiles=editor.locator('[data-selected-id]');assert.equal(await tiles.count(),count);
   await tiles.evaluateAll(xs=>Promise.all(xs.flatMap(el=>el.getAnimations().map(a=>a.finished.catch(()=>{})))));
   const rows=await tiles.evaluateAll(xs=>xs.map(x=>Math.round(x.getBoundingClientRect().top)));
   if(count===8){assert.equal(new Set(rows).size,2);assert(rows.slice(0,4).every(n=>Math.abs(n-rows[0])<=1));assert(rows.slice(4).every(n=>Math.abs(n-rows[4])<=1));}
   const size=await editor.evaluate(el=>({w:el.clientWidth,s:el.scrollWidth}));assert(size.s<=size.w+1,JSON.stringify(size));
  }
  const screenshot=async name=>{if(process.env.TRUCHAPP_QA_SCREENSHOTS){fs.mkdirSync(process.env.TRUCHAPP_QA_SCREENSHOTS,{recursive:true});await page.screenshot({path:path.join(process.env.TRUCHAPP_QA_SCREENSHOTS,name+'.png')});}};
  await launch();const before=await read(),initialWrites=await writes();
  await page.evaluate(()=>window.__lotNode=document.querySelector('.lotesLote[data-lote="A"]'));
  await open();assert.equal(await page.evaluate(()=>window.__lotNode===document.querySelector('.lc-focus-slot>.lotesLote')),true,'Se mueve el mismo nodo, sin duplicarlo');
  assert.equal(await page.locator('dialog#lotCardsEditor').count(),0);assert.equal(await page.locator('#lc-count').innerText(),'4 / 8');
  assert.equal(await page.locator('.lc-option.is-chosen').count(),4);assert.equal(await editor.locator('[data-add]').count(),13);
  assert.notEqual(await page.locator('.lc-backdrop').evaluate(el=>getComputedStyle(el).backdropFilter),'none');
  assert.equal(await page.locator('#bottomNav').evaluate(el=>el.inert),true);
  await fill();await checkGrid(8);assert.equal(await page.locator('#lc-count').innerText(),'8 / 8');assert.equal(await page.locator('.lc-option.is-chosen').count(),8);await editor.evaluate(el=>{el.scrollTop=0;});await screenshot('initial-eight');
  await page.locator('[data-add="density"]').click();assert.match(await page.locator('#lc-message').innerText(),/hasta ocho/);await checkGrid(8);
  assert.equal(await writes(),initialWrites);assert.deepEqual(await read(),before,'El borrador no escribe');
  await close();assert.equal(await page.evaluate(()=>window.__lotNode===document.querySelector('#lotesList>.lotesLote[data-lote="A"]')),true);
  assert.equal(await page.evaluate(()=>getComputedStyle(window.__lotNode).transform),'none','Cerrar elimina la transformación de retorno');
  assert.equal(await page.locator('.lotesLote[data-lote="A"] [data-card]').count(),4);assert.equal(await page.locator('#bottomNav').evaluate(el=>el.inert),false);
  await open();await fill();await editor.locator('[data-pick="7"]').click();await page.locator('#lc-earlier').click();
  const expected=['fish','growth','biomass','survival','consumed','feed','fcr','length'];
  assert.deepEqual(await editor.locator('[data-selected-id]').evaluateAll(xs=>xs.map(x=>x.dataset.selectedId)),expected);
  await page.locator('#lc-save').evaluate(el=>{el.dispatchEvent(new MouseEvent('click',{bubbles:true}));el.dispatchEvent(new MouseEvent('click',{bubbles:true}));});
  await editor.waitFor({state:'detached'});assert.equal(await writes(),initialWrites+1,'Una confirmación para doble envío');
  const saved=await read();assert.deepEqual(saved[0].listCards,expected);assert.deepEqual(saved[1],before[1]);
  const {listCards,...a}=saved[0];assert.deepEqual(a,before[0],'Solo cambia la preferencia del lote');
  await open();await editor.locator('[data-remove="0"]').click();await page.locator('[data-add="density"]').click();await page.evaluate(()=>window.__fail=true);
  await page.locator('#lc-save').click();await page.locator('#lc-message.is-error').waitFor();assert.match(await page.locator('#lc-message').innerText(),/Fallo simulado/);
  assert.deepEqual((await read())[0].listCards,expected);assert.equal(await editor.locator('[data-selected-id]').count(),8);
  await page.keyboard.press('Tab');assert.equal(await page.evaluate(()=>!!document.activeElement.closest('#lotCardsEditor')),true,'El error conserva el foco dentro del editor');
  await page.evaluate(()=>window.__fail=false);await page.locator('#lc-save').click();await editor.waitFor({state:'detached'});
  const corrected=(await read())[0].listCards;assert.equal(corrected.at(-1),'density');assert(!corrected.includes('fish'));
  await open();for(let n=0;n<8;n++)await editor.locator('[data-remove="0"]').click();assert.equal(await page.locator('#lc-count').innerText(),'0 / 8');assert.equal(await page.locator('#lc-save').isDisabled(),true);
  await page.locator('[data-add="fish"]').click();assert.equal(await page.locator('#lc-save').isDisabled(),false);await close();assert.deepEqual((await read())[0].listCards,corrected);
  await launch();assert.deepEqual((await read())[0].listCards,corrected);await open();await checkGrid(8);
  await editor.evaluate(el=>{el.scrollTop=0;});await screenshot('eight-390');
  const dayColors=await page.locator('.lc-option.is-chosen').first().evaluate(el=>({bg:getComputedStyle(el).backgroundColor,border:getComputedStyle(el).borderColor}));
  const other=await page.locator('.lc-option:not(.is-chosen)').first().evaluate(el=>getComputedStyle(el).backgroundColor);assert.notEqual(dayColors.bg,other);
  await page.setViewportSize({width:320,height:700});await checkGrid(8);await screenshot('eight-320');
  await page.evaluate(()=>document.documentElement.dataset.theme='dark');await editor.evaluate(el=>{el.scrollTop=0;return Promise.all(el.getAnimations({subtree:true}).map(a=>a.finished.catch(()=>{})));});await screenshot('eight-dark');
  const contrasts=await editor.locator('.lc-option,[data-selected-id]').evaluateAll(xs=>{
   const luminance=css=>{const c=css.match(/[\d.]+/g).slice(0,3).map(Number).map(n=>{n/=255;return n<=.04045?n/12.92:((n+.055)/1.055)**2.4;});return .2126*c[0]+.7152*c[1]+.0722*c[2];};
   return xs.map(el=>{const fg=luminance(getComputedStyle(el.querySelector('b')).color),bg=luminance(getComputedStyle(el).backgroundColor);return(Math.max(fg,bg)+.05)/(Math.min(fg,bg)+.05);});
  });assert(contrasts.every(v=>v>=4.5),JSON.stringify(contrasts));
  await close();await page.emulateMedia({reducedMotion:'reduce'});await open();assert.equal(await editor.locator('.lc-active-card').evaluate(el=>el.getAnimations().length),0,'Movimiento reducido sin FLIP');
  await page.keyboard.press('Shift+Tab');assert.equal(await page.evaluate(()=>!!document.activeElement.closest('#lotCardsEditor')),true);
  await page.keyboard.press('Escape');await editor.waitFor({state:'detached'});
  for(let n=0;n<3;n++){await open();await close();}assert.equal(await page.locator('.lc-placeholder').count(),0);
  await open('B');assert.equal(await page.locator('#lc-count').innerText(),'4 / 8');assert.deepEqual(await editor.locator('[data-selected-id]').evaluateAll(xs=>xs.map(x=>x.dataset.selectedId)),before[1].listCards);
  const noOpWrites=await writes();await page.locator('#lc-save').click();await editor.waitFor({state:'detached'});assert.equal(await writes(),noOpWrites,'Guardar sin cambios no escribe');
  await page.locator('.lotesEditRecordBtn[data-lote-id="A"]').click();const frame=page.frameLocator('.approvedLotFrame');await frame.locator('#infoDialog').waitFor({state:'visible'});assert.match(await frame.locator('#lotProfile').innerText(),/Lote 1/);
  assert.deepEqual(errors,[]);console.log(JSON.stringify({status:'passed',checks:['mismo bloque sin modal nuevo','trece indicadores reales','cuatro anteriores conservadas','ocho en dos filas de cuatro','seleccionadas resaltadas','límite de ocho','cancelación sin escrituras','orden conservado','doble envío único','otros datos y lotes idénticos','fallo revierte y permite reintento','cero desactiva Guardar','persistencia al recargar','390 y 320 sin desbordamiento','diurno y oscuro','movimiento reducido','foco y Escape','reaperturas sin duplicados','independencia por lote','ficha anterior sigue abriendo']}));
 }finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;});
