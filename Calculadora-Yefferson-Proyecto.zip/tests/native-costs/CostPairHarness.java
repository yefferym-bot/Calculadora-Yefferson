import com.yefferson.calculadora.pairing.*;
import org.json.*;
import java.nio.file.*;
import java.util.function.Consumer;

/** Production shared-document validator and patching, without Android/TLS/Room doubles. */
public class CostPairHarness {
 static int checks;static void check(boolean ok){if(!ok)throw new AssertionError();checks++;}
 static JSONObject clone(JSONObject v){return new JSONObject(v.toString());}
 static void denied(JSONObject current,JSONObject proposed,Consumer<JSONObject> edit)throws Exception{JSONObject p=clone(proposed);edit.accept(p.getJSONObject("lot").getJSONObject("detailState").getJSONObject("economics"));boolean failed=false;try{PairProduction.validate(current,p);}catch(Exception expected){failed=true;}check(failed);}
 public static void main(String[] args)throws Exception{
  JSONObject current=new JSONObject(Files.readString(Path.of(args[0]))),proposed=new JSONObject(Files.readString(Path.of(args[1])));
  PairProduction.validate(current,proposed);check(true);
  JSONObject old=clone(proposed);old.getJSONObject("lot").getJSONObject("detailState").remove("economics");PairProduction.validate(current,old);check(true);
  denied(current,proposed,e->e.put("foodPrice",-1));denied(current,proposed,e->e.put("version","1"));denied(current,proposed,e->e.put("version",1.5));
  denied(current,proposed,e->e.put("foodPrice","5"));denied(current,proposed,e->e.getJSONObject("expenses").put("mano",1e13));
  denied(current,proposed,e->e.getJSONObject("projection").put("weight",0));denied(current,proposed,e->e.getJSONObject("projection").put("survival",101));
  denied(current,proposed,e->e.getJSONObject("expenses").remove("fijos"));denied(current,proposed,e->e.put("other",2));
  JSONObject free=clone(proposed);free.getJSONObject("lot").getJSONObject("detailState").getJSONObject("economics").put("foodPrice",0);PairProduction.validate(current,free);check(true);
  JSONObject another=clone(current.getJSONObject("lot")).put("id","OTHER").put("code","Lote 2");JSONArray lots=new JSONArray().put(current.getJSONObject("lot")).put(another);
  JSONObject patch=PairProduction.patch(lots,new JSONArray(),current.getJSONObject("lot").getString("id"),proposed);
  JSONArray updated=new JSONArray(patch.getString(PairProduction.LOTS));check(updated.getJSONObject(0).getJSONObject("detailState").getJSONObject("economics").getJSONObject("expenses").getInt("mano")==20);check(PairProduction.canonical(another).equals(PairProduction.canonical(updated.getJSONObject(1))));
  JSONArray ids=new JSONArray().put(current.getJSONObject("lot").getString("id"));JSONObject a=PairProduction.summaries(lots,ids).getJSONObject(0),b=PairProduction.summaries(updated,ids).getJSONObject(0);check(!a.getString("economicsStamp").equals(b.getString("economicsStamp")));check(!b.has("economics"));check(PairProduction.summaries(updated,ids).length()==1);
  System.out.println("Production financial shared validation: "+checks+" checks passed (JVM, no Android/TLS/Room installation).");
 }
}
