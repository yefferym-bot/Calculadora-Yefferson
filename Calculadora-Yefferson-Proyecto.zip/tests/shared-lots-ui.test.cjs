/* Integración real de la vista con Chromium y un puente Android sintético aislado. */
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('playwright');
(async()=>{
 const root=path.resolve(__dirname,'../app/src/main/assets');
 const server=http.createServer((req,res)=>{
  const p=path.resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]));
  if(!p.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
  fs.readFile(p,(e,b)=>{if(e){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.ttf':'font/ttf'})[path.extname(p)]||'application/octet-stream');res.end(b);});
 });await new Promise(r=>server.listen(0,'127.0.0.1',r));
 let browser;
 try{
  browser=await chromium.launch({headless:true,...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE?{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE,args:['--no-sandbox','--no-zygote','--single-process','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']}: {})});
  const context=await browser.newContext({viewport:{width:390,height:844},locale:'es-PE',timezoneId:'America/Lima'}),page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  const installFixture=async(p,fresh=false)=>p.addInitScript(fresh=>{
   const raw=localStorage;if(fresh)raw.clear();if(!fresh)for(const k of ['truchapp_intro_v4_1_profile_done','truchapp_welcome_design_20261022_done','truchapp_onboarding_white_apk_v1_done'])raw.setItem(k,'1');
   const make=(id,code)=>({id,code,stage:'Alevinaje',unit:'Jaula',origin:'Proveedor de prueba',date:'2026-11-07',initialN:10000,initialWeight:8,n:9986,w:8,m:14,discarded:0,targetWeight:250,alimentoConsumido:null,history:[],custom:{keep:true}});
   const a=make('A','Lote 1'),b={...make('B','Lote 2'),listCards:['fcr','length','fish','growth']};
   let data=JSON.parse(raw.getItem('__lc_native')||'null')||{profile:JSON.stringify({name:'Prueba',role:'Acuicultor'}),activities:'[]',truchapp_lotes_v1:JSON.stringify(fresh?[]:[a,b]),truchapp_lotes_water_quality_v1:'[]'};
   if(!fresh)for(const k of ['truchapp_intro_v4_1_profile_done','truchapp_welcome_design_20261022_done','truchapp_onboarding_white_apk_v1_done'])data[k]='1';
   let revision=1;window.__commits=[];window.__data=()=>data;
   const apply=p=>{if(window.__fail)throw Error('Fallo simulado de escritura');if(p.revision!==revision)throw Error('Conflicto simulado');for(const[k,v]of Object.entries(p.patch))v===null?delete data[k]:data[k]=v;revision++;window.__commits.push(p);raw.setItem('__lc_native',JSON.stringify(data));return{revision};};
   const reply=(id,ok,r)=>{const s=JSON.stringify(r),n=Math.ceil(s.length/20000)||1;for(let i=0;i<n;i++)setTimeout(()=>window.TruchAppStorageReceive(id,ok,i,n,s.slice(i*20000,(i+1)*20000)),5);};
   window.AndroidAI={farmRequest(id,c,s){try{const p=JSON.parse(s);let r;if(c==='bootstrap'||c==='snapshot')r={web:data,revision};else if(c==='commit')r=apply(p);else if(c==='health')r={engine:'Prueba',bytes:1000,lots:2,daily:0,water:0,recovery:{lastBackup:0}};else r={revision};reply(id,true,r);}catch(e){reply(id,false,{error:e.message});}},farmCommitSync(s){try{return JSON.stringify({ok:true,result:apply(JSON.parse(s))});}catch(e){return JSON.stringify({error:e.message});}},getLots(){return data.truchapp_lotes_v1;},getActivities(){return data.activities;},getProfile(){return data.profile;},getMemories(){return'[]';},getModelState(){return JSON.stringify({state:'not_downloaded',ready:false});},getKnowledgeState(){return'{}';},scheduleReminder(){},requestNotificationPermission(){},clearPersonalData(){},askAI(){}};

   const fixtureStore=raw,model=JSON.parse(raw.getItem('__lp_native')||'null')||{supported:true,mode:'admin',listening:false,searching:false,endpoint:'',invitationUntil:0,notice:'',peers:[],services:[],sessions:[],availableLots:[{id:'A',code:'Lote 1',stage:'Alevinaje',unit:'Jaula'},{id:'B',code:'Lote 2',stage:'Alevinaje',unit:'Jaula'}]};
   window.__lpCalls=[];window.__lpState=model;
   const localReply=(id,ok,value)=>setTimeout(()=>window.TruchAppLocalPairReceive(id,ok,0,1,JSON.stringify(value)),15);
   window.__lpChanged=()=>window.dispatchEvent(new Event('truchapp-local-pair-changed'));
   window.__lpComplete=()=>{const session=model.sessions[0];if(!session)return;session.state='connected';model.peers=[{fingerprint:'b'.repeat(64),name:'Equipo <img src=x>',role:model.mode==='admin'?'collaborator':'admin',revoked:false,permission:'view',lotIds:['A'],lots:[{id:'A',code:'Lote <img src=x>',stage:'Alevinaje',unit:'Jaula'}]}];model.notice='Equipo vinculado y conectado por red local.';window.__lpChanged();};
   window.__nativePairObject=window.AndroidAI;window.AndroidAI.localPairRequest=(id,command,raw)=>{
    const input=JSON.parse(raw);window.__lpCalls.push({command,input});
    model.mode=JSON.parse(data.truchapp_access_mode_v1||'{"mode":"admin"}').mode;
    try{
     if(window.__lpFail&&command==='confirm')throw Error('Fallo simulado al guardar la vinculación');if(window.__lpFailUpdate&&command==='update')throw Error('Fallo simulado al guardar permisos');if(window.__lpFailMaster&&command==='listen')throw Error('Fallo simulado al activar');
     if(command==='qr'){model.listening=true;model.endpoint='192.168.1.5:55000';model.qrExpires=Date.now()+300000;model.invitationUntil=model.qrExpires;model.qr={image:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aB1sAAAAASUVORK5CYII=',expires:model.qrExpires,endpoint:model.endpoint};}
     if(command==='invite'||command==='listen'){model.listening=true;model.endpoint='192.168.1.5:41435';model.invitationUntil=command==='invite'?Date.now()+300000:0;model.notice='Invitación abierta durante 5 minutos.';}
     if(command==='search'){model.searching=true;model.services=[{id:'service-1',name:'TruchApp-prueba'}];}
     if(command==='connect'){if(input.endpoint&&!/^192\.168\.1\.5:41435$/.test(input.endpoint))throw Error('Usa una dirección local válida');model.sessions=[{id:'session-1',name:'Equipo <img src=x>',fingerprint:'b'.repeat(64),code:'1234 5678',state:model.mode==='collaborator'?'waiting':'verify'}];model.notice=model.mode==='collaborator'?'Solicitud enviada. Esperando aprobación del administrador.':'';}
     if(command==='confirm'){model.sessions[0].state='waiting';model.notice='Esperando al otro teléfono.';}
     if(command==='reject'){model.sessions=model.sessions.filter(session=>session.id!==input.session);model.notice=model.mode==='admin'?'Solicitud rechazada.':'Solicitud cancelada.';}
     if(command==='update'){model.peers[0].lotIds=input.lotIds;model.peers[0].permission=input.permission;model.sessions=[];model.notice='Permisos guardados. Reconecta para actualizarlos.';}
     if(command==='revoke'){model.peers[0].revoked=true;model.peers[0].lots=[];model.peers[0].lotIds=[];model.sessions=[];}
     if(command==='disconnect')model.sessions=model.sessions.filter(session=>session.fingerprint!==input.fingerprint);
     if(command==='stop'){model.enabled=false;model.reconnecting=false;model.qrExpires=0;model.listening=false;model.searching=false;model.sessions=[];model.services=[];model.endpoint='';model.invitationUntil=0;}
     model.maxConnections=20;model.connectedCount=model.sessions.filter(session=>session.state==='connected').length;model.capacityUsed=model.sessions.length;const qr=command==='qr'?model.qr:null;delete model.qr;fixtureStore.setItem('__lp_native',JSON.stringify(model));localReply(id,true,{...structuredClone(model),...(qr?{qr}: {})});
    }catch(error){localReply(id,false,{error:error.message});}
   };
  },fresh);
  await installFixture(page);page.setDefaultTimeout(12000);await page.emulateMedia({reducedMotion:'reduce'});
  const url='http://127.0.0.1:'+server.address().port+'/index.html';await page.goto(url,{waitUntil:'domcontentloaded'});await page.locator('#farmBoot').waitFor({state:'detached'});await page.waitForFunction(()=>window.TruchAppLocalPair?.getState().supported);
  const original=await page.evaluate(()=>structuredClone(window.__data())),calls=async()=>page.evaluate(()=>window.__lpCalls.filter(c=>c.command!=='status'));
  const snap=async name=>{if(process.env.TRUCHAPP_QA_SCREENSHOTS){fs.mkdirSync(process.env.TRUCHAPP_QA_SCREENSHOTS,{recursive:true});await page.screenshot({path:path.join(process.env.TRUCHAPP_QA_SCREENSHOTS,name+'.png')});}};
  const idle=async()=>page.waitForFunction(()=>document.getElementById('lpBusy')?.textContent==='');
  const navFits=async mode=>{
   const selectors=mode==='admin'?{top:'#tnMenuOpen',bar:'#bottomNav',bottom:'#bottomNav [data-target]'}:{top:'#coMenu',bar:'.co-nav',bottom:'.co-nav [data-co-tab]'};
   await page.waitForFunction(({top,bar})=>{const panel=document.getElementById('localPairingDialog').getBoundingClientRect(),t=document.querySelector(top).getBoundingClientRect(),b=document.querySelector(bar).getBoundingClientRect();return panel.top>=t.bottom&&panel.bottom<=b.top&&panel.width>0;},selectors);
   assert(await page.evaluate(({top,bottom})=>[top,bottom].every(selector=>{const el=document.querySelector(selector),r=el.getBoundingClientRect(),hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return el===hit||el.contains(hit);}),selectors),'original navigation buttons remain clickable');
  };


  const checks=[],group=s=>checks.push(s);
  await page.evaluate(()=>{
   const owner='b'.repeat(64),lot=JSON.parse(window.__data().truchapp_lotes_v1)[0],engine=window.TruchAppLotDetailData;
   lot.listCards=['fish','consumed','feed','survival','growth','length','biomass','condition'];window.__sharedDoc={lot:engine.toLot(lot,engine.fromLot(lot,[])),water:[]};window.__cache={document:structuredClone(window.__sharedDoc),hash:'a'.repeat(64),pending:false};window.__pending=[];window.__sharedCalls=[];window.__online=true;window.__sharedSequence=0;
   const native=window.__nativePairObject.localPairRequest;
   window.__nativePairObject.localPairRequest=(id,cmd,raw)=>{
    if(!cmd.startsWith('shared-')){native(id,cmd,raw);return;}const input=JSON.parse(raw);window.__sharedCalls.push({cmd,input});
    const reply=(ok,value)=>setTimeout(()=>{const text=JSON.stringify(value),parts=Math.ceil(text.length/16000);for(let i=0;i<parts;i++)window.TruchAppLocalPairReceive(id,ok,i,parts,text.slice(i*16000,(i+1)*16000));},2);
    try{let value={};if(cmd==='shared-list'){const copy=structuredClone(window.__sharedDoc.lot);delete copy.detailState;delete copy.history;value={lots:[copy],status:{pending:window.__pending},updated:Date.now()};}
     if(cmd==='shared-read')value=structuredClone(window.__cache);
     if(cmd==='shared-status')value={pending:window.__pending};
     if(cmd==='shared-begin'){if(window.__lpState.peers[0].permission!=='record')throw Error('Sin permiso');window.__upload='';value={};}
     if(cmd==='shared-chunk'){if(input.offset!==window.__upload.length)throw Error('Fragmento incorrecto');window.__upload+=input.text;value={offset:window.__upload.length};}
     if(cmd==='shared-save'){const request=JSON.parse(window.__upload);window.__cache={document:request.document,hash:String(++window.__sharedSequence).repeat(64),pending:!window.__online};if(window.__online){window.__sharedDoc=structuredClone(request.document);window.__pending=[];}else window.__pending.push({lotId:'A',operation:'pending-'+window.__sharedSequence,created:Date.now(),error:''});value={...structuredClone(window.__cache),status:{pending:window.__pending}};}
     if(cmd==='shared-draft'){if(!window.__archive)throw Error('No hay borrador');value=window.__archive;}
     if(cmd==='shared-archive'){window.__archive=structuredClone(window.__cache);window.__cache={document:structuredClone(window.__sharedDoc),hash:'c'.repeat(64),pending:false};window.__pending=[];value=window.__cache;}
     reply(true,{shared:value});
    }catch(e){reply(false,{error:e.message});}
   };
   Object.assign(window.__lpState,{mode:'collaborator',recordsVersion:1,sessions:[{id:'native',fingerprint:owner,state:'connected',records:true}],peers:[{fingerprint:owner,name:'Administrador',role:'admin',permission:'record',revoked:false,lots:[{id:'A',code:'Lote 1',stage:'Alevinaje',unit:'Jaula'}]}]});window.TruchAppAccess.save('collaborator','Yefferson');window.__lpChanged();
  });
  await page.locator('.co-shared-lot').waitFor({state:'visible'});await page.locator('[data-shared-refresh]').click();await page.waitForFunction(()=>document.querySelector('.co-lot-metrics')?.textContent.includes('9,986'));
  assert.equal(await page.locator('.co-lot-metrics>div').count(),8);assert.equal(await page.locator('[data-shared-register]').isEnabled(),true);assert.equal(await page.locator('.co-nav').isVisible(),true);await snap('shared-lots-record');group('assigned full lot list has eight metrics and authorized record action');
  await page.locator('[data-shared-register]').click();let frame=page.frameLocator('.co-shared-detail iframe');await frame.locator('#dailyDialog').waitFor({state:'visible'});assert.equal(await frame.locator('#deleteProductionLot').isVisible(),false);assert.match(await frame.locator('#sharedPermissionNote').innerText(),/Registro completo/);
  await frame.locator('#dailyDate').fill('2026-11-08');await frame.locator('#dailyTime').fill('08:00');await frame.locator('#dailyFeed').fill('1');await frame.locator('#dailyMortality').fill('1');await frame.locator('#dailyDiscard').fill('0');await frame.locator('#dailyNote').fill('Alimentación de la mañana');await frame.locator('#dailyForm button[type=submit]').click();await page.waitForFunction(()=>window.__sharedDoc.lot.alimentoConsumido===1);assert.equal(await page.evaluate(()=>window.__sharedDoc.lot.n),9985);await frame.locator('#dailyDialog').waitFor({state:'hidden'});group('existing daily form sends a numeric record to the administrator');
  await page.evaluate(()=>{window.__online=false;window.__lpState.sessions=[];window.__lpChanged();});await page.locator('.co-shared-detail-bar button').first().click();await page.locator('[data-shared-register]').click();frame=page.frameLocator('.co-shared-detail iframe');await frame.locator('#dailyDialog').waitFor({state:'visible'});await frame.locator('#dailyDate').fill('2026-11-08');await frame.locator('#dailyTime').fill('17:00');await frame.locator('#dailyFeed').fill('2');await frame.locator('#dailyMortality').fill('0');await frame.locator('#dailyDiscard').fill('0');await frame.locator('#dailyForm button[type=submit]').click();await page.waitForFunction(()=>window.__pending.length===1);assert.equal(await page.evaluate(()=>window.__cache.document.lot.alimentoConsumido),3);assert.equal(await page.evaluate(()=>window.__sharedDoc.lot.alimentoConsumido),1);assert.match(await page.locator('.co-shared-detail-bar').innerText(),/pendiente/);group('offline second feeding remains queued and total is three, not an overwrite');
  await frame.locator('#dailyDialog').waitFor({state:'hidden'});await page.locator('.co-shared-detail-bar button').first().click();await page.evaluate(()=>{window.__lpState.peers[0].permission='view';window.__lpChanged();});await page.waitForFunction(()=>document.querySelector('[data-shared-register]')?.disabled);await page.locator('[data-shared-open]').click();frame=page.frameLocator('.co-shared-detail iframe');await frame.locator('#sharedPermissionNote').waitFor();assert.match(await frame.locator('#sharedPermissionNote').innerText(),/Solo consulta/);assert.equal(await frame.locator('#deleteProductionLot').isVisible(),false);
  await frame.locator('[data-tab=sanidad]').click();await frame.locator('#healthDaily').click();await frame.locator('#dailyDialog').waitFor({state:'visible'});assert.equal(await frame.locator('#dailyForm button[type=submit]').isDisabled(),true);group('view-only permission opens complete data but cannot submit records');
  await frame.locator('#dailyDialog [data-close]').first().click();await page.locator('.co-shared-detail-bar button').first().click();
  for(const [width,height,theme] of [[320,700,'light'],[390,844,'dark'],[844,390,'light']]){await page.setViewportSize({width,height});await page.evaluate(theme=>document.documentElement.dataset.theme=theme,theme);assert(await page.locator('#collaboratorApp').evaluate(el=>el.scrollWidth<=el.clientWidth+1));assert(await page.locator('.co-nav').evaluate(el=>Math.abs(el.getBoundingClientRect().bottom-innerHeight)<2));await snap('shared-lots-'+width+'-'+theme);}group('menus and responsive lot cards stay inside the mobile viewport');
  assert.equal(await page.evaluate(()=>window.__data().truchapp_lotes_v1),original.truchapp_lotes_v1);assert.deepEqual(errors,[]);group('collaborator private farm remains unchanged; no JavaScript errors');
  console.log(JSON.stringify({status:'passed',groups:checks.length,checks}));
 }finally{await browser?.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exit(1);});
