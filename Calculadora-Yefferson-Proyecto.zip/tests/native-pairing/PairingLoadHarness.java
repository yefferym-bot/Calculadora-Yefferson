import com.yefferson.calculadora.pairing.*;
import org.json.*;
import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.BooleanSupplier;

/** Twenty distinct certificates on the actual bounded runtime, with real mutual TLS and fault injection. */
public class PairingLoadHarness {
 static int groups;static String owner;
 static void check(boolean value,String why){if(!value)throw new AssertionError(why);}
 static void group(String name){groups++;System.out.println("LOAD PASS "+name);}
 static void await(BooleanSupplier condition,int millis,String why) throws Exception {long until=System.nanoTime()+millis*1000000L;while(System.nanoTime()<until){if(condition.getAsBoolean())return;Thread.sleep(10);}throw new AssertionError(why);}
 static String fingerprint(Path path,String password) throws Exception {KeyStore keys=KeyStore.getInstance("PKCS12");try(InputStream input=Files.newInputStream(path)){keys.load(input,password.toCharArray());}return PairWire.fingerprint((X509Certificate)keys.getCertificate("device"));}
 static class ClientHost implements PairSession.Host {
  final String fingerprint;volatile boolean trusted;volatile int verifications;volatile String code="";volatile PairSession session;volatile Exception error;
  ClientHost(String fingerprint){this.fingerprint=fingerprint;}
  public String name(){return "Colaborador "+fingerprint.substring(0,8);}
  public boolean known(String peer,String role){return trusted&&peer.equals(owner)&&role.equals("admin");}
  public boolean invitationOpen(){return false;}
  public void verifying(PairSession s){session=s;verifications++;code=s.code;s.confirm(new JSONObject());}
  public JSONObject approve(PairSession s){throw new AssertionError("client cannot grant");}
  public void accept(PairSession s,JSONObject grant) throws Exception {JSONArray lots=PairRecords.received(grant.getJSONArray("lots"));check(lots.length()==100,"full catalog received");for(int i=0;i<lots.length();i++)check(lots.getJSONObject(i).getString("id").equals("lot-"+fingerprint.substring(0,12)+"-"+i),"assignments never cross between clients");trusted=true;}
  public void connected(PairSession s){session=s;}
  public void revoked(PairSession s){trusted=false;}
  public void ended(PairSession s,Exception e){error=e;}
 }
 static class HubHost implements PairSession.Host {
  final ConcurrentMap<String,Boolean> trusted=new ConcurrentHashMap<>();final ConcurrentMap<String,String> codes=new ConcurrentHashMap<>();final AtomicInteger verified=new AtomicInteger();
  public String name(){return "Administrador carga 20";}
  public boolean known(String peer,String role){return Boolean.TRUE.equals(trusted.get(peer))&&role.equals("collaborator");}
  public boolean invitationOpen(){return true;}
  public void verifying(PairSession s){verified.incrementAndGet();codes.put(s.peer,s.code);s.confirm(new JSONObject());}
  public JSONObject approve(PairSession s) throws Exception {trusted.put(s.peer,true);JSONArray lots=new JSONArray();for(int i=0;i<100;i++)lots.put(new JSONObject().put("id","lot-"+s.peer.substring(0,12)+"-"+i).put("code","🐟".repeat(24)+" "+s.peer.substring(0,12)+"-"+i).put("stage","Engorde / prueba de concurrencia").put("unit","Jaula de cultivo número "+i));return new JSONObject().put("version",1).put("permission","view").put("lots",lots);}
  public void accept(PairSession s,JSONObject grant){throw new AssertionError("owner cannot accept a remote grant");}
  public void connected(PairSession s){}
  public void revoked(PairSession s){trusted.put(s.peer,false);}
  public void ended(PairSession s,Exception error){}
 }
 static class Hub implements AutoCloseable {
  final PairRuntime runtime=new PairRuntime(Executors.defaultThreadFactory());final PairLimits.Admission admission=new PairLimits.Admission();final HubHost host=new HubHost();final SSLServerSocket server;final ExecutorService acceptor=Executors.newSingleThreadExecutor();volatile boolean closed;
  Hub(SSLContext context) throws Exception {
   server=(SSLServerSocket)context.getServerSocketFactory().createServerSocket(0,20,InetAddress.getLoopbackAddress());server.setNeedClientAuth(true);server.setEnabledProtocols(new String[]{"TLSv1.2"});
   acceptor.execute(()->{while(!closed)try{SSLSocket socket=(SSLSocket)server.accept();socket.setEnabledProtocols(new String[]{"TLSv1.2"});if(runtime.size()>=PairRuntime.MAX_CONNECTIONS||!admission.allow(System.nanoTime())){socket.close();continue;}PairSession session=new PairSession(socket,"admin",host);try{runtime.start(session);}catch(Exception e){session.close();}}catch(Exception e){if(!closed)throw new RuntimeException(e);}});
  }
  PairSession connect(SSLContext context,ClientHost host,PairRuntime client) throws Exception {SSLSocket socket=(SSLSocket)context.getSocketFactory().createSocket(InetAddress.getLoopbackAddress(),server.getLocalPort());socket.setEnabledProtocols(new String[]{"TLSv1.2"});PairSession session=new PairSession(socket,"collaborator",host);if(client==null)new Thread(session,"raw-client").start();else client.start(session);return session;}
  public void close() throws Exception {closed=true;server.close();runtime.close();acceptor.shutdownNow();acceptor.awaitTermination(2,TimeUnit.SECONDS);}
 }
 static class Blocked extends OutputStream {
  final CountDownLatch entered=new CountDownLatch(1),released=new CountDownLatch(1);volatile boolean closed;
  public void write(int value) throws IOException {write(new byte[]{(byte)value},0,1);}
  public void write(byte[] value,int from,int count) throws IOException {entered.countDown();try{released.await();}catch(InterruptedException error){Thread.currentThread().interrupt();}throw new IOException("stalled peer closed");}
  public void close(){closed=true;released.countDown();}
 }
 static void queues() throws Exception {
  PairRuntime runtime=new PairRuntime(Executors.defaultThreadFactory(),200,2000);List<PairOutbound> outboxes=new ArrayList<>();
  try{
   for(int i=0;i<4;i++){Blocked blocked=new Blocked();PairOutbound out=new PairOutbound(runtime,blocked,blocked::close);outboxes.add(out);check(out.offer(new byte[4096],null),"slow frame admitted");check(blocked.entered.await(1,TimeUnit.SECONDS),"writer blocked");}
   ByteArrayOutputStream received=new ByteArrayOutputStream();PairOutbound healthy=new PairOutbound(runtime,received,()->{});outboxes.add(healthy);long at=System.nanoTime();healthy.send(new byte[]{1,2,3});check((System.nanoTime()-at)<1500000000L,"four slow peers cannot indefinitely starve a healthy writer");check(new DataInputStream(new ByteArrayInputStream(received.toByteArray())).readInt()==3,"framing preserved");PairRuntime first=runtime;await(()->first.queuedBytes()==0,1500,"all stalled bytes released");group("stalled writers time out while another peer continues");
  }finally{for(PairOutbound out:outboxes)out.close();runtime.close();}
  runtime=new PairRuntime(Executors.defaultThreadFactory(),2000,10000);List<PairOutbound> many=new ArrayList<>();int rejected=0;
  try{
   for(int i=0;i<20;i++){Blocked blocked=new Blocked();PairOutbound out=new PairOutbound(runtime,blocked,blocked::close);many.add(out);for(int j=0;j<3;j++)if(!out.offer(new byte[170000],null))rejected++;}
   check(rejected>0&&runtime.queuedBytes()<=PairRuntime.GLOBAL_OUTBOUND_BYTES&&runtime.peakBytes()<=PairRuntime.GLOBAL_OUTBOUND_BYTES,"global backpressure bounded at 8 MiB");
   for(PairOutbound out:many)out.close();check(runtime.queuedBytes()==0,"closing releases every byte once");group("global byte budget and per-peer queues cannot grow without bound");
  }finally{for(PairOutbound out:many)out.close();runtime.close();}
  PairLimits.Admission admission=new PairLimits.Admission();long now=1000000000L;for(int i=0;i<40;i++)check(admission.allow(now),"initial burst fits twenty clients and one reconnect wave");check(!admission.allow(now),"further burst throttled");check(admission.allow(now+500000000L),"tokens refill monotonically");PairLimits.Retry retry=new PairLimits.Retry();retry.failed("peer",now,0);check(retry.remaining("peer",now)==1000,"first cooldown");retry.failed("peer",now,1);check(retry.remaining("peer",now)==4000,"exponential jitter bound");for(int i=0;i<10;i++)retry.failed("peer",now,1);check(retry.remaining("peer",now)==30000,"cooldown capped");retry.reset();check(retry.remaining(now)==0,"success clears cooldown");group("admission and manual retry backoff have explicit bounds");
 }
 public static void main(String[] args) throws Exception {
  Path folder=Paths.get(args[0]);String password=args[1];owner=fingerprint(folder.resolve("admin.p12"),password);SSLContext server=PairingHarness.context(folder.resolve("admin.p12").toString(),password);
  SSLContext[] contexts=new SSLContext[20];ClientHost[] hosts=new ClientHost[20];PairSession[] sessions=new PairSession[20];PairRuntime[] clients=new PairRuntime[20];
  for(int i=0;i<20;i++){Path key=folder.resolve(i==0?"client.p12":"client"+i+".p12");contexts[i]=PairingHarness.context(key.toString(),password);hosts[i]=new ClientHost(fingerprint(key,password));clients[i]=new PairRuntime(Executors.defaultThreadFactory());}
  try(Hub hub=new Hub(server)){
   long start=System.nanoTime();for(int i=0;i<20;i++)sessions[i]=hub.connect(contexts[i],hosts[i],clients[i]);
   await(()->hub.runtime.connected()==20,25000,"twenty unique peers must all connect");for(int i=0;i<20;i++){final int n=i;await(()->"connected".equals(sessions[n].state),3000,"client connected");check(hosts[i].code.equals(hub.host.codes.get(hosts[i].fingerprint)),"matching certificate-bound verification per peer");}
   check(hub.runtime.peakConnections()==20&&hub.runtime.peakHandshakes()<=4,"twenty slots, at most four handshakes");System.out.println("Twenty sessions established in "+((System.nanoTime()-start)/1000000)+" ms");group("twenty distinct mutual-TLS peers simultaneously paired on the production runtime");
   SSLContext overflowContext=PairingHarness.context(folder.resolve("overflow.p12").toString(),password);ClientHost overflowHost=new ClientHost(fingerprint(folder.resolve("overflow.p12"),password));PairRuntime overflowRuntime=new PairRuntime(Executors.defaultThreadFactory());try{PairSession overflow=hub.connect(overflowContext,overflowHost,overflowRuntime);await(()->"disconnected".equals(overflow.state),5000,"twenty-first must be refused");check(!overflowHost.trusted&&hub.runtime.connected()==20,"existing twenty unaffected");}finally{overflowRuntime.close();}group("twenty-first connection rejected without evicting a connected peer");
   sessions[19].close();await(()->hub.runtime.size()==19,5000,"slot released");ClientHost duplicate=new ClientHost(hosts[0].fingerprint);duplicate.trusted=true;PairRuntime dup=new PairRuntime(Executors.defaultThreadFactory());try{PairSession d=hub.connect(contexts[0],duplicate,dup);await(()->"disconnected".equals(d.state),5000,"duplicate identity refused");check("connected".equals(sessions[0].state),"first identity connection preserved");}finally{dup.close();}await(()->hub.runtime.size()==19,3000,"duplicate slot reclaimed");sessions[19]=hub.connect(contexts[19],hosts[19],clients[19]);await(()->hub.runtime.connected()==20,8000,"slot reused");check(hub.host.verified.get()==20,"trusted reconnect does not request another approval");group("duplicate identities rejected and freed slots safely reused");
   for(int round=0;round<7;round++){for(PairSession session:sessions)session.ping();Thread.sleep(250);}check(hub.runtime.connected()==20,"twenty remain connected after concurrent control traffic");group("parallel control traffic remains isolated across all twenty peers");
   sessions[0].close();await(()->hub.runtime.size()==19,5000,"flood slot released");PairSession flood=hub.connect(contexts[0],hosts[0],null);await(()->"connected".equals(flood.state),8000,"raw verified peer connected");for(int i=0;i<50;i++)flood.ping();await(()->"disconnected".equals(flood.state),5000,"flood isolated");check(hub.runtime.connected()==19,"nineteen healthy peers survive one flooding peer");sessions[0]=hub.connect(contexts[0],hosts[0],clients[0]);await(()->hub.runtime.connected()==20,8000,"normal peer reconnects");group("one flooding peer is disconnected while nineteen remain usable");
   for(PairSession session:sessions)session.close();await(()->hub.runtime.size()==0,5000,"all slots released on network loss");Thread.sleep(3000);for(int i=0;i<20;i++)sessions[i]=hub.connect(contexts[i],hosts[i],clients[i]);await(()->hub.runtime.connected()==20,25000,"twenty can reconnect after interruption");check(hub.host.verified.get()==20,"reconnect retains established trust");group("twenty reconnect after a simultaneous interruption");
   Thread.sleep(17000);check(hub.runtime.connected()==20,"jittered heartbeats keep all twenty live");hub.runtime.stopAll();await(()->hub.runtime.size()==0&&hub.runtime.queuedBytes()==0,5000,"shutdown releases sockets and queued bytes");group("idle heartbeats and full shutdown release every session");
  }finally{for(PairSession session:sessions)if(session!=null)session.close();for(PairRuntime client:clients)if(client!=null)client.close();}
  final class CatalogSource implements PairCatalog.Source {String generation="db-a",data="[{\"id\":\"A\",\"code\":\"Lote A\",\"daily\":[{\"feed\":99}]}]";long revision=1;int reads;boolean change;public String stamp(){return generation+":"+revision;}public String lots(){reads++;if(change){revision++;change=false;}return data;}}
  CatalogSource source=new CatalogSource();PairCatalog catalog=new PairCatalog();for(int i=0;i<20;i++)check(catalog.read(source).getJSONObject(0).getString("id").equals("A"),"catalog reused for twenty readers");check(source.reads==1&&!catalog.read(source).getJSONObject(0).has("daily"),"histories excluded and source read only once");source.generation="db-b";source.data="[{\"id\":\"B\",\"code\":\"Restored\"}]";check(catalog.read(source).getJSONObject(0).getString("id").equals("B")&&source.reads==2,"same revision in a restored database cannot reuse old metadata");source.revision++;source.change=true;catalog.read(source);int before=source.reads;catalog.read(source);check(source.reads==before+1,"concurrent revision change is not cached");group("metadata cache reuses twenty reads and invalidates after database restoration");
  queues();System.out.println("PASSED "+groups+" twenty-peer load groups");
 }
}
