import com.yefferson.calculadora.pairing.*;
import org.json.*;
import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;

/** Runs the production protocol over real mutual-TLS loopback sockets, without Android mocks. */
public class PairingHarness {
 static SSLContext adminContext,clientContext;static String adminFingerprint,clientFingerprint;static int checks;
 static void check(boolean value,String why){if(!value)throw new AssertionError(why);}
 static void group(String text){checks++;System.out.println("PASS "+text);}
 static SSLContext context(String path,String password) throws Exception {
  KeyStore keys=KeyStore.getInstance("PKCS12");try(InputStream input=new FileInputStream(path)){keys.load(input,password.toCharArray());}
  return PairTls.context((PrivateKey)keys.getKey("device",password.toCharArray()),(X509Certificate)keys.getCertificate("device"));
 }
 static class Host implements PairSession.Host {
  final boolean admin;final Map<String,JSONObject> saved=new ConcurrentHashMap<>();volatile boolean invite=true,failSave=false,revoked=false,auto=true;volatile int verifications,writes,connections;volatile String code="";volatile PairSession session;volatile Exception error;
  final CountDownLatch verified=new CountDownLatch(1),connected=new CountDownLatch(1),ended=new CountDownLatch(1);CyclicBarrier comparison;
  Host(boolean admin){this.admin=admin;}
  public String name(){return admin?"Administrador prueba":"Colaborador prueba";}
  public boolean known(String fingerprint,String remoteRole){JSONObject peer=saved.get(fingerprint);return peer!=null&&!peer.optBoolean("revoked")&&(admin?"collaborator":"admin").equals(remoteRole);}
  public boolean denied(String fingerprint){JSONObject peer=saved.get(fingerprint);return admin&&peer!=null&&peer.optBoolean("revoked")&&!invite;}
  public boolean invitationOpen(){return invite;}
  public void verifying(PairSession value){session=value;code=value.code;verifications++;verified.countDown();if(!auto)return;try{if(comparison!=null)comparison.await(5,TimeUnit.SECONDS);if(admin)value.confirm(new JSONObject().put("lotIds",new JSONArray().put("A")).put("permission","view"));else value.submitRequest();}catch(Exception e){throw new IllegalStateException(e);}}
  public JSONObject approve(PairSession value) throws Exception {if(failSave)throw new IOException("Fallo de guardado del administrador");writes++;saved.put(value.peer,new JSONObject().put("revoked",false));return new JSONObject().put("version",1).put("permission","view").put("lots",new JSONArray().put(new JSONObject().put("id","A").put("code","Lote 1").put("stage","Alevinaje").put("unit","Jaula")));}
  public void accept(PairSession value,JSONObject grant) throws Exception {check(grant.getJSONArray("lots").length()==1,"assigned catalog");if(failSave)throw new IOException("Fallo de guardado del colaborador");writes++;saved.put(value.peer,new JSONObject().put("revoked",false));}
  public void connected(PairSession value){session=value;connections++;connected.countDown();}
  public void revoked(PairSession value) throws Exception {revoked=true;saved.put(value.peer,new JSONObject().put("revoked",true));}
  public void ended(PairSession value,Exception failure){error=failure;ended.countDown();}
 }
 static class Connection implements AutoCloseable {
  SSLServerSocket server;ExecutorService executor=Executors.newFixedThreadPool(2);PairRuntime adminRuntime=new PairRuntime(Executors.defaultThreadFactory()),clientRuntime=new PairRuntime(Executors.defaultThreadFactory());volatile PairSession admin,client;
  Connection(Host a,Host b) throws Exception {
   server=(SSLServerSocket)adminContext.getServerSocketFactory().createServerSocket(0,2,InetAddress.getLoopbackAddress());server.setNeedClientAuth(true);server.setEnabledProtocols(new String[]{"TLSv1.2"});
   executor.execute(()->{try{SSLSocket socket=(SSLSocket)server.accept();admin=new PairSession(socket,"admin",a);adminRuntime.start(admin);}catch(Exception e){a.error=e;a.ended.countDown();}});
   SSLSocket socket=(SSLSocket)clientContext.getSocketFactory().createSocket(InetAddress.getLoopbackAddress(),server.getLocalPort());socket.setEnabledProtocols(new String[]{"TLSv1.2"});client=new PairSession(socket,"collaborator",b);clientRuntime.start(client);
  }
  void connected(Host a,Host b) throws Exception {check(a.connected.await(8,TimeUnit.SECONDS),"admin connected: "+a.error);check(b.connected.await(8,TimeUnit.SECONDS),"client connected: "+b.error);}
  public void close() throws Exception {if(admin!=null)admin.close();if(client!=null)client.close();server.close();adminRuntime.close();clientRuntime.close();executor.shutdownNow();executor.awaitTermination(3,TimeUnit.SECONDS);}
 }
 static Host[] fresh(boolean auto){Host a=new Host(true),b=new Host(false);a.auto=b.auto=auto;return new Host[]{a,b};}
 static Host[] trusted() throws Exception {Host[] p=fresh(true);p[0].invite=false;p[0].saved.put(clientFingerprint,new JSONObject().put("revoked",false));p[1].saved.put(adminFingerprint,new JSONObject().put("revoked",false));return p;}
 static void waitEnded(Host... peers) throws Exception {for(Host h:peers)check(h.ended.await(8,TimeUnit.SECONDS),"connection closes");}
 static void fragmentedConfirmation() throws Exception {
  Host host=new Host(true);SSLServerSocket listener=(SSLServerSocket)adminContext.getServerSocketFactory().createServerSocket(0,2,InetAddress.getLoopbackAddress());listener.setNeedClientAuth(true);ExecutorService executor=Executors.newSingleThreadExecutor();
  executor.execute(()->{try{new PairSession((SSLSocket)listener.accept(),"admin",host).run();}catch(Exception e){host.error=e;host.ended.countDown();}});
  try(SSLSocket socket=(SSLSocket)clientContext.getSocketFactory().createSocket(InetAddress.getLoopbackAddress(),listener.getLocalPort())){
   socket.startHandshake();PairWire wire=new PairWire(socket);String nonce="c".repeat(64);wire.send(PairWire.message("commit").put("version",1).put("digest",PairWire.commitment("collaborator",clientFingerprint,nonce)));wire.receive();wire.send(PairWire.message("hello").put("role","collaborator").put("nonce",nonce).put("name","Fragmentado").put("known",false).put("requests",true));wire.receive();PairWire.expect(wire.receive(),"confirm");
   byte[] payload=PairWire.message("confirm").toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);ByteArrayOutputStream buffer=new ByteArrayOutputStream();DataOutputStream encoded=new DataOutputStream(buffer);encoded.writeInt(payload.length);encoded.write(payload);byte[] bytes=buffer.toByteArray();OutputStream out=socket.getOutputStream();out.write(bytes,0,2);out.flush();Thread.sleep(650);out.write(bytes,2,5);out.flush();Thread.sleep(650);out.write(bytes,7,bytes.length-7);out.flush();PairWire.expect(wire.receive(),"grant");wire.send(PairWire.message("saved"));PairWire.expect(wire.receive(),"ready");check(host.connected.await(5,TimeUnit.SECONDS),"fragmented confirmation preserved across socket timeouts");
  }finally{listener.close();executor.shutdownNow();executor.awaitTermination(3,TimeUnit.SECONDS);}
 }
 static void malicious(String kind) throws Exception {
  Host host=new Host(true);SSLServerSocket listener=(SSLServerSocket)adminContext.getServerSocketFactory().createServerSocket(0,2,InetAddress.getLoopbackAddress());listener.setNeedClientAuth(true);ExecutorService thread=Executors.newSingleThreadExecutor();
  thread.execute(()->{try{new PairSession((SSLSocket)listener.accept(),"admin",host).run();}catch(Exception e){host.error=e;host.ended.countDown();}});
  try(SSLSocket socket=(SSLSocket)clientContext.getSocketFactory().createSocket(InetAddress.getLoopbackAddress(),listener.getLocalPort())){
   socket.startHandshake();if(kind.equals("oversized")){DataOutputStream out=new DataOutputStream(socket.getOutputStream());out.writeInt(PairWire.MAX_FRAME+1);out.flush();}
   else if(kind.equals("deep-json")||kind.equals("bad-utf8")){byte[] raw=kind.equals("deep-json")?("{\"nested\":"+"[".repeat(100)+"0"+"]".repeat(100)+"}").getBytes(java.nio.charset.StandardCharsets.UTF_8):new byte[]{(byte)0xff,(byte)0xff};DataOutputStream out=new DataOutputStream(socket.getOutputStream());out.writeInt(raw.length);out.write(raw);out.flush();}
   else {PairWire wire=new PairWire(socket);String nonce="a".repeat(64),role=kind.equals("wrong-role")?"admin":"collaborator";wire.send(PairWire.message("commit").put("version",kind.equals("wrong-version")?99:1).put("digest",PairWire.commitment(role,clientFingerprint,nonce)));wire.receive();if(!kind.equals("wrong-version")){wire.send(PairWire.message("hello").put("role",role).put("nonce",kind.equals("bad-commitment")?"b".repeat(64):nonce).put("name","Intruso").put("known",true).put("requests",!kind.equals("legacy-request")));wire.receive();}}
   check(host.ended.await(6,TimeUnit.SECONDS),"malformed connection closes");check(host.writes==0&&host.verifications==0,"unverified peer cannot save");
  }finally{listener.close();thread.shutdownNow();}
 }
 public static void main(String[] args) throws Exception {
  adminContext=context(args[0],args[2]);clientContext=context(args[1],args[2]);
  for(int i=0;i<2;i++){KeyStore keys=KeyStore.getInstance("PKCS12");try(InputStream input=new FileInputStream(args[i])){keys.load(input,args[2].toCharArray());}String fp=PairWire.fingerprint((X509Certificate)keys.getCertificate("device"));if(i==0)adminFingerprint=fp;else clientFingerprint=fp;}
  Host[] p=fresh(false);try(Connection c=new Connection(p[0],p[1])){check(p[0].verified.await(8,TimeUnit.SECONDS)&&p[1].verified.await(8,TimeUnit.SECONDS),"both show code");check(p[0].code.equals(p[1].code)&&p[0].code.matches("[0-9]{4} [0-9]{4}"),"same verification code");check(p[0].writes==0&&p[1].writes==0,"no trust before approval");c.admin.confirm(new JSONObject().put("lotIds",new JSONArray().put("A")).put("permission","view"));Thread.sleep(50);check(p[0].writes==0,"one approval does not grant access");c.client.confirm(new JSONObject());c.connected(p[0],p[1]);check(p[0].writes==1&&p[1].writes==1,"confirmed trust saved once");check(c.admin.peer.equals(clientFingerprint)&&c.client.peer.equals(adminFingerprint),"fingerprints from TLS certificates");c.admin.ping();c.client.ping();group("mutual TLS, matching code, two approvals and durable confirmation");}
  p=fresh(false);p[1].auto=true;try(Connection c=new Connection(p[0],p[1])){check(p[0].verified.await(8,TimeUnit.SECONDS)&&p[1].verified.await(8,TimeUnit.SECONDS),"request delivered");Thread.sleep(100);check("waiting".equals(c.client.state)&&"verify".equals(c.admin.state),"collaborator waits for administrator");check(p[0].writes==0&&p[1].writes==0,"request never writes trust before owner approval");c.admin.submitRequest();check("verify".equals(c.admin.state),"administrator cannot approve by submitting a request");c.admin.confirm(new JSONObject().put("lotIds",new JSONArray().put("A")).put("permission","view"));c.connected(p[0],p[1]);check(p[0].writes==1&&p[1].writes==1,"owner approval completes both sides once");group("request waits for explicit administrator approval and persists both sides");}
  p=fresh(false);p[1].auto=true;try(Connection c=new Connection(p[0],p[1])){check(p[0].verified.await(8,TimeUnit.SECONDS)&&p[1].verified.await(8,TimeUnit.SECONDS),"request before rejection");c.admin.reject();waitEnded(p);check(p[0].writes==0&&p[1].writes==0,"rejected request saves no trust");check(p[1].error!=null&&p[1].error.getMessage().contains("rechazó"),"rejection reaches collaborator: "+p[1].error);group("administrator rejection is explicit and saves no membership");}
  p=fresh(false);p[1].auto=true;try(Connection c=new Connection(p[0],p[1])){check(p[0].verified.await(8,TimeUnit.SECONDS)&&p[1].verified.await(8,TimeUnit.SECONDS),"request before withdrawal");c.client.reject();waitEnded(p);check(p[0].writes==0&&p[1].writes==0,"withdrawn request saves no trust");check(p[0].error!=null&&p[0].error.getMessage().contains("canceló"),"withdrawal reaches administrator: "+p[0].error);group("collaborator can withdraw a pending request without creating a link");}
  p=trusted();try(Connection c=new Connection(p[0],p[1])){c.connected(p[0],p[1]);check(p[0].verifications==0&&p[1].verifications==0,"known peers reconnect without repeated approval");group("known device pins reconnect with refreshed assignments");}
  p=fresh(true);p[0].invite=false;try(Connection c=new Connection(p[0],p[1])){waitEnded(p);check(p[0].writes==0&&p[1].writes==0,"closed invitation blocks new peer");group("closed invitation rejects new devices");}
  p=fresh(false);try(Connection c=new Connection(p[0],p[1])){check(p[0].verified.await(8,TimeUnit.SECONDS),"verification shown");c.admin.close();waitEnded(p);check(p[0].writes==0&&p[1].writes==0,"cancel keeps trust empty");group("cancel before approval leaves no link");}
  p=fresh(false);try(Connection c=new Connection(p[0],p[1])){check(p[0].verified.await(8,TimeUnit.SECONDS)&&p[1].verified.await(8,TimeUnit.SECONDS),"both ready before expiry");p[0].invite=false;c.admin.confirm(new JSONObject());c.client.confirm(new JSONObject());waitEnded(p);check(p[0].writes==0&&p[1].writes==0,"expired invitation cannot grant access");group("invitation expiry during verification blocks approval");}
  fragmentedConfirmation();group("fragmented frames survive polling timeouts");
  for(boolean serverFail:new boolean[]{true,false}){p=fresh(true);p[serverFail?0:1].failSave=true;try(Connection c=new Connection(p[0],p[1])){waitEnded(p);check(p[0].connections==0&&p[1].connections==0,"save failure cannot report connected");if(serverFail)check(p[1].writes==0,"no grant if administrator storage fails");else check(p[1].writes==0,"failed client save not acknowledged");group("storage failure on "+(serverFail?"administrator":"collaborator")+" prevents success");}}
  p=trusted();p[0].saved.put(clientFingerprint,new JSONObject().put("revoked",true));try(Connection c=new Connection(p[0],p[1])){waitEnded(p);check(p[1].revoked&&p[0].connections==0,"owner revocation reaches pinned collaborator on reconnect");group("offline revocation enforced at reconnect");}
  p=trusted();try(Connection c=new Connection(p[0],p[1])){c.connected(p[0],p[1]);c.admin.revoke();check(p[1].ended.await(5,TimeUnit.SECONDS)&&p[1].revoked,"live revocation");group("connected owner can revoke client");}
  p=trusted();try(Connection c=new Connection(p[0],p[1])){c.connected(p[0],p[1]);c.client.unlink();check(p[0].ended.await(5,TimeUnit.SECONDS)&&p[0].revoked,"client unlink");group("collaborator can withdraw pairing");}
  for(String kind:new String[]{"oversized","bad-commitment","wrong-role","wrong-version","deep-json","bad-utf8","legacy-request"}){malicious(kind);group("reject "+kind);}
  JSONObject lot=new JSONObject().put("id","A").put("code","Lote 1").put("stage","Alevinaje").put("unit","Jaula").put("daily",new JSONArray().put(new JSONObject().put("feed",99))).put("cost",500).put("origin","Privado");JSONArray catalog=PairRecords.catalog(new JSONArray().put(lot)),assigned=PairRecords.assign(catalog,new JSONArray().put("A"));check(assigned.getJSONObject(0).length()==4&&!assigned.toString().contains("Privado")&&!assigned.toString().contains("feed"),"metadata allowlist only");group("assigned catalog excludes production data and private fields");
  for(JSONArray invalid:new JSONArray[]{new JSONArray().put("A").put("A"),new JSONArray().put("missing"),new JSONArray().put(1)}){boolean rejected=false;try{PairRecords.assign(catalog,invalid);}catch(Exception e){rejected=true;}check(rejected,"invalid assignment rejected");}boolean rejected=false;try{PairRecords.permission("admin");}catch(Exception e){rejected=true;}check(rejected,"permission cannot become administrator");check(PairRecords.catalog(new JSONArray().put(new JSONObject().put("id"," A "))).length()==0,"ids never rewritten");group("invalid, duplicated and missing assignments rejected");
  check(!PairWire.commitment("admin",adminFingerprint,"a".repeat(64)).equals(PairWire.commitment("collaborator",adminFingerprint,"a".repeat(64))),"role separated commitment");check(!PairWire.verification(adminFingerprint,clientFingerprint,"a".repeat(64),"b".repeat(64)).equals(PairWire.verification(clientFingerprint,adminFingerprint,"a".repeat(64),"b".repeat(64))),"identity bound code");group("commitment and verification bind roles and certificate identities");
  System.out.println("PASSED "+checks+" native protocol groups");
 }
}
