import com.yefferson.calculadora.pairing.*;
import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.cert.*;

/** Exercises the production TLS setup, preflight and actionable error categories. */
public class PairingTlsHarness {
 static void check(boolean value,String reason){if(!value)throw new AssertionError(reason);}
 static String wrap(Exception cause){return PairFailure.message(new SSLHandshakeException("negotiation failed"){{initCause(cause);}});}
 public static void main(String[] args) throws Exception {
  SSLContext context=PairingHarness.context(args[0],args[2]);PairTls.checkLocal(context);PairTls.checkLocal(context);
  System.out.println("PASS production identity selection/trust and bounded mutual-TLS preflight");
  KeyStore a=KeyStore.getInstance("PKCS12"),b=KeyStore.getInstance("PKCS12");
  try(InputStream input=new FileInputStream(args[0])){a.load(input,args[2].toCharArray());}
  try(InputStream input=new FileInputStream(args[1])){b.load(input,args[2].toCharArray());}
  PairTls.checkRawRsa((PrivateKey)a.getKey("device",args[2].toCharArray()),(X509Certificate)a.getCertificate("device"));
  check(PairIdentityChoice.select(null,false).equals(PairIdentityChoice.CURRENT),"unpaired uses compatible identity");
  check(PairIdentityChoice.select(null,true).equals(PairIdentityChoice.LEGACY),"existing peers retain legacy");
  check(PairIdentityChoice.select(PairIdentityChoice.CURRENT,true).equals(PairIdentityChoice.CURRENT),"compatible pin survives restart");
  check(PairIdentityChoice.select(PairIdentityChoice.LEGACY,false).equals(PairIdentityChoice.LEGACY),"remembered legacy stays stable");
  try{PairIdentityChoice.select("unknown",false);throw new AssertionError("unknown selection accepted");}catch(IOException expected){}
  try{PairIdentityChoice.checkCommit(null,PairIdentityChoice.CURRENT,true);throw new AssertionError("peer race accepted");}catch(IOException expected){}
  try{PairIdentityChoice.checkCommit(PairIdentityChoice.LEGACY,PairIdentityChoice.CURRENT,false);throw new AssertionError("remembered identity replaced");}catch(IOException expected){}
  PairIdentityChoice.checkCommit(null,PairIdentityChoice.CURRENT,false);
  System.out.println("PASS raw RSA primitive and eight identity preservation/commit cases");
  try{PairTls.context((PrivateKey)b.getKey("device",args[2].toCharArray()),(X509Certificate)a.getCertificate("device"));throw new AssertionError("mismatched key accepted");}catch(InvalidKeyException expected){}
  try{PairTls.verifyCertificate(new X509Certificate[0]);throw new AssertionError("empty chain accepted");}catch(CertificateException expected){}
  System.out.println("PASS mismatched private key and absent certificate rejected");
  SSLContext missingIdentity=SSLContext.getInstance("TLSv1.2");missingIdentity.init(new KeyManager[0],null,new SecureRandom());
  long began=System.nanoTime();
  try{PairTls.checkLocal(missingIdentity);throw new AssertionError("missing TLS identity accepted");}catch(SSLException expected){}
  check(System.nanoTime()-began<8000000000L,"failed preflight bounded");
  for(Thread thread:Thread.getAllStackTraces().keySet())if(thread.getName().equals("TruchApp-TLS-check")){thread.join(1000);check(!thread.isAlive(),"preflight worker released");}
  System.out.println("PASS failed local TLS preflight reports error and releases its worker");
  check(wrap(new CertificateExpiredException("expired")).startsWith("[TLS-DATE]"),"expired date");
  check(wrap(new CertificateNotYetValidException("future")).startsWith("[TLS-DATE]"),"future date");
  check(wrap(new CertificateException("bad signature")).startsWith("[TLS-CERT]"),"certificate");
  check(wrap(new InvalidKeyException("hardware sign denied")).startsWith("[TLS-KEY]"),"key");
  check(PairFailure.message(new SSLHandshakeException("peer rejected")).startsWith("[TLS-HANDSHAKE]"),"handshake");
  check(PairFailure.message(new SSLException("socket closed")).startsWith("[TLS-CONNECTION]"),"other TLS");
  check(PairFailure.message(new ConnectException("refused")).startsWith("[TCP-CONNECT]"),"TCP rejected");
  check(PairFailure.message(new SocketTimeoutException("timeout")).startsWith("[NET-TIMEOUT]"),"timeout");
  check(PairFailure.message(new PairFailure.LocalIdentityException(new InvalidKeyException("denied"))).startsWith("[TLS-LOCAL]"),"local identity");
  String longError=PairFailure.message(new SSLHandshakeException("x".repeat(2000)+"\n\u202e"));
  check(longError.length()<500&&!longError.contains("\n")&&!longError.contains("\u202e"),"bounded safe detail");
  check(!PairFailure.message(new SSLHandshakeException("alert")).contains("fecha"),"no unsupported date diagnosis");
  Exception cycle=new Exception("loop");Exception other=new Exception("other",cycle);cycle.initCause(other);
  check(!PairFailure.message(cycle).isEmpty(),"cyclic cause safely bounded");
  check(PairFailure.message(new IOException("existing protocol message")).equals("existing protocol message"),"protocol messages preserved");
  System.out.println("PASS thirteen diagnostic, bounded-detail and message-preservation checks");
 }
}
