#!/usr/bin/env python3
"""Production QR codec and real ZXing roundtrip; no Android device required."""
import os,subprocess,tempfile
from pathlib import Path
r=Path(__file__).resolve().parents[2];pair=r/'app/src/main/java/com/yefferson/calculadora/pairing'
with tempfile.TemporaryDirectory(prefix='truchapp-qr-') as temp:
 cp=os.environ['PAIR_JSON_JAR']+os.pathsep+os.environ['PAIR_ZXING_JAR']
 source=[pair/(name+'.java') for name in ['PairQr','PairRecords','PairRuntime','PairSession','PairWire','PairOutbound']]+[Path(__file__).with_name('PairQrHarness.java')]
 subprocess.run(['java','-jar',os.environ['PAIR_ECJ_JAR'],'-17','-nowarn','-cp',cp,'-d',temp,*map(str,source)],check=True)
 subprocess.run(['java','-cp',temp+os.pathsep+cp,'PairQrHarness'],check=True,timeout=20)
