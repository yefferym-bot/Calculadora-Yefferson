#!/usr/bin/env python3
"""Run production pairing protocol on loopback TLS with disposable identities.
Requires a JDK (javac/keytool/java) and PAIR_JSON_JAR=org.json's JSON-java jar.
A JRE plus PAIR_ECJ_JAR may replace javac. No Android device or real data is used.
"""
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import tempfile
import concurrent.futures

root = Path(__file__).resolve().parents[2]
json_jar = Path(os.environ['PAIR_JSON_JAR']).resolve()
sources = [root / 'app/src/main/java/com/yefferson/calculadora/pairing' / (name + '.java')
           for name in ['PairWire', 'PairSession', 'PairRecords', 'PairRuntime', 'PairOutbound', 'PairLimits', 'PairCatalog', 'PairTls', 'PairFailure', 'PairIdentityChoice']]
sources += [Path(__file__).with_name(name) for name in ['PairingHarness.java', 'PairingLoadHarness.java', 'PairingTlsHarness.java']]
conscrypt = os.environ.get('PAIR_CONSCRYPT_JAR')
classpath = str(json_jar)
if conscrypt:
    classpath += os.pathsep + str(Path(conscrypt).resolve())
    sources += [Path(__file__).with_name('PairingConscryptHarness.java')]
with tempfile.TemporaryDirectory(prefix='truchapp-pair-test-') as temp:
    folder = Path(temp)
    classes = folder / 'classes'
    password = secrets.token_hex(20)
    keytool = shutil.which('keytool') or str(Path(shutil.which('java')).resolve().parent / 'keytool')
    ecj = os.environ.get('PAIR_ECJ_JAR')
    compiler = ['java', '-jar', str(Path(ecj).resolve()), '-17', '-nowarn'] if ecj else ['javac', '--release', '17']
    subprocess.run(compiler + ['-cp', classpath, '-d', str(classes)] + list(map(str, sources)), check=True)
    names = ['admin', 'client'] + ['client' + str(i) for i in range(1, 20)] + ['overflow']
    def identity(name):
        subprocess.run([keytool, '-genkeypair', '-alias', 'device', '-keyalg', 'RSA', '-keysize', '2048',
                        '-validity', '2', '-dname', 'CN=TruchApp disposable ' + name, '-storetype', 'PKCS12',
                        '-keystore', str(folder / (name + '.p12')), '-storepass', password, '-noprompt'],
                       check=True, capture_output=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        list(executor.map(identity, names))
    if conscrypt:
        subprocess.run(['java', '--add-opens=java.base/java.net=ALL-UNNAMED', '-cp', str(classes) + os.pathsep + classpath,
                        'PairingConscryptHarness', str(folder / 'admin.p12'), password], check=True, timeout=30)
    subprocess.run(['java', '-cp', str(classes) + os.pathsep + str(json_jar), 'PairingTlsHarness',
                    str(folder / 'admin.p12'), str(folder / 'client.p12'), password], check=True, timeout=30)
    subprocess.run(['java', '-cp', str(classes) + os.pathsep + str(json_jar), 'PairingHarness',
                    str(folder / 'admin.p12'), str(folder / 'client.p12'), password], check=True, timeout=120)

    subprocess.run(['java', '-Xmx256m', '-cp', str(classes) + os.pathsep + str(json_jar), 'PairingLoadHarness', str(folder), password], check=True, timeout=150)
