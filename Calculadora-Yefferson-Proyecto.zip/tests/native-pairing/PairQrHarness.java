import com.yefferson.calculadora.pairing.*;import com.google.zxing.*;import com.google.zxing.common.*;import com.google.zxing.qrcode.QRCodeReader;import java.util.*;
/** Real ZXing encoder/decoder plus the production bounded invitation codec. */
public class PairQrHarness {
 static int groups;static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}static void group(String s){groups++;System.out.println("QR PASS "+s);}
 static void reject(String raw,long now)throws Exception{boolean rejected=false;try{PairQr.parse(raw,now);}catch(Exception expected){rejected=true;}check(rejected,"invalid QR rejected");}
 public static void main(String[] args)throws Exception{
  long now=1000000000L;String fp="a".repeat(64),token="b".repeat(64);PairQr value=PairQr.create("192.168.43.1:55000",fp,token,now+300000,now);PairQr parsed=PairQr.parse(value.text(),now);check(parsed.endpoint.equals(value.endpoint)&&parsed.fingerprint.equals(fp)&&parsed.token.equals(token),"exact fields round trip");group("versioned bounded invitation roundtrip");
  BitMatrix matrix=value.matrix();int size=matrix.getWidth();int[] pixels=new int[size*size];for(int y=0;y<size;y++)for(int x=0;x<size;x++)pixels[y*size+x]=matrix.get(x,y)?0xff000000:0xffffffff;Result decoded=new QRCodeReader().decode(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(size,size,pixels))));check(decoded.getText().equals(value.text()),"actual image decodes");group("production QR image decodes with real ZXing");
  reject(value.text(),now+300001);reject(value.text(),now-1);group("expired and excessively future invitations rejected");
  for(String host:new String[]{"127.0.0.1:55000","8.8.8.8:55000","224.0.0.1:55000","0.0.0.0:55000","999.1.1.1:55000","192.168.1.2:80","192.168.1.2:65536","example.org:55000","192.168.1.2:550000"}){boolean failed=false;try{PairQr.create(host,fp,token,now+1000,now);}catch(Exception e){failed=true;}check(failed,host);}group("only private IPv4 and valid unprivileged ports");
  for(String bad:new String[]{"","WIFI:S:test;P:secret;;","https://example.org/","TRUCHAPP:LOCAL:2:{}",value.text()+"x","x".repeat(2049),value.text().replace(fp,"bad"),value.text().replace(token,"bad"),value.text().replace("\"v\":1","\"v\":99")})reject(bad,now);group("unrelated malformed oversized and wrong-identity payloads rejected");
  String extra=value.text().replace("\"kind\":\"local\"","\"kind\":\"local\",\"grant\":true");reject(extra,now);group("QR never carries permission grants or unrelated fields");System.out.println("PASSED "+groups+" QR groups");
 }
}
