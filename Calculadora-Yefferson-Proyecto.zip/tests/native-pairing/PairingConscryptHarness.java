import com.yefferson.calculadora.pairing.*;
import java.io.*;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAKey;
import java.security.spec.AlgorithmParameterSpec;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.*;
import javax.net.ssl.*;
import org.conscrypt.Conscrypt;

/** Real Conscrypt with an opaque-key authorization model, not Android hardware emulation. */
public class PairingConscryptHarness {
 static final AtomicInteger denied=new AtomicInteger(),rawCalls=new AtomicInteger();
 public static final class OpaqueKey implements PrivateKey,RSAKey {
  final PrivateKey material;final boolean allowRaw;final BigInteger modulus;
  OpaqueKey(PrivateKey material,boolean allowRaw){this.material=material;this.allowRaw=allowRaw;modulus=((RSAKey)material).getModulus();}
  public String getAlgorithm(){return "RSA";}public String getFormat(){return null;}public byte[] getEncoded(){return null;}public BigInteger getModulus(){return modulus;}
 }
 public static class DelegatedCipher extends CipherSpi {
  final String padding;Cipher cipher;
  DelegatedCipher(String padding){this.padding=padding;}
  protected void engineSetMode(String mode) throws NoSuchAlgorithmException {if(!mode.equalsIgnoreCase("ECB"))throw new NoSuchAlgorithmException(mode);}
  protected void engineSetPadding(String p) throws NoSuchPaddingException {if(!p.equalsIgnoreCase(padding))throw new NoSuchPaddingException(p);}
  protected int engineGetBlockSize(){return 0;}protected int engineGetOutputSize(int n){return 256;}protected byte[] engineGetIV(){return null;}protected AlgorithmParameters engineGetParameters(){return null;}
  protected void engineInit(int mode,Key key,SecureRandom random) throws InvalidKeyException {
   if(!(key instanceof OpaqueKey))throw new InvalidKeyException("Only the opaque test key is supported");
   OpaqueKey opaque=(OpaqueKey)key;
   if(padding.equals("NoPadding")){if(!opaque.allowRaw){denied.incrementAndGet();throw new InvalidKeyException("KM_PAD_NONE is not authorized");}rawCalls.incrementAndGet();}
   try{cipher=Cipher.getInstance("RSA/ECB/"+padding,"SunJCE");cipher.init(mode,opaque.material,random);}catch(GeneralSecurityException e){throw new InvalidKeyException(e);}
  }
  protected void engineInit(int mode,Key key,AlgorithmParameterSpec spec,SecureRandom random) throws InvalidKeyException {engineInit(mode,key,random);}
  protected void engineInit(int mode,Key key,AlgorithmParameters spec,SecureRandom random) throws InvalidKeyException {engineInit(mode,key,random);}
  protected byte[] engineUpdate(byte[] in,int off,int len){return cipher.update(in,off,len);}
  protected int engineUpdate(byte[] in,int off,int len,byte[] out,int pos) throws ShortBufferException {return cipher.update(in,off,len,out,pos);}
  protected byte[] engineDoFinal(byte[] in,int off,int len) throws IllegalBlockSizeException,BadPaddingException {return cipher.doFinal(in,off,len);}
  protected int engineDoFinal(byte[] in,int off,int len,byte[] out,int pos) throws ShortBufferException,IllegalBlockSizeException,BadPaddingException {return cipher.doFinal(in,off,len,out,pos);}
 }
 public static final class RawCipher extends DelegatedCipher {public RawCipher(){super("NoPadding");}}
 public static final class PkcsCipher extends DelegatedCipher {public PkcsCipher(){super("PKCS1Padding");}}
 public static final class DelegatedSignature extends SignatureSpi {
  Signature signature;
  void create() throws InvalidKeyException {try{signature=Signature.getInstance("SHA256withRSA","SunRsaSign");}catch(GeneralSecurityException e){throw new InvalidKeyException(e);}}
  protected void engineInitVerify(PublicKey key) throws InvalidKeyException {create();signature.initVerify(key);}
  protected void engineInitSign(PrivateKey key) throws InvalidKeyException {create();signature.initSign(key instanceof OpaqueKey?((OpaqueKey)key).material:key);}
  protected void engineUpdate(byte b) throws SignatureException {signature.update(b);}
  protected void engineUpdate(byte[] in,int off,int len) throws SignatureException {signature.update(in,off,len);}
  protected byte[] engineSign() throws SignatureException {return signature.sign();}
  protected boolean engineVerify(byte[] value) throws SignatureException {return signature.verify(value);}
  protected void engineSetParameter(String name,Object value){}protected Object engineGetParameter(String name){return null;}
 }
 public static final class DelegateProvider extends Provider {
  DelegateProvider(){super("TruchAppOpaqueTest",1.0,"Test authorization model");put("Cipher.RSA/ECB/NoPadding",RawCipher.class.getName());put("Cipher.RSA/ECB/PKCS1Padding",PkcsCipher.class.getName());put("Signature.SHA256withRSA",DelegatedSignature.class.getName());}
 }
 static void check(boolean value,String why){if(!value)throw new AssertionError(why);}
 public static void main(String[] args) throws Exception {
  KeyStore keys=KeyStore.getInstance("PKCS12");try(InputStream input=new FileInputStream(args[0])){keys.load(input,args[1].toCharArray());}
  PrivateKey material=(PrivateKey)keys.getKey("device",args[1].toCharArray());X509Certificate cert=(X509Certificate)keys.getCertificate("device");
  Security.insertProviderAt(Conscrypt.newProvider(),1);Security.insertProviderAt(new DelegateProvider(),1);
  check(SSLContext.getInstance("TLSv1.2").getProvider().getName().contains("Conscrypt"),"real Conscrypt selected");
  OpaqueKey legacy=new OpaqueKey(material,false);
  SSLContext legacyTls=PairTls.context(legacy,cert);check(legacy.getEncoded()==null,"opaque legacy key");
  try{PairTls.checkLocal(legacyTls);throw new AssertionError("legacy authorization unexpectedly worked");}catch(SSLException expected){
   check(denied.get()>0,"failure must involve missing raw authorization");
   String detail=expected.getMessage();check(detail!=null&&detail.contains("04000044"),"same RSA internal error as both phone reports");
  }
  System.out.println("PASS real Conscrypt reproduces failed TLS when delegated RSA lacks KM_PAD_NONE");
  OpaqueKey compatible=new OpaqueKey(material,true);SSLContext current=PairTls.context(compatible,cert);
  int before=rawCalls.get();PairTls.checkRawRsa(compatible,cert);PairTls.checkLocal(current);check(rawCalls.get()>=before+3,"raw probe plus mutual-TLS signatures");
  check(compatible.getEncoded()==null,"key stays opaque");
  System.out.println("PASS real Conscrypt completes mutual TLS with corrected raw-signing authorization");
  java.util.concurrent.ExecutorService worker=java.util.concurrent.Executors.newSingleThreadExecutor();
  int signatures=rawCalls.get();
  try(SSLServerSocket listener=(SSLServerSocket)current.getServerSocketFactory().createServerSocket(0,1,java.net.InetAddress.getLoopbackAddress())){
   listener.setNeedClientAuth(true);listener.setEnabledProtocols(new String[]{"TLSv1.2"});listener.setEnabledCipherSuites(PairTls.suites(listener.getSupportedCipherSuites()));listener.setSoTimeout(5000);
   for(int round=0;round<4;round++){
    java.util.concurrent.Future<?> received=worker.submit(()->{try(SSLSocket socket=(SSLSocket)listener.accept()){
     socket.setSoTimeout(5000);socket.startHandshake();PairTls.PeerIdentity id=PairTls.identify(socket.getSession());check(id.local.equals(PairWire.fingerprint(cert)),"server chain present");
     check(socket.getInputStream().read()==1,"client data still encrypted and usable after invalidate");socket.getOutputStream().write(1);socket.getOutputStream().flush();
    }return null;});
    try(SSLSocket socket=(SSLSocket)current.getSocketFactory().createSocket()){
     socket.setEnabledProtocols(new String[]{"TLSv1.2"});socket.setEnabledCipherSuites(PairTls.suites(socket.getSupportedCipherSuites()));socket.setSoTimeout(5000);
     socket.connect(new java.net.InetSocketAddress(java.net.InetAddress.getLoopbackAddress(),listener.getLocalPort()),5000);socket.startHandshake();PairTls.PeerIdentity id=PairTls.identify(socket.getSession());check(id.peer.equals(PairWire.fingerprint(cert)),"peer fingerprint preserved");
     socket.getOutputStream().write(1);socket.getOutputStream().flush();check(socket.getInputStream().read()==1,"server confirmation");received.get(5,java.util.concurrent.TimeUnit.SECONDS);
    }
   }
  }finally{worker.shutdownNow();}
  check(rawCalls.get()>=signatures+8,"all four connections perform both RSA authentications, no resumed identity shortcut");
  System.out.println("PASS four real Conscrypt reconnects retain both certificates and full mutual authentication");
 }
}
