import com.yefferson.calculadora.pairing.*;
import android.content.Context;import android.net.Network;
import java.net.*;import java.util.*;import java.io.*;
/** Real LAN sockets; only Android's network inventory/binding is doubled. */
public class PairNetworkHarness {
    static int groups;
    static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    static void group(String text){groups++;System.out.println("NETWORK PASS "+text);}
    static class Attempts implements PairNetwork.Attempt {
        final List<Socket> opened=new ArrayList<>();boolean cancel;
        public Socket open(){Socket socket=new Socket();opened.add(socket);return socket;}
        public void pending(Socket socket)throws IOException{if(cancel)throw new IOException("Conexión cancelada");}
    }
    public static void main(String[] args)throws Exception {
        Context c=new Context();c.ip=InetAddress.getLoopbackAddress();
        try(ServerSocket server=new ServerSocket(0,4,c.ip)){
            c.bindFails=true;Attempts attempts=new Attempts();
            try(Socket connected=PairNetwork.connect(c,c.ip,server.getLocalPort(),1000,attempts)){
                check(connected.isConnected()&&attempts.opened.size()==2,"fresh fallback connects");
                check(attempts.opened.get(0).isClosed(),"ENONET socket closed");
                check(connected.getLocalAddress().equals(c.ip),"explicit LAN source");
            }group("ENONET fallback uses a new socket and the current LAN source address");
            c.bindFails=false;c.nullNetworks=true;
            try(Socket connected=PairNetwork.connect(c,c.ip,server.getLocalPort(),1000,new Attempts())){check(connected.isConnected(),"null array fallback");}
            c.nullNetworks=false;c.throwNetworks=true;
            check(PairNetwork.local(PairNetwork.routes(c),"").equals(c.ip),"throwing service fallback");
            c.throwNetworks=false;group("null and failing network inventory recover from the assigned Wi-Fi IP");
            Network wrong=new Network(c,"first-wrong");wrong.ip=InetAddress.getByName("10.40.0.2");
            Network right=new Network(c,"right");right.ip=c.ip;
            Network mobile=new Network(c,"mobile");mobile.wifi=false;mobile.ip=c.ip;
            Network vpn=new Network(c,"vpn");vpn.vpn=true;vpn.ip=c.ip;
            c.extraNetworks=new Network[]{null,wrong,mobile,vpn,right};
            try(Socket connected=PairNetwork.connect(c,c.ip,server.getLocalPort(),1000,new Attempts())){check(c.lastBound.equals("right"),"target subnet wins");}
            check(PairNetwork.routes(c).stream().noneMatch(r->r.local.getHostAddress().equals("0.0.0.0")),"no unspecified route");
            group("target route wins over array order; null entries, mobile and VPN excluded");
            c.extraNetworks=null;c.wifi=false;check(PairNetwork.routes(c).isEmpty(),"no Wi-Fi route");
            boolean refused=false;try{PairNetwork.connect(c,c.ip,server.getLocalPort(),1000,new Attempts());}catch(IOException expected){refused=true;}
            check(refused,"no default/mobile socket");c.wifi=true;
            Attempts cancelled=new Attempts();cancelled.cancel=true;try{PairNetwork.connect(c,c.ip,server.getLocalPort(),1000,cancelled);}catch(IOException expected){}
            check(!cancelled.opened.isEmpty()&&cancelled.opened.stream().allMatch(Socket::isClosed),"cancelled attempts closed");
            group("missing Wi-Fi never uses the default route; cancellation closes every socket");
        }
        System.out.println("PASSED "+groups+" LAN network groups");
    }
}
