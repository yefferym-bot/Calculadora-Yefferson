from pathlib import Path
import re
root=Path('/mnt/data/truchapp_menu_work')
assets=root/'app/src/main/assets'
idx=assets/'index.html'
s=idx.read_text(encoding='utf-8')

def icon(name, cls=''):
    shapes={
      'menu':'<path d="M4 7h16M4 12h16M4 17h16"/>',
      'close':'<path d="M18 6 6 18M6 6l12 12"/>',
      'fish':'<path d="M6.2 12c2.2-3.4 5.8-5.5 10-5.5l3.8-3v7l-3.8 1.5 3.8 1.5v7l-3.8-3C12 17.5 8.4 15.4 6.2 12Z"/><circle cx="11.2" cy="10.8" r="1"/><path d="m4 9-2 3 2 3"/>',
      'home':'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
      'package':'<path d="m3 7 9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10M7.5 5l9 4"/>',
      'calendar':'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18M7 14h3M14 14h3"/>',
      'wallet':'<rect x="3" y="6" width="18" height="15" rx="2"/><path d="M3 10h18M7 6V4h12M15 15h3"/>',
      'plus':'<path d="M12 5v14M5 12h14"/>',
      'chart':'<path d="M4 20V13h4v7M10 20V5h4v15M16 20v-10h4v10M3 21h18"/>',
      'droplet':'<path d="M12 3c2.8 4.2 7 9.2 7 12a7 7 0 0 1-14 0c0-2.8 4.2-7.8 7-12Z"/>',
      'calculator':'<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M8 6h8v3H8zM8 13h1M12 13h1M16 13h1M8 17h1M12 17h1M16 17h1"/>',
      'chevron':'<path d="m9 18 6-6-6-6"/>',
      'info':'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
      'bug':'<path d="M8 9V7a4 4 0 0 1 8 0v2M7 9h10v8a5 5 0 0 1-10 0zM4 12h3M17 12h3M4 17h3M17 17h3M6 5l2 2M18 5l-2 2"/>',
      'settings':'<circle cx="12" cy="12" r="3"/><path d="m10 2-.5 2-2 .9-2-.9-2 3 .9 1.9-1 2-2 .5v3l2 .5 1 2-.9 2 2 3 2-.9 2 1  .5 2h4l.5-2 2-1 2 .9 2-3-.9-2 1-2 2-.5v-3l-2-.5-1-2 .9-1.9-2-3-2 .9-2-.9-.5-2z"/>',
      'check':'<path d="M5 12l4 4L19 6"/>',
      'arrow':'<path d="M5 12h14M13 6l6 6-6 6"/>',
      'copy':'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M5 16H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1"/>',
      'spark':'<path d="m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z"/>',
      'shield':'<path d="m12 2 8 4v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6zM9 12l2 2 4-4"/>'
    }
    return f'<svg class="tn-menu-svg {cls}" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{shapes[name]}</svg>'

def item(name,ic,action,style='mint'):
    return f'<button class="tn-menu-item" type="button" {action}><span class="tn-menu-ico tn-tone-{style}">{icon(ic)}</span><span class="tn-menu-item-label">{name}</span>{icon("chevron","tn-menu-arrow")}</button>'

panel = f'''<div id="tnSideMenu" class="tn-menu-layer" aria-hidden="true">
  <div class="tn-menu-backdrop" id="tnMenuBackdrop"></div>
  <aside class="tn-menu-drawer" id="tnMenuDrawer" role="dialog" aria-modal="true" aria-label="Menú principal de TruchAPP" tabindex="-1" inert>
    <div class="tn-menu-hero">
      <div class="tn-menu-hero-row"><span class="tn-menu-appmark">{icon('fish')}</span><button type="button" id="tnMenuClose" class="tn-menu-close" aria-label="Cerrar menú">{icon('close')}</button></div>
      <div class="tn-menu-hero-title">TruchAPP</div>
      <div class="tn-menu-hero-sub">Tu gestión acuícola, organizada.</div>
      <div class="tn-menu-local">{icon('shield')} <span>Información guardada en tu dispositivo</span></div>
    </div>
    <div class="tn-menu-scroll" id="tnMenuScroll">
      <section class="tn-menu-section" aria-labelledby="tnMenuQuickHead">
        <h2 id="tnMenuQuickHead" class="tn-menu-section-label">Acciones rápidas</h2>
        <div class="tn-menu-card">
        {item('Crear nuevo lote','plus','data-menu-action="new-lot"','mint')}
        {item('Nueva actividad','calendar','data-menu-action="new-activity"','blue')}
        {item('Registrar producto','package','data-menu-action="new-product"','gold')}
        </div>
      </section>
      <section class="tn-menu-section" aria-labelledby="tnMenuModulesHead">
        <h2 id="tnMenuModulesHead" class="tn-menu-section-label">Módulos</h2>
        <div class="tn-menu-card">
        {item('Inicio','home','data-menu-target="inicio"','mint')}
        {item('Lotes','fish','data-menu-target="lotes"','blue')}
        {item('Almacén','package','data-menu-target="almacen"','gold')}
        {item('Agenda','calendar','data-menu-target="agenda"','mint')}
        {item('Finanzas','wallet','data-menu-target="finanzas"','violet')}
        </div>
      </section>
      <section class="tn-menu-section" aria-labelledby="tnMenuToolsHead">
        <h2 id="tnMenuToolsHead" class="tn-menu-section-label">Herramientas</h2>
        <div class="tn-menu-card">
        {item('Rendimiento de lotes','chart','data-menu-action="performance"','blue')}
        {item('Calidad del agua','droplet','data-menu-action="water"','mint')}
        {item('Calculadora','calculator','data-menu-target="calc"','gold')}
        </div>
      </section>
      <section class="tn-menu-section" aria-labelledby="tnMenuOptionsHead">
        <h2 id="tnMenuOptionsHead" class="tn-menu-section-label">Ajustes y ayuda</h2>
        <div class="tn-menu-card">
          <label class="tn-menu-option"><span class="tn-menu-ico tn-tone-violet">{icon('settings')}</span><span class="tn-menu-item-label">Reducir movimiento <small>Animación del menú</small></span><input id="tnMenuReducedMotion" type="checkbox" aria-label="Reducir animación del menú"><span class="tn-menu-switch" aria-hidden="true"></span></label>
          {item('Acerca de TruchAPP','info','data-menu-action="about"','blue')}
          {item('Reportar un error','bug','data-menu-action="report"','mint')}
        </div>
      </section>
      <div class="tn-menu-end">TruchAPP · Gestión pesquera y acuícola</div>
    </div>
    <div class="tn-menu-detail" id="tnMenuDetail" hidden>
       <button id="tnMenuDetailBack" type="button" class="tn-menu-detail-back">← Volver al menú</button>
       <div id="tnMenuDetailContent"></div>
    </div>
  </aside>
</div>'''
old_header='<header><div class="brand">TruchApp<small>Gestión acuícola</small></div><div id="status" class="status">● preparando</div></header>'
new_header=f'<header class="tn-main-header"><div class="tn-brand-group"><button id="tnMenuOpen" class="tn-menu-trigger" type="button" aria-label="Abrir menú" aria-haspopup="dialog" aria-controls="tnMenuDrawer" aria-expanded="false">{icon("menu")}</button><div class="brand">TruchApp<small>Gestión acuícola</small></div></div><div id="status" class="status">● preparando</div></header>'
assert s.count(old_header)==1
s=s.replace(old_header,new_header+'\n'+panel,1)
assert '<link rel="stylesheet" href="ui/theme/truchanote.css">' in s
s=s.replace('<link rel="stylesheet" href="ui/theme/truchanote.css">','<link rel="stylesheet" href="ui/theme/truchanote.css">\n<link rel="stylesheet" href="ui/menu/side-menu.css">',1)
s=s.replace('<script src="ui/agenda/agenda.js"></script>','<script src="ui/agenda/agenda.js"></script>\n<script src="ui/menu/side-menu.js"></script>',1)
idx.write_text(s,encoding='utf-8')

menudir=assets/'ui/menu';menudir.mkdir(exist_ok=True)
css=r'''/* TruchAPP 4.8.4 — Menú superior desacoplado. Solo afecta a tn-menu-. */
.phone{position:relative!important}
.phone>.tn-main-header{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;padding:11px 12px!important}
.tn-brand-group{display:flex;align-items:center;gap:9px;min-width:0;flex:1 1 auto}
.tn-brand-group .brand{min-width:0;white-space:nowrap;font-size:clamp(18px,4.4vw,22px)!important}
.phone>.tn-main-header .status{min-width:0;max-width:45%;overflow:hidden;text-overflow:ellipsis;flex:0 1 auto;font-size:9px!important;padding:7px 8px!important}
.phone>.tn-main-header .tn-menu-trigger{display:grid!important;place-items:center!important;flex:0 0 39px;width:39px;min-height:39px;height:39px;border-radius:13px!important;background:#ebf8f4!important;border:1px solid #d0e7e1!important;color:#0e736c!important;padding:0!important;cursor:pointer;-webkit-tap-highlight-color:transparent;box-shadow:0 1px 3px rgba(11,59,58,.05)}
.tn-menu-svg{display:block;width:20px;height:20px;flex-shrink:0}
.tn-menu-trigger .tn-menu-svg{width:22px;height:22px}
.phone>.tn-main-header .tn-menu-trigger:focus-visible,.tn-menu-layer button:focus-visible,.tn-menu-layer input:focus-visible,.tn-menu-layer textarea:focus-visible{outline:3px solid rgba(13,148,136,.32)!important;outline-offset:2px!important}
.phone>.tn-main-header .tn-menu-trigger:active{transform:scale(.96)}
.tn-menu-layer{position:absolute;inset:0;z-index:1250;pointer-events:none;overflow:hidden;color:#0b3b3a;font-family:Inter,system-ui,Arial,sans-serif;font-size:13px}
.tn-menu-backdrop{position:absolute;inset:0;background:rgba(5,35,30,.53);opacity:0;transition:opacity .25s ease;touch-action:pan-y}
.tn-menu-drawer{position:absolute;left:0;top:0;bottom:0;width:min(355px,calc(100% - 40px));max-width:100%;background:#f3f8f7;border-radius:0 22px 22px 0;display:flex;flex-direction:column;overflow:hidden;box-shadow:12px 0 42px rgba(5,46,41,.16);transform:translate3d(-103%,0,0);transition:transform .29s cubic-bezier(.22,1,.36,1);will-change:transform;contain:layout paint;isolation:isolate;backface-visibility:hidden;outline:none}
.tn-menu-layer.tn-open{pointer-events:auto}
.tn-menu-layer.tn-open .tn-menu-backdrop{opacity:1}
.tn-menu-layer.tn-open .tn-menu-drawer{transform:translate3d(0,0,0)}
.tn-menu-hero{flex:none;background:linear-gradient(143deg,#0e766e 0%,#0b8e86 60%,#0a7581 100%);padding:19px 19px 20px;color:#fff;position:relative}
.tn-menu-hero:after{content:"";position:absolute;right:-28px;bottom:-36px;width:138px;height:138px;border:1px solid rgba(255,255,255,.13);border-radius:50%;pointer-events:none}
.tn-menu-hero-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:13px;position:relative;z-index:1}
.tn-menu-appmark{display:grid;place-items:center;width:44px;height:44px;border:1px solid rgba(255,255,255,.26);background:rgba(255,255,255,.14);border-radius:14px;color:#fff}
.tn-menu-appmark svg{width:26px;height:26px}
.tn-menu-close{display:grid!important;place-items:center!important;width:36px!important;height:36px!important;min-height:36px!important;border-radius:12px!important;background:rgba(255,255,255,.18)!important;border:1px solid rgba(255,255,255,.24)!important;color:#fff!important;padding:0!important;cursor:pointer}
.tn-menu-hero-title{font:700 29px/1.15 "Playfair Display",Georgia,serif;letter-spacing:-.02em;position:relative;z-index:1}
.tn-menu-hero-sub{margin-top:5px;color:#d6f8f1;font-size:12px;line-height:1.45;position:relative;z-index:1}
.tn-menu-local{margin-top:15px;display:flex;align-items:center;gap:7px;border:1px solid rgba(255,255,255,.2);border-radius:999px;background:rgba(255,255,255,.13);padding:8px 10px;width:max-content;max-width:100%;font-size:10px;font-weight:650;line-height:1.3;position:relative;z-index:1}
.tn-menu-local svg{width:15px;height:15px}
.tn-menu-scroll{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;padding:15px 13px max(16px,env(safe-area-inset-bottom));scrollbar-width:thin;scrollbar-color:#c3dcd7 transparent}
.tn-menu-section{margin:0 0 19px}
.tn-menu-section-label{font:800 10px/1.4 Inter,system-ui,sans-serif;color:#79918a;letter-spacing:.1em;text-transform:uppercase;margin:0 0 8px 9px}
.tn-menu-card{padding:2px 8px;background:#fff;border:1px solid #dce9e5;border-radius:19px;box-shadow:0 2px 8px rgba(11,59,58,.04)}
.tn-menu-item{width:100%;display:flex;align-items:center;gap:11px;padding:10px 3px;text-align:left;background:transparent!important;border:0!important;border-radius:0!important;min-height:53px!important;font:650 12.5px/1.25 Inter,system-ui,sans-serif!important;color:#1b4945!important;cursor:pointer;box-shadow:none!important}
.tn-menu-card>.tn-menu-item:not(:last-child),.tn-menu-card>.tn-menu-option:not(:last-child){border-bottom:1px solid #edf2f0!important}
.tn-menu-ico{display:grid;place-items:center;width:34px;height:34px;flex:none;border-radius:11px;border:1px solid transparent}
.tn-tone-mint{background:#e3f5ef;border-color:#d4ebe3;color:#15877c}
.tn-tone-blue{background:#e6f2fa;border-color:#d4e8f6;color:#397f99}
.tn-tone-gold{background:#fef3dd;border-color:#f5e7c6;color:#ac832b}
.tn-tone-violet{background:#f1ecf9;border-color:#e6dcf6;color:#866b9e}
.tn-menu-item-label{flex:1;min-width:0}
.tn-menu-item-label small{display:block;color:#78918b;font-size:10px;line-height:1.3;font-weight:500;margin-top:3px}
.tn-menu-arrow{width:17px;height:17px;color:#8fa9a2}
.tn-menu-item:active{background:#f0faf7!important;transform:none!important}
.tn-menu-option{display:flex;align-items:center;gap:11px;min-height:58px;padding:9px 3px;cursor:pointer;position:relative}
.tn-menu-option input{position:absolute;opacity:0;width:1px;height:1px}
.tn-menu-switch{width:39px;height:23px;border-radius:99px;background:#d5e4df;flex:none;transition:background .18s;position:relative}
.tn-menu-switch:before{content:"";width:17px;height:17px;background:#fff;border-radius:50%;position:absolute;left:3px;top:3px;box-shadow:0 1px 3px rgba(0,0,0,.13);transition:transform .18s}
.tn-menu-option input:checked+.tn-menu-switch{background:#168b80}
.tn-menu-option input:checked+.tn-menu-switch:before{transform:translateX(16px)}
.tn-menu-end{font-size:10px;color:#91a9a2;text-align:center;margin:6px 0 13px}
.tn-menu-detail{flex:1;min-height:0;overflow-y:auto;padding:18px 16px;background:#f7fbfa;color:#214945}
.tn-menu-detail[hidden]{display:none!important}
.tn-menu-scroll[hidden]{display:none!important}
.tn-menu-detail-back{width:100%!important;min-height:38px!important;background:transparent!important;color:#167f75!important;font-size:12px!important;font-weight:800!important;text-align:left!important;padding:0 5px!important;margin-bottom:12px}
.tn-menu-detail h2{font:700 24px/1.2 "Playfair Display",Georgia,serif;margin:0 0 10px;color:#153e3b}
.tn-menu-detail p{font-size:12px;color:#667e78;line-height:1.58}
.tn-menu-detail-box{background:#fff;border-radius:16px;border:1px solid #d9e9e4;padding:13px;margin:12px 0}
.tn-menu-detail-box strong{display:block;font-size:12px}
.tn-menu-detail-box textarea{display:block;min-height:100px;width:100%;margin-top:10px;border:1px solid #d9e8e3;background:#f9fdfb;border-radius:12px;padding:11px;font:12px/1.5 Inter,system-ui,sans-serif;color:#234743;resize:vertical}
.tn-menu-detail-btn{width:100%;min-height:42px!important;margin-top:10px;padding:9px 12px!important;border-radius:13px!important;font:750 12px Inter,system-ui,sans-serif!important;background:#0d9488!important;color:#fff!important}
.tn-menu-copy-status{font-size:11px;color:#0e786e;min-height:16px;margin-top:6px}
.phone.tn-menu-open .content{overflow:hidden!important}
.phone.tn-menu-reduced .tn-menu-drawer,.phone.tn-menu-reduced .tn-menu-backdrop{transition-duration:0s!important}
@media(max-width:360px){.phone>.tn-main-header{padding:10px 9px!important}.tn-brand-group{gap:6px}.tn-menu-hero{padding:16px 15px 17px}.tn-menu-scroll{padding:12px 10px 20px}.tn-menu-drawer{width:calc(100% - 33px)}.tn-menu-hero-title{font-size:26px}}
@media(prefers-reduced-motion:reduce){.tn-menu-drawer,.tn-menu-backdrop,.tn-menu-switch,.tn-menu-switch:before{transition:none!important}}
'''
(menudir/'side-menu.css').write_text(css,encoding='utf-8')
js=r'''/* TruchAPP 4.8.4 — Menú lateral. No modifica bases de datos ni estado de otros módulos. */
(function () {
 'use strict';
 const $ = id => document.getElementById(id);
 const layer=$('tnSideMenu'), drawer=$('tnMenuDrawer'), phone=document.querySelector('.phone');
 const openBtn=$('tnMenuOpen'), closeBtn=$('tnMenuClose'), backdrop=$('tnMenuBackdrop');
 const scroll=$('tnMenuScroll'), detail=$('tnMenuDetail'), detailContent=$('tnMenuDetailContent');
 const reduced=$('tnMenuReducedMotion');
 if(!layer||!drawer||!phone||!openBtn||!closeBtn||!backdrop||!scroll||!detail||!detailContent)return;
 const PREF='truchapp_menu_reduce_motion_v1';
 let previousFocus=null;
 let open=false;
 try{reduced.checked=localStorage.getItem(PREF)==='1'}catch(_){}
 phone.classList.toggle('tn-menu-reduced',reduced.checked);
 function showMenu(){
    if(open)return;
    open=true;previousFocus=document.activeElement;
    drawer.inert=false;
    layer.setAttribute('aria-hidden','false');
    openBtn.setAttribute('aria-expanded','true');
    phone.classList.add('tn-menu-open');
    layer.classList.add('tn-open');
    drawer.focus({preventScroll:true});
 }
 function hideMenu(){
    if(!open)return;
    open=false;
    layer.classList.remove('tn-open');
    phone.classList.remove('tn-menu-open');
    openBtn.setAttribute('aria-expanded','false');
    layer.setAttribute('aria-hidden','true');
    drawer.inert=true;
    detail.hidden=true;scroll.hidden=false;
    if(previousFocus&&typeof previousFocus.focus==='function')previousFocus.focus({preventScroll:true});
    else openBtn.focus({preventScroll:true});
 }
 function route(target){
    const button=document.querySelector('.bottom .nav[data-target="'+target+'"]');
    if(button){button.click();return true}
    if(target==='calc'){
       document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active',s.id==='calc'));
       document.querySelectorAll('.bottom .nav').forEach(n=>n.classList.remove('active'));
       const main=document.querySelector('.content');
       if(main){main.classList.remove('ai-expanded');main.scrollTop=0}
       return true;
    }
    return false;
 }
 function quickAction(action){
   const map={
      'new-lot':['lotes','#createLoteTrigger'],
      'new-activity':['agenda','#addTaskBtn'],
      'new-product':['almacen','[data-action="new-item"]'],
      'performance':['lotes','#openPerformanceBtn'],
      'water':['lotes','#openWaterQualityBtn']
   };
   const entry=map[action];if(!entry)return;
   route(entry[0]);
   // Dejar que el módulo termine su primera representación antes de abrir su diálogo existente.
   requestAnimationFrame(()=>requestAnimationFrame(()=>{
      const button=document.querySelector('#'+entry[0]+' '+entry[1]);
      if(button && !button.disabled)button.click();
   }));
 }
 function openDetail(type){
    scroll.hidden=true;detail.hidden=false;detail.scrollTop=0;
    if(type==='about'){
       detailContent.innerHTML='<h2>Acerca de TruchAPP</h2><p>Aplicación de gestión acuícola con herramientas de producción, almacén, actividades y finanzas.</p><div class="tn-menu-detail-box"><strong>Versión 4.8.4</strong><p>Este menú es un acceso a las funciones ya disponibles. La información de los módulos se conserva en el almacenamiento del teléfono.</p></div><p>La inteligencia artificial sigue instalada en segundo plano. La grabadora con transcripción todavía no está incorporada.</p>';
    }else if(type==='report'){
       detailContent.innerHTML='<h2>Reportar un error</h2><p>Describe qué pasó. Puedes copiar el informe y enviarlo cuando lo necesites; no se transmite automáticamente.</p><div class="tn-menu-detail-box"><strong>Descripción</strong><textarea id="tnMenuReportText" placeholder="¿Qué estabas haciendo y qué ocurrió?" maxlength="2000"></textarea><button type="button" id="tnMenuCopyReport" class="tn-menu-detail-btn">Copiar informe</button><p id="tnMenuCopyStatus" class="tn-menu-copy-status" role="status"></p></div>';
    }
 }
 function copyReport(){
   const contents=($('tnMenuReportText')?.value||'').trim();
   if(!contents){$('tnMenuCopyStatus').textContent='Escribe primero lo que ocurrió.';return}
   const data='TruchAPP 4.8.4 — Reporte de error\n'+contents;
   const status=$('tnMenuCopyStatus');
   function failFallback(){
      const el=$('tnMenuReportText');el.value=data;el.focus();el.select();
      try{const ok=document.execCommand('copy');status.textContent=ok?'Informe copiado.':'Selecciona el texto y cópialo.'}catch(_){status.textContent='Selecciona el texto y cópialo.'}
   }
   if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(data).then(()=>{status.textContent='Informe copiado.'}).catch(failFallback);
   else failFallback();
 }
 openBtn.addEventListener('click',showMenu);
 closeBtn.addEventListener('click',hideMenu);
 backdrop.addEventListener('click',hideMenu);
 $('tnMenuDetailBack').addEventListener('click',()=>{detail.hidden=true;scroll.hidden=false});
 reduced.addEventListener('change',()=>{
   phone.classList.toggle('tn-menu-reduced',reduced.checked);
   try{localStorage.setItem(PREF,reduced.checked?'1':'0')}catch(_){}
 });
 drawer.addEventListener('click',event=>{
    if(event.target.closest('#tnMenuCopyReport')){copyReport();return}
    const control=event.target.closest('[data-menu-target],[data-menu-action]');
    if(!control)return;
    const target=control.dataset.menuTarget,action=control.dataset.menuAction;
    if(target){hideMenu();route(target);return}
    if(action==='about'||action==='report'){openDetail(action);return}
    hideMenu();quickAction(action);
 });
 document.addEventListener('keydown',event=>{
   if(!open)return;
   if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();hideMenu();return}
   if(event.key==='Tab'){
      const activeView=detail.hidden?scroll:detail;
      const focusable=[closeBtn, ...Array.from(activeView.querySelectorAll('button:not([disabled]),input:not([disabled]),textarea:not([disabled])'))].filter(el=>!el.inert&&!el.hidden);
      if(!focusable.length){event.preventDefault();drawer.focus();return}
      const first=focusable[0], last=focusable[focusable.length-1];
      if(event.shiftKey&&(document.activeElement===first||document.activeElement===drawer)){event.preventDefault();last.focus()}
      else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===drawer)){event.preventDefault();first.focus()}
   }
 },true);
 let startX=null,startY=null;
 drawer.addEventListener('touchstart',e=>{if(e.touches.length!==1)return;startX=e.touches[0].clientX;startY=e.touches[0].clientY},{passive:true});
 drawer.addEventListener('touchend',e=>{
   if(startX===null||e.changedTouches.length!==1)return;
   const dx=e.changedTouches[0].clientX-startX,dy=e.changedTouches[0].clientY-startY;
   startX=startY=null;
   if(dx< -75&&Math.abs(dx)>1.4*Math.abs(dy))hideMenu();
 },{passive:true});
 window.TruchAppMenu={open:showMenu,close:hideMenu,isOpen:()=>open};
})();
'''
(menudir/'side-menu.js').write_text(js,encoding='utf-8')
gradle=root/'app/build.gradle'
g=gradle.read_text(encoding='utf-8')
g=g.replace('versionCode 33','versionCode 34').replace("versionName '4.8.3'","versionName '4.8.4'")
assert "versionCode 34" in g and "versionName '4.8.4'" in g
gradle.write_text(g,encoding='utf-8')
print('OK', len(s),len(css),len(js))
