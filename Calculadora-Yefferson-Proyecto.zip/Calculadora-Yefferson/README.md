# Calculadora Yefferson

Calculadora Android sencilla, sin Internet.

Funciones: suma, resta, multiplicación, división, porcentaje, cambio de signo, decimal, borrar y AC.

## Compilación
El archivo `.github/workflows/build.yml` usa GitHub Actions para generar `app-debug.apk` automáticamente.
