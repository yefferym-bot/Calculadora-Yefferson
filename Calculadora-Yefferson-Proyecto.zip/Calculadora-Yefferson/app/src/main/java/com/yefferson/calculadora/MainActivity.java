package com.yefferson.calculadora;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    TextView display;
    String input = "0", op = "";
    double first = 0;
    boolean fresh = true;

    @Override public void onCreate(Bundle b) { super.onCreate(b); build(); }

    void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,24,18,18);
        root.setBackgroundColor(Color.BLACK);

        display = new TextView(this);
        display.setText(input);
        display.setTextColor(Color.WHITE);
        display.setTextSize(42);
        display.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        display.setPadding(8,8,8,16);
        root.addView(display, new LinearLayout.LayoutParams(-1,0,1.4f));

        String[][] keys = {{"AC","⌫","%","÷"},{"7","8","9","×"},{"4","5","6","−"},{"1","2","3","+"},{"±","0",".","="}};
        for (String[] row : keys) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            for (String k : row) {
                Button bt = new Button(this);
                bt.setText(k);
                bt.setTextSize(22);
                bt.setTextColor(Color.WHITE);
                bt.setAllCaps(false);
                bt.setOnClickListener(v -> click(k));
                r.addView(bt, new LinearLayout.LayoutParams(0,0,1));
            }
            root.addView(r, new LinearLayout.LayoutParams(-1,0,1));
        }
        setContentView(root);
    }

    void click(String k) {
        try {
            if (k.equals("AC")) { input="0"; op=""; first=0; fresh=true; }
            else if (k.equals("⌫")) { input=input.length()>1 ? input.substring(0,input.length()-1) : "0"; }
            else if (k.equals(".")) { if (!input.contains(".")) input += "."; }
            else if (k.equals("±")) { if (!input.equals("0")) input=input.startsWith("-") ? input.substring(1) : "-"+input; }
            else if (k.equals("%")) { input=fmt(Double.parseDouble(input)/100); }
            else if ("÷×−+".contains(k)) { first=Double.parseDouble(input); op=k; fresh=true; }
            else if (k.equals("=")) {
                double b=Double.parseDouble(input), res=first;
                if(op.equals("+")) res+=b; else if(op.equals("−")) res-=b; else if(op.equals("×")) res*=b; else if(op.equals("÷")) res=b==0?Double.NaN:res/b;
                input=fmt(res); op=""; fresh=true;
            } else { if(fresh || input.equals("0")){input=k;fresh=false;} else input+=k; }
            display.setText(input);
        } catch(Exception e) { input="Error"; fresh=true; display.setText(input); }
    }

    String fmt(double d) { if(Double.isNaN(d)||Double.isInfinite(d)) return "Error"; return new DecimalFormat("0.##########").format(d); }
}
