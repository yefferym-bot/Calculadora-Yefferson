#!/usr/bin/env python3
"""Inventario y cambios acotados para ZIP de TruchApp. Python 3.9+, sin dependencias."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import zipfile

CHUNK = 1024 * 1024


def digest(stream):
    result = hashlib.sha256()
    while True:
        block = stream.read(CHUNK)
        if not block:
            return result.hexdigest()
        result.update(block)


def safe_name(name):
    path = PurePosixPath(name)
    clean = name.rstrip('/')
    if (not clean or '\\' in name or path.is_absolute() or '..' in path.parts
            or ':' in name or str(path) != clean):
        raise ValueError('Ruta ZIP no válida: ' + name)
    return clean


def entries(archive):
    seen = set()
    result = []
    for info in archive.infolist():
        name = safe_name(info.filename)
        if name in seen:
            raise ValueError('Entrada ZIP duplicada: ' + name)
        if info.flag_bits & 1:
            raise ValueError('El ZIP de código contiene una entrada cifrada: ' + name)
        seen.add(name)
        result.append(info)
    return result


def inventory(path):
    path = Path(path)
    files = {}
    with zipfile.ZipFile(path) as archive:
        for info in entries(archive):
            if info.is_dir():
                continue
            with archive.open(info) as stream:
                checksum = digest(stream)  # ZipExtFile también comprueba el CRC.
            files[info.filename] = {'size': info.file_size, 'sha256': checksum}
    with path.open('rb') as stream:
        checksum = digest(stream)
    return {'format': 1, 'archive': path.name, 'archive_sha256': checksum,
            'archive_size': path.stat().st_size, 'file_count': len(files),
            'uncompressed_size': sum(f['size'] for f in files.values()),
            'files': dict(sorted(files.items()))}


def compare(base, candidate, allowed=(), deleted=()):
    allowed = {safe_name(n) for n in allowed}
    deleted = {safe_name(n) for n in deleted}
    before, after = inventory(base), inventory(candidate)
    old, new = before['files'], after['files']
    added = sorted(set(new) - set(old))
    removed = sorted(set(old) - set(new))
    changed = sorted(n for n in set(old) & set(new) if old[n] != new[n])
    unexpected = sorted((set(added + changed) - allowed) | (set(removed) - deleted))
    return {'base_sha256': before['archive_sha256'],
            'candidate_sha256': after['archive_sha256'],
            'candidate_size': after['archive_size'],
            'added': added, 'modified': changed, 'removed': removed,
            'identical_files': len(set(old) & set(new)) - len(changed),
            'outside_scope': unexpected, 'ok': not unexpected}


def copy_entry(source, target, info):
    with target.open(info, 'w', force_zip64=info.file_size >= zipfile.ZIP64_LIMIT) as out:
        shutil.copyfileobj(source, out, CHUNK)


def package(base, overlay, output, allowed=(), deleted=()):
    base, overlay, output = Path(base), Path(overlay), Path(output)
    allowed = {safe_name(n) for n in allowed}
    deleted = {safe_name(n) for n in deleted}
    if not overlay.is_dir():
        raise ValueError('No existe la carpeta de cambios.')
    if output.exists() or base.resolve() == output.resolve():
        raise ValueError('La salida debe ser nueva y distinta de la base.')
    if output.resolve().is_relative_to(overlay.resolve()):
        raise ValueError('La salida debe quedar fuera de la carpeta de cambios.')
    updates = {}
    for path in overlay.rglob('*'):
        if path.is_symlink():
            raise ValueError('La carpeta de cambios contiene un enlace: ' + str(path))
        if path.is_file():
            name = safe_name(path.relative_to(overlay).as_posix())
            updates[name] = path
    unexpected = sorted(set(updates) - allowed)
    if unexpected:
        raise ValueError('Cambios fuera del alcance: ' + ', '.join(unexpected))
    if set(updates) & deleted:
        raise ValueError('Una ruta no puede editarse y eliminarse a la vez.')
    with zipfile.ZipFile(base) as archive:
        infos = entries(archive)
        names = {i.filename for i in infos}
        missing = deleted - names
        if missing:
            raise ValueError('No existen las rutas a eliminar: ' + ', '.join(sorted(missing)))
    output.parent.mkdir(parents=True, exist_ok=True)
    handle, temp_name = tempfile.mkstemp(prefix='.truchapp-', suffix='.zip', dir=output.parent)
    os.close(handle)
    temporary = Path(temp_name)
    try:
        with zipfile.ZipFile(base) as source, zipfile.ZipFile(
                temporary, 'w', compression=zipfile.ZIP_DEFLATED,
                compresslevel=9, allowZip64=True) as target:
            target.comment = source.comment
            for original in infos:
                if original.filename in deleted:
                    continue
                info = copy.copy(original)
                if info.is_dir():
                    target.writestr(info, b'')
                elif info.filename in updates:
                    path = updates[info.filename]
                    info.file_size = path.stat().st_size
                    with path.open('rb') as stream:
                        copy_entry(stream, target, info)
                else:
                    with source.open(original) as stream:
                        copy_entry(stream, target, info)
            for name in sorted(set(updates) - names):
                path = updates[name]
                info = zipfile.ZipInfo.from_file(path, arcname=name)
                info.compress_type = zipfile.ZIP_DEFLATED
                with path.open('rb') as stream:
                    copy_entry(stream, target, info)
        report = compare(base, temporary, allowed, deleted)
        if not report['ok']:
            raise ValueError('La comprobación final detectó cambios ajenos al alcance.')
        if output.exists():
            raise ValueError('La salida ya existe; no se sobrescribe.')
        os.replace(temporary, output)
        report['output'] = str(output)
        return report
    finally:
        if temporary.exists():
            temporary.unlink()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    scan = commands.add_parser('inventario', help='Huellas SHA-256 por archivo.')
    scan.add_argument('zip')
    scan.add_argument('--salida', required=True)
    diff = commands.add_parser('comparar', help='Comparar y detectar cambios no permitidos.')
    diff.add_argument('base')
    diff.add_argument('candidate')
    pack = commands.add_parser('empaquetar', help='Aplicar únicamente los archivos de cambios.')
    pack.add_argument('base')
    pack.add_argument('--cambios', required=True)
    pack.add_argument('--salida', required=True)
    for command in (diff, pack):
        command.add_argument('--permitir', action='append', default=[], metavar='RUTA')
        command.add_argument('--eliminar', action='append', default=[], metavar='RUTA')
    args = parser.parse_args(argv)
    try:
        if args.command == 'inventario':
            result = inventory(args.zip)
            destination = Path(args.salida)
            if destination.exists() or destination.resolve() == Path(args.zip).resolve():
                raise ValueError('El inventario de salida ya existe; elegir otro nombre.')
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('x', encoding='utf-8') as stream:
                json.dump(result, stream, ensure_ascii=False, indent=2)
                stream.write('\n')
            print(json.dumps({k: v for k, v in result.items() if k != 'files'}, ensure_ascii=False))
            return 0
        if args.command == 'comparar':
            result = compare(args.base, args.candidate, args.permitir, args.eliminar)
        else:
            result = package(args.base, args.cambios, args.salida, args.permitir, args.eliminar)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result['ok'] else 1
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile) as error:
        print('Error de continuidad: ' + str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
