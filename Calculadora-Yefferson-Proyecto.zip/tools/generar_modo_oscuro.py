"""Deriva únicamente colores oscuros; conserva reglas de geometría y lógica originales.

Ejecutar tras cambiar colores en los CSS/HTML originales. Sin dependencias ni red.
Los ámbitos principal/detalle se separan para conservar sus cascadas independientes.
"""
from pathlib import Path
import colorsys
import os
import re

ROOT = Path(__file__).resolve().parents[1] / 'app/src/main/assets'
OUTPUT = ROOT / 'ui/theme/night-mode.css'
TOKENS = {
    'bg':'#0e1d24', 'surface':'#182d35', 'raised':'#203941',
    'text':'#e6f0ed', 'muted':'#b2c8c5', 'line':'#47636c',
    'action':'#246b67', 'accent':'#9bded1', 'danger':'#ffb4ab',
    'warning':'#efd08a', 'success':'#a3dab8', 'blue':'#b7cbf3',
    'danger-bg':'#482e35', 'warning-bg':'#423b2b', 'blue-bg':'#2b3652',
}


def split_top(text, delimiter):
    start = depth = 0
    quote = None
    escaped = False
    for i, c in enumerate(text):
        if escaped:
            escaped = False
            continue
        if c == '\\':
            escaped = True
            continue
        if quote:
            if c == quote:
                quote = None
        elif c in '\"\'':
            quote = c
        elif c in '([':
            depth += 1
        elif c in ')]':
            depth -= 1
        elif c == delimiter and depth == 0:
            yield text[start:i]
            start = i + 1
    yield text[start:]


def blocks(text):
    # Las únicas llaves de las fuentes fuera de bloques son las de valores citados.
    text = re.sub(r'/\*[\s\S]*?\*/', '', text)
    start = 0
    depth = 0
    quote = None
    escaped = False
    for i, c in enumerate(text):
        if escaped:
            escaped = False
            continue
        if c == '\\':
            escaped = True
            continue
        if quote:
            if c == quote:
                quote = None
            continue
        if c in '\"\'':
            quote = c
        elif c == '{':
            if depth == 0:
                head = text[start:i].strip()
                body = i + 1
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                yield head, text[body:i]
                start = i + 1
    assert depth == 0, 'CSS con llaves sin cerrar'


def color_rgba(token):
    if token.lower() in ('white', 'black'):
        return ((1,1,1,1) if token.lower() == 'white' else (0,0,0,1))
    if token.startswith('#'):
        value = token[1:]
        if len(value) in (3,4):
            value = ''.join(c*2 for c in value)
        return tuple(int(value[i:i+2],16)/255 for i in (0,2,4)) + ((int(value[6:8],16)/255) if len(value)==8 else 1,)
    try:
        parts = [p.strip() for p in re.split(r'[,/ ]+',token[token.index('(')+1:-1]) if p.strip()]
        values = [float(p[:-1])/100 if p.endswith('%') else float(p)/255 for p in parts[:3]]
        alpha = float(parts[3].strip('%'))/(100 if parts[3].endswith('%') else 1) if len(parts)>3 else 1
        return (*values,alpha)
    except ValueError:
        return None


def luminance(rgb):
    linear = [c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in rgb]
    return sum(c*w for c,w in zip(linear,(.2126,.7152,.0722)))


def role(prop):
    if prop.startswith('--'):
        if re.search(r'(?:bg|background|card|soft|surface|panel|suave)$|fondo-', prop): return 'background'
        if re.search(r'(?:line|border|borde|ln)$', prop): return 'border'
        if 'shadow' in prop: return 'shadow'
        return 'color'
    if 'shadow' in prop: return 'shadow'
    if prop.startswith(('border','outline')): return 'border'
    if prop.startswith('background'): return 'background'
    return 'color'


def translate_color(token, kind):
    rgba = color_rgba(token)
    if rgba is None: return token
    r,g,b,a = rgba
    if kind == 'shadow': return token
    h,l,s = colorsys.rgb_to_hls(r,g,b)
    hue=h*360
    lum=luminance((r,g,b))
    if kind == 'background':
        # Conservar indicadores vivos y cabeceras ya oscuras. Atenuar superficies claras.
        if lum < .16: return token
        if s>.35 and (hue<45 or hue>330): target='#482e35'
        elif s>.35 and hue<75: target='#423b2b'
        elif s>.35 and 75<=hue<155: target='#203e40'
        elif s>.3 and 205<hue<320: target='#2b3652'
        elif lum>.85: target=TOKENS['surface']
        elif lum>.45: target=TOKENS['raised']
        else: target=TOKENS['action']
    elif kind == 'border':
        if s>.45 and (hue<45 or hue>330): target='#a76c69'
        elif s>.45 and hue<75: target='#9d8652'
        elif s>.45 and 75<=hue<155: target='#5f9274'
        elif s>.4 and 205<hue<320: target='#7588b4'
        else: target=TOKENS['line']
    else:
        if lum>.8: target=TOKENS['text']
        elif lum<.065: target=TOKENS['text']
        elif s>.35 and (hue<45 or hue>330): target=TOKENS['danger']
        elif s>.35 and hue<75: target=TOKENS['warning']
        elif s>.35 and 75<=hue<155: target=TOKENS['success']
        elif s>.35 and 205<hue<320: target=TOKENS['blue']
        elif s>.5: target=TOKENS['accent']
        else: target=TOKENS['muted']
    # Blanco translúcido de los botones de cabecera sigue siendo una luz tenue.
    if a<.5 and lum>.8 and kind in ('background','border'): return token
    return target if a==1 else target+f'{round(a*255):02x}'


COLORS=re.compile(r'#[0-9a-fA-F]{3,8}\b|\brgba?\([^)]*\)|\b(?:white|black)\b',re.I)
VARS=re.compile(r'var\((--[\w-]+)(?:\s*,[^()]*)?\)')


def value_for(prop,value):
    if 'url(' in value: return value  # No modificar imágenes, fuentes ni SVG embebidos.
    kind=role(prop)
    def variable(m):
        name=m[1].lower()
        if re.search(r'(?:bg|background)$',name): key='bg'
        elif re.search(r'(?:card|surface|panel)$|fondo-alto',name): key='surface'
        elif re.search(r'(?:soft|suave)$|fondo-(?:bajo|medio)',name): key='raised'
        elif re.search(r'(?:ink|text|title|texto|tl)$',name): key='text'
        elif re.search(r'muted|mut$|mute$|tenue$',name): key='muted'
        elif re.search(r'(?:line|border|borde|ln)$',name): key='line'
        elif re.search(r'(?:accent[-]?2?|accent-2|acc|turq|teal)$',name): key='action' if kind=='background' else 'accent'
        elif re.search(r'danger|coral',name): key='danger-bg' if kind=='background' else 'danger'
        elif re.search(r'warn|gold',name): key='warning-bg' if kind=='background' else 'warning'
        elif name.endswith('agua'): key='blue-bg' if kind=='background' else 'blue'
        else: return m[0]
        return 'var(--night-'+key+')'
    value=COLORS.sub(lambda m:translate_color(m[0],kind),value)
    return VARS.sub(variable,value)


def prefixed(selector, scope):
    if '[data-high-contrast=' in selector: return None
    if selector.startswith(':root'):
        return selector.replace(':root',scope,1)
    if re.match(r'html(?=[\s.:#\[]|$)',selector):
        return re.sub(r'^html',scope,selector,count=1)
    return scope+' '+selector


def rebase_urls(value,origin):
    if origin is None: return value
    def replace(m):
        target=m[1].strip().strip('"\'')
        if target.startswith(('data:','#','http:','https:','//')): return m[0]
        path=(origin.parent/target).resolve()
        return 'url("'+os.path.relpath(path,OUTPUT.parent).replace(os.sep,'/')+'")'
    return re.sub(r'url\(([^)]+)\)',replace,value)


def image_parts(value):
    found=[]
    for m in re.finditer(r'(?:(?:repeating-)?(?:linear|radial|conic)-gradient|url|image-set)\(',value):
        if found and m.start()<found[-1][1]: continue
        depth=1;quote=None;end=m.end()
        while end<len(value) and depth:
            c=value[end]
            if quote:
                if c==quote and value[end-1]!='\\':quote=None
            elif c in '\"\'':quote=c
            elif c=='(':depth+=1
            elif c==')':depth-=1
            end+=1
        found.append((m.start(),end,value[m.start():end]))
    return found


def colored_declarations(prop,value,origin):
    if prop in ('--priority-dot','--shadow'): return []
    important='!important' if value.rstrip().endswith('!important') else ''
    clean=value.replace('!important','').strip()
    if prop=='background':
        images=image_parts(clean)
        outside=clean
        for start,end,_ in reversed(images):outside=outside[:start]+outside[end:]
        m=COLORS.search(outside) or VARS.search(outside)
        color=m[0] if m else ('transparent' if images or clean in ('none','transparent') else clean)
        image=','.join(part for _,_,part in images) or 'none'
        return [('background-color',value_for('background-color',color)+important),('background-image',rebase_urls(value_for('background-image',image),origin)+important)]
    if prop in ('background-color','background-image','color','fill','stroke','accent-color','caret-color','scrollbar-color'):
        return [(prop,rebase_urls(value_for(prop,value),origin))]
    # Los bordes se traducen SOLO por color; nunca se sobrescribe su ancho/estilo.
    if re.fullmatch(r'(?:border(?:-(?:left|right|top|bottom))?|outline)(?:-color)?',prop):
        if prop.endswith('-color'):return [(prop,value_for(prop,value))]
        m=COLORS.search(clean) or VARS.search(clean)
        if m:return [(prop+'-color',value_for(prop,m[0])+important)]
        if 'transparent' in clean:return [(prop+'-color','transparent'+important)]
    if prop.startswith('--') and COLORS.search(value):
        return [(prop,value_for(prop,value))]
    return []


def adapt(css,scope,origin=None):
    result=[]
    for selector,body in blocks(css):
        if selector.startswith(('@media','@supports','@container')):
            inner=adapt(body,scope,origin)
            if inner: result.append(selector+'{\n'+inner+'\n}')
            continue
        if selector.startswith('@'): continue
        declarations=[]
        for declaration in split_top(body,';'):
            match=re.match(r'^\s*([-\w]+)\s*:\s*([\s\S]*)$',declaration)
            if not match: continue
            prop,value=match.groups()
            for name,changed in colored_declarations(prop,value,origin):
                declarations.append(name+':'+changed.strip())
        selectors=[prefixed(sel.strip(),scope) for sel in split_top(selector,',') if sel.strip()]
        selectors=[s for s in selectors if s]
        if declarations and selectors: result.append(','.join(selectors)+'{'+(';'.join(declarations))+'}')
    return '\n'.join(result)


def sources(document):
    head=document.read_text().split('</head>')[0]
    for m in re.finditer(r'<style\b[^>]*>([\s\S]*?)</style>|<link\b[^>]*href="([^"]+)"[^>]*>',head):
        if m[1] is not None: yield 'inline',m[1]
        else:
            path=(document.parent/m[2]).resolve()
            if path.suffix=='.css' and path!=OUTPUT: yield path.relative_to(ROOT).as_posix(),path.read_text()


def build():
    output=['/* Modo oscuro: solo color. Generado con tools/generar_modo_oscuro.py. */',
            'html[data-theme=dark]{color-scheme:dark;'+''.join('--night-'+k+':'+v+';' for k,v in TOKENS.items())+'}']
    for filename,scope in [('index.html','html[data-theme=dark]:not([data-display-document=detail])'),('ui/lotes/detail/index.html','html[data-theme=dark][data-display-document=detail]')]:
        for name,css in sources(ROOT/filename):
            adapted=adapt(css,scope,(ROOT/filename) if name=='inline' else (ROOT/name))
            if adapted: output.extend(['/* '+filename+' · '+name+' */',adapted])
    # Excepciones de identidad: colores que transmiten estado o forman parte de la trucha.
    output.append('''
/* Superficies base y controles nativos; no se aplica filtro a imágenes ni indicadores. */
html[data-theme=dark][data-display-document=detail] #detailPanel{background:var(--night-bg)!important}
html[data-theme=dark][data-theme=dark] #agendaRoot :is(.dayDot.low,.priorityLegend i.low){background:#4caf72!important}
html[data-theme=dark][data-theme=dark] #agendaRoot :is(.dayDot.normal,.priorityLegend i.normal){background:#f2bb45!important}
html[data-theme=dark][data-theme=dark] #agendaRoot :is(.dayDot.high,.priorityLegend i.high){background:#e66b5b!important}

html[data-theme=dark][data-theme=dark],html[data-theme=dark][data-theme=dark] body{background:var(--night-bg)!important;color:var(--night-text)}
html[data-theme=dark][data-theme=dark] :is(input,select,textarea){color-scheme:dark;accent-color:#77c9b7}
html[data-theme=dark][data-theme=dark] ::placeholder{color:#a3bab8!important;opacity:1}
html[data-theme=dark][data-theme=dark] :is(input,select,textarea):focus-visible{outline-color:#83d8c8}
html[data-theme=dark][data-theme=dark] :is(input,select,textarea) option{background:#203941;color:#e6f0ed}
html[data-theme=dark][data-theme=dark] :is(dialog,.lotesOverlay,.tn-menu-layer) a{color:#9bded1}
html[data-theme=dark][data-theme=dark] svg text{fill:#b2c8c5}
html[data-theme=dark][data-theme=dark] #lotesRoot .lotesListHeader:before{background:var(--night-bg)!important}
html[data-theme=dark][data-theme=dark] #lotesRoot .healthLight.good{background:#22c55e!important}
html[data-theme=dark][data-theme=dark] #lotesRoot .healthLight.regular{background:#facc15!important}
html[data-theme=dark][data-theme=dark] #lotesRoot .healthLight.critical{background:#ef4444!important}
html[data-theme=dark][data-theme=dark] #lotesRoot .lotesUtility[data-display-contrast]{background:#284b54;border-color:#5f858b;color:#e6f0ed}
html[data-theme=dark][data-theme=dark] #bottomNav.bottom-nav{background:linear-gradient(120deg,#11333d,#0e2c36)!important;border-color:#395b66!important}
html[data-theme=dark][data-theme=dark] #bottomNav .nav-item.active{background:linear-gradient(145deg,#96e0d2,#65c3bc)!important;color:#103b41!important}
html[data-theme=dark][data-theme=dark] #bottomNav .nav-item.active :is(span,svg){color:#103b41!important}
html[data-theme=dark][data-theme=dark] .tn-main-header--minimal{background:transparent!important}
html[data-theme=dark][data-theme=dark][data-display-document=detail] #pane-resumen #kpis .groupLabel{color:#e6f0ed!important}
html[data-theme=dark][data-theme=dark] .truchapp-save-feedback,html[data-theme=dark][data-theme=dark][data-display-document=detail] #toast{background:#183e49;color:#e6f0ed;border-color:#5a7a84}
''')
    return '\n'.join(output)+'\n'


if __name__=='__main__':
    result=build()
    OUTPUT.write_text(result)
    print(f'{OUTPUT.name}: {len(result.encode())} bytes, solo colores condicionados a data-theme=dark.')
