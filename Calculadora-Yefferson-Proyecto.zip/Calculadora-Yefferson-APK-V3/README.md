# Calculadora Yefferson — APK V3

Esta versión usa como interfaz de Android el prototipo HTML verde aprobado.

Características:
- Diseño verde y negro.
- Operaciones encadenadas y complejas: `2 + 3 − 5 + 6 − 5`.
- Prioridad matemática: `×` y `÷` antes que `+` y `−`.
- Porcentaje, cambio de signo, decimal, retroceso y AC.
- Funciona sin Internet porque la interfaz está incluida dentro del APK.

## Compilación
Se puede compilar con GitHub Actions usando Gradle 8.7 y Android SDK 35.
