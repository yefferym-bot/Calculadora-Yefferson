# CHANGE SCOPE — V7.1 / V2.8

## Objetivo
Corregir la transición de la primera portada y agregar personalización inicial en la quinta portada.

## Cambios permitidos
- `app/src/main/assets/ui/intro/intro.css`
- `app/src/main/assets/ui/intro/intro.js`
- `app/src/main/assets/index.html` únicamente para incorporar `profile.experience` al contexto de la IA y a la respuesta de memoria.
- `app/build.gradle` únicamente para aumentar `versionCode` a 15 y `versionName` a 2.8.

## No modificar
- `AiModule.java`
- `AiConversationManager.java`
- `AiModelManager.java`
- `AiNative.java`
- `KnowledgeManager.java`
- `native_ai.cpp`
- `LocalStore.java`
- `ReminderManager.java`
- `WebViewHost.java`
- `AndroidBridge` y la lógica de calculadora.
- YKB / `rag_index.json`.

## Quinta portada
Pregunta el nombre y la experiencia del usuario:
- Recién inicio.
- Tengo experiencia.

Los datos se guardan en `profile` local y mediante `AndroidAI.saveProfile`, por lo que la IA puede usarlos en futuras conversaciones.
