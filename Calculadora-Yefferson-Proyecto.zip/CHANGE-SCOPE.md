# Change Scope

## Versión integrada YKB v1.2.0

### Modificado
- `app/build.gradle`: `versionCode 10`, `versionName 2.4`.
- `AiModule.java`: carga de YKB y adición de contexto recuperado al prompt local.
- `MainActivity.java`: puente de diagnóstico `getKnowledgeState()`.
- `ai/knowledge/KnowledgeManager.java`: nuevo módulo aislado de recuperación.
- `assets/knowledge/`: Yefferson Knowledge Book v1.2.0 incrustado localmente.
- `ARCHITECTURE.md`: documentación de la nueva capa.

### No modificado intencionalmente
- Diseño visual y estructura HTML de la calculadora.
- JavaScript de calculadora, memoria, agenda y recordatorios.
- `AiConversationManager`.
- `AiNative` y `native_ai.cpp`.
- Flujo de firma del APK.
