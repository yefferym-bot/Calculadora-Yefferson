# CHANGE SCOPE — V7.2 / V3.0

## Objetivo
Evitar el destello de la calculadora al iniciar, conservar la portada de bienvenida como capa inicial y cambiar la marca visible de la aplicación a TruchApp sin alterar su núcleo modular.

## Cambios permitidos
- `app/src/main/assets/ui/intro/intro.css`
- `app/src/main/assets/ui/intro/intro.js`
- `app/src/main/assets/index.html` para el bloqueo visual de arranque y el cambio de marca visible a TruchApp.
- Archivos de documentación y workflows para actualizar la marca.
- `app/build.gradle` únicamente para aumentar `versionCode` a 17 y `versionName` a 3.0.

## No modificar
- `AiModule.java`
- `AiConversationManager.java`
- `AiModelManager.java`
- `AiNative.java`
- `KnowledgeManager.java`
- `native_ai.cpp`
- `LocalStore.java`
- `ReminderManager.java`
- `WebViewHost.java`
- `AndroidBridge` y la lógica de calculadora.
- YKB / `rag_index.json`.

## Quinta portada
Pregunta el nombre y la experiencia del usuario:
- Recién inicio.
- Tengo experiencia.

Los datos se guardan en `profile` local y mediante `AndroidAI.saveProfile`, por lo que la IA puede usarlos en futuras conversaciones.
