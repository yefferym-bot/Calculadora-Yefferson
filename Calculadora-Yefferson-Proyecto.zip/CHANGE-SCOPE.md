# Regla de cambios por partes

## Base congelada
`app/src/main/assets/index.html` y las funciones de calculadora no se modifican al reparar IA.

## Problema de IA
Solo están autorizados inicialmente:
- `app/src/main/java/com/yefferson/calculadora/ai/`
- `app/src/main/cpp/native_ai.cpp`
- `app/src/main/cpp/CMakeLists.txt` si el problema es de compilación nativa.

## Problema de memoria/agenda
Trabajar primero en `data/` y el puente mínimo de `MainActivity`.

## Problema de recordatorios
Trabajar en `reminders/` y, cuando sea necesario, solo en los receivers de Android.

## Problema visual
Solo entonces se toca `index.html` o `ui/WebViewHost.java`.

## Regla de prueba
Cada corrección debe producir una versión incremental y se verifica contra la versión estable anterior antes de incorporar la siguiente corrección.


## V6.2 — AI performance and reasoning cleanup
Only AI files were functionally changed: `AiModule.java` and `AiModelManager.java`.
`app/build.gradle` only increments the app version for an installable update.
The UI asset `app/src/main/assets/index.html` is intentionally unchanged.
Changes: append Qwen3 `/no_think` for normal chat, cap generation at 192 tokens, remove any leaked `<think>...</think>` block from final output, and reduce the 1.7B runtime context from 3072 to 2048.
