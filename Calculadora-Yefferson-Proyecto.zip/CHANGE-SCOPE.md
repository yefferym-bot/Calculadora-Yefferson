# Change Scope

## Versión V6.6 — corrección de captura de nombre + contexto

### Modificado
- `app/build.gradle`: `versionCode 12`, `versionName 2.6`.
- `app/src/main/assets/index.html`: captura de nombre más estricta para no confundir palabras como “genial”, “perfecto”, “gracias”, “bien” u otras respuestas comunes con un nombre.
- Se eliminó la detección frágil basada solamente en el último mensaje de la IA.
- Se añadió un estado explícito de “esperando nombre” cuando la IA local pregunta cómo se llama el usuario.
- Se aceptan nombres escritos con o sin mayúscula cuando el contexto es claramente una solicitud de nombre.
- La corrección conserva el arreglo V6.5 de contexto/historial.

### No modificado intencionalmente
- Diseño visual y estructura HTML de la calculadora.
- JavaScript de operaciones matemáticas.
- Biblioteca YKB y `KnowledgeManager.java`.
- `AiConversationManager.java` salvo que permanezca la versión V6.5 ya integrada en el ZIP.
- `AiNative.java` y `native_ai.cpp`.
- Flujo de firma del APK.
