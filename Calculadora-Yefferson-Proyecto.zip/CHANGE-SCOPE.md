# CHANGE SCOPE — V7.2 / V3.0

## Objetivo
Evitar el destello de la calculadora al iniciar, conservar la portada de bienvenida como capa inicial y cambiar la marca visible de la aplicación a TruchApp sin alterar su núcleo modular.

## Cambios permitidos
- `app/src/main/assets/ui/intro/intro.css`
- `app/src/main/assets/ui/intro/intro.js`
- `app/src/main/assets/index.html` para el bloqueo visual de arranque y el cambio de marca visible a TruchApp.
- Archivos de documentación y workflows para actualizar la marca.
- `app/build.gradle` únicamente para aumentar `versionCode` a 17 y `versionName` a 3.0.

## No modificar
- `AiModule.java`
- `AiConversationManager.java`
- `AiModelManager.java`
- `AiNative.java`
- `KnowledgeManager.java`
- `native_ai.cpp`
- `LocalStore.java`
- `ReminderManager.java`
- `WebViewHost.java`
- `AndroidBridge` y la lógica de calculadora.
- YKB / `rag_index.json`.

## Quinta portada
Pregunta el nombre y la experiencia del usuario:
- Recién inicio.
- Tengo experiencia.

Los datos se guardan en `profile` local y mediante `AndroidAI.saveProfile`, por lo que la IA puede usarlos en futuras conversaciones.


## V4.5 — Módulo Lotes
- Se retira Calculadora de la navegación principal, pero se conserva su pantalla y funcionalidad.
- Se agrega `assets/ui/lotes/lotes.css` y `lotes.js`.
- Se registra seguimiento local de lotes con existencias, biometrías, alimento, mortalidad, cosecha e indicadores productivos.
- No se modifica memoria interna de IA, YKB, Agenda ni Finanzas.


## V4.5.1 — Tutorial inicial de Lotes
- Se retiró la tarjeta informativa de gestión de producción del flujo normal del módulo Lotes.
- Se convirtió en un tutorial modal centrado que aparece solo la primera vez que el usuario entra a Lotes.
- Se puede cerrar con X (arriba a la derecha) o tocando fuera del contenedor.
- El contenedor conserva el estilo visual de `.card.hero`; el cambio es de presentación y persistencia del tutorial.
- No se modifican calculadora, IA, YKB, memoria, agenda ni finanzas.

## V4.8.9 — Inicio / rendimiento global de la granja

- Reemplazo exclusivo de la presentación y consultas de `ui/dashboard/dashboard.js` y `dashboard.css`.
- Imagen `ui/dashboard/trout.svg`, derivada de la trucha vectorial ya incluida en Lotes.
- `app/build.gradle`: versionCode 39 / versionName 4.8.9.
- `ui/menu/side-menu.js`: solo se actualiza el texto de versión; su comportamiento permanece igual.
- README actualizado con el alcance y la compilación manual.
- Workflows, index.html, módulos Lotes, Agenda, Almacén, Finanzas e IA, datos y código nativo conservados.

## V4.8.10 — Control operativo en Inicio

- `ui/dashboard/dashboard-data.js`: cálculos y separación por centro/periodo, sin acceso a almacenamiento.
- `ui/dashboard/dashboard.js` y `dashboard.css`: panel operativo, gráficas de registros, ajustes y vínculos.
- `index.html`: únicamente la carga del nuevo archivo de cálculos antes del módulo Inicio.
- `ui/agenda/agenda.js`: acceso adicional `TruchAppAgendaOpenTask(id)` al editor existente; no cambia las reglas de guardado, repetición o recordatorios.
- `app/build.gradle`: versionCode 40 / versionName 4.8.10. Menú lateral: texto de versión actualizado.
- README y alcance actualizados.
- Workflows, código Java/C++, módulo Lotes, Almacén, Finanzas, IA y recursos de conocimiento conservados.
- Preferencias nuevas de Inicio en una clave independiente, incluidas por la exportación completa existente. No se migran ni reescriben datos de los otros módulos.
