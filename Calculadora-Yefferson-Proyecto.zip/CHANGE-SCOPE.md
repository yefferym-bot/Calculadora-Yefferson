# V7 — Cambio visual: portadas de bienvenida

## Alcance
- Agrega un módulo lógico de assets en `app/src/main/assets/ui/intro/`.
- Implementa 5 portadas de bienvenida inspiradas directamente en el código proporcionado por el usuario:
  1. Portada principal TruchaNote con cardumen animado, burbujas y transición.
  2. Todo sobre cada tanque en un solo lugar.
  3. Planifique el trabajo y las finanzas con claridad.
  4. Vea qué necesita atención.
  5. La secuencia anterior se presenta como la portada inicial + 4 pantallas de introducción.
- El módulo es solo visual/UX. No modifica `AiModule`, `AiConversationManager`, `KnowledgeManager`, `LocalStore`, `ReminderManager`, `native_ai.cpp` ni el YKB.
- La portada aparece una sola vez por instalación/versión visual y se marca con `localStorage` como `yefferson_intro_v7_done`.
- `versionCode` pasa de 12 a 13 y `versionName` de 2.6 a 2.7.

## Nota
La imagen fotográfica embebida del código original se sustituyó en esta primera etapa por una ilustración SVG local del mismo estilo visual, para mantener el módulo offline y aislado. La paleta, layout, tipografías solicitadas, cardumen y animaciones de la portada se conservaron/adaptaron a WebView válido.
