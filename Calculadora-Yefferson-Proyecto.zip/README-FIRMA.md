# Firma permanente de la Calculadora Yefferson

Esta versión usa un keystore externo mediante secretos de GitHub Actions.

Secretos requeridos:
- KEYSTORE_BASE64
- KEYSTORE_PASSWORD
- KEY_ALIAS
- KEY_PASSWORD

No subir nunca el archivo `yefferson-release-key.jks` al repositorio.

La primera instalación de esta versión puede requerir desinstalar el APK debug anterior si Android detecta una firma diferente. Desde esta versión, las actualizaciones Release futuras deben usar el mismo keystore y aumentar `versionCode`.
