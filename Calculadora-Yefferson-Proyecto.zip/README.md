# Calculadora Yefferson IA V5

Proyecto Android basado en la V3 que ya funcionó, ahora con IA local real, memoria personal, agenda, recordatorios y base de conocimiento local.

## Qué incorpora

- Calculadora con operaciones encadenadas y precedencia matemática.
- IA local con llama.cpp.
- Modelo Qwen3 GGUF seleccionado automáticamente según RAM.
- 4–5 GB RAM: Qwen3 0.6B Q8_0 (~805 MB).
- 6 GB o más: Qwen3 1.7B Q4_K_M (~1.28 GB).
- Memoria personal: nombre, ocupación y recuerdos.
- Registros técnicos: temperatura, oxígeno, pH, amoniaco, biomasa, alimento, mortalidad y FCR.
- Agenda con notificaciones locales y restauración tras reinicio.
- Recuperación local de conocimiento de acuicultura, trucha, alimentación, FCR, agua, incubación, HACCP/BPM, procesamiento y otros temas.
- La conversación reciente se guarda localmente en el WebView para contextualizar respuestas.
- Después de descargar el modelo una vez, la generación es local y no usa una API de pago.

## Compilación

El workflow mantiene la misma idea del workflow V3: Java 17 + Android SDK + Gradle 8.7 + `assembleDebug`. Antes de compilar descarga `llama.cpp` y lo compila con el NDK de Android para `arm64-v8a`.

## Primera ejecución

1. Instalar el APK.
2. Abrir la pestaña IA.
3. Pulsar “Preparar IA local”.
4. Con Wi‑Fi, esperar la descarga del modelo.
5. Cuando diga “IA local lista”, se puede usar sin Internet.

El tamaño del modelo no se mete dentro del APK para evitar que la aplicación pese más de 800 MB–1.2 GB desde la instalación. Se descarga una sola vez y queda en el almacenamiento privado de la app.

## Nota

El modelo y llama.cpp son componentes de terceros. La aplicación no incluye claves de API ni requiere una cuenta de IA para la generación local.
