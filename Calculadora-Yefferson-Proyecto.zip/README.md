# TruchApp IA

Proyecto Android basado en la V3 que ya funcionó, ahora con IA local real, memoria personal, agenda, recordatorios y base de conocimiento local.

## Qué incorpora

- Calculadora con operaciones encadenadas y precedencia matemática.
- IA local con llama.cpp.
- Modelo Qwen3 GGUF seleccionado automáticamente según RAM.
- 4–5 GB RAM: Qwen3 0.6B Q8_0 (~805 MB).
- 6 GB o más: Qwen3 1.7B Q4_K_M (~1.28 GB).
- Memoria personal: nombre, ocupación y recuerdos.
- Registros técnicos: temperatura, oxígeno, pH, amoniaco, biomasa, alimento, mortalidad y FCR.
- Agenda con notificaciones locales y restauración tras reinicio.
- Recuperación local de conocimiento de acuicultura, trucha, alimentación, FCR, agua, incubación, HACCP/BPM, procesamiento y otros temas.
- La conversación reciente se guarda localmente en el WebView para contextualizar respuestas.
- Después de descargar el modelo una vez, la generación es local y no usa una API de pago.

## Compilación

El workflow mantiene la misma idea del workflow V3: Java 17 + Android SDK + Gradle 8.7 + `assembleDebug`. Antes de compilar descarga `llama.cpp` y lo compila con el NDK de Android para `arm64-v8a`.

## Primera ejecución

1. Instalar el APK.
2. Abrir la pestaña IA.
3. Pulsar “Preparar IA local”.
4. Con Wi‑Fi, esperar la descarga del modelo.
5. Cuando diga “IA local lista”, se puede usar sin Internet.

El tamaño del modelo no se mete dentro del APK para evitar que la aplicación pese más de 800 MB–1.2 GB desde la instalación. Se descarga una sola vez y queda en el almacenamiento privado de la app.

## Nota

El modelo y llama.cpp son componentes de terceros. La aplicación no incluye claves de API ni requiere una cuenta de IA para la generación local.


## V6.3 — Motor IA fluido y conversacional

Cambios exclusivos del módulo IA:
- Conversación modular con ventana móvil de hasta 6 intercambios.
- Reutilización de prefijo/KV cache cuando la conversación anterior es compatible.
- Modo rápido sin thinking para preguntas simples y modo thinking adaptativo para preguntas complejas.
- Samplers de Qwen3 separados para non-thinking y thinking.
- Caché de respuestas exactas recientes para respuestas instantáneas repetidas.
- Detección de nombre en respuestas cortas como “Juan” cuando la IA acaba de pedir el nombre.
- El nombre se guarda en la memoria local existente.
- Borrado de memoria personal también limpia la conversación viva de la IA.
- La interfaz visual, HTML fuera de la lógica de IA, calculadora, agenda y diseño no se modifican.

Nota: el streaming token a token se reserva para una fase posterior después de validar esta base.


## V4.5 — Lotes
La barra principal es: Inicio · Lotes · IA · Agenda · Finanzas. La Calculadora permanece en segundo plano y sigue accesible desde accesos secundarios.


## V4.6.0 — Lotes productivos conectados con la memoria local

- Interfaz del módulo Lotes integrada con diseño claro menta, indicadores, etiquetas de estado con luz tipo neón, modal de creación y modal de muestreo.
- Registra peso, talla, mortalidad, descarte, calibre de pellet, alimento por periodo e historial. La supervivencia, la biomasa y el estado del lote se recalculan al guardar.
- Los datos de lotes se conservan en el almacenamiento local de la aplicación y en la memoria persistente nativa de Android. Los lotes existentes guardados en WebView se migran al formato nuevo.
- La memoria muestra los lotes; la IA recibe contexto productivo cuando la pregunta trata sobre lotes, biomasa, alimentación, FCR, talla, supervivencia o mortalidad.
- La Agenda permite vincular actividades a un lote. Finanzas puede copiar cantidad inicial, pesos y supervivencia del lote elegido, dejando los costos/precios para que los ingrese el usuario.
- Borrar la memoria personal no elimina los lotes productivos.
- Los lotes de demostración del prototipo no se crean automáticamente como datos reales: la instalación inicia vacía si no existen registros previos, para evitar introducir datos productivos ficticios.

## V4.7.1 — Integración verificable de Lotes

- Se mantiene el módulo Lotes y su diseño aprobado, con creación de lotes, muestreos e indicadores productivos.
- Los datos de los lotes se comparten mediante `TruchAppData` con IA, Agenda y Finanzas, y se guardan también en `SharedPreferences` de Android.
- El workflow de compilación desde ZIP prepara `llama.cpp` explícitamente en la raíz del proyecto antes de ejecutar Gradle, para evitar el error de ruta que podía aparecer al configurar CMake.
- El número de versión sube a `4.7.1` (versionCode `28`) para que el APK firmado pueda instalarse como actualización de la versión anterior, siempre que se use la misma clave de firma.

## V4.8.9 — Panel de rendimiento global en Inicio

- Inicio incorpora el panel verde azulado con una trucha vectorial y cuatro tarjetas: indicadores biológicos, rentabilidad, monitoreo y tareas/alertas.
- El FCR es el promedio de los últimos valores disponibles por lote; el crecimiento semanal es el promedio equivalente entre las dos últimas fechas de biometría de cada lote con datos. El anillo muestra la supervivencia global y el estado conserva los criterios ya usados por Lotes.
- Los importes de Finanzas son proyecciones del ciclo calculadas a partir de los valores guardados, no ventas mensuales registradas.
- Se priorizan las últimas mediciones de agua por centro, lote, punto y parámetro; se muestran fecha y hora. Las tareas tienen en cuenta repeticiones y fechas completadas.
- Los títulos de las tarjetas abren las funciones existentes. No se cambia la lógica de los demás módulos ni las claves de almacenamiento.
- versionCode 39, versionName 4.8.9. Se conserva el applicationId y el workflow de firma.

### Compilar esta entrega

Conserva el nombre `Calculadora-Yefferson-Proyecto.zip`, reemplaza el ZIP de la raíz de tu repositorio y ejecuta tu workflow existente para construir el APK. Este ZIP contiene el proyecto fuente; el APK instalable se obtiene al terminar la compilación en GitHub.

## V4.8.10 — Inicio operativo para control y decisiones

- Orden del panel: atención prioritaria, resumen productivo, evolución de lotes, trabajo de hoy y resumen económico del ciclo.
- Los avisos explican el valor, motivo, fecha y antigüedad de las mediciones. Los datos faltantes o antiguos no generan un estado verde. Los límites de revisión y la vigencia en horas pueden ajustarse desde Inicio.
- Filtro por granja/centro y vista de registros sin centro. En Configurar Inicio se vinculan los lotes a los centros existentes; una asociación única en las mediciones se muestra como sugerencia y puede cambiarse.
- Las tendencias de peso, mortalidad y alimento permiten elegir 7 o 30 días y consultar los valores registrados. El peso agregado usa fechas comunes y ponderación por existencias; los días sin registro no se completan con ceros. El alimento corresponde a intervalos entre muestreos, no a un consumo diario inventado.
- El FCR del conjunto usa alimento total dividido por ganancia estimada de biomasa en fechas comunes a los lotes con existencias. Se exige alimento registrado en todos los intervalos incluidos. La ganancia se reconstruye con pesos y existencias, utilizando los registros de mortalidad y descarte. Si los datos son incompletos o no comparables, no se muestra un FCR parcial como global.
- La mortalidad registrada hoy incluye el número de lotes que tienen registros de esa fecha.
- Trabajo de hoy reconoce actividades únicas, repeticiones y fechas completadas. Cada actividad abre su editor existente en Agenda; los accesos de lote abren su ficha. Las repeticiones vencidas se revisan dentro de la ventana elegida; una actividad única vencida se conserva aunque sea anterior a ella.
- Finanzas se presenta como una proyección de un ciclo. Su asociación a un centro se confirma desde Inicio y se vuelve a solicitar si cambian los valores de esa proyección. No se presenta como ventas mensuales ni como suma de todas las granjas.
- Vínculos, preferencias y límites se guardan en `truchapp_inicio_control_v1`. El mecanismo de copia de seguridad existente ya exporta todas las claves locales e incluye esta configuración.
- Nuevo motor de cálculos `ui/dashboard/dashboard-data.js`, sin escrituras de registros productivos.
- Comprobaciones: cálculos y filtros con registros de prueba, casos de datos ausentes/antiguos, FCR comparable, repeticiones, enlaces, guardado de ajustes y ausencia de cambios en registros de producción. La compilación e instalación se realizan con el workflow del usuario.
- versionCode 40 / versionName 4.8.10. Se mantiene `Calculadora-Yefferson-Proyecto.zip`, la estructura del archivo y los workflows existentes.


## V4.9.0 — Detalle de lote aprobado

- «Ver / actualizar lote» abre la interfaz aprobada: Resumen, Biometría, Agua e Historial, con la misma paleta, tipografías, trucha vectorial y ola animada de la muestra.
- Las seis tarjetas abren sus detalles y gráficos. Se incluyen filtros 7 días / 30 días / MAX para registros diarios, últimos controles / MAX para biometrías, selección de puntos, tablas y el calendario compacto de bajas.
- Alimento, mortalidad y descarte se registran por día. Actualizar una fecha reemplaza sus totales sin duplicarlos. Las biometrías guardan el peso medido y, opcionalmente, los pesos individuales. Los ceros confirmados y los datos ausentes siguen siendo distintos.
- Los registros anteriores conservan su historial y sus totales de períodos. Los saldos sin desglose no se reparten en días ficticios. La copia del historial y los valores anteriores se conserva en los datos del lote.
- El FCR aparente requiere alimento y bajas confirmados entre dos biometrías y una ganancia neta positiva. El volumen, las referencias y los planes quedan fechados. Las mediciones se comparten con el módulo de agua sin reemplazar registros de otros lotes o centros.
- El guardado usa las claves locales existentes y `AndroidAI.saveLots`, con confirmación y recuperación ante errores. Inicio, Agenda, IA y Finanzas continúan recibiendo las existencias y datos actualizados. Los registros diarios no crean pesos ficticios en Inicio.
- La instalación permanece vacía si no hay lotes. Los seis meses simulados pertenecen exclusivamente a la muestra HTML y no se generan en el APK.
- Verificación: cálculos y migración, filtros y formularios en navegador móvil, actualización del mismo día, reapertura, interfaz nativa modelada, fallo de guardado y recuperación, mediciones de otros lotes, deshacer y ausencia de datos de ejemplo. La compilación e instalación final se realizan mediante el workflow de GitHub del usuario.
- `versionCode 41`, `versionName 4.9.0`; se conserva `com.yefferson.calculadora`, la firma y ambos workflows.

Para compilar, reemplaza **Calculadora-Yefferson-Proyecto.zip** en la raíz del repositorio y ejecuta tu workflow existente. No cambies el nombre del ZIP.


## V4.9.1 · Apertura del detalle de lote

- Carga con pez, olas y burbujas en los tonos de TruchApp; respeta la preferencia de movimiento reducido.
- La vista aparece después de preparar los datos y el primer dibujo. La carga puede cerrarse o reintentarse si falla.
- Reutiliza una sola vista interna; cada apertura lee de nuevo el lote y reinicia formularios, filtros y deshacer para evitar datos de otra sesión.
- El historial se prepara al consultarlo. Conserva los registros y el workflow de compilación manual.


## V4.9.2 · Estabilidad visual del detalle de lotes

- Panel, tarjetas, pestañas e indicadores sin animaciones de entrada ni cambios de opacidad.
- El cargador conserva su animación acuática y cubre de forma opaca la vista mientras se prepara. Solo se desvanece el cargador al terminar; el detalle ya está dibujado a opacidad completa.
- La cobertura es inmediata en cada reapertura para evitar mostrar datos de la sesión anterior.
- Se eliminan desenfoques superpuestos y se mantienen superficies estables al abrir ventanas o desplazar gráficos.
- Conserva los registros, la lógica compartida, el diseño y el workflow de compilación manual.


## V4.9.3 · Ancho de las ventanas de indicadores

Las ventanas abiertas desde las tarjetas comparten el ancho máximo y los márgenes laterales del detalle principal del lote, incluidos los dispositivos pequeños. Se conservan el contenido, las alturas, el guardado y la estabilidad visual.


## V4.9.4 · Menú inferior SVG

Aplica el diseño de menu-inferior-svg.html: cinco botones flotantes, iconos SVG originales, fondo transparente, contornos redondeados y selección verde. Conserva las rutas y acciones existentes de los cinco módulos. El contenido dispone de espacio inferior para desplazarse por encima de los botones.


## V4.9.5 · Posición del menú inferior

El menú flotante se fija al borde inferior del área visible, centrado en el ancho de la aplicación, con 5 px de separación bajo los botones. La posición ya no depende de la altura del contenedor `.phone`. La barra mantiene el fondo transparente y evita repetir el espacio de las barras del sistema que ya reserva Android. El contenido conserva margen para desplazarse por encima del menú.

Se conserva el diseño de los botones, las rutas de los cinco módulos y los datos guardados. `versionCode 46`, `versionName 4.9.5`; la compilación sigue siendo manual con el workflow existente y el nombre `Calculadora-Yefferson-Proyecto.zip`.


## V4.10.0 · Alimentación, almacén y costos por lote

Desde **Lotes → Ver / actualizar lote → Registrar día** se puede vincular el alimento suministrado a uno o varios productos y lotes de fabricación del almacén. Cada entrega genera su salida en el Kardex y su costo por lote productivo. Se conserva el menú de cinco módulos.

### Uso

1. En **Almacén**, registra el alimento y su entrada con cantidad, costo, lote de fabricación y vencimiento cuando corresponda. Se admiten kg, g y sacos. Para sacos, indica el contenido real en kg en la ficha del producto.
2. En **Registro diario**, selecciona **Vincular entrega al almacén**, el producto, su lote de fabricación y los kg entregados. Puedes añadir varias líneas. El total del día se calcula con esas líneas. Para confirmar que no se alimentó, marca **No se alimentó este día**.
3. Consulta **Costo de alimentación** en el resumen o la tarjeta de alimentación del lote. En **Finanzas → Alimentación por lote**, filtra el lote que quieres revisar.

Al actualizar un día se reemplazan sus entregas; no se suman de nuevo. Deshacer revierte el mismo registro, stock y costo. No se permite consumir más del saldo disponible en la fecha indicada ni usar un lote vencido en esa fecha. El guardado se vuelve a comprobar con el almacén actual y conserva la confirmación nativa de Android.

Los consumos antiguos permanecen sin valorar cuando no tienen producto y lote vinculados. **Registro sin vincular** permite conservar esos totales sin generar otra salida ni inventar precios. Si una entrega ya tiene una salida manual en Almacén, no la vuelvas a descontar como entrega vinculada.

### Cálculo y conservación

- El costo usa promedio móvil por lote de alimento y fecha. Una compra con fecha posterior no cambia el costo de una entrega anterior. Corregir una fecha pasada puede actualizar la valoración de las entregas posteriores del mismo lote de alimento.
- **Alimento por kg ganado** = costo de alimento del período ÷ aumento neto estimado de biomasa entre dos biometrías. Requiere alimento y bajas confirmados en todos los días del período, alimento vinculado por completo y aumento neto positivo. En caso contrario se muestra **Por completar** y el motivo. No representa el costo total de producción.
- Las salidas se calculan desde las entregas guardadas en el lote, evitando dos registros independientes del mismo consumo. Al eliminar un lote con entregas, su historial de salidas y resumen económico se conservan para no devolver al stock alimento ya entregado.
- La unidad y el contenido del saco se protegen cuando ya existen movimientos. Se conservan las claves de datos, los demás módulos, la firma y ambos workflows. El respaldo existente incluye los registros de alimentación y almacén.

Validación: `node tests/feeding.test.cjs` comprueba cantidades, valoración, fechas, correcciones, unidades, datos antiguos, deshacer e integridad. También se verificaron formularios en navegador móvil, fallos de almacenamiento, guardado nativo modelado, reapertura, datos de otros lotes, ventanas y menú inferior. La compilación e instalación final se realizan con el workflow del usuario.

`versionCode 47`, `versionName 4.10.0`. Conserva **Calculadora-Yefferson-Proyecto.zip** al reemplazar el archivo en la raíz del repositorio y ejecutar el workflow manual.
