# TruchApp IA

Proyecto Android basado en la V3 que ya funcionó, ahora con IA local real, memoria personal, agenda, recordatorios y base de conocimiento local.

## Qué incorpora

- Calculadora con operaciones encadenadas y precedencia matemática.
- IA local con llama.cpp.
- Modelo Qwen3 GGUF seleccionado automáticamente según RAM.
- 4–5 GB RAM: Qwen3 0.6B Q8_0 (~805 MB).
- 6 GB o más: Qwen3 1.7B Q4_K_M (~1.28 GB).
- Memoria personal: nombre, ocupación y recuerdos.
- Registros técnicos: temperatura, oxígeno, pH, amoniaco, biomasa, alimento, mortalidad y FCR.
- Agenda con notificaciones locales y restauración tras reinicio.
- Recuperación local de conocimiento de acuicultura, trucha, alimentación, FCR, agua, incubación, HACCP/BPM, procesamiento y otros temas.
- La conversación reciente se guarda localmente en el WebView para contextualizar respuestas.
- Después de descargar el modelo una vez, la generación es local y no usa una API de pago.

## Compilación

El workflow mantiene la misma idea del workflow V3: Java 17 + Android SDK + Gradle 8.7 + `assembleDebug`. Antes de compilar descarga `llama.cpp` y lo compila con el NDK de Android para `arm64-v8a`.

## Primera ejecución

1. Instalar el APK.
2. Abrir la pestaña IA.
3. Pulsar “Preparar IA local”.
4. Con Wi‑Fi, esperar la descarga del modelo.
5. Cuando diga “IA local lista”, se puede usar sin Internet.

El tamaño del modelo no se mete dentro del APK para evitar que la aplicación pese más de 800 MB–1.2 GB desde la instalación. Se descarga una sola vez y queda en el almacenamiento privado de la app.

## Nota

El modelo y llama.cpp son componentes de terceros. La aplicación no incluye claves de API ni requiere una cuenta de IA para la generación local.


## V6.3 — Motor IA fluido y conversacional

Cambios exclusivos del módulo IA:
- Conversación modular con ventana móvil de hasta 6 intercambios.
- Reutilización de prefijo/KV cache cuando la conversación anterior es compatible.
- Modo rápido sin thinking para preguntas simples y modo thinking adaptativo para preguntas complejas.
- Samplers de Qwen3 separados para non-thinking y thinking.
- Caché de respuestas exactas recientes para respuestas instantáneas repetidas.
- Detección de nombre en respuestas cortas como “Juan” cuando la IA acaba de pedir el nombre.
- El nombre se guarda en la memoria local existente.
- Borrado de memoria personal también limpia la conversación viva de la IA.
- La interfaz visual, HTML fuera de la lógica de IA, calculadora, agenda y diseño no se modifican.

Nota: el streaming token a token se reserva para una fase posterior después de validar esta base.


## V4.5 — Lotes
La barra principal es: Inicio · Lotes · IA · Agenda · Finanzas. La Calculadora permanece en segundo plano y sigue accesible desde accesos secundarios.


## V4.6.0 — Lotes productivos conectados con la memoria local

- Interfaz del módulo Lotes integrada con diseño claro menta, indicadores, etiquetas de estado con luz tipo neón, modal de creación y modal de muestreo.
- Registra peso, talla, mortalidad, descarte, calibre de pellet, alimento por periodo e historial. La supervivencia, la biomasa y el estado del lote se recalculan al guardar.
- Los datos de lotes se conservan en el almacenamiento local de la aplicación y en la memoria persistente nativa de Android. Los lotes existentes guardados en WebView se migran al formato nuevo.
- La memoria muestra los lotes; la IA recibe contexto productivo cuando la pregunta trata sobre lotes, biomasa, alimentación, FCR, talla, supervivencia o mortalidad.
- La Agenda permite vincular actividades a un lote. Finanzas puede copiar cantidad inicial, pesos y supervivencia del lote elegido, dejando los costos/precios para que los ingrese el usuario.
- Borrar la memoria personal no elimina los lotes productivos.
- Los lotes de demostración del prototipo no se crean automáticamente como datos reales: la instalación inicia vacía si no existen registros previos, para evitar introducir datos productivos ficticios.

## V4.7.1 — Integración verificable de Lotes

- Se mantiene el módulo Lotes y su diseño aprobado, con creación de lotes, muestreos e indicadores productivos.
- Los datos de los lotes se comparten mediante `TruchAppData` con IA, Agenda y Finanzas, y se guardan también en `SharedPreferences` de Android.
- El workflow de compilación desde ZIP prepara `llama.cpp` explícitamente en la raíz del proyecto antes de ejecutar Gradle, para evitar el error de ruta que podía aparecer al configurar CMake.
- El número de versión sube a `4.7.1` (versionCode `28`) para que el APK firmado pueda instalarse como actualización de la versión anterior, siempre que se use la misma clave de firma.
