# Calculadora Yefferson

Versión 1.1 de la calculadora Android con interfaz oscura, botones redondeados y operaciones básicas.

Funciones: suma, resta, multiplicación, división, porcentaje, cambio de signo, decimal, borrar y AC.
