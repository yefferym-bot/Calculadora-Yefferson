from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path('/mnt/data/truchapp_menu_work/app/src/main/assets')
s=(root/'index.html').read_text(encoding='utf-8')
for asset in re.findall(r'<link rel="stylesheet" href="([^"]+)">',s):
 f=root/asset
 if not f.exists(): print('missing CSS',asset);continue
 s=s.replace(f'<link rel="stylesheet" href="{asset}">', '<style>\n'+f.read_text(encoding='utf-8')+'\n</style>',1)
for asset in re.findall(r'<script src="([^"]+)"></script>',s):
 f=root/asset
 if not f.exists(): print('missing JS',asset);continue
 script=f.read_text(encoding='utf-8')
 s=s.replace(f'<script src="{asset}"></script>', '<script>\n'+script+'\n</script>',1)
# No external assets under server for these functional tests
s=re.sub(r'<link rel="preconnect"[^>]*>', '',s)
s=re.sub(r'<link href="https://fonts.googleapis.com/[^"]*"[^>]*>', '',s)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':340,'height':740},is_mobile=True,has_touch=True)
 errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.evaluate("""() => {const vals={'truchapp_intro_v4_1_profile_done':'1','truchapp_lotes_tutorial_v2':'1'};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>vals[k]||null,setItem:(k,v)=>{vals[k]=String(v)},removeItem:k=>{delete vals[k]}}})}""")
 page.set_content(s,wait_until='domcontentloaded',timeout=60000)
 page.evaluate("() => {document.documentElement.classList.remove('truchapp-boot'); document.getElementById('yb-intro')?.remove()}")
 page.locator('#tnMenuOpen').click()
 page.keyboard.press('Escape')
 assert page.locator('#tnMenuOpen').get_attribute('aria-expanded')=='false'
 page.locator('#tnMenuOpen').click()
 page.locator('[data-menu-target="calc"]').click()
 assert page.locator('#calc.screen.active').count()==1
 page.locator('#tnMenuOpen').click()
 page.locator('[data-menu-action="new-lot"]').click()
 page.wait_for_timeout(240)
 assert page.locator('#lotes #createModal.open').count()==1
 page.screenshot(path='/mnt/data/truchapp_menu_work/newlot-open.png')
 print('quick create LOT:OK calc:OK escape:OK initialJsErrors:',errs[:2])
 b.close()
