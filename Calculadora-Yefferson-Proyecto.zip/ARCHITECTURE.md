# TruchApp — arquitectura modular

## Capas

- UI/WebView: `app/src/main/assets/index.html`
- IA local: `app/src/main/java/com/yefferson/calculadora/ai/`
- Biblioteca YKB: `app/src/main/java/com/yefferson/calculadora/ai/knowledge/KnowledgeManager.java`
- Datos personales: `data/LocalStore.java`
- Recordatorios: `reminders/ReminderManager.java`
- Motor nativo: `app/src/main/cpp/`

## Biblioteca incrustada

La aplicación incluye localmente `Yefferson Knowledge Book v1.2.0` dentro de `app/src/main/assets/knowledge/`.

El archivo `rag_index.json` contiene 240 registros recuperables. `KnowledgeManager` carga el índice y realiza recuperación híbrida local por tema, módulo, título, palabras clave y contenido. Los registros recuperados se añaden al contexto de Qwen3 como `[BIBLIOTECA_YKB]`.

La biblioteca está separada de la memoria personal, el historial conversacional y las herramientas de la calculadora.

## Regla de diseño

Las modificaciones futuras del conocimiento deben permanecer dentro de `ai/knowledge/` y `assets/knowledge/`, sin cambiar el diseño visual ni la lógica de la calculadora salvo que una función específica lo requiera.

## Alimentación integrada (4.10.0)

- `ui/feeding/feeding-data.js`: motor puro, sin almacenamiento ni DOM. Convierte unidades, deriva las salidas de alimento, comprueba saldos por fecha y calcula costos por lote. El promedio móvil se reconstruye desde las entradas y salidas de cada lote de alimento. Las entradas del mismo día se consideran antes de sus salidas porque el almacén registra fechas, sin hora de recepción.
- `ui/feeding/feeding-store.js`: acceso a los datos existentes de Lotes y Almacén. Conserva la identidad del lote productivo por ID. No confunde el lote productivo con el lote de fabricación del alimento.
- `ui/feeding/feeding-ui.js` y `feeding.css`: formulario de entregas y componentes de costos compartidos. Las funciones de la interfaz no realizan escrituras de registros productivos por su cuenta.
- Fuente de una entrega: `detailState.daily[].feedStock.lines`. Cada línea contiene identificador, producto y unidad, equivalencia en kg, lote de fabricación, vencimiento, cantidad y referencia de valoración. Los movimientos derivados tienen ID estable por lote productivo, fecha y línea.
- `TruchAppData.saveLotDetail` valida la entrega contra el almacén actual y guarda el lote con el mecanismo local y nativo existente. La respuesta devuelve el estado confirmado y el almacén actualizado a la vista interna. Stock y costo se derivan del mismo registro confirmado.
- `truchapp_almacen_kardex_v1` conserva las fichas y los movimientos manuales existentes. `feedArchive` y `feedArchivedLots` conservan las entregas de lotes eliminados; se ignoran mientras el lote siga presente, evitando duplicaciones si una eliminación se interrumpe.
- Las referencias de costo de una entrega no sustituyen la valoración del Kardex. El informe usa los movimientos derivados valorados de forma cronológica; así una corrección histórica mantiene coherentes los costos posteriores y el valor del stock restante.
- Las entregas sin vincular no generan stock ni costo automático. La proyección económica existente permanece separada del costo documentado de alimentación.

Pruebas del motor: `node tests/feeding.test.cjs`. No requiere dependencias de terceros ni acceso a la red.
