# Calculadora Yefferson — arquitectura modular V6

Esta versión conserva la interfaz `app/src/main/assets/index.html` sin cambios y separa responsabilidades.

## Módulos

- `MainActivity.java`: composición y puente mínimo con JavaScript.
- `ui/WebViewHost.java`: creación/configuración del WebView y solo UI de contenedor.
- `ai/AiNative.java`: frontera JNI de llama.cpp.
- `ai/AiModelManager.java`: selección, descarga, almacenamiento y estado del modelo.
- `ai/AiModule.java`: inicialización, carga y generación de respuestas.
- `data/LocalStore.java`: perfil, memoria, actividades y recordatorios persistidos localmente.
- `reminders/ReminderManager.java`: permisos, canales y alarmas.
- `cpp/native_ai.cpp`: implementación nativa de inferencia.

## Regla de mantenimiento

1. No modificar `index.html` para corregir problemas exclusivamente de IA.
2. Para errores del motor local, trabajar primero en `ai/` y `native_ai.cpp`.
3. Para memoria/agenda, trabajar en `data/` y su puente explícito.
4. Para recordatorios, trabajar en `reminders/`.
5. Antes de fusionar una corrección, comprobar que la interfaz y la calculadora no hayan cambiado.

## Congelado visual

`app/src/main/assets/index.html` es la referencia visual de esta versión. Cualquier cambio visual debe ser una tarea independiente y explícita.
