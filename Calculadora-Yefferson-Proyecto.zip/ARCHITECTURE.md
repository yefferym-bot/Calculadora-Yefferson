# Calculadora Yefferson — arquitectura modular

## Capas

- UI/WebView: `app/src/main/assets/index.html`
- IA local: `app/src/main/java/com/yefferson/calculadora/ai/`
- Biblioteca YKB: `app/src/main/java/com/yefferson/calculadora/ai/knowledge/KnowledgeManager.java`
- Datos personales: `data/LocalStore.java`
- Recordatorios: `reminders/ReminderManager.java`
- Motor nativo: `app/src/main/cpp/`

## Biblioteca incrustada

La aplicación incluye localmente `Yefferson Knowledge Book v1.2.0` dentro de `app/src/main/assets/knowledge/`.

El archivo `rag_index.json` contiene 240 registros recuperables. `KnowledgeManager` carga el índice y realiza recuperación híbrida local por tema, módulo, título, palabras clave y contenido. Los registros recuperados se añaden al contexto de Qwen3 como `[BIBLIOTECA_YKB]`.

La biblioteca está separada de la memoria personal, el historial conversacional y las herramientas de la calculadora.

## Regla de diseño

Las modificaciones futuras del conocimiento deben permanecer dentro de `ai/knowledge/` y `assets/knowledge/`, sin cambiar el diseño visual ni la lógica de la calculadora salvo que una función específica lo requiera.
