# Continuidad de TruchApp

Actualizado: 23 de octubre de 2026, zona America/Lima.

## Estado para retomar

- Aplicación: TruchApp. applicationId/namespace: `com.yefferson.calculadora`.
- Última entrega de código: **4.15.3 / versionCode 60**.
- Yefferson confirmó la instalación y los cambios de 4.15.2 el 23/10/2026.
  Esta entrega unifica el tamaño de los títulos principales de los módulos,
  ventanas y detalle del lote con la referencia «Alimentación del lote»:
  20 px, o 19 px en pantallas de hasta 360 px.
- Los tutoriales internos de Lotes y Agenda siguen retirados.
- Se conserva la presentación compacta y blanca de Alimentación de 4.15.1.
- Biometría ahora está dentro de Resumen como bloque desplegable, con el formulario
  existente y un botón propio para guardar. Mantiene un control por día.
- La segunda pestaña es Alimentación. Consulta el plan existente, lo suministrado
  hoy, la diferencia con el plan, la biomasa y el agua que lo sostienen, productos
  y lotes de alimento del almacén compartido, cobertura y registros de siete días.
- El escenario del lote proyecta desde mañana una ración constante usando primero
  los saldos que vencen antes. No reserva stock, no anticipa crecimiento ni compras
  y no equivale a la cobertura de toda la granja. Otra cifra utiliza salidas y ajustes
  negativos globales recientes del producto, con su ventana de observación visible.
- Alimentación abre el registro diario ya existente y el módulo Almacén mediante
  su navegación existente. Consultar o elegir un producto no escribe datos ni
  genera salidas. Las entregas siguen guardándose una sola vez desde el registro diario.
- Se conservan Sanidad, el icono de instalación, la bienvenida, las cuatro portadas
  blancas, Mis lotes compacto y los módulos anteriores.
- Base funcional conservada: 4.15.2 / 59; SHA-256
  `c77376d4c6453e6d898c3b91361c673d5a965c06c928eda3afe113a567f77c53`.
  Inventario: `control/base-4.15.2.json`. Describe la base antes de este ajuste,
  no el ZIP resultante. Los inventarios anteriores también se conservan.
- Validación de 4.15.3: estructura CSS y referencias al nuevo archivo verificadas.
  En los dos HTML solo se añade el enlace CSS al final de sus estilos; todos sus
  identificadores y scripts permanecen idénticos. Pasan las 9 comprobaciones
  existentes del detalle con DOM simulado. La comparación completa del ZIP exige
  que solo cambien los archivos previstos.
  En 4.15.0 también habían pasado los 16 casos de cálculo de la pestaña y los
  57 casos anteriores de alimentación, Inicio, Sanidad y almacenamiento.
- La compilación manual en GitHub y la instalación de 4.15.3 quedan pendientes
  de Yefferson. No se realizó renderizado en Android ni compilación del APK aquí.

## Mapa breve

Las rutas siguientes parten de `app/src/main/`:

| Trabajo | Archivos principales |
| --- | --- |
| Entrada y conexión de módulos | `assets/index.html` |
| Inicio | `assets/ui/dashboard/` |
| Lista de lotes | `assets/ui/lotes/lotes.js`, `lotes.css` |
| Detalle del lote | `assets/ui/lotes/detail/`, `lot-detail-data.js`, `lot-detail-host.js` |
| Sanidad | `assets/ui/lotes/health/` y `detailState.health` dentro del lote |
| Alimentación compartida | `assets/ui/feeding/` (guardado y valoración existentes) |
| Pestaña Alimentación por lote | `assets/ui/lotes/feeding/`, cargada por `assets/ui/lotes/detail/index.html` |
| Biometría en Resumen | `assets/ui/lotes/detail/index.html` y `detail.js`, sección `biometrySection` |
| Agenda, Almacén, Finanzas | `assets/ui/agenda/`, `almacen/`, `finance/` |
| Bienvenida y cuatro portadas | `assets/ui/intro/` |
| Guardado y recuperación | `assets/ui/shared/storage*`, `recovery-ui.js` y capa nativa |
| Respaldos y menú | `assets/ui/menu/` |
| Icono de instalación | `AndroidManifest.xml`, `res/mipmap-*`, `res/values/launcher_colors.xml` |

`ARCHITECTURE.md`, `ALMACENAMIENTO-4.13.md` y `CHANGE-SCOPE.md` contienen contexto
anterior. Sus números de versión históricos no sustituyen al estado actual ni al
alcance de la nueva solicitud. Verificar el código antes de dar hechos por vigentes.

## Método para cada cambio

1. Identificar la base y generar un inventario antes de editar. Guardar una copia
   de recuperación y anotar la petición, los archivos previstos y lo pendiente.
2. Buscar el módulo y leer fragmentos. Mantener recursos grandes como archivos;
   calcular hashes por bloques, sin pegarlos ni cargarlos enteros en el chat.
3. Hacer el cambio localizado sobre la base. Las muestras usan datos y claves
   separados; la autorización de integración debe existir antes de tocar el APK.
4. Ejecutar las verificaciones que correspondan. Un ajuste de texto puede requerir
   sintaxis y revisión estructural; un cambio de datos requiere probar guardado,
   recuperación, errores y compatibilidad. No inventar compilaciones exitosas.
5. Comparar todos los archivos por SHA-256 y revisar la lista de cambios permitidos.
   Volver a comprimir el contenedor ZIP no significa reescribir el código fuente:
   el control comprueba que los archivos ajenos al cambio sigan idénticos.
6. Actualizar este resumen, empaquetar y conservar la base anterior. Para el código
   alojado en GitHub, usar commits y versiones recuperables cuando corresponda;
   no hacer pushes ni iniciar compilaciones sin autorización.

## Herramienta incluida

Requiere Python 3.9 o posterior y solo su biblioteca estándar. No instala paquetes,
no usa internet ni compila Android. Procesa el contenido en bloques de 1 MiB;
la lista de rutas y hashes crece con el número de archivos del proyecto.

Inventariar un ZIP antes de trabajar:

```bash
python3 tools/continuidad.py inventario base.zip --salida inventario.json
```

Comparar dos versiones y rechazar cambios fuera del alcance (repetir `--permitir`):

```bash
python3 tools/continuidad.py comparar base.zip nuevo.zip \
  --permitir app/src/main/assets/ui/lotes/lotes.js \
  --permitir app/build.gradle
```

Empaquetar desde la base con una carpeta que contenga solo los archivos editados,
conservando sus rutas relativas:

```bash
python3 tools/continuidad.py empaquetar base.zip --cambios cambios \
  --salida Calculadora-Yefferson-Proyecto.zip \
  --permitir app/src/main/assets/ui/lotes/lotes.js \
  --permitir app/build.gradle
```

No se reemplaza la base ni una salida existente. Las eliminaciones requieren
`--eliminar ruta`; una ausencia accidental en la carpeta de cambios no elimina
archivos del proyecto. Una comparación sin `--permitir` exige contenidos idénticos.
SHA-256 detecta cambios de bytes; no acredita que una función sea correcta ni es una
firma del autor. ZIP64 permite contenedores grandes, pero siguen aplicándose los
límites de transferencia, tiempo, disco y contexto del entorno disponible.

## Registro histórico: preparación de continuidad

Alcance: reglas de trabajo, resumen, inventario de la base y herramienta de control.
En esa preparación se conservaron los 175 archivos existentes. La herramienta se validó
con pruebas que incluyen cambios ajenos al alcance, eliminaciones, entradas ZIP
duplicadas/rutas inválidas y conservación de un recurso sintético de 64 MiB.
La compilación Android y la instalación no son parte de esta preparación.

Para retomar en otra conversación, adjuntar el último ZIP y pedir: «Lee AGENTS.md y
CONTINUIDAD.md; continúa desde esta base y modifica solo [la parte solicitada]».
Estos archivos permiten recuperar contexto cuando se tiene acceso al proyecto;
no cambian la capacidad ni la memoria permanente del modelo.

## Registro histórico: Alimentación y Biometría (4.15.0)

Archivos existentes modificados: `app/build.gradle`, `assets/ui/lotes/detail/index.html`,
`assets/ui/lotes/detail/detail.js`, `assets/ui/lotes/lot-detail-host.js` (rutas de assets
bajo `app/src/main/`) y este resumen. Se añaden el módulo de consulta Alimentación,
una imagen de cabecera optimizada, sus pruebas y el inventario de la base.

La imagen decorativa se preparó con ImageGen y se empaquetó en PNG RGBA de
512 × 341 px, aproximadamente 159 KB. El contenido técnico se basa en FAO,
PRODUCE/SINACUI (2022) y FONDEPES; los enlaces y límites del cálculo se incluyen
sin conexión dentro de la pestaña. Las proyecciones de stock son cálculos del
producto, no una recomendación de ración publicada por esas instituciones.

## Registro histórico: presentación de Alimentación (4.15.1)

Solicitud: reducir los textos exagerados y aproximar la interfaz de Alimentación
a la tarjeta blanca con bordes finos de la segunda imagen enviada. No se añade
contenido ni se cambia la ración, cobertura, registro diario o almacenamiento.

Archivos existentes modificados: `app/build.gradle`, este resumen y
`app/src/main/assets/ui/lotes/feeding/feeding-panel.css` / `feeding-panel-ui.js`.
Archivo añadido: `control/base-4.15.0.json`.

La tarjeta del plan reúne ración diaria, registrado hoy y pendiente en tres
columnas con divisores finos. Conserva los estados «Sin cálculo», «Sin registro»,
cero y exceso, y las mismas acciones. Las tarjetas de stock y consulta usan
tipografía más pequeña y superficies blancas. La ilustración se conserva.

Los cambios en JavaScript solo reorganizan el marcado de esa tarjeta. Los archivos
de cálculo, guardado, navegación, Biometría, otras pestañas, portadas y recursos
de la aplicación deben quedar idénticos a la base. El alcance se comprueba por
SHA-256 al empaquetar; no se reconstruye el proyecto desde cero.

## Registro histórico: retirar tutoriales internos (4.15.2)

Solicitud: quitar los tutoriales de Lotes y Agenda. Se eliminan su contenido,
estilos, eventos, comprobaciones de «visto» y llamadas de apertura. También se
retira el acceso «Ver tutorial otra vez». La navegación continúa renderizando
Lotes y Agenda con sus funciones existentes.

Archivos existentes modificados: `app/build.gradle`, este resumen,
`app/src/main/assets/index.html`, `ui/lotes/lotes.js`, `ui/lotes/lotes.css`,
`ui/agenda/agenda.js` y `ui/agenda/agenda.css` (rutas ui bajo assets).
Archivo añadido: `control/base-4.15.1.json`.

No se modifican los datos ni las claves de almacenamiento compartido. Las marcas
antiguas de tutorial visto quedan sin uso; no se borra ni se reinicia información.
La bienvenida, las cuatro portadas y el bloque Alimentación se conservan idénticos
a la base, al igual que los demás archivos fuera del alcance. No se compila ni se
instala Android en este entorno; Yefferson lo hará con su flujo de GitHub.

## Cambio actual: tamaño de títulos (4.15.3)

Solicitud: usar en los títulos el tamaño de «Alimentación del lote» de la captura
aprobada. Se añade `app/src/main/assets/ui/theme/title-sizes.css`, con una medida
compartida de 20 px y 19 px hasta 360 px. Se carga tanto en la página principal
como en el documento independiente del detalle del lote.

La regla se limita a cabeceras principales de Inicio, Lotes, Agenda, Almacén y
Finanzas; títulos de ventanas y paneles; nombre del lote y cabeceras principales
de sus secciones. Conserva las fuentes, pesos, colores y espacios existentes.
Los subtítulos pequeños de tarjetas y cifras no se amplían. La marca TruchApp,
la bienvenida y las portadas iniciales conservan sus tamaños aprobados.

Archivos existentes modificados: `app/build.gradle`, este resumen,
`app/src/main/assets/index.html` y `app/src/main/assets/ui/lotes/detail/index.html`.
Archivos añadidos: `app/src/main/assets/ui/theme/title-sizes.css` e inventario
`control/base-4.15.2.json`. No se modifica ningún JavaScript ni almacenamiento.

Las comprobaciones locales no sustituyen la revisión visual en el teléfono. La
compilación e instalación de esta versión quedan pendientes del flujo de GitHub.
