# Continuidad de TruchApp

Actualizado: 23 de octubre de 2026, zona America/Lima.

## Estado para retomar

- Aplicación: TruchApp. applicationId/namespace: `com.yefferson.calculadora`.
- Última entrega de código: **4.15.0 / versionCode 57**.
- Biometría ahora está dentro de Resumen como bloque desplegable, con el formulario
  existente y un botón propio para guardar. Mantiene un control por día.
- La segunda pestaña es Alimentación. Consulta el plan existente, lo suministrado
  hoy, la diferencia con el plan, la biomasa y el agua que lo sostienen, productos
  y lotes de alimento del almacén compartido, cobertura y registros de siete días.
- El escenario del lote proyecta desde mañana una ración constante usando primero
  los saldos que vencen antes. No reserva stock, no anticipa crecimiento ni compras
  y no equivale a la cobertura de toda la granja. Otra cifra utiliza salidas y ajustes
  negativos globales recientes del producto, con su ventana de observación visible.
- Alimentación abre el registro diario ya existente y el módulo Almacén mediante
  su navegación existente. Consultar o elegir un producto no escribe datos ni
  genera salidas. Las entregas siguen guardándose una sola vez desde el registro diario.
- Se conservan Sanidad, el icono de instalación, la bienvenida, las cuatro portadas
  blancas, Mis lotes compacto y los módulos anteriores.
- Base recibida: 4.14.2 con controles de continuidad; SHA-256
  `0981514f3a3cfb60a5ffbd7323bcf8e91019c65d201dd064b5455ab39f4d5faf`.
  Inventario: `control/base-4.14.2-continuidad.json`. Describe la base antes de este
  cambio, no el ZIP resultante. El inventario anterior también se conserva.
- Validación: 16 casos nuevos de cálculo de Alimentación y 9 comprobaciones de
  integración de eventos con DOM simulado; además pasan los 57 casos anteriores de
  alimentación, Inicio, Sanidad y almacenamiento. No se realizó renderizado visual
  en un navegador Android ni compilación/instalación del APK en este entorno.
- La instalación de 4.15.0 queda pendiente de la compilación manual en GitHub y la
  comprobación de Yefferson en su celular. No afirmar que ya se probó allí.

## Mapa breve

Las rutas siguientes parten de `app/src/main/`:

| Trabajo | Archivos principales |
| --- | --- |
| Entrada y conexión de módulos | `assets/index.html` |
| Inicio | `assets/ui/dashboard/` |
| Lista de lotes | `assets/ui/lotes/lotes.js`, `lotes.css` |
| Detalle del lote | `assets/ui/lotes/detail/`, `lot-detail-data.js`, `lot-detail-host.js` |
| Sanidad | `assets/ui/lotes/health/` y `detailState.health` dentro del lote |
| Alimentación compartida | `assets/ui/feeding/` (guardado y valoración existentes) |
| Pestaña Alimentación por lote | `assets/ui/lotes/feeding/`, cargada por `assets/ui/lotes/detail/index.html` |
| Biometría en Resumen | `assets/ui/lotes/detail/index.html` y `detail.js`, sección `biometrySection` |
| Agenda, Almacén, Finanzas | `assets/ui/agenda/`, `almacen/`, `finance/` |
| Bienvenida y cuatro portadas | `assets/ui/intro/` |
| Guardado y recuperación | `assets/ui/shared/storage*`, `recovery-ui.js` y capa nativa |
| Respaldos y menú | `assets/ui/menu/` |
| Icono de instalación | `AndroidManifest.xml`, `res/mipmap-*`, `res/values/launcher_colors.xml` |

`ARCHITECTURE.md`, `ALMACENAMIENTO-4.13.md` y `CHANGE-SCOPE.md` contienen contexto
anterior. Sus números de versión históricos no sustituyen al estado actual ni al
alcance de la nueva solicitud. Verificar el código antes de dar hechos por vigentes.

## Método para cada cambio

1. Identificar la base y generar un inventario antes de editar. Guardar una copia
   de recuperación y anotar la petición, los archivos previstos y lo pendiente.
2. Buscar el módulo y leer fragmentos. Mantener recursos grandes como archivos;
   calcular hashes por bloques, sin pegarlos ni cargarlos enteros en el chat.
3. Hacer el cambio localizado sobre la base. Las muestras usan datos y claves
   separados; la autorización de integración debe existir antes de tocar el APK.
4. Ejecutar las verificaciones que correspondan. Un ajuste de texto puede requerir
   sintaxis y revisión estructural; un cambio de datos requiere probar guardado,
   recuperación, errores y compatibilidad. No inventar compilaciones exitosas.
5. Comparar todos los archivos por SHA-256 y revisar la lista de cambios permitidos.
   Volver a comprimir el contenedor ZIP no significa reescribir el código fuente:
   el control comprueba que los archivos ajenos al cambio sigan idénticos.
6. Actualizar este resumen, empaquetar y conservar la base anterior. Para el código
   alojado en GitHub, usar commits y versiones recuperables cuando corresponda;
   no hacer pushes ni iniciar compilaciones sin autorización.

## Herramienta incluida

Requiere Python 3.9 o posterior y solo su biblioteca estándar. No instala paquetes,
no usa internet ni compila Android. Procesa el contenido en bloques de 1 MiB;
la lista de rutas y hashes crece con el número de archivos del proyecto.

Inventariar un ZIP antes de trabajar:

```bash
python3 tools/continuidad.py inventario base.zip --salida inventario.json
```

Comparar dos versiones y rechazar cambios fuera del alcance (repetir `--permitir`):

```bash
python3 tools/continuidad.py comparar base.zip nuevo.zip \
  --permitir app/src/main/assets/ui/lotes/lotes.js \
  --permitir app/build.gradle
```

Empaquetar desde la base con una carpeta que contenga solo los archivos editados,
conservando sus rutas relativas:

```bash
python3 tools/continuidad.py empaquetar base.zip --cambios cambios \
  --salida Calculadora-Yefferson-Proyecto.zip \
  --permitir app/src/main/assets/ui/lotes/lotes.js \
  --permitir app/build.gradle
```

No se reemplaza la base ni una salida existente. Las eliminaciones requieren
`--eliminar ruta`; una ausencia accidental en la carpeta de cambios no elimina
archivos del proyecto. Una comparación sin `--permitir` exige contenidos idénticos.
SHA-256 detecta cambios de bytes; no acredita que una función sea correcta ni es una
firma del autor. ZIP64 permite contenedores grandes, pero siguen aplicándose los
límites de transferencia, tiempo, disco y contexto del entorno disponible.

## Registro histórico: preparación de continuidad

Alcance: reglas de trabajo, resumen, inventario de la base y herramienta de control.
En esa preparación se conservaron los 175 archivos existentes. La herramienta se validó
con pruebas que incluyen cambios ajenos al alcance, eliminaciones, entradas ZIP
duplicadas/rutas inválidas y conservación de un recurso sintético de 64 MiB.
La compilación Android y la instalación no son parte de esta preparación.

Para retomar en otra conversación, adjuntar el último ZIP y pedir: «Lee AGENTS.md y
CONTINUIDAD.md; continúa desde esta base y modifica solo [la parte solicitada]».
Estos archivos permiten recuperar contexto cuando se tiene acceso al proyecto;
no cambian la capacidad ni la memoria permanente del modelo.

## Cambio actual: Alimentación y Biometría (4.15.0)

Archivos existentes modificados: `app/build.gradle`, `assets/ui/lotes/detail/index.html`,
`assets/ui/lotes/detail/detail.js`, `assets/ui/lotes/lot-detail-host.js` (rutas de assets
bajo `app/src/main/`) y este resumen. Se añaden el módulo de consulta Alimentación,
una imagen de cabecera optimizada, sus pruebas y el inventario de la base.

La imagen decorativa se preparó con ImageGen y se empaquetó en PNG RGBA de
512 × 341 px, aproximadamente 159 KB. El contenido técnico se basa en FAO,
PRODUCE/SINACUI (2022) y FONDEPES; los enlaces y límites del cálculo se incluyen
sin conexión dentro de la pestaña. Las proyecciones de stock son cálculos del
producto, no una recomendación de ración publicada por esas instituciones.
