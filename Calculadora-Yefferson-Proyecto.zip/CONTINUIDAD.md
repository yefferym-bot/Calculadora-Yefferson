# Continuidad de TruchApp

Actualizado: 3 de noviembre de 2026, zona America/Lima.

## Cambio vigente: integrar la muestra de Lotes aprobada (4.16.7 / 68)

Yefferson aprobó la muestra v6 y pidió incorporarla al ZIP de Android. Se parte
de la entrega funcional 4.16.6 / 67, SHA-256
`a96fe00174aede582e35772ac349321a72df191fdfd6e04b24bb67a79f3193fc`.
La base se conserva; su inventario completo queda en `control/base-4.16.6.json`.
Muestra aprobada: TruchApp-Lotes-Muestra-v6.html, SHA-256
`f4e3ef6a7292f5e1e5408d35d1bcdd86a9259fb41c02e778bb38cd62d66f8393`.

En Lotes se retira «Qué conviene registrar» con sus referencias técnicas y se
elimina el fondo, borde, sombra y relleno exterior de «Mis lotes». El buscador
y cada tarjeta conservan sus propios estilos. «＋ Crear nuevo lote» pasa a la
derecha del buscador en una fila adaptable, con su mismo ID, evento y formulario.

En el detalle, la barra Resumen/Alimentación/Agua/Sanidad mide 58 px, con botones
de 48 px e iconos de 18 px. Se mantienen etiquetas, colores, selección y eventos.
El desplegable Biometría se retira del resumen; su mismo formulario se conserva
en un diálogo abierto desde las tarjetas y Alimentación. Reutiliza la apertura,
cierre, bloqueo durante guardado y notificación al menú flotante existentes.
Guardar una biometría cierra ese diálogo y devuelve el resumen. No cambian las
reglas de un control por día, los cálculos ni el guardado de alimento/bajas.

Archivos de aplicación modificados: app/build.gradle,
app/src/main/assets/ui/lotes/lotes.js, lotes.css,
app/src/main/assets/ui/lotes/detail/index.html, detail.js y header-tabs.css.
Se adapta tests/lot-detail-feeding-ui.test.cjs para reconocer los diálogos por
su marcado y comprobar el cierre/aviso del formulario biométrico. También se
actualiza este documento y se añade el inventario de la base. No se reconstruyen
módulos ni se incorpora código de muestra, datos temporales, Reiniciar, Map,
srcdoc, imágenes generadas ni herramientas del editor al proyecto Android.

Verificado: sintaxis de los dos JavaScript modificados; 15 comprobaciones de
integración del detalle y 17 de navegación/guardado con DOM simulado, incluidas
biometría persistida, cierre del formulario, un control por día, cero confirmado,
vista reutilizada y protección de sesión. Revisión de los archivos integrados
en Chrome a 390×844 y 320×700: buscador y botón juntos, sin contenedor exterior,
sin nota informativa, cuatro pestañas completas y funcionales, doce tarjetas,
sin desplegable Biometría en resumen, costo después de las tarjetas, apertura
y cierre del diálogo biométrico con ocultación/restauración del menú flotante,
sin desbordamiento horizontal. La comprobación visual usa datos aislados fuera
del APK. Se validan IDs, recursos locales, integridad, versión y alcance del ZIP.

El resto de archivos se conserva por SHA-256: identidad
com.yefferson.calculadora, firma, Room/SQLite, respaldo, almacenamiento, stock,
servicios nativos, portadas y otros módulos. Se entrega únicamente el ZIP fuente;
compilación y firma en GitHub e instalación en el teléfono quedan pendientes de
Yefferson. No se ejecutan Actions ni se modifica su repositorio.

## Cambio anterior conservado: menú flotante elevado y más visible (4.16.6 / 67)

Yefferson confirmó el cambio anterior y mostró que el botón quedaba demasiado
abajo en su Android, cubriendo parte del nombre del lote y del texto de Almacén.
Pidió subirlo y destacar su forma/color. Base conservada: 4.16.5 / 66,
SHA-256 `39524deec6f53d45a2243352c6b3f1bc31915e989a6e5d9d476598d5ea7dceef`;
inventario en `control/base-4.16.5.json`.

El botón se ancla a 6 px del borde superior del área de la app. Se retira
max(8px, env(safe-area-inset-top)) de su posición: WebViewHost ya aplica el
espacio de la barra de estado mediante el contenedor nativo. La separación
adicional en la captura es compatible con volver a sumar esa área. No se
modifica el manejo nativo de las barras del sistema ni el menú inferior.

Se conserva el tamaño de 39×39 px y la ubicación horizontal aprobada. El botón
pasa a ser circular, con degradado turquesa claro #b0f3e6 → #60d8cb, borde menta,
sombra suave y el mismo SVG en petróleo #103f46, ahora con trazo 2.1. El foco de
teclado tiene un contorno sólido. La cabecera continúa fuera del flujo y no
vuelve la franja blanca. Los espacios laterales de las cabeceras no cambian.

Archivos modificados: app/build.gradle, CONTINUIDAD.md y
app/src/main/assets/ui/menu/floating-menu.css. Nuevo: control/base-4.16.5.json.
Todos los HTML, JavaScript, funciones de menú/formularios, portadas, datos,
cálculos, stock, Room/SQLite, código nativo, firma e identidad Android se
conservan idénticos a la base por SHA-256. No se reconstruyen módulos.

Verificado en Chrome a 390×844 y 320×700: botón en y=6, tamaño 39×39, forma
circular, colores y trazo correctos. El nombre del lote empieza en y=48; el
botón termina en y=45. La etapa conserva espacio a su derecha. En Almacén, los
títulos y la descripción quedan libres y no hay desbordamiento horizontal.
El botón abre/cierra el menú lateral existente. Contraste mínimo calculado del
icono sobre los extremos del degradado: 6.69:1 (extremo claro 9.23:1).
Se verifica estructura CSS, versión, alcance e integridad del ZIP. No se añaden
ni repiten pruebas de datos para este cambio exclusivamente visual; sus scripts
y las pruebas anteriores permanecen intactos. La revisión de navegador no
reproduce los insets de un Android real: compilación en GitHub, instalación y
comprobación final en el teléfono quedan pendientes de Yefferson.

ImageGen se utilizó para una referencia visual del acabado. La imagen no se
incorpora al APK ni sustituye los controles reales de la aplicación.

## Cambio anterior conservado: acceso de menú flotante sin franja superior (4.16.5 / 66)

Yefferson pidió desaparecer la franja blanca del encabezado principal y dejar
solo el botón izquierdo como acceso flotante. Se continúa desde 4.16.4 / 65,
SHA-256 `933ca72ce6aee420667ab2c7df394ec50d22a40349cbc2dffd68ce7dfbe82181`;
base conservada e inventario en `control/base-4.16.4.json`.

El encabezado queda fuera del flujo, transparente y limitado a los 39×39 px del
botón, colocado arriba a la izquierda con una sombra suave. Conserva el mismo
#tnMenuOpen, SVG, etiquetas, estado expandido y eventos del menú existente. No
se crea un segundo botón. Su antigua fila de aproximadamente 52 px se devuelve
al contenido; el menú inferior petróleo/turquesa no cambia. El #status oculto
sigue presente para la compatibilidad de los scripts anteriores.

Se reserva solo el espacio lateral necesario en la primera línea de Inicio,
Lotes, Almacén, Agenda, Finanzas y los accesos conservados de Calculadora/IA.
En detalle la cápsula de etapa queda a la derecha del botón, manteniendo los
botones de información y retorno a la derecha. No cambian los tamaños aprobados
del nombre, tarjetas, pestañas ni el fondo de la cabecera del lote. Al envolver,
la fecha de Agenda sigue legible en pantallas de 320 px.

Los diálogos internos del iframe notifican únicamente si hay un formulario
abierto. El host oculta el acceso flotante mientras ese diálogo está abierto y
lo recupera al cerrarlo o salir del lote, para que no cubra sus títulos/campos.
El mensaje usa la fuente y sesión verificadas ya existentes; los mensajes de
una sesión anterior se ignoran. Se mantienen los bloqueos del guardado y los
registros/validaciones anteriores. Esta notificación no escribe datos.

Archivos modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html (solo enlace CSS),
app/src/main/assets/ui/lotes/detail/header-tabs.css y detail.js,
app/src/main/assets/ui/lotes/lot-detail-host.js,
tests/lot-detail-page.test.cjs y tests/lot-detail-feeding-ui.test.cjs.
Nuevos: app/src/main/assets/ui/menu/floating-menu.css y control/base-4.16.4.json.
No se modifican cálculos, stock, esquemas, módulos productivos, Room/SQLite,
firma, applicationId, portadas ni los archivos del menú inferior.

Verificado: sintaxis de ambos JavaScript modificados; las 14 comprobaciones
existentes del detalle y 17 del host con DOM simulado, incluyendo comunicación
de apertura/cierre, sesión antigua ignorada y recuperación del acceso al salir.
En Chrome a 390×844 y 320×700 la cabecera ocupa solo el área transparente del
botón, el contenido empieza en y=0, no existe una franja adicional y la cápsula
de etapa no se superpone. El menú abre/cierra, los formularios de Alimentación
y Sanidad abren y el acceso flotante se oculta/restaura correctamente.
Revisadas las cinco cabeceras reales en ambos tamaños sin desbordamiento.
Se verifican IDs, scripts inline, recursos locales, integridad y alcance del ZIP.

ImageGen se utilizó para una referencia visual. La imagen no se incluye en el
APK: la aplicación conserva controles reales. La compilación e instalación en
Android quedan pendientes del flujo de GitHub y del teléfono de Yefferson.

## Cambio anterior conservado: detalle más compacto sin barra de registro (4.16.4 / 65)

Yefferson confirmó el diseño de la cabecera y pidió retirar el bloque inferior de
«+ Registrar día», reducir los espacios entre la etapa, el nombre y los datos de
ingreso, y ampliar un poco el nombre del lote. Base conservada: 4.16.3 / 64,
SHA-256 `21995535ab56f61e802e7f3f9c16d1c3c8e371aa5e5b61252c310dfc0ea7d673`;
inventario en `control/base-4.16.3.json`.

Se elimina el footer completo del detalle, su botón #mainAction, sus estilos y
sus referencias de actualización/evento. El espacio se devuelve al contenido
con desplazamiento. Las notificaciones de guardado quedan a 12 px del borde
inferior del detalle, al no existir la barra que antes ocupaba ese espacio.
No se elimina el registro diario: siguen sus accesos en Alimentación, las
ventanas de las tarjetas y «Registrar bajas» en Sanidad. Agua conserva el
registro desde cada tarjeta y Sanidad su botón propio. Los formularios, sus
validaciones y el guardado compartido no cambian.

La cabecera reduce el margen entre nombre y metadatos de 24 a 8 px, además de
compactar sus separaciones exteriores y retirar la altura mínima del bloque de
identidad. El nombre pasa de 20 a 24 px (de 19 a 23 px hasta 359 px de ancho).
Esta excepción solicitada se limita al nombre del lote; los demás títulos
conservan el tamaño aprobado. Se reserva espacio al SVG de la trucha para que
los metadatos puedan envolver sin quedar debajo de la ilustración. Se mantienen
la paleta, la etapa, las cuatro pestañas, los iconos y las acciones superiores.
La cabecera principal y el menú inferior siguen accesibles y con su diseño previo.

Archivos modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/ui/lotes/detail/index.html, detail.js y header-tabs.css;
tests/lot-detail-feeding-ui.test.cjs adapta su comprobación al botón existente
dentro de Alimentación. Nuevo: control/base-4.16.3.json. En detail.js solo se
retiran la función, la llamada y el evento del botón eliminado. Los scripts
inline, todas las pestañas y sus SVG, los otros 12 indicadores y los archivos de
cálculo, almacenamiento, host de página, Room/SQLite y firma quedan intactos.

Verificado: sintaxis de detail.js; 14 comprobaciones existentes del detalle con
DOM simulado (incluye registro diario y cero confirmado desde Alimentación),
y 14 del host de página. En Chrome a 390×844 y 320×700 no existe el footer ni su
botón, el nombre calcula 24/23 px, los metadatos conservan su margen de 8 px y
no hay desbordamiento horizontal. Las cuatro pestañas cambian de panel y los
formularios de alimentación y sanidad abren desde sus accesos conservados.
Se revisan recursos, IDs, diferencias e integridad del ZIP antes de entregarlo.
No se compila ni instala Android aquí: queda pendiente el flujo de GitHub y la
comprobación final en el teléfono de Yefferson.

## Cambio anterior conservado: cabecera y pestañas del lote (4.16.3 / 64)

Yefferson pidió aplicar al detalle el estilo de su primera referencia, especialmente
los botones destacados. Su segunda captura muestra el detalle ya integrado como
página, con la cabecera y el menú inferior aprobados. Se continúa sobre 4.16.2 / 63,
SHA-256 `da02f56e54c68a36d7f004566b649d4951b0d876f41325837ecf2facf7886723`;
inventario conservado en `control/base-4.16.2.json`.

El cambio es de presentación: cabecera con degradado verde petróleo y borde
inferior redondeado, etapa en una cápsula superior, acciones de información y
retorno claras sobre superficies translúcidas, y nombre/metadatos en blanco.
Se mantiene el tamaño moderado aprobado del nombre y los datos reales del lote.
El SVG animado existente de la trucha se conserva. No se añaden días, fechas o
valores ficticios de las imágenes.

Las cuatro pestañas se presentan sobre una barra blanca con sombra suave,
iconos encima de las etiquetas y una tarjeta verde petróleo para la selección.
Se conservan Resumen, Alimentación, Agua y Sanidad, todos los identificadores,
roles, acciones y la flecha de volver. El #stage solo cambia de lugar dentro de
la cabecera. Una regla nueva asegura que el icono de Alimentación no se oculte
en pantallas estrechas; las etiquetas completas caben a 320 px.

ImageGen se usó para una referencia visual. El APK utiliza estilos y controles
reales; no incluye la imagen generada ni sustituye la interfaz por una captura.
La navegación de página entre cabecera y menú inferior permanece en su host
anterior. No se modifican formularios, indicadores, cálculos, registros, inventario,
Room/SQLite, firma, applicationId, portadas ni otros módulos.

Archivos cambiados: app/build.gradle, CONTINUIDAD.md y
app/src/main/assets/ui/lotes/detail/index.html. Archivos nuevos:
app/src/main/assets/ui/lotes/detail/header-tabs.css y control/base-4.16.2.json.
Todos los JavaScript permanecen idénticos a la base. El marcado y SVG de la
navegación de pestañas también permanecen idénticos; cambia su presentación.

Verificado: 14 comprobaciones existentes del detalle y 14 del host con DOM
simulado; mismos IDs sin duplicados, mismos scripts inline, referencias locales
válidas, CSS con delimitadores válidos y alcance del ZIP controlado por SHA-256.
En Chrome con datos de prueba aislados, las cuatro pestañas cambian de panel y
la seleccionada muestra fondo oscuro/texto blanco. Revisadas a 390×844 y 320×700:
cuatro iconos visibles, etiquetas completas y sin desbordamiento horizontal.
Contraste calculado: selección 11.55:1, etiquetas inactivas 5.02:1 y metadatos
sobre el extremo más claro del degradado 4.75:1. No se añaden pruebas para este
ajuste reversible; se usan las existentes y la revisión visual de los controles.
La imagen generada es una propuesta, no prueba de ejecución. La compilación e
instalación Android y revisión final en el teléfono quedan pendientes de GitHub.

## Cambio anterior conservado: detalle del lote como página (4.16.2 / 63)

Yefferson confirmó que le gustó la navegación inferior de 4.16.1. Pidió que
«Ver / actualizar lote» abra una página que ocupe el área útil de la aplicación,
sin cubrir el encabezado ni el menú inferior. La base conservada es 4.16.1 / 62,
SHA-256 `9dd44a40b12469c44e0bcd940d2cd94e18c5bf3575d292c8f9be677d162653cc`;
su inventario está en `control/base-4.16.1.json`.

El host ahora monta la vista reutilizable dentro de #lotes, junto a #lotesRoot.
La lista se oculta solo mientras se ve la página. Se retiran la capa fija de
pantalla completa, el fondo oscurecido, el margen exterior y el marco redondeado.
La cabecera del lote, sus pestañas, sus doce tarjetas y el botón de registrar
conservan sus diseños; el botón inferior del detalle queda antes de la barra
principal. Un enlace de retorno con flecha conserva #closeDetail y vuelve a la
lista con su posición de desplazamiento y foco. La página tiene rol de región;
los formularios y ventanas internas conservan su semántica de diálogo.

El contenedor usa el espacio restante bajo la cabecera y reserva la altura real
del menú inferior, observada con ResizeObserver y actualizada al redimensionar.
Se conservan colores y SVG de ambos menús. La barra y el encabezado siguen
accesibles. Cambiar de módulo cierra la página mediante la navegación existente.
Esc del menú lateral lo cierra sin cerrar también la página. El foco de la página
ya no queda encerrado como si fuera una ventana modal.

Durante una escritura se bloquean temporalmente los accesos de cabecera/barra y
la salida; se restauran con la confirmación o el fallo. Se mantienen el token de
sesión, la revisión, el guardado único, la carga con reintento, los datos nuevos
por lote y el enlace a Almacén. No cambian cálculos, raciones, inventario, Room,
firma, applicationId ni otras funciones. Inicio y Finanzas ya navegan a Lotes
antes de abrir una ficha; esos accesos siguen usando el mismo host.

Archivos cambiados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/ui/lotes/lot-detail-host.js y lot-detail-host.css,
ui/lotes/detail/index.html y detail.js (rutas ui bajo assets). En detail.js solo
cambia la condición del bloqueo de Tab para reservarlo a paneles modales.
Archivos nuevos: ui/lotes/detail/page-layout.css, tests/lot-detail-page.test.cjs,
y control/base-4.16.1.json. El index.html principal, ambos menús y los archivos de
cálculo/almacenamiento se mantienen idénticos a la base por SHA-256.

Verificado: 14 comprobaciones del host con DOM simulado (montaje, sesión nueva,
altura del menú, scroll/foco, cambio de módulo, guardado único, salida bloqueada,
fallos recuperables y respuestas antiguas ignoradas); 14 comprobaciones existentes
del detalle (pestañas, formularios y ceros); 9 casos de almacenamiento existentes.
Sintaxis JS e integridad, recursos locales, IDs y comparación acotada del ZIP.

Prueba visual local con Chrome: página sin marco, cambio a Almacén, abrir/cerrar
menú lateral, Esc y regreso a lista. En viewports anidados 390×844 y 320×700 la
página empieza en y=52 y termina respectivamente en y=767.5 / 623.5, justo antes
del menú. No hay desbordamiento horizontal. Se usó una página de prueba local
con datos ficticios aislados; no se incluye en el ZIP ni cambia datos del usuario.
Esto no equivale a una instalación ni renderizado en un Android real. Compilación,
instalación y comprobación final en el teléfono quedan pendientes de GitHub.

## Cambio anterior conservado: encabezado y navegación (4.16.1 / 62)

Yefferson confirmó la incorporación correcta de 4.16.0 y pidió trabajar directamente
en el ZIP: quitar TruchApp, Gestión acuícola y el aviso del modelo de la cabecera;
conservar el botón izquierdo; dar mayor presencia a la barra inferior.

Base funcional: 4.16.0 / 61, SHA-256
`71efc6c154e30d26f383a819417d87cf6c58149bee4d609744f7690d40d3f41a`.
Inventario: `control/base-4.16.0.json`. Se conserva la base sin sobrescribirla.

La cabecera ya no tiene el nombre/subtítulo ni la pastilla visible de modelo.
Conserva íntegro el botón y su acceso al menú lateral, con altura más compacta.
El elemento #status queda oculto para mantener compatible updateStatus(), sin
cambiar descargas, estado nativo ni los scripts existentes.

La navegación inferior usa un fondo azul petróleo (#1b545b, #123e46, #0e343d),
iconos/texto claros (#d8eee9) y la selección turquesa (#aae9df, #71cdc2), con
texto/icono oscuro (#103a3f). Conserva cinco destinos, SVG, etiquetas, selección
activa, aria-current, foco de teclado y preferencia de movimiento reducido.
Se mantiene el espacio inferior reservado para no tapar el contenido.

ImageGen se utilizó solo para una referencia visual de la paleta. El APK usa
HTML/CSS y los SVG previos, no una imagen plana ni un nuevo recurso raster.

Archivos cambiados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html y ui/menu/side-menu.css / bottom-nav.css (ui bajo
assets). Archivo añadido: control/base-4.16.0.json. Ningún JavaScript cambia.
Todos los archivos del detalle de lote aprobado, cálculos, guardado, base Room,
firma, identidad Android, portadas y restantes módulos se conservan por SHA-256.

Validación: scripts inline idénticos, botón y navegación inferior idénticos,
IDs DOM preservados, 39 referencias locales existentes, CSS con delimitadores
válidos y colores de etiquetas con contraste mínimo calculado de 7.03:1 en
inactivos y 6.60:1 en activo. Comparación del ZIP exige solamente el alcance citado.
No se escriben pruebas nuevas para este ajuste visual reversible. No se repite
la batería de datos al conservar íntegros sus scripts. La imagen es una propuesta,
no una captura del APK ejecutándose. La compilación, revisión visual e instalación
Android quedan pendientes de Yefferson mediante GitHub.

## Integración anterior conservada: detalle aprobado (4.16.0)

Yefferson aprobó integrar la muestra v15 con su proyecto JSON del 28/10/2026.
La base es el ZIP 4.15.3 / 60, SHA-256
`d89669e165dfbd56322c380d19301f56dd053752913a95eba70fb25fe2f66fcb`;
se conserva fuera de esta entrega como recuperación y se inventaría en
`control/base-4.15.3.json`. El diseño recibido está en
`control/approved-detail-design.json`; es referencia visual, no datos productivos.

- Cabecera compacta, ilustración existente y radio de 11 px aprobados.
- Situación actual: Peces vivos, Alimento total consumido, Alimentación para hoy.
  Mortalidad/descarte y última fecha proceden de registros reales; no del ejemplo.
  Alimentación para hoy muestra la ración del plan y lo registrado se indica debajo.
- Biometría: Peso promedio (g), Talla promedio (cm), Biomasa. Cada fecha corresponde
  a su medición; una talla antigua no se mezcla con un peso nuevo para calcular K.
- Indicadores: K estimado con promedios del mismo control, TCE/SGR del período,
  CV muestral (n−1), FCR aparente existente, TEA aparente y densidad de carga.
  Los doce indicadores abren sus datos o la ventana previa correspondiente.
- K = 100 W/L³ (g, cm); TCE = 100(ln Wf−ln Wi)/días; CV = SD/promedio×100;
  TEA = ganancia neta de biomasa/alimento×100; densidad = biomasa/volumen.
  Se conservan valores cero, crecimiento negativo y TEA mayor de 100 cuando
  corresponde. Faltantes, un solo peso, fechas iguales, volumen cero o alimento
  cero no generan divisiones inválidas. TEA requiere la cobertura completa y
  ganancia positiva del FCR existente; no corrige biomasa perdida por bajas.
- Las ventanas muestran fórmulas, período/origen y datos necesarios, con fuentes
  primarias DOI 10.3390/ani14172567 (trucha, K/SGR) y 10.47853/FAS.2025.e2
  (definiciones de CV/eficiencia). No se añaden umbrales sanitarios o raciones.
- Se retira el texto inferior marcado del costo de alimentación solo en detalle
  mediante una opción compacta; las llamadas compartidas conservan su presentación.
- No se incluyen el editor, el puente de demostración ni valores ficticios en los
  assets. No cambian Room/SQLite, firma, applicationId, esquema detailState v2,
  guardado compartido ni los archivos de otros módulos. Consultar no crea salidas.

Archivos existentes cambiados: app/build.gradle, este resumen,
app/src/main/assets/ui/lotes/detail/index.html y detail.js,
app/src/main/assets/ui/feeding/feeding-ui.js (opción compacta, valor por defecto
conservado), tests/lot-detail-feeding-ui.test.cjs (carga del nuevo script y casos).
Nuevos: summary-indicators.js y approved-summary.css junto a detail.js,
tests/lot-summary-indicators.test.cjs y los dos archivos de control citados.

Verificado: 83 casos de lógica (73 previos y 10 de indicadores), más 14
comprobaciones de integración con DOM simulado: apertura, orden y 12 tarjetas,
ventanas propias, consultas sin escritura, sin datos ficticios, costo compacto,
guardado de biometría, un control por día, alimentación cero, reutilización por
lote y enlace a Almacén. Sintaxis JS, recursos referenciados, IDs y alcance por
SHA-256 se comprueban antes de empaquetar. El ensayo de interfaz
storage-ui.test.cjs no pudo iniciar: falta su ejecutable Chromium en este entorno.
Sus fuentes de producción no cambian. No se instaló otro navegador para el ensayo.
No se dispone de SDK Android configurado; compilación/instalación y revisión visual
real en el teléfono quedan pendientes de Yefferson mediante su flujo de GitHub.

## Estado conservado de módulos anteriores

- Aplicación: TruchApp. applicationId/namespace: `com.yefferson.calculadora`.
- Última entrega de código: **4.16.6 / versionCode 67**.
- Yefferson confirmó la instalación y los cambios de 4.15.2 el 23/10/2026.
  La versión 4.15.3 unificó el tamaño de los títulos principales de los módulos,
  ventanas y detalle del lote con la referencia «Alimentación del lote»:
  20 px, o 19 px en pantallas de hasta 360 px.
- Los tutoriales internos de Lotes y Agenda siguen retirados.
- Se conserva la presentación compacta y blanca de Alimentación de 4.15.1.
- Biometría ahora está dentro de Resumen como bloque desplegable, con el formulario
  existente y un botón propio para guardar. Mantiene un control por día.
- La segunda pestaña es Alimentación. Consulta el plan existente, lo suministrado
  hoy, la diferencia con el plan, la biomasa y el agua que lo sostienen, productos
  y lotes de alimento del almacén compartido, cobertura y registros de siete días.
- El escenario del lote proyecta desde mañana una ración constante usando primero
  los saldos que vencen antes. No reserva stock, no anticipa crecimiento ni compras
  y no equivale a la cobertura de toda la granja. Otra cifra utiliza salidas y ajustes
  negativos globales recientes del producto, con su ventana de observación visible.
- Alimentación abre el registro diario ya existente y el módulo Almacén mediante
  su navegación existente. Consultar o elegir un producto no escribe datos ni
  genera salidas. Las entregas siguen guardándose una sola vez desde el registro diario.
- Se conservan Sanidad, el icono de instalación, la bienvenida, las cuatro portadas
  blancas, Mis lotes compacto y los módulos anteriores.
- Base funcional conservada: 4.15.2 / 59; SHA-256
  `c77376d4c6453e6d898c3b91361c673d5a965c06c928eda3afe113a567f77c53`.
  Inventario: `control/base-4.15.2.json`. Describe la base antes de este ajuste,
  no el ZIP resultante. Los inventarios anteriores también se conservan.
- Validación de 4.15.3: estructura CSS y referencias al nuevo archivo verificadas.
  En los dos HTML solo se añade el enlace CSS al final de sus estilos; todos sus
  identificadores y scripts permanecen idénticos. Pasan las 9 comprobaciones
  existentes del detalle con DOM simulado. La comparación completa del ZIP exige
  que solo cambien los archivos previstos.
  En 4.15.0 también habían pasado los 16 casos de cálculo de la pestaña y los
  57 casos anteriores de alimentación, Inicio, Sanidad y almacenamiento.
- La compilación manual en GitHub y la instalación de 4.15.3 quedan pendientes
  de Yefferson. No se realizó renderizado en Android ni compilación del APK aquí.

## Mapa breve

Las rutas siguientes parten de `app/src/main/`:

| Trabajo | Archivos principales |
| --- | --- |
| Entrada y conexión de módulos | `assets/index.html` |
| Inicio | `assets/ui/dashboard/` |
| Lista de lotes | `assets/ui/lotes/lotes.js`, `lotes.css` |
| Detalle del lote | `assets/ui/lotes/detail/`, `lot-detail-data.js`, `lot-detail-host.js` |
| Sanidad | `assets/ui/lotes/health/` y `detailState.health` dentro del lote |
| Alimentación compartida | `assets/ui/feeding/` (guardado y valoración existentes) |
| Pestaña Alimentación por lote | `assets/ui/lotes/feeding/`, cargada por `assets/ui/lotes/detail/index.html` |
| Biometría en Resumen | `assets/ui/lotes/detail/index.html` y `detail.js`, sección `biometrySection` |
| Agenda, Almacén, Finanzas | `assets/ui/agenda/`, `almacen/`, `finance/` |
| Bienvenida y cuatro portadas | `assets/ui/intro/` |
| Guardado y recuperación | `assets/ui/shared/storage*`, `recovery-ui.js` y capa nativa |
| Respaldos y menú | `assets/ui/menu/` |
| Icono de instalación | `AndroidManifest.xml`, `res/mipmap-*`, `res/values/launcher_colors.xml` |

`ARCHITECTURE.md`, `ALMACENAMIENTO-4.13.md` y `CHANGE-SCOPE.md` contienen contexto
anterior. Sus números de versión históricos no sustituyen al estado actual ni al
alcance de la nueva solicitud. Verificar el código antes de dar hechos por vigentes.

## Método para cada cambio

1. Identificar la base y generar un inventario antes de editar. Guardar una copia
   de recuperación y anotar la petición, los archivos previstos y lo pendiente.
2. Buscar el módulo y leer fragmentos. Mantener recursos grandes como archivos;
   calcular hashes por bloques, sin pegarlos ni cargarlos enteros en el chat.
3. Hacer el cambio localizado sobre la base. Las muestras usan datos y claves
   separados; la autorización de integración debe existir antes de tocar el APK.
4. Ejecutar las verificaciones que correspondan. Un ajuste de texto puede requerir
   sintaxis y revisión estructural; un cambio de datos requiere probar guardado,
   recuperación, errores y compatibilidad. No inventar compilaciones exitosas.
5. Comparar todos los archivos por SHA-256 y revisar la lista de cambios permitidos.
   Volver a comprimir el contenedor ZIP no significa reescribir el código fuente:
   el control comprueba que los archivos ajenos al cambio sigan idénticos.
6. Actualizar este resumen, empaquetar y conservar la base anterior. Para el código
   alojado en GitHub, usar commits y versiones recuperables cuando corresponda;
   no hacer pushes ni iniciar compilaciones sin autorización.

## Herramienta incluida

Requiere Python 3.9 o posterior y solo su biblioteca estándar. No instala paquetes,
no usa internet ni compila Android. Procesa el contenido en bloques de 1 MiB;
la lista de rutas y hashes crece con el número de archivos del proyecto.

Inventariar un ZIP antes de trabajar:

```bash
python3 tools/continuidad.py inventario base.zip --salida inventario.json
```

Comparar dos versiones y rechazar cambios fuera del alcance (repetir `--permitir`):

```bash
python3 tools/continuidad.py comparar base.zip nuevo.zip \
  --permitir app/src/main/assets/ui/lotes/lotes.js \
  --permitir app/build.gradle
```

Empaquetar desde la base con una carpeta que contenga solo los archivos editados,
conservando sus rutas relativas:

```bash
python3 tools/continuidad.py empaquetar base.zip --cambios cambios \
  --salida Calculadora-Yefferson-Proyecto.zip \
  --permitir app/src/main/assets/ui/lotes/lotes.js \
  --permitir app/build.gradle
```

No se reemplaza la base ni una salida existente. Las eliminaciones requieren
`--eliminar ruta`; una ausencia accidental en la carpeta de cambios no elimina
archivos del proyecto. Una comparación sin `--permitir` exige contenidos idénticos.
SHA-256 detecta cambios de bytes; no acredita que una función sea correcta ni es una
firma del autor. ZIP64 permite contenedores grandes, pero siguen aplicándose los
límites de transferencia, tiempo, disco y contexto del entorno disponible.

## Registro histórico: preparación de continuidad

Alcance: reglas de trabajo, resumen, inventario de la base y herramienta de control.
En esa preparación se conservaron los 175 archivos existentes. La herramienta se validó
con pruebas que incluyen cambios ajenos al alcance, eliminaciones, entradas ZIP
duplicadas/rutas inválidas y conservación de un recurso sintético de 64 MiB.
La compilación Android y la instalación no son parte de esta preparación.

Para retomar en otra conversación, adjuntar el último ZIP y pedir: «Lee AGENTS.md y
CONTINUIDAD.md; continúa desde esta base y modifica solo [la parte solicitada]».
Estos archivos permiten recuperar contexto cuando se tiene acceso al proyecto;
no cambian la capacidad ni la memoria permanente del modelo.

## Registro histórico: Alimentación y Biometría (4.15.0)

Archivos existentes modificados: `app/build.gradle`, `assets/ui/lotes/detail/index.html`,
`assets/ui/lotes/detail/detail.js`, `assets/ui/lotes/lot-detail-host.js` (rutas de assets
bajo `app/src/main/`) y este resumen. Se añaden el módulo de consulta Alimentación,
una imagen de cabecera optimizada, sus pruebas y el inventario de la base.

La imagen decorativa se preparó con ImageGen y se empaquetó en PNG RGBA de
512 × 341 px, aproximadamente 159 KB. El contenido técnico se basa en FAO,
PRODUCE/SINACUI (2022) y FONDEPES; los enlaces y límites del cálculo se incluyen
sin conexión dentro de la pestaña. Las proyecciones de stock son cálculos del
producto, no una recomendación de ración publicada por esas instituciones.

## Registro histórico: presentación de Alimentación (4.15.1)

Solicitud: reducir los textos exagerados y aproximar la interfaz de Alimentación
a la tarjeta blanca con bordes finos de la segunda imagen enviada. No se añade
contenido ni se cambia la ración, cobertura, registro diario o almacenamiento.

Archivos existentes modificados: `app/build.gradle`, este resumen y
`app/src/main/assets/ui/lotes/feeding/feeding-panel.css` / `feeding-panel-ui.js`.
Archivo añadido: `control/base-4.15.0.json`.

La tarjeta del plan reúne ración diaria, registrado hoy y pendiente en tres
columnas con divisores finos. Conserva los estados «Sin cálculo», «Sin registro»,
cero y exceso, y las mismas acciones. Las tarjetas de stock y consulta usan
tipografía más pequeña y superficies blancas. La ilustración se conserva.

Los cambios en JavaScript solo reorganizan el marcado de esa tarjeta. Los archivos
de cálculo, guardado, navegación, Biometría, otras pestañas, portadas y recursos
de la aplicación deben quedar idénticos a la base. El alcance se comprueba por
SHA-256 al empaquetar; no se reconstruye el proyecto desde cero.

## Registro histórico: retirar tutoriales internos (4.15.2)

Solicitud: quitar los tutoriales de Lotes y Agenda. Se eliminan su contenido,
estilos, eventos, comprobaciones de «visto» y llamadas de apertura. También se
retira el acceso «Ver tutorial otra vez». La navegación continúa renderizando
Lotes y Agenda con sus funciones existentes.

Archivos existentes modificados: `app/build.gradle`, este resumen,
`app/src/main/assets/index.html`, `ui/lotes/lotes.js`, `ui/lotes/lotes.css`,
`ui/agenda/agenda.js` y `ui/agenda/agenda.css` (rutas ui bajo assets).
Archivo añadido: `control/base-4.15.1.json`.

No se modifican los datos ni las claves de almacenamiento compartido. Las marcas
antiguas de tutorial visto quedan sin uso; no se borra ni se reinicia información.
La bienvenida, las cuatro portadas y el bloque Alimentación se conservan idénticos
a la base, al igual que los demás archivos fuera del alcance. No se compila ni se
instala Android en este entorno; Yefferson lo hará con su flujo de GitHub.

## Registro histórico: tamaño de títulos (4.15.3)

Solicitud: usar en los títulos el tamaño de «Alimentación del lote» de la captura
aprobada. Se añade `app/src/main/assets/ui/theme/title-sizes.css`, con una medida
compartida de 20 px y 19 px hasta 360 px. Se carga tanto en la página principal
como en el documento independiente del detalle del lote.

La regla se limita a cabeceras principales de Inicio, Lotes, Agenda, Almacén y
Finanzas; títulos de ventanas y paneles; nombre del lote y cabeceras principales
de sus secciones. Conserva las fuentes, pesos, colores y espacios existentes.
Los subtítulos pequeños de tarjetas y cifras no se amplían. La marca TruchApp,
la bienvenida y las portadas iniciales conservan sus tamaños aprobados.

Archivos existentes modificados: `app/build.gradle`, este resumen,
`app/src/main/assets/index.html` y `app/src/main/assets/ui/lotes/detail/index.html`.
Archivos añadidos: `app/src/main/assets/ui/theme/title-sizes.css` e inventario
`control/base-4.15.2.json`. No se modifica ningún JavaScript ni almacenamiento.

Las comprobaciones locales no sustituyen la revisión visual en el teléfono. La
compilación e instalación de esta versión quedan pendientes del flujo de GitHub.
