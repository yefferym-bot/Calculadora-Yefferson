# Continuidad de TruchApp

Actualizado: 12 de noviembre de 2026, zona America/Lima.

## Cambio vigente: diseño aprobado del colaborador (4.16.28 / 89)

Yefferson aprobó las muestras del colaborador y pidió incorporarlas al ZIP:
retirar el logo de Inicio/Mis lotes/Tareas/Equipo, conservar Wi-Fi y cadena en
todos esos módulos, bajar el menú inferior y mostrar Colaborador/Hola, nombre
una sola vez al vincular. Se continúa desde 4.16.27 / 88, SHA-256
`31663a057db20ce76730ac0ab85720a917f30d134de3bc82519b4c46315901d4`.
Base intacta, copia aislada e inventario control/base-4.16.27.json.

Una cabecera compartida sin marca mantiene menú a la izquierda y, a la derecha,
Wi-Fi, cadena y usuario, en ese orden, con botones de 44 px. Wi-Fi verde requiere
sesión conectada con un administrador vinculado; rojo indica que no la hay.
Cadena verde requiere un administrador vigente en el almacén nativo de confianza;
rojo indica ausencia o revocación. Ambos estados son independientes: perder red
no retira el vínculo. Antes de recibir un estado nativo del modo colaborador se
usa un estado neutro de consulta, sin inventar éxito. Títulos y etiquetas accesibles
explican el significado. Tocar Wi-Fi/cadena abre el panel local existente, sin
conectar, desconectar ni revocar automáticamente.

Inicio conserva Mis lotes y las asignaciones reales. Retira Tu equipo, el bloque
Conexión del equipo y el adelanto de tareas de ese inicio. La entrada a conexión
sigue disponible desde ambos indicadores y desde el menú. Mis lotes mantiene sus
asignaciones; Tareas conserva su pantalla; Equipo conserva ajustes/datos de
vinculación. La cabecera común no muestra logo en ninguno. El menú inferior
reduce relleno a 4 px, se mantiene pegado al borde de la app y respeta safe-area;
sus cuatro destinos y áreas de pulsación se conservan. Paleta nocturna regenerada
solo para los cambios de access; no cambia la del administrador.

La bienvenida aparece en Inicio después del primer vínculo nativo observado,
cuando la vista está visible y fuera del panel de conexión. Se conserva en esa
primera visita y se oculta al salir de Inicio o mandar la app al fondo. El booleano
welcomeSeen se guarda atómicamente dentro de la preferencia de modo existente;
no concede permisos ni simula vinculación. Sobrevive a cambios de nombre/modo y
a recarga/reconexión. Si el guardado falla, no marca éxito y admite reintento en
una visita posterior. Un código escrito o una solicitud sin aprobar no muestra
la bienvenida. Las actualizaciones de indicadores no borran el formulario que
esté en edición. No cambia la firma, el protocolo, el almacén de confianza ni TLS.

Validación: 35 grupos Chromium de panel/conexión y colaborador, incluidos los
tres estados de vínculo/conexión, los cuatro módulos sin logo, formulario en
edición, bienvenida con error/reintento y persistencia al recargar. Se mantienen
los escenarios anteriores de veinte pares/solicitudes y 500 lotes. Pasan 19 grupos
de modos/acceso, nueve comprobaciones de access-data, cinco pruebas de paleta y
ocho de continuidad. Se inspeccionan capturas de bienvenida, Inicio habitual,
sin conexión, sin vínculo y oscuro; 320/390/paisaje y escritorio sin desbordes.
Se valida sintaxis, CRC, versión y cambios por hashes. No se ejecutan Gradle,
Actions ni instalación física; la conexión POCO/Samsung ya confirmada se conserva
por integridad del código nativo. WebRTC/registro productivo siguen pendientes.

Modificados: app/build.gradle; ui/access/access-ui.js, access-data.js y access.css;
ui/theme/night-mode.css (ui bajo app/src/main/assets); tests/access-data.test.cjs,
tests/access-ui.test.cjs y tests/local-pairing-ui.test.cjs; docs/EMPAREJAMIENTO-LOCAL.md
y CONTINUIDAD.md. Nuevo control/base-4.16.27.json. Java, manifiesto, Room, firma,
assets del administrador, fuentes, pairing v4, menús del administrador y workflow
permanecen iguales por bytes. No se incluyen capturas, demos ni datos de prueba.
Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.28 / versionCode 89.

## Cambio anterior conservado: integrar Conexión local v4 (4.16.27 / 88)

Yefferson pidió sustituir el diseño anterior por el HTML adjunto
TruchApp-Conexion-Local-v4.html, conservando el menú superior y el inferior.
Se retoma y completa ese cambio sobre la última entrega funcional, sin rehacer
otros módulos. La conexión física POCO/Samsung quedó confirmada en 4.16.24;
no se modifican sus clases nativas, identidad RSA, TLS, confianza ni protocolo.

Base intacta 4.16.26 / 87, SHA-256
`8c158210c448fcf611504bcfe84553fa28ae9ee760bc63608b5b9857eefa5a71`.
Inventario control/base-4.16.26.json; trabajo aislado y empaquetado por cambios.

La vista usa cabecera compacta con flecha para volver y las pestañas Conexión y
Colaboradores (Administradores en el colaborador). El interruptor refleja el
estado devuelto por Android: activa escucha/búsqueda según el rol y desactiva
con stop; mientras espera la respuesta conserva el estado anterior. Los veinte
cupos y los contadores se derivan de las sesiones reales. Se conservan invitación,
reconexión, búsqueda NSD, dirección manual, espera entre reintentos y avisos.
Una verificación nueva abre la pestaña Conexión y exige comparar el código y
confirmar explícitamente en ambos móviles, igual que antes.

Las fichas de equipos muestran nombre, estado, Consulta y Registro próximamente.
Los lotes se seleccionan mediante chips, con Guardar cambios explícito: cambiar
de pestaña o cerrar no escribe. Se mantienen los borradores y los errores de
guardado; el éxito toma el estado nativo. Hay como máximo un editor de equipo
con hasta 500 opciones y otro de solicitud; se mantiene el límite de 100 lotes
asignados. Los otros equipos/solicitudes se revisan bajo demanda. El permiso
record anterior se conserva como opción futura; esta entrega no habilita
registros productivos compartidos. Desconectar conserva la vinculación;
desvincular requiere confirmación. El colaborador ve sus asignaciones sin editar.

Se conserva dialog.show y el encuadre entre las barras originales de 4.16.26.
No se clonan menús. Navegar cierra solo la vista y restaura inert de inmediato;
no envía stop, disconnect ni revoke. Volver/Escape restauran contenido y foco.
Las fuentes siguen empaquetadas y se usan SVG de trazos. Se respetan modo oscuro
y movimiento reducido. night-mode.css se regenera y solo pierde una regla de
lpPeerBusy que ya no existe; no cambia la paleta de los demás módulos.

Validación: 27 grupos de integración Chromium con bridge de prueba; 19 grupos
de acceso/modos; cinco pruebas de paleta y ocho de continuidad. Incluye fallos y
reintentos del interruptor/guardado, código en ambos roles, borradores, revocación,
20 equipos, 20 solicitudes, un editor de 500 lotes, ráfagas de eventos, nombres
seguros y datos productivos intactos. Se inspeccionan capturas claro/oscuro y
ambos roles, con navegación real activa y tamaños 320/390/paisaje/escritorio.
Se comprueban sintaxis JS, CRC, versión e integridad del ZIP. No se ejecutan
Gradle/CMake, Actions ni una instalación física de esta nueva interfaz.

Modificados: app/build.gradle; ui/pairing/local-pairing.js y .css;
ui/theme/night-mode.css (ui bajo app/src/main/assets); tests/local-pairing-ui.test.cjs;
docs/EMPAREJAMIENTO-LOCAL.md y CONTINUIDAD.md. Nuevo: control/base-4.16.26.json.
Los archivos Java, manifiesto, menús, access, index.html, fuentes, firma, Room y
workflow se conservan por bytes. No se incluyen el HTML de muestra, capturas,
navegador, dependencias de prueba ni datos simulados en la aplicación.
WebRTC y la sincronización productiva continúan pendientes como antes.
Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.27 / versionCode 88.

## Cambio anterior conservado: recuperar ambos menús en conexión local (4.16.26 / 87)

Yefferson confirma que el diseño integrado en 4.16.25 es correcto y pide volver
a mostrar el menú superior e inferior, conservando ese diseño. La vista modal
anterior los cubría y volvía inactivo el resto de la página. Se corrige solo la
presentación/navegación del panel; no se elimina ni se duplica ninguna barra.

Base intacta 4.16.25 / 86, SHA-256
`77ce7706b5aaa467cade0f46d5d6791e5c4a6e6cbfcc3baf7e60de843d5d7eae`.
Inventario `control/base-4.16.25.json`; copia aislada. La conexión física POCO /
Samsung y la corrección RSA permanecen confirmadas en la entrega anterior.

El panel se abre con dialog.show (no modal) y se encaja entre los rectángulos
reales del botón superior y la barra inferior. Detecta los menús originales del
administrador o del colaborador; recalcula con ResizeObserver, resize y visual
viewport. Mantiene contador, degradado, acciones, fichas y editor inferior. La
hoja de edición sigue siendo modal, acotada también al espacio entre barras;
Escape cierra primero esa hoja. Escape de la vista principal la cierra mediante
su manejador propio. Se limpian observadores y consulta periódica al cerrar.

Solo el contenido central que queda debajo se marca inert temporalmente para
impedir foco o edición inadvertida. Las barras reales permanecen activas. Al
pulsar menú superior, navegación inferior o perfil del colaborador se restaura
ese contenido y cierra la vista antes de seguir la navegación original. No se
manda stop, disconnect ni revoke: la conexión nativa continúa abierta mientras
la app siga en primer plano. Volver a abrir muestra su estado actual. Cerrar
con X/Escape también restaura el estado inert previo y el foco de origen.

Pruebas: 29 grupos Chromium del panel, incluidos clics reales en ambos menús de
ambos roles, navegación sin comandos de cierre de conexión, contenido central
inert/restaurado, límites entre barras, tamaños 320/390, paisaje y escritorio,
editor, oscuro y escenarios anteriores de confianza/permisos/20 pares/500 lotes.
19 pruebas de modos/acceso, cinco de paleta y ocho de continuidad. Se inspeccionan
capturas de ambos roles y de la hoja. Sintaxis JS y comparación de integridad del
ZIP. El código nativo, las barras y rutas existentes, Room, firma, manifiesto,
recursos y workflow se comparan por bytes con la base. No se ejecutan Gradle,
Actions ni instalación física ni se repite la carga TLS nativa sin cambios.

Modificados: app/build.gradle; app/src/main/assets/ui/pairing/local-pairing.js y
.css; tests/local-pairing-ui.test.cjs; docs/EMPAREJAMIENTO-LOCAL.md y CONTINUIDAD.md.
Nuevo: control/base-4.16.25.json. Sin cambios en index.html, access, archivos de
menú, generador nocturno, night-mode.css, Java, claves ni datos. Se preserva la
regla nativa anterior de pausa al mandar toda la app a segundo plano.
Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.26 / versionCode 87.

## Cambio anterior conservado: diseño Conexión local v3 (4.16.25 / 86)

Yefferson confirma que POCO y Samsung ya se pueden conectar con 4.16.24.
La corrección RSA queda confirmada por el usuario para estos dos móviles.
No atribuir nuevos problemas de UI al defecto anterior ni sustituir su solución.
Pidió integrar en el ZIP el diseño de TruchApp-Conexion-Local-v3.html adjunto.
La captura muestra la interfaz anterior; el HTML es la referencia visual nueva.

Base funcional intacta 4.16.24 / 85, SHA-256
`e0ac2c75168060c4b379c3f927d379902c4912991acee127ddd5ffb02b728903`.
Inventario `control/base-4.16.24.json`; trabajo aislado. No se modifican las trece
clases nativas de pairing, el bridge, las claves, certificados, identidades,
confianza, límites, protocolo ni repositorio/Room. Firma y workflow conservados.

Se adapta el diseño: cabecera teal degradada con título/cierre, contador circular
real y estado de escucha/conexión; dos tarjetas con SVG para vincular/reconectar;
pasos; lista de fichas con inicial, nombre, estado, permiso y lotes. El colaborador
conserva búsqueda NSD y conexión manual con el mismo lenguaje visual. La cifra,
arco, solicitudes y cantidad de vinculados se derivan del estado nativo: no se
copian los datos Lucas/Lote 1/Lote 2 ni las simulaciones de la muestra. El avatar
se deriva del nombre. Los conectados se presentan en su ficha, sin duplicarlos
como solicitudes; las verificaciones pendientes siguen siendo explícitas.

Tocar una ficha abre una hoja inferior modal con los permisos y lotes reales,
guardar, desconectar y retirar acceso con confirmación. Los controles son
perezosos: solo una hoja/editor con hasta 500 lotes, conservando borradores y el
límite de 100 asignaciones. Consultar es siempre obligatorio; el switch Autorizar
registro (próximamente) conserva el enum record anterior como permiso futuro,
sin habilitar escrituras productivas. Las aprobaciones nuevas conservan código,
casilla de comparación y confirmación en ambos móviles. Guardar fallido mantiene
la selección y muestra el error en la hoja; éxito la cierra. Escape/cierre de la
hoja conserva abierto el panel y devuelve el foco. Cerrar panel no revoca acceso.

Se reutilizan Inter/Playfair y fuentes ya empaquetadas, sin Google Fonts ni nuevos
recursos/red. CSS con prefijo del diálogo, tokens propios de modo oscuro, ring
con transición y pulso, hoja con entrada suave y respeto por reduced-motion.
Se resetea el header genérico heredado para mantener el contador bajo el título
y dentro de 320 px. El generador nocturno omite solo las reglas de este panel
ya adaptadas, conserva sus reglas co-/intro y las demás salidas. El archivo
night-mode.css se regenera y se valida contra el generador, sin cambiar módulos.

Pruebas: 25 grupos de integración Chromium del panel (mock del bridge), incluidos
permisos, error/borrador, aprobaciones, revocación, desconexión, 20 pares y 500
lotes perezosos, ráfagas de eventos, dos roles, 320/390, oscuro, Escape y datos
productivos intactos; 19 comprobaciones de modos/acceso; cinco pruebas de paleta
y ocho de continuidad. Se inspeccionan capturas reales del DOM claro/oscuro,
320 px y la hoja. Se valida sintaxis JS, CRC, versión y comparación por hashes.
No se recompila el módulo nativo sin cambios ni se repite su carga TLS de la
entrega anterior; su éxito y la confirmación física se conservan como evidencia.
No se ejecutan Gradle/CMake, Actions ni instalación Android para este ajuste UI.

Modificados: app/build.gradle; ui/pairing/local-pairing.js y .css;
ui/theme/night-mode.css (ui bajo app/src/main/assets); tools/generar_modo_oscuro.py;
tests/local-pairing-ui.test.cjs; docs/EMPAREJAMIENTO-LOCAL.md y CONTINUIDAD.md.
Nuevo: control/base-4.16.24.json. No se empaquetan HTML demo, capturas, navegador,
dependencias de QA, claves ni datos de ejecución. Diseño listo; la validación
visual de esta versión en los móviles queda para Yefferson.
Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.25 / versionCode 86.

## Cambio anterior conservado: corrección RSA de la conexión local (4.16.24 / 85)

Yefferson instaló 4.16.23 en ambos teléfonos. Capturas del POCO administrador y
Samsung colaborador: TLS-LOCAL, SSLProtocolException, error OpenSSL 04000044 RSA
routines/internal error durante autocomprobación. Se identificó una autorización
faltante en la generación original de la clave: Conscrypt usa RSA/ECB/NoPadding
para firmar bloques RSA-PSS ya preparados; la v1 no autorizaba KM_PAD_NONE.
AOSP CryptoUpcalls y AndroidKeyStoreRSACipherSpi explican la ruta. Se reprodujo
el mismo código 04000044 con Conscrypt nativo real y una clave opaca/proveedor
JCA de prueba que modela esa autorización; al permitirla el TLS mutuo pasa.
Aún falta confirmar el resultado en los móviles físicos del usuario.

Base intacta 4.16.23 / 84, SHA-256
`556ef6e9b95c453f53cf0322726b657ddf825b7177df84fc1b6753dfe82d0d05`.
Inventario `control/base-4.16.23.json`; copia aislada. No reconstruir otros módulos.

La identidad v2 añade ENCRYPTION_PADDING_NONE, conserva RSA 2048,
DIGEST_NONE/SHA256/SHA384/SHA512 y las firmas PKCS1/PSS con propósito solo
SIGN|VERIFY. No se agregan propósitos ENCRYPT/DECRYPT, no se relajan TLS 1.2,
ECDHE_RSA/AES-GCM, validación de certificados ni aprobación/pins. Se prueba la
primitiva con reto aleatorio/verificación pública antes del TLS local completo.

PairIdentityChoice y la preferencia identity_alias impiden rotar identidades
aprobadas. Sin marcador ni registros de pares se genera/reutiliza v2, conservando
v1. Con pares e identidad no marcada se mantiene v1; con marcador se mantiene
su identidad siempre. Se considera también el historial revocado para evitar
rotaciones inesperadas. Una selección desconocida o clave recordada ausente
bloquean y conservan información. Se guarda la selección solo tras pasar todas
las pruebas y comprobar la generación/primer plano; el commit vuelve a comprobar
que los pares no cambiaron. Fallar el guardado no abre listener. No se borran
alias ni pares ni se rota una identidad que ya esté vinculada. El caso de v1
vinculada que falle permanece protegido y requeriría reparación explícita.
El usuario actualmente muestra cero pares vinculados, por lo que aplica la
reparación automática de la identidad aún no aprobada.

Pruebas: dos casos sobre Conscrypt nativo 2.5.2 y claves opacas modeladas
(reproducción exacta 04000044 y TLS mutuo exitoso corregido); cinco grupos TLS,
con trece comprobaciones de mensajes y ocho decisiones/commits de identidad;
veinte grupos del protocolo y once de carga con veinte pares distintos.
Compilación del módulo de trece clases con Java 8/tipos Android 35 y stub read /
revisionStamp; ocho pruebas de continuidad. Conscrypt de escritorio y el modelo
no sustituyen Keystore/TEE ni hotspot físicos. No se ejecutan Gradle/CMake,
Actions ni instalación. Actualizar ambos con firma habitual sin desinstalar,
reintentar y conservar nuevos diagnósticos si falla. Registros productivos,
Room, UI, respaldo, package, firma, workflow y las otras capacidades no cambian.

Modificados: app/build.gradle; pairing/PairIdentity.java, PairStore.java,
LocalPairingController.java y PairTls.java; tests/native-pairing/PairingTlsHarness.java
y run_tests.py; docs/EMPAREJAMIENTO-LOCAL.md y CONTINUIDAD.md. Nuevos:
pairing/PairIdentityChoice.java, tests/native-pairing/PairingConscryptHarness.java e
inventario. Pairing bajo app/src/main/java/com/yefferson/calculadora. No se incluyen
jars, claves, certificados de prueba ni capturas. Referencias y límites en el doc.
Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.24 / versionCode 85.

## Cambio anterior conservado: diagnóstico del fallo POCO/Samsung (4.16.23 / 84)

Reporte: POCO como administrador/punto de acceso y Samsung colaborador. Capturas
con ECONNREFUSED y SSL genérico; las fechas de ambos equipos están correctas según
Yefferson. La causa física exacta sigue sin confirmar. No insistir en la fecha ni
presentar como probado que cámara, marca, red o veinte conexiones sean el origen.

Base 4.16.22 / 83 intacta, SHA-256
`6690acc325ee6b4334f89e75578d3b72e154eb470b730ffd8a8d369f17b52fdb`.
Inventario `control/base-4.16.22.json`; trabajo aislado. Se corrige el diagnóstico
que convertía cualquier SSLException en una recomendación sobre la fecha.

PairTls reúne configuración TLS, la selección de identidad para socket y
SSLEngine mediante X509ExtendedKeyManager, validación de certificado y comprobación
de firma de un reto. Antes de la primera activación del controlador se realiza
TLS mutuo real por loopback con la clave Android retenida y suites actuales.
Esto distingue un fallo local de Keystore/proveedor de un fallo que involucra al
otro teléfono. Va fuera del hilo UI y tiene timeouts/limpieza de recursos. No
ocupa plazas de vinculación. Volver del segundo plano conserva la obligación de
reactivar la escucha; se impide activar una generación cancelada durante el test.

PairFailure distingue ocho categorías y muestra la causa conservada y acotada;
solo una excepción real de vigencia invita a revisar las fechas. Los códigos
TLS-LOCAL/TLS-DATE/TLS-CERT/TLS-KEY/TLS-HANDSHAKE/TLS-CONNECTION y TCP-CONNECT /
NET-TIMEOUT permiten pedir evidencia concreta. No registra ni envía datos a un
servidor. Alias/clave/certificado de dispositivo permanecen intactos. No se rota
identidad, borra información ni relaja la verificación. Se preservan TLS 1.2,
ECDHE_RSA/AES-GCM, aprobación humana/pins, veinte plazas y catálogo de metadatos.

Los ensayos de escritorio ahora usan PairTls de producción. Pasan cuatro grupos
nuevos de TLS/diagnóstico (incluyen trece comprobaciones de mensajes), veinte
grupos del protocolo y once de carga con veinte certificados distintos. Compilan
las doce clases del módulo con Java 8/tipos Android 35 y stub de lectura del
repositorio. No cambian UI, Room, módulos productivos, workflow, package ni firma.
Los ensayos siguen usando claves PKCS12 temporales y JSSE; la nueva autocomprobación
con Android Keystore/Conscrypt se ejecutará por primera vez al instalar en móviles.
No se ejecutan Gradle/CMake, Actions ni instalación física. No afirmar que el fallo
de estos dos teléfonos ya quedó resuelto. Actualizar ambos, reintentar y recoger
el nuevo código/detalle si persiste. Los límites/referencias están en
`docs/EMPAREJAMIENTO-LOCAL.md`.

Archivos existentes modificados: app/build.gradle, pairing/PairIdentity.java y
LocalPairingController.java; tests/native-pairing/PairingHarness.java y run_tests.py;
docs/EMPAREJAMIENTO-LOCAL.md y CONTINUIDAD.md. Nuevos: pairing/PairTls.java,
PairFailure.java, tests/native-pairing/PairingTlsHarness.java e inventario.
Rutas pairing bajo app/src/main/java/com/yefferson/calculadora.
Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.23 / versionCode 84.

## Cambio anterior conservado: veinte colaboradores simultáneos (4.16.22 / 83)

Yefferson autorizó aumentar de cuatro a veinte colaboradores simultáneos y pidió
investigar técnicas para reforzar la transferencia y los fallos de concurrencia.
Base intacta 4.16.21 / 82, SHA-256
`c16030eec808dae0ee8347c27eb37a3b3f765f0635efe3ab38b35f5f6f8b9c28`.
Inventario completo `control/base-4.16.21.json`; copia de trabajo aislada.

El límite es veinte sesiones: veinte colaboradores más el teléfono administrador.
Las sesiones en inicio/cierre reservan plaza. La escucha ya no comparte el grupo
de sesiones. PairRuntime centraliza veinte lectores bajo demanda, cuatro inicios
TLS en paralelo, cuatro escritores, supervisores, límites de admisión y liberación.
Una identidad no abre dos sesiones; un cierre antiguo no retira la asociación de
una conexión nueva. Se rechaza la número 21 sin expulsar otra. La persistencia
mantiene veinte vinculaciones activas y cien identidades históricas, sin migración.

PairOutbound incorpora una cola FIFO por equipo con ocho tramas/512 KiB, presupuesto
global de 8 MiB, turnos de una trama, ejecución de escritura limitada a 3 s y
permanencia total de 20 s. Se escriben bloques de 16 KiB dentro del formato versión
1 existente, sin alterar los certificados ni la aprobación. Un equipo lento no
bloquea indefinidamente a los otros ni el hilo principal. Los fallos cierran su
socket, completan sus esperas y liberan bytes una sola vez. Revocar/desvincular
encola el aviso sin bloquear el comando en una escritura de red.

La actividad se distribuye aleatoriamente entre 10 y 16 s y se omite si ya hay
tráfico reciente. Se detectan equipos sin respuesta tras 45 s y tramas parciales
tras 15 s, con supervisión periódica. Los controles se limitan a 1 KiB y cinco
mensajes/s con ráfaga de diez; el catálogo conserva 256 KiB. Los comandos nativos
usan una cola de 32 y tamaño de entrada acotado. El inicio TLS tiene semáforo justo,
espera de 25 s y plazo inicial global de 45 s. Se admite una ráfaga de cuarenta
intentos con recarga de dos por segundo; no se conserva el límite anterior de doce.

Los fallos de conexión generan una espera manual progresiva con variación aleatoria,
hasta 30 s. No se repiten automáticamente aprobaciones ni escrituras. La limpieza
de pausa/destrucción sale del hilo principal e invalida la generación anterior;
un trabajo tardío no cierra recursos creados después de volver. Los eventos de
estado se agrupan 120 ms y la WebView conserva una consulta en vuelo más una
actualización pendiente, evitando perder el último cambio. Se reutiliza el catálogo
mediante una marca de generación de base de datos y revisión, conservando solo
metadatos. El getter revisionStamp añadido al repositorio es de lectura y no usa
la caché de documentos internos: evita reutilizar una revisión obsoleta. Una base
restaurada con igual revisión invalida el catálogo por tener otra generación.

La pantalla incorpora contador sobre veinte y Desconectar, que libera conexión
sin revocar confianza. Solo una solicitud muestra sus controles completos y se
conservan los borradores al pasar a otra. Los editores de permisos/lotes son
perezosos y se retiran al cerrarse, evitando veinte grupos de quinientas casillas.
Se conserva estilo, cifrado, nombre/modo, revocación y permisos anteriores.

Se investigaron fuentes primarias de Oracle, Android Developers/AOSP y Amazon
Builders' Library sobre recursos acotados, hilos de UI, timeouts y jitter. Las
referencias, decisiones, límites y comprobaciones están en
`docs/CONCURRENCIA-20.md`. La fase sigue siendo emparejamiento/transporte del
catálogo permitido; diario, agua y otros registros productivos no se sincronizan
aún y WebRTC sigue pendiente. No se prometen veinte clientes donde el hotspot o
router no los admita. Las pruebas son de software, no de veinte móviles físicos.

Archivos existentes modificados: app/build.gradle; pairing/LocalPairingController,
PairSession, PairWire y PairStore; data/db/FarmRepository.java (getter de lectura); ui/pairing/local-pairing.js y .css;
ui/theme/night-mode.css; tests/native-pairing/PairingHarness.java y run_tests.py;
tests/local-pairing-ui.test.cjs; docs/EMPAREJAMIENTO-LOCAL.md y CONTINUIDAD.md.
Rutas pairing bajo app/src/main/java/com/yefferson/calculadora y ui bajo assets.
Nuevos: PairRuntime.java, PairOutbound.java, PairLimits.java y PairCatalog.java en pairing;
tests/native-pairing/PairingLoadHarness.java; docs/CONCURRENCIA-20.md e inventario.
Los demás archivos se comparan por SHA-256. Se conservan identidad/firma Android,
escrituras/versiones/tablas de Room, datos, respaldo, manifiesto y workflows.

Validación: las diez clases del módulo compilan con sintaxis Java 8 y tipos de
Android 35, con stub de read y revisionStamp del repositorio. Veinte grupos
del protocolo y once de carga sobre sockets TLS mutuos reales de loopback,
veinte certificados distintos y cien lotes Unicode por cliente. Se prueban número
21 rechazado, identidades duplicadas, plazas reutilizadas, mensajes sin mezcla,
tráfico concurrente, aislamiento de emisor abusivo, reconexión de veinte, reposo,
liberación de recursos y colas/presupuestos bajo flujos bloqueados controlados.
La caché se comprueba con veinte lecturas, restauración que conserva la revisión
numérica y cambio concurrente de revisión, sin retener los historiales productivos.
Chromium: veintiún grupos de conexión local/UI y capturas 320/390/oscuro; pasan
las 19 comprobaciones de modos, 28 del editor/menú y 24 del diario por momentos.
El primer intento paralelo del diario falló en la comprobación inmediata de
Deshacer; la ejecución aislada pasó sin modificar diario ni su prueba. Pasan
las pruebas JS de lógica/DOM, almacenamiento, indicadores, alimentación, preferencias,
paleta nocturna y continuidad. El fixture antiguo storage-ui sigue pendiente como
se documentó antes, sin afirmar que toda la suite histórica esté completada.

No se ejecutan Gradle/CMake, Actions ni instalación Android. Se comprueban CRC,
versión, recursos, entradas únicas y alcance del ZIP. No se empaquetan navegador,
SDK, jars, claves, certificados, capturas ni datos de ejecución. Compilación/firma
en GitHub y prueba física de veinte colaboradores con Keystore/NSD y red real
pendientes de Yefferson. Repetir pruebas de carga solo si cambian estos caminos.

Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.22 / versionCode 83.

## Cambio anterior conservado: emparejamiento local (4.16.21 / 82)

Yefferson eligió empezar por emparejamiento local antes de WebRTC y autorizó su
implementación en el ZIP. El alcance acordado primero es vincular, aprobar,
asignar permisos/lotes, reconectar y retirar acceso; el intercambio de registros
productivos se añade después. Base 4.16.20 / 81 verificada intacta: SHA-256
`3a53e115acbf530848b273d5ef168fefc4fd222aa8199a7d181653b739216871`.
Inventario en `control/base-4.16.20.json`. Se trabaja en una copia aislada.

Se añade Conexión local al menú administrador y al espacio del colaborador.
La cuarta portada conserva su diseño y permite Continuar y vincular en local,
guardando primero el modo/nombre por la transacción anterior. El emparejamiento
se realiza en un diálogo propio con búsqueda NSD o dirección IPv4:puerto manual.
Ambos teléfonos se conectan previamente a la misma Wi-Fi o a la zona Wi-Fi de
uno de ellos; no se automatiza la creación ni conexión a un hotspot. No requiere
internet cuando la LAN permite comunicación entre clientes. WebRTC y QR siguen
pendientes y no se hacen conexiones a servidores externos.

El administrador abre una invitación de cinco minutos, controlada con reloj
monotónico, y selecciona lotes/permisos. Cada teléfono muestra el mismo código
de ocho dígitos y exige confirmar su coincidencia. Solo se guarda confianza
tras aprobar en ambos lados y se muestra conectado tras confirmación de guardado.
Los equipos conocidos reconectan mediante sus certificados guardados; un equipo
nuevo, cancelado o revocado requiere otra invitación y aprobación. Se pueden
editar asignaciones y retirar el acceso con confirmación; cambios de permisos
requieren reconectar. Un retiro offline se recibe al volver a conectar; no se
promete borrar datos de un teléfono desconectado.

La clave RSA de dispositivo está en Android Keystore. Se usa TLS 1.2 mutuo con
ECDHE_RSA/AES-GCM, certificados propios, compromisos de nonces previos a su
revelación y código ligado a certificados/roles/nonces. La aceptación de un
certificado propio no autoriza al equipo: lo hace la verificación en ambos lados
o el certificado previamente aprobado. La confianza TLS personalizada se limita
a estos sockets; HTTPS/WebView y usesCleartextTraffic=false permanecen intactos.
Tramas de 256 KiB máximo, UTF-8 válido, profundidad JSON acotada, tiempo máximo de
trama parcial, lectura fragmentada y comandos permitidos. Se limitan sesiones e
intentos. Se cierran sockets, NSD y multicast al salir de primer plano. La clave
del dispositivo y la firma permanente del APK son elementos distintos.

El catálogo compartido contiene únicamente id, código, etapa y unidad de los
lotes asignados. Se guarda separado de los datos del propietario. El colaborador
muestra sus asignaciones reales y el estado conectado/desconectado. Registrar
datos compartidos permanece desactivado: diario, mediciones, biometría, almacén,
agenda y finanzas no se sincronizan en esta fase. El permiso record se conserva
como autorización futura y no habilita escritura remota. No se modifica la base
Room, sus versiones/tablas, cantidades, sumas, firma, package, respaldo ni workflows.
La confianza privada y el catálogo no se incluyen en los respaldos productivos.

Límites iniciales y arquitectura detallados en `docs/EMPAREJAMIENTO-LOCAL.md`:
100 lotes por colaborador, catálogo de asignación de primeros 500 lotes, 20
vinculaciones activas, 100 identidades conservadas y cuatro sesiones simultáneas.
Nombre/servicio NSD/IP/modo visual/código escrito como borrador no conceden acceso.
La reconexión se inicia desde la interfaz local; no se promete conexión permanente
en segundo plano. Android Keystore conserva identidad al actualizar; reinstalar
requiere emparejar de nuevo. Se conserva la compatibilidad con minSdk 23.

Archivos existentes modificados: app/build.gradle, AndroidManifest.xml,
MainActivity.java, assets/index.html, assets/ui/access/access-ui.js,
assets/ui/intro/intro.js, assets/ui/theme/night-mode.css, tests/access-ui.test.cjs
(expectativas de Local disponible) y CONTINUIDAD.md. Nuevos: seis clases en
app/src/main/java/com/yefferson/calculadora/pairing; assets/ui/pairing/local-pairing.js
y .css; tests/local-pairing-ui.test.cjs; tests/native-pairing/PairingHarness.java
y run_tests.py; docs/EMPAREJAMIENTO-LOCAL.md; inventario de base. Fuera de estos
archivos se preservan los SHA-256 de la entrega anterior.

Validación: sintaxis JS; clases nuevas compiladas contra tipos de Android 35 con
stub del único método read del repositorio. Protocolo real con TLS mutuo sobre
loopback y claves temporales: 20 grupos, incluidos confirmaciones, reconexión,
revocación, invitación cerrada/vencida, cancelación, fallos de guardado, tramas
fragmentadas, exceso de tamaño, JSON profundo, UTF-8 incorrecto y catálogo sin
datos privados. Chromium con puente sintético: 15 grupos nuevos y capturas en
390/320 px y oscuro, más 19 de modos/bienvenida, 28 de tarjetas/menú y 24 del
diario. Pasan también las pruebas JS de lógica/DOM, almacenamiento y preferencias,
las cinco comprobaciones de paleta nocturna y las ocho de continuidad. Se
comprueba CRC, versión, recursos, entradas únicas y cambios permitidos del ZIP.
La prueba antigua storage-ui con fixture desactualizado sigue pendiente como se
documentó antes; no se afirma que toda la suite histórica esté completada.

No se ejecutan Gradle/CMake ni se instala Android en este entorno. El módulo
nativo compila; la prueba TLS de loopback no sustituye a Android Keystore,
Conscrypt ni NSD reales. Emparejamiento en dos teléfonos Wi-Fi/hotspot pendiente
de validar después de compilar/firmar con el flujo GitHub habitual de Yefferson.
No se empaquetan capturas, jars, certificados, claves ni datos de ejecución.

Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.21 / versionCode 82.

## Cambio anterior conservado: modos Administrador y Colaborador (4.16.20 / 81)

Yefferson aprobó las tres muestras: selección del modo en la última portada,
formulario desplegable de vinculación e Inicio del colaborador. Autorizó su
incorporación al ZIP. Base funcional intacta 4.16.19 / 80, SHA-256
`0e9ee362a3cedd150a8e8591b389b613f6392188892e54d5ea7e159b204ba845`.
Inventario completo `control/base-4.16.19.json`.

Un solo APK contiene ambos modos. La cuarta portada ofrece Administrador y
Colaborador con selección visual, radios accesibles e iconos SVG. Seleccionar
Colaborador despliega nombre y código de invitación; el nombre es obligatorio y
el código puede guardarse después. Continúa como colaborador con vinculación
pendiente. Se conservan la bienvenida animada, las primeras tres portadas y el
perfil opcional del administrador dentro de un desplegable. La ocupación del
perfil existente no se usa ni se sobrescribe como modo de acceso.

Inicio del colaborador usa logo real, saludo con nombre, estado del equipo,
sección de lotes y cuatro destinos propios: Inicio, Mis lotes, Tareas y Equipo.
Muestra cero lotes y ninguna tarea asignada hasta existir una vinculación real;
no copia ni presenta los lotes locales del administrador. Registrar datos queda
desactivado. Equipo permite guardar o corregir el borrador local de nombre y
código; un fallo mantiene los campos para reintentar. Escanear QR, Vincular
dispositivo y las conexiones Local/Por internet están desactivados y marcados
como Próximamente. No se implementa WebRTC, conexión local, descubrimiento,
servidor, lectura QR, autorización remota ni sincronización en esta entrega.

Las instalaciones existentes sin preferencia continúan en Administrador sin
forzar la bienvenida. Ajustes y ayuda añade Modo de trabajo para abrir la última
portada y cambiarlo; el colaborador dispone del mismo acceso. Cancelar o Escape
cierra sin guardar. La preferencia `truchapp_access_mode_v1` incluye schema 1,
mode y borrador collaborator; linkState siempre es pending. Se confirma con la
transacción existente, junto a las marcas de bienvenida cuando corresponde.
No migra, vacía ni duplica datos productivos; se preservan lotes, agua, agenda,
almacén, perfil y registros por momento del día. La preferencia genérica es
compatible con el códec de documentos actual de Room, sin cambiar Java.

Esta fase es una selección de interfaz local, no autenticación ni control de
permisos. El cambio a Administrador sigue disponible en el mismo dispositivo.
Para la fase P2P/local habrá que validar invitaciones y permisos de cada equipo
sin confiar en mode ni en el código guardado. No convertir el borrador pendiente
en una vinculación real ni añadir asignaciones ficticias. Los estados inválidos
se presentan pendientes y los textos de usuario se insertan de forma segura.

Archivos existentes modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html, ui/intro/intro.js y ui/theme/night-mode.css.
Nuevos: ui/access/access-data.js, access-ui.js y access.css (rutas ui bajo assets),
tests/access-data.test.cjs, tests/access-ui.test.cjs e inventario de base.
Se conservan los archivos restantes mediante comparación SHA-256. Sin cambios
en identidad Android, firma, Java/Room, respaldos, módulos productivos, recursos
existentes ni workflows. No se ejecutan Actions ni se modifica el repositorio.

Validación: sintaxis de los tres scripts; ocho grupos de lógica del modo; pruebas
existentes de registros/agua, alimentación/stock, ficha, indicadores, sanidad,
almacenamiento, decisiones y preferencias; cinco comprobaciones de paleta
nocturna reproducible y ocho de continuidad. Chromium con puente Android
sintético: 19 grupos nuevos que cubren instalaciones existentes y nuevas,
selección por teclado, formulario, controles pendientes, nombre vacío,
fallo/reintento atómico, cancelación/Escape, cambio de modo, conservación de
perfil/lotes/agua/actividades, cuatro destinos, texto seguro, persistencia,
320/390 px, acciones inferiores y modo oscuro. También pasan las 28
comprobaciones del editor/menú/acceso diario y los 24 grupos de registros por
momento del día. Se revisan capturas diurnas y nocturnas. CRC, entradas únicas,
versión, recursos y alcance del ZIP se comprueban antes de entregar. Capturas,
navegador y datos de ejecución de pruebas no se empaquetan. La prueba antigua
storage-ui y su fixture desactualizado siguen pendientes como se documentó
para 4.16.19; no se afirma que toda la suite histórica se haya completado.

Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.20 / versionCode 81.
Compilación/firma en GitHub e instalación real en Android pendientes de Yefferson.

## Cambio anterior conservado: varios registros por momento del día (4.16.19 / 80)

Yefferson confirmó que la integración de 4.16.18 fue correcta. Detectó que
registrar 1 kg por la mañana y 1 kg por la tarde dejaba el total en 1 kg por
reemplazo. Autorizó entregas/registros por hora con sumas automáticas, edición,
eliminación y varias mediciones de agua. Base intacta: 4.16.18 / 79, SHA-256
`576bdb4717f7113cf4bce0367a37fc148e50676026c8f0fb3c35ae9baba95f37`.
Inventario completo en `control/base-4.16.18.json`.

Registrar datos abre un registro nuevo vacío para la fecha elegida y hora actual.
Resumen del día muestra alimento, mortalidad y descarte acumulados, aparte de las
cantidades por introducir. Se añade Añadir entrega; Hora del registro sustituye a
Hora del cierre y las bajas se identifican como cantidades de este registro.
Guardar registro añade una entrada con ID propio; Guardar cambios reemplaza solo
la entrada seleccionada. Se conserva el cierre del diálogo al confirmar y el
retorno a la métrica de origen. Editar conserva la fecha del registro; la fecha
se puede seleccionar al crear otro registro. No se exige introducir todos los
campos y no se convierten los placeholders en valores. Dos entradas de 1 kg
producen 2 kg, mientras que dos mediciones de agua permanecen separadas por hora.

Registros de este día muestra hora, cantidades, apetito, observaciones y las
mediciones de cada entrada, con Editar y Eliminar. La eliminación pide una
confirmación dentro del mismo formulario; cancelar no escribe. Eliminar una
entrada recalcula las sumas; quitar la última retira el resumen de ese día.
Deshacer restaura cantidades y mediciones en la misma transacción. La lista
muestra veinte entradas y permite cargar veinte más; el modelo admite hasta
500 por día. Se mantienen cabecera, X centrada, campos suaves, Observaciones
negro en modo diurno, botón + de parámetros y acciones inferiores accesibles.
El contenido sigue desplazándose en pantallas pequeñas y funciona en oscuro.

Cada día conserva una única fila agregada compatible con los cálculos, la lista,
Inicio, alimentación, indicadores y FCR. El desglose vive en `daily[].entries`
con `entriesVersion:1`; cada entrada tiene ID, fecha, hora, cantidades, apetito,
nota y sus vínculos de agua. El validador contrasta los totales con las entradas,
rechaza IDs repetidos y conserva la diferencia entre cero confirmado y ausencia.
No se modifica Java/Room: el códec existente conserva objetos y listas anidados.
La compatibilidad probada es hacia los registros anteriores; no se hace una
migración destructiva ni se cambia la versión 2 del detalle completo.

Un día anterior se presenta sin escrituras como Total anterior · sin desglose.
Al guardar su primera mejora se conserva ese total como una entrada identificada,
con su hora guardada, metadatos y mediciones originales. No se inventan comidas ni
se reparte el total previo en entregas supuestas. El agregado mantiene una sola
copia contable de sus cantidades. Las nuevas cantidades se suman a ese origen.
Las observaciones y el apetito individuales se conservan en cada entrada; el
resumen usa el último dato no vacío por hora para las vistas existentes.

Las mediciones de agua pertenecen a su entrada, mantienen IDs al corregirla y
adoptan su hora. Dos entradas del mismo parámetro no se sobrescriben. Eliminar
quita únicamente sus lecturas asociadas, conservando las manuales independientes
y las de otros lotes. La transacción existente confirma diario/agua juntos;
fallos revierten ambos historiales y mantienen el borrador para reintentar.

El alimento nuevo sigue siendo manual, sin salida automática. Un total antiguo
vinculado al almacén mantiene sus líneas originales y su costo al añadir comida
manual: 1 kg vinculado más 1 kg manual = 2 kg registrados, con una única salida de
1 kg y valoración parcial. La firma de cambios y la validación del alimento
vinculado distinguen esa cantidad del agregado. Si se revalora una salida, se
sincroniza su costo con el registro de origen. La hora de esa salida conserva la
de su entrada original. Los kg de un total vinculado no se cambian sin desglose;
pueden añadirse nuevas entregas por separado. Eliminar explícitamente ese total
advierte y retira también su salida vinculada. Esto se prueba sin duplicar stock.

Archivos existentes modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html, ui/feeding/feeding-data.js y feeding-store.js,
ui/lotes/lot-detail-data.js, ui/lotes/detail/index.html, detail.js, daily-water.js,
daily-register.css, ui/theme/night-mode.css, tests/daily-register-ui.test.cjs y
 tests/lot-detail-feeding-ui.test.cjs (rutas ui bajo assets). Nuevos:
ui/lotes/detail/daily-events.js, tests/daily-events.test.cjs e inventario de base.
Los demás archivos se conservan mediante comparación SHA-256. No se cambia
identidad Android, firma, respaldos, workflows, bienvenida, ficha general ni el
editor aprobado de ocho tarjetas; no se ejecutan Actions ni se toca el repositorio.

Validación: sintaxis de scripts modificados; pruebas JavaScript de
lógica y DOM simulado, incluidas cantidades, stock/costos, ficha, sanidad, indicadores,
almacenamiento y decisiones; paleta nocturna reproducible y continuidad. Las
pruebas Chromium se ejecutan con navegador local y puente Android sintético:
28 comprobaciones anteriores del editor/menú/acceso; 24 grupos del diario por
momentos, incluidas 1+1=2, bajas sumadas, correcciones, doble envío, fallos y
reintentos, varias lecturas horarias, borrado/confirmación/cancelación/deshacer,
totales anteriores, costos parciales y protección de datos ajenos, persistencia,
320/390 px y modo oscuro. Se revisan capturas y recursos, entradas únicas, CRC, versión y alcance
del ZIP. No se empaquetan navegador, capturas ni datos de ejecución de pruebas.

La prueba adicional antigua `tests/storage-ui.test.cjs` no se completa: su
fixture solo marca una de las portadas previas y la bienvenida intercepta la
navegación. Ese archivo y la bienvenida quedan idénticos a la base; no se cambia
producción para ajustar una prueba fuera del alcance. Las nueve pruebas del
puente de almacenamiento y el nuevo flujo Chromium comprueban guardado atómico,
fallos/reintentos y conservación de datos. Actualizar ese fixture queda pendiente.

Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.19 / versionCode 80.
Compilación/firma GitHub e instalación real en Android pendientes de Yefferson.

## Cambio anterior conservado: Registro diario aprobado y mediciones de agua (4.16.18 / 79)

Yefferson aprobó la muestra final `Registro diario - Lote 1` con subtítulo
`Complete su registro diario`. Se usa la variante de encabezado blanco y campos
suaves: rechazó la franja menta y los contornos resaltados. Base verificada:
4.16.17 / 78, SHA-256
`e7a24b21c7ad4086c835e12049754b6bc798aeeb6d42e53a1cceaf048d3d35ee`.
Inventario en `control/base-4.16.17.json`; ZIP anterior conservado intacto.

Se incorpora al formulario existente: título con nombre real del lote (texto
seguro y salto para nombres largos), cierre SVG centrado en botón redondeado,
iconos SVG teal junto a los campos y Observaciones en negro en modo diurno.
Alimento es entrada decimal manual con placeholder 0.00; mortalidad/descarte
son enteros con placeholder 0. Los placeholders no son valores guardados.
Se elimina el bloque Alimento y almacén y el párrafo de campos vacíos. Se
conserva el aviso Antes de guardar. Cabecera y acciones quedan visibles y el
contenido intermedio se desplaza en pantallas pequeñas y con más parámetros.
No se estrechan los controles de agua hasta el tamaño gráfico de la muestra.
Se conserva la preferencia opcional de contornos resaltados y el modo oscuro.

Calidad del agua contiene temperatura (°C), oxígeno disuelto (mg/L), pH y TAN
(mg N/L), vacíos con `Sin medir`. El botón + despliega el catálogo existente
para añadir parámetros, sin duplicados; los adicionales pueden quitarse. Los
campos numéricos admiten decimales y los parámetros descriptivos del catálogo
conservan entrada de texto. No se añaden rangos ideales ni alertas automáticas.
Las selecciones se guardan por lote solo al confirmar un registro. Las lecturas
usan fecha/hora de cierre y la jaula/unidad del lote como punto de medición.

El diario y sus lecturas de agua se confirman en la transacción existente. Se
permiten días con solo agua sin inventar alimento o bajas. Las lecturas se
identifican mediante `daily[].waterReadingIds` y usan los mismos registros y
unidades del historial compartido de agua. Reabrir y corregir conserva sus IDs;
vaciar o quitar un resultado elimina solo esa lectura diaria asociada. El
adaptador reconcilia esas lecturas incluso después de cerrar/reabrir la ficha;
no modifica mediciones manuales independientes ni lecturas de otros lotes.
La comprobación de vínculos usa índices para evitar recorridos cuadráticos.
Se conservan validación, guardado confirmado, reversión, deshacer y bloqueo
de doble envío. Un fallo conserva el borrador y no confirma datos parciales.

Al retirar el enlace de almacén, los registros nuevos de alimento son manuales,
sin salida ni costo automático. Los registros antiguos que ya tenían entregas
vinculadas mantienen íntegra su estructura y costo al editar otros campos. Si
se cambia el total de alimento de uno de esos días, se muestra una validación
que exige conservar los kg vinculados; no se desvincula ni redistribuye una
entrega antigua de forma silenciosa. Esta restricción solo afecta esos días.

Archivos existentes modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html, ui/lotes/lotes.js,
ui/lotes/detail/index.html, ui/lotes/detail/detail.js, ui/theme/night-mode.css,
tests/list-cards-ui.test.cjs y tests/lot-detail-feeding-ui.test.cjs (rutas ui
bajo assets). Nuevos: ui/lotes/detail/daily-register.css y daily-water.js,
tests/daily-water.test.cjs, tests/daily-register-ui.test.cjs y el inventario base.
No se cambian Java/Room, identidad, firma, respaldos, cálculos, bienvenida,
editor de ocho tarjetas, ficha general ni workflows de GitHub.

Validación: sintaxis JS; pruebas de diario/agua, alimentación, indicadores,
ficha general, almacenamiento, infraestructura del detalle, paleta nocturna
reproducible y herramienta de continuidad. Chromium con puente Android aislado:
prueba anterior de 28 comprobaciones; prueba nueva de 19 grupos que cubre
apertura sin escrituras, diseño, entradas manuales, selección + sin duplicados,
cancelación, pH inválido, agua sola con ceros/vacíos distintos, doble envío,
corrección tras reabrir, fallo/reintento, eliminación asociada, otros lotes,
320/390 px sin desbordamiento, cierre alineado, acciones accesibles, noche,
recarga y entregas antiguas conservadas. Se revisan capturas; navegador,
datos sintéticos y capturas no se empaquetan. CRC, versión, recursos y cambios
permitidos del ZIP se comprueban antes de entregar.

Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.18 / versionCode 79.
Compilación/firma en GitHub e instalación real en Android pendientes de Yefferson.
No se ejecutan Actions ni se modifica su repositorio.

## Cambio anterior conservado: apariencia/respaldo al menú y acceso Registrar datos (4.16.17 / 78)

Yefferson pidió mover los botones de sol y nube de la cabecera de Lotes al menú
superior izquierdo y añadir Registrar datos junto a Ver / actualizar lote.
Base verificada: 4.16.16 / 77, SHA-256
`b66ac45f44f1df31d05dd60f635195ff758d3523c770bbd067ed50dff04a9215`;
inventario completo en `control/base-4.16.16.json`. La base anterior se conserva.

Lotes ya no muestra esos dos botones en su cabecera. El menú, en Ajustes y ayuda,
incorpora Apariencia con el mismo control de tres modos: Diurno, Contornos
resaltados y Oscuro. La leyenda visible indica el modo vigente y el icono cambia
a luna en oscuro. Se conserva la misma preferencia, guardado confirmado,
nombres accesibles y propagación al detalle. El menú permanece abierto al cambiar
el modo, permitiendo recorrer las opciones sin reabrirlo.

Se reutiliza la única entrada de respaldo del menú, ahora identificada como
Respaldo cifrado / Importar y exportar y con el icono de nube del acceso anterior.
Abre el mismo panel y las mismas funciones originales; no crea otro respaldo
ni exporta/importa al abrir. No se cambia cifrado, recuperación o credenciales.
El controlador del menú y su CSS permanecen idénticos a la base.

Cada bloque normal del lote tiene dos botones en una fila: Ver / actualizar lote
y Registrar datos. El primero conserva su apertura habitual. El segundo abre
el Registro diario existente de ese lote mediante la acción daily del host,
después de que la ficha confirme la carga. Reutiliza sesión, validación y guardado;
no crea un formulario nuevo ni registra nada al tocar el acceso. La reutilización
del iframe no mezcla datos entre lotes. En configuración del diseño siguen
apareciendo Cancelar y Guardar diseño; al salir vuelven ambos botones normales
con sus listeners. Se conserva el editor de hasta ocho indicadores y su animación.

Archivos existentes modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html, ui/lotes/lotes.js,
ui/shared/display-preferences.js (rutas ui bajo assets) y
 tests/list-cards-ui.test.cjs. Nuevo: control/base-4.16.16.json.
El resto queda idéntico por SHA-256: CSS/paleta, editor de ocho tarjetas, ficha,
host/detalle, cálculos, registros, almacenamiento, Java/Room, respaldo, firma,
identidad Android, bienvenida y workflows. No se añaden datos de demostración.

Validación: sintaxis de los dos scripts; trece casos de preferencias/guardado y
cinco comprobaciones de paleta nocturna reproducible. Chromium con Android
simulado en 390×844 y 320×700: se conserva toda la prueba del editor anterior;
no quedan accesos de sol/nube en Lotes; Apariencia existe una vez en el menú y
recorre los tres modos con leyenda actualizada; el respaldo es único y abrirlo
no escribe ni exporta; ambos botones del lote comparten fila sin solaparse.
Registrar datos abre el lote correcto sin escribir, guarda exactamente un
registro diario con ceros confirmados y conserva otros lotes y listCards.
Al abrir otro lote se renuevan los campos; Ver / actualizar no abre un diálogo
automáticamente. Sin errores JavaScript. Se revisan imágenes de QA, recursos,
CRC, versión, entradas únicas y cambios permitidos del ZIP. Las capturas,
páginas/datos sintéticos y navegador de QA no se incorporan a la entrega.

Entrega: Calculadora-Yefferson-Proyecto.zip, versión 4.16.17 / versionCode 78.
La compilación y firma en GitHub y la instalación real en Android quedan
pendientes de Yefferson; no se ejecutan Actions ni se modifica su repositorio.

## Cambio anterior conservado: configuración en el mismo bloque, hasta ocho indicadores (4.16.16 / 77)

Yefferson aprobó la última muestra con ocho tarjetas en dos filas de cuatro,
Indicadores del lote, Cancelar y Guardar diseño, mortalidad/descarte a la derecha,
botones rojos de quitar y opciones seleccionadas resaltadas. Solicitó además
una animación suave al cambiar la posición del bloque y aparecer el catálogo.
Base verificada: 4.16.15 / 76, SHA-256
`3297a84e1090bd1919ede7e37078662d24795eed99e6fcbd15548ee55fc7f8cd`;
inventario en `control/base-4.16.15.json`. La base anterior se conserva intacta.

El engranaje mueve el mismo nodo del bloque a una región de configuración sobre
el fondo suavemente difuminado (2 px). No clona el lote ni abre el anterior
dialog independiente. Un marcador conserva la posición de origen; cancelar
restaura el mismo nodo, sus botones y listeners, el desplazamiento y el foco.
El resto de la aplicación queda inerte durante la edición para impedir cambios
involuntarios. El catálogo flota debajo del bloque, con desplazamiento vertical,
tres columnas y las trece opciones reales ya existentes, incluida Supervivencia.
Las seleccionadas tienen fondo menta, contorno teal y check; las otras muestran +.
La navegación inferior permanece visible y difuminada, fuera del área desplazable.
La paleta nocturna conserva legibilidad y un resaltado propio de selección.

La selección permite de uno a ocho indicadores únicos, manteniendo el orden.
Las cuatro preferencias anteriores y el predeterminado original se conservan;
no se rellenan ocho automáticamente ni se escriben registros al abrir. Ocho
seleccionadas aparecen en dos filas de cuatro, también a 320 px. Quitar permite
llegar temporalmente a cero, con Guardar desactivado; añadir no duplica y un
noveno indicador se rechaza con un mensaje. Tocar una tarjeta seleccionada
muestra controles para moverla una posición antes/después, conservando el orden
accesible del editor anterior sin ocupar espacio cuando no se usan.

La transición del bloque usa su posición real de inicio y fin (360 ms, curva
sin rebote), el catálogo aparece con desplazamiento corto y opacidad (300 ms,
90 ms de demora), los cambios de orden/alta se animan (260 ms) y la vuelta
se resuelve en 220 ms. La opacidad del fondo cambia suavemente, sin animar el
filtro de desenfoque. Se cancelan y limpian todas las animaciones al cerrar,
incluidas las terminadas con fill, para evitar transformaciones persistentes
al reabrir. Movimiento reducido desactiva los desplazamientos animados.

La configuración sigue guardándose solo en listCards del lote por la ruta
transaccional confirmada existente. Cancelar, cerrar y guardar sin cambios no
escriben; el doble envío se bloquea. Un error revierte el estado almacenado y
conserva el borrador para reintentar. El guardado comprueba que otro proceso no
haya cambiado esa selección desde que se abrió. No altera existencias, pesos,
alimentación, historial, ajustes productivos ni otros lotes. Las tarjetas usan
los mismos cálculos de datos/indicadores existentes; las notas se calculan una
vez al abrir, sin inventar valores ni duplicar registros. La ficha aprobada
en 4.16.15, su botón lápiz, jaula, días y edición de datos quedan conservados.

Archivos existentes modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/ui/lotes/lotes.js, ui/lotes/list-cards-data.js,
ui/lotes/list-cards-editor.js, ui/lotes/list-cards-editor.css,
ui/theme/night-mode.css (rutas ui bajo assets),
tools/generar_modo_oscuro.py y tests/list-cards.test.cjs.
Nuevos: control/base-4.16.15.json y tests/list-cards-ui.test.cjs.
El generador nocturno añade solo dos excepciones de color del catálogo nuevo.
El resto del proyecto se conserva por SHA-256, incluidos Java/Room, respaldos,
identidad Android, firma, ambos workflows, bienvenida y demás módulos.

Validación: sintaxis de los scripts; compatibilidad de cuatro preferencias,
rango uno-ocho, rechazo de nueve/duplicadas/vacías, orden, datos ausentes/cero,
guardado confirmado y conservación de producción. Pasan las regresiones de
ficha, indicadores, almacenamiento, preferencias, alimentación, host y formularios
del detalle, y la generación reproducible de cinco pruebas de paleta nocturna.
Chromium con Android simulado y datos aislados a 390×844 y 320×700: mismo nodo,
borrador sin escrituras, ocho en dos filas, catálogo y checks, límite, cancelación,
orden, doble envío único, otros datos/lotes idénticos, fallo y reintento,
cero desactiva Guardar, recarga con preferencias, ausencia de desbordamientos,
modo oscuro con contraste de cifras >=4.5, foco/Tab/Escape, movimiento reducido,
reaperturas sin duplicados ni transformaciones residuales, no-op sin escritura
y apertura de la ficha anterior. Recursos e integridad del ZIP verificados.
Las páginas, capturas, datos sintéticos y navegador de QA no se incorporan.

Entrega: Calculadora-Yefferson-Proyecto.zip, 4.16.16 / versionCode 77.
Compilación, firma en GitHub e instalación real en el teléfono pendientes de
Yefferson; no se ejecutan Actions ni se modifica su repositorio desde aquí.

## Cambio anterior conservado: ficha de lote aprobada (4.16.15 / 76)

Yefferson aprobó integrar la última muestra de imagen (botón Editar datos hasta
la mitad del ancho) al ZIP para compilarlo él mismo en GitHub. Se incorporan
únicamente los cambios aprobados de la ficha, sin los campos adicionales que
se propusieron después. Base verificada: 4.16.14 / 75, SHA-256
`f4f9d0dd7d1bf4af45a1a7af48c85ff14c0b126caf42b1f4a94e3d8faa2a3b61`;
inventario completo en `control/base-4.16.14.json`. La base se conserva intacta.

La ventana muestra Información general del lote, Código y Etapa sobre una banda
menta, seis datos en dos columnas con SVG, Editar datos y Ajustes del lote en
mitades iguales y Eliminar lote resaltado en rojo en una fila propia.
Se conservan los seis datos originales y se añaden Días en el lote (diferencia
de fechas de calendario desde el ingreso, cero el mismo día, sin sumar uno;
se actualiza al abrir) y Asignación de Jaula (Sin asignar mientras esté vacía).
No se insertan los valores de ejemplo de la imagen como registros productivos.

Editar datos abre un formulario para Código, Etapa, Unidad, Origen y Asignación
de Jaula. La fecha y los peces iniciales se muestran como referencia y se
conservan: la ruta de guardado existente protege los datos de ingreso del
historial. Guardar usa la transacción confirmada por Android existente,
conserva el ID estable y permite Deshacer. Cancelar/consultar no escribe.
Un fallo conserva el borrador para reintentar y revierte el estado productivo.
Se impiden códigos duplicados al renombrar; textos largos de lotes anteriores
siguen admitiéndose. La asignación se conserva tanto en el lote compartido
como en detailState. Los módulos siguen enlazados por el mismo ID.
Al renombrar un lote se actualiza el código de sus mediciones de agua, incluidas
las antiguas que solo tenían lotCode, vinculándolas por ID sin duplicarlas.
La confirmación original de eliminación y el tratamiento del alimento se conservan.

Archivos existentes modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/ui/lotes/lotes.js, ui/lotes/lot-detail-data.js,
ui/lotes/detail/index.html, ui/lotes/detail/detail.js,
ui/theme/night-mode.css y tests/lot-detail-feeding-ui.test.cjs (rutas ui bajo
assets). Nuevos: ui/lotes/detail/lot-profile.css, tests/lot-profile.test.cjs
y control/base-4.16.14.json. Se regenera únicamente la paleta nocturna derivada
de la nueva ficha. El fixture de integración carga summary-data.js, dependencia
que faltaba en esa prueba anterior; no se cambia el motor de indicadores.
El resto de archivos, Java/Room, respaldos, firma, applicationId, navegación,
portadas y workflows se conservan por comparación SHA-256.

Validación: sintaxis JS; cinco casos nuevos de compatibilidad/edición de ficha;
regresiones existentes de indicadores, tarjetas configurables, preferencias,
almacenamiento, alimentación, navegación del host y formularios del detalle;
cinco comprobaciones de la paleta nocturna. Chromium con datos sintéticos
aislados y Android simulado a 390×844 y 320×700: datos correctos, días desde el
ingreso, mitades iguales, ausencia de desbordamiento, lectura sin escrituras,
Ajustes, edición y reapertura, persistencia al recargar, ID estable, otro lote
idéntico, medición antigua sin duplicación, código duplicado rechazado, fallo
con recuperación y reintento, Deshacer, modo oscuro y confirmación al eliminar
(cancelada durante la revisión). Se revisan recursos, IDs DOM, integridad,
versión y alcance del ZIP. Las imágenes/páginas de prueba y el navegador de QA
no se incorporan al proyecto entregado.

Entrega: Calculadora-Yefferson-Proyecto.zip, versión 4.16.15 / 76. Compilación,
firma en GitHub e instalación real en Android pendientes de Yefferson.

## Cambio anterior conservado: lápiz abre Ficha del lote (4.16.14 / 75)

Yefferson pidió que el lápiz situado a la izquierda del engranaje abriera la
ventana Ficha del lote de su captura. Base verificada: 4.16.13 / 74, SHA-256
`3f51f14e5fc7751bb39c8de104a94065c624db1dd9780feeecedb0301e659967`;
inventario completo en `control/base-4.16.13.json`.

El lápiz ahora solicita la acción profile. La ficha de detalle se carga mediante
el mismo host y, cuando confirma que está lista, abre su infoDialog existente.
Se reutilizan Código, Etapa, Unidad, Origen, Ingreso y Peces iniciales, tomados
del estado real del lote seleccionado. Se conservan Ajustes del lote y Eliminar
lote, con sus funciones, validaciones y confirmaciones originales. El acceso de
información del encabezado sigue abriendo esa misma ventana.

La lista cambia solo la acción del lápiz y su nombre accesible/tooltip a Ficha
del lote. Host e iframe aceptan profile además de daily, con la misma validación
de ventana, sesión y guardado en curso. La solicitud se consume una sola vez tras
la carga. No se crea otro formulario ni se cambia la navegación habitual de
Ver / actualizar lote. La reutilización del iframe renueva los datos por lote.
Abrir la ficha no registra un día ni escribe datos productivos.

Archivos modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/ui/lotes/lotes.js, ui/lotes/lot-detail-host.js,
ui/lotes/detail/detail.js y tests/lot-detail-page.test.cjs
(rutas ui bajo assets). Nuevo: control/base-4.16.13.json.
No cambian HTML, CSS, los tres modos de lectura, formularios, cálculos,
almacenamiento, Room, respaldo cifrado, identidad ni firma. Todos los demás
archivos se conservan idénticos a la base.

Validación: sintaxis de los tres scripts; 20 comprobaciones existentes del host,
actualizando el caso del atajo a profile (espera de carga, sesión antigua
ignorada, apertura única, apertura normal conservada). Pasan también las 13
pruebas de preferencias/avisos, siete de tarjetas, nueve de almacenamiento y
cinco de paleta nocturna.

Chrome con datos sintéticos aislados a 390×844 y 320×700: lápiz abre Ficha del
lote; datos correctos en lotes 1/2/3/4; acceso a Ajustes y cancelación; cierre,
regreso a Lotes y reapertura usando el iframe existente; apertura normal sin
activar un diálogo; una sola ventana abierta; registro diario no abierto por
el lápiz; modo oscuro conservado; sin errores de la aplicación. No se ejecutan
eliminaciones ni se escriben registros reales durante la revisión.
Se comprueban recursos, versión, integridad y alcance por archivo del ZIP.

ImageGen se usa solo como referencia nocturna de la ficha existente; esa imagen
y las páginas/datos de prueba no se incorporan. La compilación, firma en GitHub
e instalación en el teléfono quedan pendientes de Yefferson.

## Cambio anterior conservado: tercer modo de lectura nocturna (4.16.13 / 74)

Yefferson pidió conservar la función de contornos del botón solar y añadir una
tercera opción para utilizar toda la interfaz de noche. Base verificada:
4.16.12 / 73, SHA-256
`5703043ff213e329d1be988dc415abfb96161afb1893d38677f301ba0c5bdb90`;
inventario completo en `control/base-4.16.12.json`.

El botón recorre Diurno → Contornos resaltados → Oscuro → Diurno. En oscuro
muestra una luna. Su nombre accesible indica el modo vigente y la siguiente
acción. Se conserva la preferencia existente de vista compacta/ampliada.
El nuevo campo theme se guarda en truchapp_display_preferences_v1 por la misma
ruta confirmada de preferencias. Un documento anterior con highContrast=true
se interpreta como Contornos, sin reescribirlo al iniciar. Si el guardado falla,
se mantiene el modo anterior. Cambiar el tema no genera un aviso de registro
guardado ni modifica registros de producción.

El padre envía el tema al iframe existente del detalle, incluida una ficha
reutilizada. El hijo valida ventana de origen, tipo de mensaje y lista cerrada
de modos; no escribe almacenamiento. Se mantienen los mensajes anteriores que
solo contienen highContrast. El respaldo cifrado y los avisos existentes siguen
funcionando.

night-mode.css se carga al final de ambos documentos. Solo se activa con
html[data-theme=dark]. Usa fondos azul petróleo, superficies oscuras, texto claro
y estados de advertencia distinguibles. Cubre Inicio, Lotes, Almacén, Agenda,
Finanzas, herramientas laterales, formularios, editor de tarjetas, recuperación,
y las cuatro pestañas del detalle. Incluye los estilos del resto de la página
principal y de la bienvenida. Los colores del indicador luminoso y los puntos
de prioridad se preservan expresamente; no se invierten imágenes ni gráficos.
color-scheme adapta los controles del navegador que lo admiten.

El CSS se deriva de los colores originales mediante
`python3 tools/generar_modo_oscuro.py`, sin dependencias ni red. Se conservan las
cascadas separadas del padre y detalle y sus condiciones de anchura. La salida
contiene colores, fondos y degradados; los bordes se cambian solo por color,
sin sobrescribir su ancho/estilo. No contiene tamaños, posiciones ni fuentes.
Tras cambiar colores originales, regenerar y ejecutar tests/night_palette_test.py.
El diseño diurno y los contornos conservan sus CSS originales.

Archivos existentes modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html, ui/lotes/detail/index.html,
ui/shared/display-preferences.js y tests/display-tools.test.cjs
(rutas ui bajo assets). Nuevos: ui/theme/night-mode.css,
tools/generar_modo_oscuro.py, tests/night_palette_test.py y el inventario de base.
El resto del proyecto queda idéntico a la base. No cambian Java/Room, firma,
paquete, respaldo, datos, cálculos, funciones productivas ni módulos originales.

Pruebas: 13 casos de preferencias/avisos, incluidos cinco nuevos para ciclo,
migración, reapertura, fallo de confirmación y mensajes padre/hijo. Cinco casos
de paleta comprueban contraste de los colores base, ausencia de geometría,
recursos/estados, nombres de colores antiguos y generación reproducible. Pasan las regresiones de navegación
del detalle, tarjetas personalizadas, almacenamiento, alimentación e indicadores.

Chrome en un entorno aislado con datos sintéticos, a 390×844 y 320×700: ciclo del
botón, icono y etiquetas, regreso a diurno, cinco módulos principales, editor de
tarjetas, formulario de Agenda, respaldo, resumen/Alimentación/Agua/Sanidad y
registro diario del detalle. La auditoría de textos visibles no encontró pares
por debajo de 4.4 en las superficies revisadas. Los tokens principales se prueban
con mínimo 4.5. Los errores de la primera página de prueba, que omitía el final
del marcado de Agenda, se corrigieron en la muestra aislada; el APK conserva su
marcado completo original. No se alteran diseños de ancho ni se corrigen otros
problemas previos ajenos al tema. Se comprueban recursos, sintaxis, integridad,
versión y alcance por archivo del ZIP.

ImageGen se usó solo como referencia de paleta nocturna. La imagen, las páginas
de prueba y sus datos no se incorporan. No se compila ni instala Android aquí;
Yefferson compilará y firmará en GitHub y verificará el resultado en su celular.

## Cambio anterior conservado: herramientas de Lotes en el menú (4.16.12 / 73)

Yefferson pidió retirar de la cabecera de Lotes los botones «Rendimiento de
lotes» y «Parámetros físico-químicos» y trasladarlos al menú desplegable
izquierdo. Base verificada: 4.16.11 / 72, SHA-256
`4cc5d1464760e536414794b508285366741352cd4b59c57031a45addbafd0432`;
inventario completo en `control/base-4.16.11.json`.

Se retiran únicamente esos dos botones del marcado de Lotes y sus listeners.
Se reutilizan las dos entradas existentes de Herramientas en el menú, sin
crear duplicados. Calidad del agua pasa a llamarse Parámetros físico-químicos.
Los accesos llevan a Lotes y abren las mismas funciones y paneles originales
mediante una interfaz explícita, después de la representación del módulo.
El foco pasa al botón de cerrar del panel. No se depende de botones ocultos.
La descripción dispone del ancho libre y no se conserva el espacio de los
botones. Se mantienen los accesos de contraste/respaldo, selector de vista,
lápiz, engranaje, estado luminoso, buscador fijo y navegación aprobados.

Archivos modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html, ui/lotes/lotes.js y ui/menu/side-menu.js
(rutas ui bajo assets). Se añade solo el inventario de base indicado.
El resto del proyecto queda idéntico a la base. No cambian CSS, cálculos,
registros, almacenamiento, Room, respaldo cifrado, firma ni identidad Android.
Las funciones internas de rendimiento y calidad del agua quedan idénticas.

Validación: sintaxis de los dos scripts; pruebas existentes de preferencias y
avisos (8 casos), navegación del detalle (20 comprobaciones) y tarjetas (7 casos).
Chrome con datos sintéticos aislados a 390×844 y 320×700: ausencia de los botones
en la lista, nombres únicos del menú, apertura/cierre de ambos paneles,
comparación de los ocho lotes y administrador de granjas de agua. Sin
desbordamiento horizontal ni errores de la aplicación. Se revisan integridad,
versión, recursos y alcance por archivo del ZIP. Los datos y páginas de prueba
quedan fuera de la entrega. No se compila ni instala Android aquí; Yefferson
compilará y firmará en GitHub y comprobará la actualización en el celular.

## Cambio anterior conservado: incorporar solo controles seleccionados (4.16.11 / 72)

Yefferson seleccionó partes concretas de la muestra: mayor contraste, acceso al
respaldo, selector compacta/ampliada, aviso inferior después de guardar y botón
de editar a la izquierda del engranaje. Pidió conservar el resto del avance.
Base verificada: 4.16.10 / 71, SHA-256
`f84c365ad371cadd29ce1fd13c1eff1afa41e70cbbda5bf795bfa1ac81dd2bb2`;
inventario completo en `control/base-4.16.10.json`.

Se añaden esos dos accesos junto al título de Lotes y el selector junto a Mis
lotes. La vista ampliada original sigue siendo el valor inicial. Compacta oculta
el progreso y su nota, reduce márgenes y permite regresar a todos los datos con
el selector; no elimina valores. Una transición breve acompaña el cambio de
vista. Contraste y vista son preferencias en truchapp_display_preferences_v1,
confirmadas mediante el almacenamiento compartido. No escriben registros de
producción. El contraste también llega al iframe de detalle por un mensaje
limitado a esa preferencia y validado por origen de ventana.

La nube abre el mismo panel de respaldo cifrado existente. No exporta nada al
tocar el acceso, ni modifica contraseñas, cifrado, restauración o recuperación.
El lápiz aparece inmediatamente a la izquierda del engranaje en cada lote y
abre el Registro diario existente cuando la ficha termina de cargar. Conserva
sesiones, validaciones y guardado; se ejecuta una sola vez. La apertura habitual
de Ver / actualizar lote y el editor de cuatro tarjetas siguen funcionando.

Un aviso petrolero confirma los cambios de producción después del evento de
commit existente. No aparece al cambiar preferencias ni ante un fallo. En el
detalle se conserva su propio aviso y Deshacer, con el nuevo aspecto, para no
duplicar confirmaciones. No se añade la franja permanente de guardado de la
muestra. Movimiento reducido desactiva la animación nueva.

No se incorporan estados nuevos, fechas adicionales en tarjetas, datos de
ejemplo, formularios de la muestra, registro sucesivo entre lotes ni rediseños
de otros módulos. El estado luminoso y los cálculos se conservan.

Archivos existentes modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html, ui/lotes/lotes.js,
ui/lotes/lot-detail-host.js, ui/lotes/detail/index.html,
ui/lotes/detail/detail.js, ui/menu/side-menu.js y
tests/lot-detail-page.test.cjs (rutas ui bajo assets). Nuevos:
ui/shared/display-preferences.js, ui/shared/display-tools.css,
ui/shared/save-feedback.js, tests/display-tools.test.cjs e inventario de base.
El resto queda idéntico al ZIP de base, incluidas las fuentes de almacenamiento,
Room, respaldo, cálculos de lotes, alimentación, indicadores, identidad y firma.

Pruebas: ocho casos nuevos con el almacenamiento real en un entorno simulado
(preferencias, commit confirmado, fallo, no-op, ausencia de avisos duplicados,
mensaje de contraste validado y respaldo sin exportación automática); tres
comprobaciones nuevas del atajo en la prueba del host. Pasan las regresiones de
navegación, tarjetas personalizadas, guardado, alimentación e indicadores.
Chrome 390×844 y 320×700: posición del lápiz, ambas vistas, contraste dentro del
detalle, acceso al respaldo, registro diario con cero, confirmación, Deshacer,
regreso a la lista, guardado de tarjetas y aviso por encima del menú. El buscador
sigue fijo y Mis lotes se desplaza a la derecha sin cubrirse con el menú.

Se comprueban sintaxis, recursos, integridad y alcance por archivo del ZIP.
ImageGen se utiliza solo como referencia visual de colocación; la imagen, los
datos y las páginas de prueba no se incorporan. Compilación y firma en GitHub e
instalación en el celular quedan pendientes de Yefferson.

## Cambio anterior conservado: tarjetas configurables por lote (4.16.10 / 71)

Yefferson pidió activar el engranaje para reemplazar y ordenar las cuatro
estadísticas de cada lote usando las tarjetas disponibles en su detalle.
Base conservada: 4.16.9 / 70, SHA-256
`013e6349600ff675be0ce94364c8a41133c8aa886f1ba607a2c57d75eb399885`;
inventario completo en `control/base-4.16.9.json`.

El engranaje abre «Editar y ordenar», un panel modal con cuatro posiciones,
controles rojos de quitar, opciones verdes de añadir, flechas para ordenar,
Restablecer, Cancelar y Guardar cambios. Se puede reemplazar directamente una
posición sin quitarla primero. Ofrece las doce métricas del resumen del detalle
más Supervivencia. Exige cuatro opciones distintas. Las instalaciones anteriores
mantienen Peces, Peso prom., Biomasa y Supervivencia hasta guardar un cambio.
El panel entra y sale con transiciones breves, resalta la tarjeta cambiada y
respeta movimiento reducido. Las acciones reservan al menos 48 px de zona táctil.
No depende de recursos externos ni de una conexión a Internet.

La selección se guarda por lote en listCards, dentro del documento de lotes
existente, por el guardado transaccional compartido. Al confirmar se consulta
la versión actual del lote y solo se cambia esa preferencia. Abrir, editar,
restablecer un borrador o cancelar no escribe datos. Un fallo conserva la
selección anterior y permite reintentar; se impiden envíos repetidos mientras se
espera confirmación. Se conserva al actualizar la biometría y en los respaldos
existentes. No se cambia el esquema de Room ni el puente Android.

summary-data.js comparte las consultas de resumen y plan de alimentación que
ya utilizaba detail.js. Usa también summary-indicators.js existente para K,
SGR, CV, TEA y carga. Las cifras diferencian cero confirmado de dato ausente.
El editor no registra días, descuenta alimento ni cambia el estado luminoso.

Archivos existentes modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html, ui/lotes/lotes.js, ui/lotes/detail/detail.js y
ui/lotes/detail/index.html (rutas ui bajo assets). Archivos añadidos:
ui/lotes/detail/summary-data.js, ui/lotes/list-cards-data.js,
ui/lotes/list-cards-editor.js, ui/lotes/list-cards-editor.css,
tests/list-cards.test.cjs y el inventario indicado. Resto idéntico a la base.

Verificación: sintaxis de los scripts; siete pruebas nuevas de selección,
consultas, ceros/ausencias, cobertura, plan, conservación y transacción nativa
simulada; regresiones de indicadores, alimentación, guardado y navegación.
Además, 80 escenarios comparan exactamente las consultas compartidas con las
funciones originales de 4.16.9. Chrome a 390×844 y 320×700: apertura, quitar,
reemplazar directamente, añadir, ordenar, guardar, reabrir, cancelar,
restablecimiento como borrador, Escape y detalle del lote. Sin desbordamiento
horizontal en el editor; controles y pie visibles. Se comprueban integridad,
versión, recursos y cambios permitidos del ZIP. Las páginas de prueba quedan
fuera de la entrega. Los tests del proyecto solo incluyen datos sintéticos.
No se compila ni instala Android aquí; compilación, firma en GitHub e instalación
quedan pendientes de Yefferson.

Referencias de interacción: Material Design Motion
https://m3.material.io/styles/motion/overview/how-it-works y Android Accessibility
https://developer.android.com/develop/ui/compose/accessibility/api-defaults.

## Cambio anterior conservado: engranaje en lugar de Estado (4.16.9 / 70)

Yefferson pidió sustituir únicamente el texto «Estado», situado a la derecha
del encabezado de cada tarjeta de Lotes, por el engranaje de su referencia.
Base conservada: 4.16.8 / 69, SHA-256
`fc397b73c18b71c4c2ca3bee07337028a2e045c66c923ad464d27295040e33ea`;
inventario completo en `control/base-4.16.8.json`.

La etiqueta se sustituye por un SVG de engranaje con contorno redondeado,
trazo verde azulado y fondo menta circular de 22 px; el dibujo mide 16 px.
Conserva el nombre accesible «Estado del lote». El indicador luminoso adyacente,
sus colores automáticos, texto accesible y cálculo de salud quedan idénticos.
Es un cambio visual: no se añade una acción de ajustes ni una nueva ventana.
El recurso vectorial se incluye en el marcado, funciona sin conexión y no
necesita imágenes de mapa de bits ni archivos externos.

Archivos modificados: app/build.gradle, app/src/main/assets/ui/lotes/lotes.js,
app/src/main/assets/ui/lotes/lotes.css y CONTINUIDAD.md. Nuevo inventario de base.
El JavaScript solo sustituye un fragmento de marcado; todos los eventos,
funciones de datos, guardado, cálculo, stock, buscador fijo, detalle del lote,
otros módulos, Room/SQLite, firma e identidad de Android se conservan.

Verificado: sintaxis JavaScript; revisión de las tarjetas en Chrome a 390×844
y 320×700, engranaje y luces presentes por cada lote, texto Estado retirado de
la etiqueta visible, nombre accesible conservado y sin desbordamiento. La
comparación con la base verifica que la única diferencia del script es ese
marcado. Se revisan el alcance, versión e integridad del ZIP. No se escriben
pruebas de datos para este ajuste visual. ImageGen se usa solo como referencia;
la imagen generada y los datos de comprobación quedan fuera del proyecto.
Compilación/firma en GitHub e instalación de esta versión quedan pendientes de
Yefferson.

## Cambio anterior conservado: buscador de Lotes fijo al desplazar (4.16.8 / 69)

Yefferson confirmó que la instalación y modificaciones anteriores funcionaron.
Con más de cuatro lotes pidió mantener «Mis lotes», el buscador y Crear nuevo
lote arriba al recorrer la lista, desplazando el título a la derecha para dejar
libre el menú flotante. Base conservada: 4.16.7 / 68, SHA-256
`1851f83c6dffb0e350063601902a71137f535a0ac9db88456ec83f20116b46d4`;
inventario en `control/base-4.16.7.json`.

Un contenedor sticky agrupa únicamente el título y la barra existente. Al llegar
al límite superior del área desplazable, se aplica is-stuck: «Mis lotes» se
desplaza 48 px a la derecha y 12 px abajo; el buscador/botón bajan 22 px para
quedar debajo del menú. La transición usa transform durante 180 ms, sin cambiar
el espacio que ocupan en la lista. Al volver arriba recuperan sus posiciones.
El fondo tapa las tarjetas que pasan por detrás. La barra queda por debajo del
menú flotante y de las ventanas existentes. Movimiento reducido desactiva la
transición. No se duplican ni reemplazan los campos y botones.

Se escucha el scroll real de .phone>.content mediante un evento pasivo y como
máximo una actualización por frame. Se considera el relleno superior real del
contenedor. ResizeObserver y resize actualizan el estado tras filtros, cambios
de tamaño o visibilidad. Cada render consulta el contenedor actual; los eventos
de scroll se instalan una sola vez al iniciar el módulo. Estas acciones no
leen ni escriben datos productivos y no cambian el filtrado ni la creación.

Archivos modificados: app/build.gradle, app/src/main/assets/ui/lotes/lotes.js,
app/src/main/assets/ui/lotes/lotes.css y CONTINUIDAD.md. Nuevo inventario de base.
Se conserva el resto por SHA-256: formularios, detalle del lote, cálculos,
almacenamiento, Room/SQLite, respaldo, stock, portadas, navegación inferior,
otros módulos, firma y com.yefferson.calculadora.

Verificado: sintaxis JavaScript; revisión de los archivos Android integrados
en Chrome a 390×844 y 320×700 con ocho lotes ficticios aislados. Barra normal
arriba de la página, fijación al bajar, título despejado a la derecha del menú,
buscador debajo del botón flotante, sin desbordamiento horizontal. Búsqueda,
reducción a un resultado, apertura del formulario Crear nuevo lote, vuelta al
inicio y nuevo render de Lotes conservan un único buscador/botón. Se revisa que
el menú flotante siga delante de la barra y se pueda abrir. Se comprueban el
alcance de los cambios, versión e integridad del ZIP. La imagen generada es
solo una referencia visual y no se añade al APK; tampoco se añaden los datos ni
las herramientas de prueba. Compilación/firma en GitHub e instalación de esta
versión en el teléfono quedan pendientes de Yefferson.

## Cambio anterior conservado: integrar la muestra de Lotes aprobada (4.16.7 / 68)

Yefferson aprobó la muestra v6 y pidió incorporarla al ZIP de Android. Se parte
de la entrega funcional 4.16.6 / 67, SHA-256
`a96fe00174aede582e35772ac349321a72df191fdfd6e04b24bb67a79f3193fc`.
La base se conserva; su inventario completo queda en `control/base-4.16.6.json`.
Muestra aprobada: TruchApp-Lotes-Muestra-v6.html, SHA-256
`f4e3ef6a7292f5e1e5408d35d1bcdd86a9259fb41c02e778bb38cd62d66f8393`.

En Lotes se retira «Qué conviene registrar» con sus referencias técnicas y se
elimina el fondo, borde, sombra y relleno exterior de «Mis lotes». El buscador
y cada tarjeta conservan sus propios estilos. «＋ Crear nuevo lote» pasa a la
derecha del buscador en una fila adaptable, con su mismo ID, evento y formulario.

En el detalle, la barra Resumen/Alimentación/Agua/Sanidad mide 58 px, con botones
de 48 px e iconos de 18 px. Se mantienen etiquetas, colores, selección y eventos.
El desplegable Biometría se retira del resumen; su mismo formulario se conserva
en un diálogo abierto desde las tarjetas y Alimentación. Reutiliza la apertura,
cierre, bloqueo durante guardado y notificación al menú flotante existentes.
Guardar una biometría cierra ese diálogo y devuelve el resumen. No cambian las
reglas de un control por día, los cálculos ni el guardado de alimento/bajas.

Archivos de aplicación modificados: app/build.gradle,
app/src/main/assets/ui/lotes/lotes.js, lotes.css,
app/src/main/assets/ui/lotes/detail/index.html, detail.js y header-tabs.css.
Se adapta tests/lot-detail-feeding-ui.test.cjs para reconocer los diálogos por
su marcado y comprobar el cierre/aviso del formulario biométrico. También se
actualiza este documento y se añade el inventario de la base. No se reconstruyen
módulos ni se incorpora código de muestra, datos temporales, Reiniciar, Map,
srcdoc, imágenes generadas ni herramientas del editor al proyecto Android.

Verificado: sintaxis de los dos JavaScript modificados; 15 comprobaciones de
integración del detalle y 17 de navegación/guardado con DOM simulado, incluidas
biometría persistida, cierre del formulario, un control por día, cero confirmado,
vista reutilizada y protección de sesión. Revisión de los archivos integrados
en Chrome a 390×844 y 320×700: buscador y botón juntos, sin contenedor exterior,
sin nota informativa, cuatro pestañas completas y funcionales, doce tarjetas,
sin desplegable Biometría en resumen, costo después de las tarjetas, apertura
y cierre del diálogo biométrico con ocultación/restauración del menú flotante,
sin desbordamiento horizontal. La comprobación visual usa datos aislados fuera
del APK. Se validan IDs, recursos locales, integridad, versión y alcance del ZIP.

El resto de archivos se conserva por SHA-256: identidad
com.yefferson.calculadora, firma, Room/SQLite, respaldo, almacenamiento, stock,
servicios nativos, portadas y otros módulos. Se entrega únicamente el ZIP fuente;
compilación y firma en GitHub e instalación en el teléfono quedan pendientes de
Yefferson. No se ejecutan Actions ni se modifica su repositorio.

## Cambio anterior conservado: menú flotante elevado y más visible (4.16.6 / 67)

Yefferson confirmó el cambio anterior y mostró que el botón quedaba demasiado
abajo en su Android, cubriendo parte del nombre del lote y del texto de Almacén.
Pidió subirlo y destacar su forma/color. Base conservada: 4.16.5 / 66,
SHA-256 `39524deec6f53d45a2243352c6b3f1bc31915e989a6e5d9d476598d5ea7dceef`;
inventario en `control/base-4.16.5.json`.

El botón se ancla a 6 px del borde superior del área de la app. Se retira
max(8px, env(safe-area-inset-top)) de su posición: WebViewHost ya aplica el
espacio de la barra de estado mediante el contenedor nativo. La separación
adicional en la captura es compatible con volver a sumar esa área. No se
modifica el manejo nativo de las barras del sistema ni el menú inferior.

Se conserva el tamaño de 39×39 px y la ubicación horizontal aprobada. El botón
pasa a ser circular, con degradado turquesa claro #b0f3e6 → #60d8cb, borde menta,
sombra suave y el mismo SVG en petróleo #103f46, ahora con trazo 2.1. El foco de
teclado tiene un contorno sólido. La cabecera continúa fuera del flujo y no
vuelve la franja blanca. Los espacios laterales de las cabeceras no cambian.

Archivos modificados: app/build.gradle, CONTINUIDAD.md y
app/src/main/assets/ui/menu/floating-menu.css. Nuevo: control/base-4.16.5.json.
Todos los HTML, JavaScript, funciones de menú/formularios, portadas, datos,
cálculos, stock, Room/SQLite, código nativo, firma e identidad Android se
conservan idénticos a la base por SHA-256. No se reconstruyen módulos.

Verificado en Chrome a 390×844 y 320×700: botón en y=6, tamaño 39×39, forma
circular, colores y trazo correctos. El nombre del lote empieza en y=48; el
botón termina en y=45. La etapa conserva espacio a su derecha. En Almacén, los
títulos y la descripción quedan libres y no hay desbordamiento horizontal.
El botón abre/cierra el menú lateral existente. Contraste mínimo calculado del
icono sobre los extremos del degradado: 6.69:1 (extremo claro 9.23:1).
Se verifica estructura CSS, versión, alcance e integridad del ZIP. No se añaden
ni repiten pruebas de datos para este cambio exclusivamente visual; sus scripts
y las pruebas anteriores permanecen intactos. La revisión de navegador no
reproduce los insets de un Android real: compilación en GitHub, instalación y
comprobación final en el teléfono quedan pendientes de Yefferson.

ImageGen se utilizó para una referencia visual del acabado. La imagen no se
incorpora al APK ni sustituye los controles reales de la aplicación.

## Cambio anterior conservado: acceso de menú flotante sin franja superior (4.16.5 / 66)

Yefferson pidió desaparecer la franja blanca del encabezado principal y dejar
solo el botón izquierdo como acceso flotante. Se continúa desde 4.16.4 / 65,
SHA-256 `933ca72ce6aee420667ab2c7df394ec50d22a40349cbc2dffd68ce7dfbe82181`;
base conservada e inventario en `control/base-4.16.4.json`.

El encabezado queda fuera del flujo, transparente y limitado a los 39×39 px del
botón, colocado arriba a la izquierda con una sombra suave. Conserva el mismo
#tnMenuOpen, SVG, etiquetas, estado expandido y eventos del menú existente. No
se crea un segundo botón. Su antigua fila de aproximadamente 52 px se devuelve
al contenido; el menú inferior petróleo/turquesa no cambia. El #status oculto
sigue presente para la compatibilidad de los scripts anteriores.

Se reserva solo el espacio lateral necesario en la primera línea de Inicio,
Lotes, Almacén, Agenda, Finanzas y los accesos conservados de Calculadora/IA.
En detalle la cápsula de etapa queda a la derecha del botón, manteniendo los
botones de información y retorno a la derecha. No cambian los tamaños aprobados
del nombre, tarjetas, pestañas ni el fondo de la cabecera del lote. Al envolver,
la fecha de Agenda sigue legible en pantallas de 320 px.

Los diálogos internos del iframe notifican únicamente si hay un formulario
abierto. El host oculta el acceso flotante mientras ese diálogo está abierto y
lo recupera al cerrarlo o salir del lote, para que no cubra sus títulos/campos.
El mensaje usa la fuente y sesión verificadas ya existentes; los mensajes de
una sesión anterior se ignoran. Se mantienen los bloqueos del guardado y los
registros/validaciones anteriores. Esta notificación no escribe datos.

Archivos modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html (solo enlace CSS),
app/src/main/assets/ui/lotes/detail/header-tabs.css y detail.js,
app/src/main/assets/ui/lotes/lot-detail-host.js,
tests/lot-detail-page.test.cjs y tests/lot-detail-feeding-ui.test.cjs.
Nuevos: app/src/main/assets/ui/menu/floating-menu.css y control/base-4.16.4.json.
No se modifican cálculos, stock, esquemas, módulos productivos, Room/SQLite,
firma, applicationId, portadas ni los archivos del menú inferior.

Verificado: sintaxis de ambos JavaScript modificados; las 14 comprobaciones
existentes del detalle y 17 del host con DOM simulado, incluyendo comunicación
de apertura/cierre, sesión antigua ignorada y recuperación del acceso al salir.
En Chrome a 390×844 y 320×700 la cabecera ocupa solo el área transparente del
botón, el contenido empieza en y=0, no existe una franja adicional y la cápsula
de etapa no se superpone. El menú abre/cierra, los formularios de Alimentación
y Sanidad abren y el acceso flotante se oculta/restaura correctamente.
Revisadas las cinco cabeceras reales en ambos tamaños sin desbordamiento.
Se verifican IDs, scripts inline, recursos locales, integridad y alcance del ZIP.

ImageGen se utilizó para una referencia visual. La imagen no se incluye en el
APK: la aplicación conserva controles reales. La compilación e instalación en
Android quedan pendientes del flujo de GitHub y del teléfono de Yefferson.

## Cambio anterior conservado: detalle más compacto sin barra de registro (4.16.4 / 65)

Yefferson confirmó el diseño de la cabecera y pidió retirar el bloque inferior de
«+ Registrar día», reducir los espacios entre la etapa, el nombre y los datos de
ingreso, y ampliar un poco el nombre del lote. Base conservada: 4.16.3 / 64,
SHA-256 `21995535ab56f61e802e7f3f9c16d1c3c8e371aa5e5b61252c310dfc0ea7d673`;
inventario en `control/base-4.16.3.json`.

Se elimina el footer completo del detalle, su botón #mainAction, sus estilos y
sus referencias de actualización/evento. El espacio se devuelve al contenido
con desplazamiento. Las notificaciones de guardado quedan a 12 px del borde
inferior del detalle, al no existir la barra que antes ocupaba ese espacio.
No se elimina el registro diario: siguen sus accesos en Alimentación, las
ventanas de las tarjetas y «Registrar bajas» en Sanidad. Agua conserva el
registro desde cada tarjeta y Sanidad su botón propio. Los formularios, sus
validaciones y el guardado compartido no cambian.

La cabecera reduce el margen entre nombre y metadatos de 24 a 8 px, además de
compactar sus separaciones exteriores y retirar la altura mínima del bloque de
identidad. El nombre pasa de 20 a 24 px (de 19 a 23 px hasta 359 px de ancho).
Esta excepción solicitada se limita al nombre del lote; los demás títulos
conservan el tamaño aprobado. Se reserva espacio al SVG de la trucha para que
los metadatos puedan envolver sin quedar debajo de la ilustración. Se mantienen
la paleta, la etapa, las cuatro pestañas, los iconos y las acciones superiores.
La cabecera principal y el menú inferior siguen accesibles y con su diseño previo.

Archivos modificados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/ui/lotes/detail/index.html, detail.js y header-tabs.css;
tests/lot-detail-feeding-ui.test.cjs adapta su comprobación al botón existente
dentro de Alimentación. Nuevo: control/base-4.16.3.json. En detail.js solo se
retiran la función, la llamada y el evento del botón eliminado. Los scripts
inline, todas las pestañas y sus SVG, los otros 12 indicadores y los archivos de
cálculo, almacenamiento, host de página, Room/SQLite y firma quedan intactos.

Verificado: sintaxis de detail.js; 14 comprobaciones existentes del detalle con
DOM simulado (incluye registro diario y cero confirmado desde Alimentación),
y 14 del host de página. En Chrome a 390×844 y 320×700 no existe el footer ni su
botón, el nombre calcula 24/23 px, los metadatos conservan su margen de 8 px y
no hay desbordamiento horizontal. Las cuatro pestañas cambian de panel y los
formularios de alimentación y sanidad abren desde sus accesos conservados.
Se revisan recursos, IDs, diferencias e integridad del ZIP antes de entregarlo.
No se compila ni instala Android aquí: queda pendiente el flujo de GitHub y la
comprobación final en el teléfono de Yefferson.

## Cambio anterior conservado: cabecera y pestañas del lote (4.16.3 / 64)

Yefferson pidió aplicar al detalle el estilo de su primera referencia, especialmente
los botones destacados. Su segunda captura muestra el detalle ya integrado como
página, con la cabecera y el menú inferior aprobados. Se continúa sobre 4.16.2 / 63,
SHA-256 `da02f56e54c68a36d7f004566b649d4951b0d876f41325837ecf2facf7886723`;
inventario conservado en `control/base-4.16.2.json`.

El cambio es de presentación: cabecera con degradado verde petróleo y borde
inferior redondeado, etapa en una cápsula superior, acciones de información y
retorno claras sobre superficies translúcidas, y nombre/metadatos en blanco.
Se mantiene el tamaño moderado aprobado del nombre y los datos reales del lote.
El SVG animado existente de la trucha se conserva. No se añaden días, fechas o
valores ficticios de las imágenes.

Las cuatro pestañas se presentan sobre una barra blanca con sombra suave,
iconos encima de las etiquetas y una tarjeta verde petróleo para la selección.
Se conservan Resumen, Alimentación, Agua y Sanidad, todos los identificadores,
roles, acciones y la flecha de volver. El #stage solo cambia de lugar dentro de
la cabecera. Una regla nueva asegura que el icono de Alimentación no se oculte
en pantallas estrechas; las etiquetas completas caben a 320 px.

ImageGen se usó para una referencia visual. El APK utiliza estilos y controles
reales; no incluye la imagen generada ni sustituye la interfaz por una captura.
La navegación de página entre cabecera y menú inferior permanece en su host
anterior. No se modifican formularios, indicadores, cálculos, registros, inventario,
Room/SQLite, firma, applicationId, portadas ni otros módulos.

Archivos cambiados: app/build.gradle, CONTINUIDAD.md y
app/src/main/assets/ui/lotes/detail/index.html. Archivos nuevos:
app/src/main/assets/ui/lotes/detail/header-tabs.css y control/base-4.16.2.json.
Todos los JavaScript permanecen idénticos a la base. El marcado y SVG de la
navegación de pestañas también permanecen idénticos; cambia su presentación.

Verificado: 14 comprobaciones existentes del detalle y 14 del host con DOM
simulado; mismos IDs sin duplicados, mismos scripts inline, referencias locales
válidas, CSS con delimitadores válidos y alcance del ZIP controlado por SHA-256.
En Chrome con datos de prueba aislados, las cuatro pestañas cambian de panel y
la seleccionada muestra fondo oscuro/texto blanco. Revisadas a 390×844 y 320×700:
cuatro iconos visibles, etiquetas completas y sin desbordamiento horizontal.
Contraste calculado: selección 11.55:1, etiquetas inactivas 5.02:1 y metadatos
sobre el extremo más claro del degradado 4.75:1. No se añaden pruebas para este
ajuste reversible; se usan las existentes y la revisión visual de los controles.
La imagen generada es una propuesta, no prueba de ejecución. La compilación e
instalación Android y revisión final en el teléfono quedan pendientes de GitHub.

## Cambio anterior conservado: detalle del lote como página (4.16.2 / 63)

Yefferson confirmó que le gustó la navegación inferior de 4.16.1. Pidió que
«Ver / actualizar lote» abra una página que ocupe el área útil de la aplicación,
sin cubrir el encabezado ni el menú inferior. La base conservada es 4.16.1 / 62,
SHA-256 `9dd44a40b12469c44e0bcd940d2cd94e18c5bf3575d292c8f9be677d162653cc`;
su inventario está en `control/base-4.16.1.json`.

El host ahora monta la vista reutilizable dentro de #lotes, junto a #lotesRoot.
La lista se oculta solo mientras se ve la página. Se retiran la capa fija de
pantalla completa, el fondo oscurecido, el margen exterior y el marco redondeado.
La cabecera del lote, sus pestañas, sus doce tarjetas y el botón de registrar
conservan sus diseños; el botón inferior del detalle queda antes de la barra
principal. Un enlace de retorno con flecha conserva #closeDetail y vuelve a la
lista con su posición de desplazamiento y foco. La página tiene rol de región;
los formularios y ventanas internas conservan su semántica de diálogo.

El contenedor usa el espacio restante bajo la cabecera y reserva la altura real
del menú inferior, observada con ResizeObserver y actualizada al redimensionar.
Se conservan colores y SVG de ambos menús. La barra y el encabezado siguen
accesibles. Cambiar de módulo cierra la página mediante la navegación existente.
Esc del menú lateral lo cierra sin cerrar también la página. El foco de la página
ya no queda encerrado como si fuera una ventana modal.

Durante una escritura se bloquean temporalmente los accesos de cabecera/barra y
la salida; se restauran con la confirmación o el fallo. Se mantienen el token de
sesión, la revisión, el guardado único, la carga con reintento, los datos nuevos
por lote y el enlace a Almacén. No cambian cálculos, raciones, inventario, Room,
firma, applicationId ni otras funciones. Inicio y Finanzas ya navegan a Lotes
antes de abrir una ficha; esos accesos siguen usando el mismo host.

Archivos cambiados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/ui/lotes/lot-detail-host.js y lot-detail-host.css,
ui/lotes/detail/index.html y detail.js (rutas ui bajo assets). En detail.js solo
cambia la condición del bloqueo de Tab para reservarlo a paneles modales.
Archivos nuevos: ui/lotes/detail/page-layout.css, tests/lot-detail-page.test.cjs,
y control/base-4.16.1.json. El index.html principal, ambos menús y los archivos de
cálculo/almacenamiento se mantienen idénticos a la base por SHA-256.

Verificado: 14 comprobaciones del host con DOM simulado (montaje, sesión nueva,
altura del menú, scroll/foco, cambio de módulo, guardado único, salida bloqueada,
fallos recuperables y respuestas antiguas ignoradas); 14 comprobaciones existentes
del detalle (pestañas, formularios y ceros); 9 casos de almacenamiento existentes.
Sintaxis JS e integridad, recursos locales, IDs y comparación acotada del ZIP.

Prueba visual local con Chrome: página sin marco, cambio a Almacén, abrir/cerrar
menú lateral, Esc y regreso a lista. En viewports anidados 390×844 y 320×700 la
página empieza en y=52 y termina respectivamente en y=767.5 / 623.5, justo antes
del menú. No hay desbordamiento horizontal. Se usó una página de prueba local
con datos ficticios aislados; no se incluye en el ZIP ni cambia datos del usuario.
Esto no equivale a una instalación ni renderizado en un Android real. Compilación,
instalación y comprobación final en el teléfono quedan pendientes de GitHub.

## Cambio anterior conservado: encabezado y navegación (4.16.1 / 62)

Yefferson confirmó la incorporación correcta de 4.16.0 y pidió trabajar directamente
en el ZIP: quitar TruchApp, Gestión acuícola y el aviso del modelo de la cabecera;
conservar el botón izquierdo; dar mayor presencia a la barra inferior.

Base funcional: 4.16.0 / 61, SHA-256
`71efc6c154e30d26f383a819417d87cf6c58149bee4d609744f7690d40d3f41a`.
Inventario: `control/base-4.16.0.json`. Se conserva la base sin sobrescribirla.

La cabecera ya no tiene el nombre/subtítulo ni la pastilla visible de modelo.
Conserva íntegro el botón y su acceso al menú lateral, con altura más compacta.
El elemento #status queda oculto para mantener compatible updateStatus(), sin
cambiar descargas, estado nativo ni los scripts existentes.

La navegación inferior usa un fondo azul petróleo (#1b545b, #123e46, #0e343d),
iconos/texto claros (#d8eee9) y la selección turquesa (#aae9df, #71cdc2), con
texto/icono oscuro (#103a3f). Conserva cinco destinos, SVG, etiquetas, selección
activa, aria-current, foco de teclado y preferencia de movimiento reducido.
Se mantiene el espacio inferior reservado para no tapar el contenido.

ImageGen se utilizó solo para una referencia visual de la paleta. El APK usa
HTML/CSS y los SVG previos, no una imagen plana ni un nuevo recurso raster.

Archivos cambiados: app/build.gradle, CONTINUIDAD.md,
app/src/main/assets/index.html y ui/menu/side-menu.css / bottom-nav.css (ui bajo
assets). Archivo añadido: control/base-4.16.0.json. Ningún JavaScript cambia.
Todos los archivos del detalle de lote aprobado, cálculos, guardado, base Room,
firma, identidad Android, portadas y restantes módulos se conservan por SHA-256.

Validación: scripts inline idénticos, botón y navegación inferior idénticos,
IDs DOM preservados, 39 referencias locales existentes, CSS con delimitadores
válidos y colores de etiquetas con contraste mínimo calculado de 7.03:1 en
inactivos y 6.60:1 en activo. Comparación del ZIP exige solamente el alcance citado.
No se escriben pruebas nuevas para este ajuste visual reversible. No se repite
la batería de datos al conservar íntegros sus scripts. La imagen es una propuesta,
no una captura del APK ejecutándose. La compilación, revisión visual e instalación
Android quedan pendientes de Yefferson mediante GitHub.

## Integración anterior conservada: detalle aprobado (4.16.0)

Yefferson aprobó integrar la muestra v15 con su proyecto JSON del 28/10/2026.
La base es el ZIP 4.15.3 / 60, SHA-256
`d89669e165dfbd56322c380d19301f56dd053752913a95eba70fb25fe2f66fcb`;
se conserva fuera de esta entrega como recuperación y se inventaría en
`control/base-4.15.3.json`. El diseño recibido está en
`control/approved-detail-design.json`; es referencia visual, no datos productivos.

- Cabecera compacta, ilustración existente y radio de 11 px aprobados.
- Situación actual: Peces vivos, Alimento total consumido, Alimentación para hoy.
  Mortalidad/descarte y última fecha proceden de registros reales; no del ejemplo.
  Alimentación para hoy muestra la ración del plan y lo registrado se indica debajo.
- Biometría: Peso promedio (g), Talla promedio (cm), Biomasa. Cada fecha corresponde
  a su medición; una talla antigua no se mezcla con un peso nuevo para calcular K.
- Indicadores: K estimado con promedios del mismo control, TCE/SGR del período,
  CV muestral (n−1), FCR aparente existente, TEA aparente y densidad de carga.
  Los doce indicadores abren sus datos o la ventana previa correspondiente.
- K = 100 W/L³ (g, cm); TCE = 100(ln Wf−ln Wi)/días; CV = SD/promedio×100;
  TEA = ganancia neta de biomasa/alimento×100; densidad = biomasa/volumen.
  Se conservan valores cero, crecimiento negativo y TEA mayor de 100 cuando
  corresponde. Faltantes, un solo peso, fechas iguales, volumen cero o alimento
  cero no generan divisiones inválidas. TEA requiere la cobertura completa y
  ganancia positiva del FCR existente; no corrige biomasa perdida por bajas.
- Las ventanas muestran fórmulas, período/origen y datos necesarios, con fuentes
  primarias DOI 10.3390/ani14172567 (trucha, K/SGR) y 10.47853/FAS.2025.e2
  (definiciones de CV/eficiencia). No se añaden umbrales sanitarios o raciones.
- Se retira el texto inferior marcado del costo de alimentación solo en detalle
  mediante una opción compacta; las llamadas compartidas conservan su presentación.
- No se incluyen el editor, el puente de demostración ni valores ficticios en los
  assets. No cambian Room/SQLite, firma, applicationId, esquema detailState v2,
  guardado compartido ni los archivos de otros módulos. Consultar no crea salidas.

Archivos existentes cambiados: app/build.gradle, este resumen,
app/src/main/assets/ui/lotes/detail/index.html y detail.js,
app/src/main/assets/ui/feeding/feeding-ui.js (opción compacta, valor por defecto
conservado), tests/lot-detail-feeding-ui.test.cjs (carga del nuevo script y casos).
Nuevos: summary-indicators.js y approved-summary.css junto a detail.js,
tests/lot-summary-indicators.test.cjs y los dos archivos de control citados.

Verificado: 83 casos de lógica (73 previos y 10 de indicadores), más 14
comprobaciones de integración con DOM simulado: apertura, orden y 12 tarjetas,
ventanas propias, consultas sin escritura, sin datos ficticios, costo compacto,
guardado de biometría, un control por día, alimentación cero, reutilización por
lote y enlace a Almacén. Sintaxis JS, recursos referenciados, IDs y alcance por
SHA-256 se comprueban antes de empaquetar. El ensayo de interfaz
storage-ui.test.cjs no pudo iniciar: falta su ejecutable Chromium en este entorno.
Sus fuentes de producción no cambian. No se instaló otro navegador para el ensayo.
No se dispone de SDK Android configurado; compilación/instalación y revisión visual
real en el teléfono quedan pendientes de Yefferson mediante su flujo de GitHub.

## Estado conservado de módulos anteriores

- Aplicación: TruchApp. applicationId/namespace: `com.yefferson.calculadora`.
- Última entrega de código: **4.16.6 / versionCode 67**.
- Yefferson confirmó la instalación y los cambios de 4.15.2 el 23/10/2026.
  La versión 4.15.3 unificó el tamaño de los títulos principales de los módulos,
  ventanas y detalle del lote con la referencia «Alimentación del lote»:
  20 px, o 19 px en pantallas de hasta 360 px.
- Los tutoriales internos de Lotes y Agenda siguen retirados.
- Se conserva la presentación compacta y blanca de Alimentación de 4.15.1.
- Biometría ahora está dentro de Resumen como bloque desplegable, con el formulario
  existente y un botón propio para guardar. Mantiene un control por día.
- La segunda pestaña es Alimentación. Consulta el plan existente, lo suministrado
  hoy, la diferencia con el plan, la biomasa y el agua que lo sostienen, productos
  y lotes de alimento del almacén compartido, cobertura y registros de siete días.
- El escenario del lote proyecta desde mañana una ración constante usando primero
  los saldos que vencen antes. No reserva stock, no anticipa crecimiento ni compras
  y no equivale a la cobertura de toda la granja. Otra cifra utiliza salidas y ajustes
  negativos globales recientes del producto, con su ventana de observación visible.
- Alimentación abre el registro diario ya existente y el módulo Almacén mediante
  su navegación existente. Consultar o elegir un producto no escribe datos ni
  genera salidas. Las entregas siguen guardándose una sola vez desde el registro diario.
- Se conservan Sanidad, el icono de instalación, la bienvenida, las cuatro portadas
  blancas, Mis lotes compacto y los módulos anteriores.
- Base funcional conservada: 4.15.2 / 59; SHA-256
  `c77376d4c6453e6d898c3b91361c673d5a965c06c928eda3afe113a567f77c53`.
  Inventario: `control/base-4.15.2.json`. Describe la base antes de este ajuste,
  no el ZIP resultante. Los inventarios anteriores también se conservan.
- Validación de 4.15.3: estructura CSS y referencias al nuevo archivo verificadas.
  En los dos HTML solo se añade el enlace CSS al final de sus estilos; todos sus
  identificadores y scripts permanecen idénticos. Pasan las 9 comprobaciones
  existentes del detalle con DOM simulado. La comparación completa del ZIP exige
  que solo cambien los archivos previstos.
  En 4.15.0 también habían pasado los 16 casos de cálculo de la pestaña y los
  57 casos anteriores de alimentación, Inicio, Sanidad y almacenamiento.
- La compilación manual en GitHub y la instalación de 4.15.3 quedan pendientes
  de Yefferson. No se realizó renderizado en Android ni compilación del APK aquí.

## Mapa breve

Las rutas siguientes parten de `app/src/main/`:

| Trabajo | Archivos principales |
| --- | --- |
| Entrada y conexión de módulos | `assets/index.html` |
| Inicio | `assets/ui/dashboard/` |
| Lista de lotes | `assets/ui/lotes/lotes.js`, `lotes.css` |
| Detalle del lote | `assets/ui/lotes/detail/`, `lot-detail-data.js`, `lot-detail-host.js` |
| Sanidad | `assets/ui/lotes/health/` y `detailState.health` dentro del lote |
| Alimentación compartida | `assets/ui/feeding/` (guardado y valoración existentes) |
| Pestaña Alimentación por lote | `assets/ui/lotes/feeding/`, cargada por `assets/ui/lotes/detail/index.html` |
| Biometría en Resumen | `assets/ui/lotes/detail/index.html` y `detail.js`, sección `biometrySection` |
| Agenda, Almacén, Finanzas | `assets/ui/agenda/`, `almacen/`, `finance/` |
| Bienvenida y cuatro portadas | `assets/ui/intro/` |
| Guardado y recuperación | `assets/ui/shared/storage*`, `recovery-ui.js` y capa nativa |
| Respaldos y menú | `assets/ui/menu/` |
| Icono de instalación | `AndroidManifest.xml`, `res/mipmap-*`, `res/values/launcher_colors.xml` |

`ARCHITECTURE.md`, `ALMACENAMIENTO-4.13.md` y `CHANGE-SCOPE.md` contienen contexto
anterior. Sus números de versión históricos no sustituyen al estado actual ni al
alcance de la nueva solicitud. Verificar el código antes de dar hechos por vigentes.

## Método para cada cambio

1. Identificar la base y generar un inventario antes de editar. Guardar una copia
   de recuperación y anotar la petición, los archivos previstos y lo pendiente.
2. Buscar el módulo y leer fragmentos. Mantener recursos grandes como archivos;
   calcular hashes por bloques, sin pegarlos ni cargarlos enteros en el chat.
3. Hacer el cambio localizado sobre la base. Las muestras usan datos y claves
   separados; la autorización de integración debe existir antes de tocar el APK.
4. Ejecutar las verificaciones que correspondan. Un ajuste de texto puede requerir
   sintaxis y revisión estructural; un cambio de datos requiere probar guardado,
   recuperación, errores y compatibilidad. No inventar compilaciones exitosas.
5. Comparar todos los archivos por SHA-256 y revisar la lista de cambios permitidos.
   Volver a comprimir el contenedor ZIP no significa reescribir el código fuente:
   el control comprueba que los archivos ajenos al cambio sigan idénticos.
6. Actualizar este resumen, empaquetar y conservar la base anterior. Para el código
   alojado en GitHub, usar commits y versiones recuperables cuando corresponda;
   no hacer pushes ni iniciar compilaciones sin autorización.

## Herramienta incluida

Requiere Python 3.9 o posterior y solo su biblioteca estándar. No instala paquetes,
no usa internet ni compila Android. Procesa el contenido en bloques de 1 MiB;
la lista de rutas y hashes crece con el número de archivos del proyecto.

Inventariar un ZIP antes de trabajar:

```bash
python3 tools/continuidad.py inventario base.zip --salida inventario.json
```

Comparar dos versiones y rechazar cambios fuera del alcance (repetir `--permitir`):

```bash
python3 tools/continuidad.py comparar base.zip nuevo.zip \
  --permitir app/src/main/assets/ui/lotes/lotes.js \
  --permitir app/build.gradle
```

Empaquetar desde la base con una carpeta que contenga solo los archivos editados,
conservando sus rutas relativas:

```bash
python3 tools/continuidad.py empaquetar base.zip --cambios cambios \
  --salida Calculadora-Yefferson-Proyecto.zip \
  --permitir app/src/main/assets/ui/lotes/lotes.js \
  --permitir app/build.gradle
```

No se reemplaza la base ni una salida existente. Las eliminaciones requieren
`--eliminar ruta`; una ausencia accidental en la carpeta de cambios no elimina
archivos del proyecto. Una comparación sin `--permitir` exige contenidos idénticos.
SHA-256 detecta cambios de bytes; no acredita que una función sea correcta ni es una
firma del autor. ZIP64 permite contenedores grandes, pero siguen aplicándose los
límites de transferencia, tiempo, disco y contexto del entorno disponible.

## Registro histórico: preparación de continuidad

Alcance: reglas de trabajo, resumen, inventario de la base y herramienta de control.
En esa preparación se conservaron los 175 archivos existentes. La herramienta se validó
con pruebas que incluyen cambios ajenos al alcance, eliminaciones, entradas ZIP
duplicadas/rutas inválidas y conservación de un recurso sintético de 64 MiB.
La compilación Android y la instalación no son parte de esta preparación.

Para retomar en otra conversación, adjuntar el último ZIP y pedir: «Lee AGENTS.md y
CONTINUIDAD.md; continúa desde esta base y modifica solo [la parte solicitada]».
Estos archivos permiten recuperar contexto cuando se tiene acceso al proyecto;
no cambian la capacidad ni la memoria permanente del modelo.

## Registro histórico: Alimentación y Biometría (4.15.0)

Archivos existentes modificados: `app/build.gradle`, `assets/ui/lotes/detail/index.html`,
`assets/ui/lotes/detail/detail.js`, `assets/ui/lotes/lot-detail-host.js` (rutas de assets
bajo `app/src/main/`) y este resumen. Se añaden el módulo de consulta Alimentación,
una imagen de cabecera optimizada, sus pruebas y el inventario de la base.

La imagen decorativa se preparó con ImageGen y se empaquetó en PNG RGBA de
512 × 341 px, aproximadamente 159 KB. El contenido técnico se basa en FAO,
PRODUCE/SINACUI (2022) y FONDEPES; los enlaces y límites del cálculo se incluyen
sin conexión dentro de la pestaña. Las proyecciones de stock son cálculos del
producto, no una recomendación de ración publicada por esas instituciones.

## Registro histórico: presentación de Alimentación (4.15.1)

Solicitud: reducir los textos exagerados y aproximar la interfaz de Alimentación
a la tarjeta blanca con bordes finos de la segunda imagen enviada. No se añade
contenido ni se cambia la ración, cobertura, registro diario o almacenamiento.

Archivos existentes modificados: `app/build.gradle`, este resumen y
`app/src/main/assets/ui/lotes/feeding/feeding-panel.css` / `feeding-panel-ui.js`.
Archivo añadido: `control/base-4.15.0.json`.

La tarjeta del plan reúne ración diaria, registrado hoy y pendiente en tres
columnas con divisores finos. Conserva los estados «Sin cálculo», «Sin registro»,
cero y exceso, y las mismas acciones. Las tarjetas de stock y consulta usan
tipografía más pequeña y superficies blancas. La ilustración se conserva.

Los cambios en JavaScript solo reorganizan el marcado de esa tarjeta. Los archivos
de cálculo, guardado, navegación, Biometría, otras pestañas, portadas y recursos
de la aplicación deben quedar idénticos a la base. El alcance se comprueba por
SHA-256 al empaquetar; no se reconstruye el proyecto desde cero.

## Registro histórico: retirar tutoriales internos (4.15.2)

Solicitud: quitar los tutoriales de Lotes y Agenda. Se eliminan su contenido,
estilos, eventos, comprobaciones de «visto» y llamadas de apertura. También se
retira el acceso «Ver tutorial otra vez». La navegación continúa renderizando
Lotes y Agenda con sus funciones existentes.

Archivos existentes modificados: `app/build.gradle`, este resumen,
`app/src/main/assets/index.html`, `ui/lotes/lotes.js`, `ui/lotes/lotes.css`,
`ui/agenda/agenda.js` y `ui/agenda/agenda.css` (rutas ui bajo assets).
Archivo añadido: `control/base-4.15.1.json`.

No se modifican los datos ni las claves de almacenamiento compartido. Las marcas
antiguas de tutorial visto quedan sin uso; no se borra ni se reinicia información.
La bienvenida, las cuatro portadas y el bloque Alimentación se conservan idénticos
a la base, al igual que los demás archivos fuera del alcance. No se compila ni se
instala Android en este entorno; Yefferson lo hará con su flujo de GitHub.

## Registro histórico: tamaño de títulos (4.15.3)

Solicitud: usar en los títulos el tamaño de «Alimentación del lote» de la captura
aprobada. Se añade `app/src/main/assets/ui/theme/title-sizes.css`, con una medida
compartida de 20 px y 19 px hasta 360 px. Se carga tanto en la página principal
como en el documento independiente del detalle del lote.

La regla se limita a cabeceras principales de Inicio, Lotes, Agenda, Almacén y
Finanzas; títulos de ventanas y paneles; nombre del lote y cabeceras principales
de sus secciones. Conserva las fuentes, pesos, colores y espacios existentes.
Los subtítulos pequeños de tarjetas y cifras no se amplían. La marca TruchApp,
la bienvenida y las portadas iniciales conservan sus tamaños aprobados.

Archivos existentes modificados: `app/build.gradle`, este resumen,
`app/src/main/assets/index.html` y `app/src/main/assets/ui/lotes/detail/index.html`.
Archivos añadidos: `app/src/main/assets/ui/theme/title-sizes.css` e inventario
`control/base-4.15.2.json`. No se modifica ningún JavaScript ni almacenamiento.

Las comprobaciones locales no sustituyen la revisión visual en el teléfono. La
compilación e instalación de esta versión quedan pendientes del flujo de GitHub.
