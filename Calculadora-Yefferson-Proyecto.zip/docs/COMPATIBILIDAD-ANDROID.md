# Compatibilidad de TruchApp 4.16.36

La compilación produce un solo APK con las bibliotecas para ambas arquitecturas:

| Arquitectura del teléfono | ABI incluida | Android mínimo |
| --- | --- | --- |
| ARM de 32 bits | armeabi-v7a | Android 6.0 / API 23 |
| ARM de 64 bits | arm64-v8a | Android 6.0 / API 23 |

Android elige la biblioteca correspondiente al sistema del teléfono. No hay que
instalar dos versiones de TruchApp. No se incluyen x86, x86_64 ni ARMv5.
La arquitectura no cambia los requisitos de versión de Android o de hardware.

## Compilar y actualizar

Usar el mismo ZIP, workflow de GitHub y claves de firma habituales. La versión es
4.16.36, código 97; se conservan el identificador de aplicación y los datos.
No se necesita borrar la instalación anterior. La compilación nativa ahora
construye dos arquitecturas y el APK incluye ambas bibliotecas.

Las tareas assembleDebug y assembleRelease comprueban automáticamente:

- lib/armeabi-v7a/libyefferson_ai.so: ELF de 32 bits, máquina ARM.
- lib/arm64-v8a/libyefferson_ai.so: ELF de 64 bits, máquina AArch64.

Si falta una o su arquitectura no corresponde, la tarea falla. El motor de IA
está incluido para ambas ABI; el rendimiento depende de la memoria y del equipo.
llama.cpp se fija a la revisión a956a852c9c8bc1fb07206364838ddef299178c0 para
evitar cambios inesperados durante futuras compilaciones.

## Validación de esta entrega

Las dos bibliotecas completas se compilaron con NDK r27c, CMake 3.22.1 y API 23.
Se comprobaron sus cabeceras ELF, sus seis métodos JNI y dependencias del sistema.
El verificador Gradle se probó con ZIP de ensayo que contienen esos binarios;
acepta ambas ABI correctas y rechaza bibliotecas ausentes o de arquitectura errónea.

Quedan pendientes el ensamblado del APK firmado en GitHub, la instalación en
teléfonos de ambas arquitecturas y la ejecución de un modelo en esos equipos.

Referencia: [ABI del NDK de Android](https://developer.android.com/ndk/guides/abis).
