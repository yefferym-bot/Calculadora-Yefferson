# TruchApp 4.16.22 — Emparejamiento local

## Alcance de esta entrega

Un administrador y colaboradores pueden emparejarse por una LAN Wi-Fi, verificar
un código en ambos dispositivos, guardar la identidad autorizada, asignar lotes,
reconectar y retirar el acceso. Ambos deben mantener TruchApp en primer plano.
Al salir de la aplicación se cierran sockets, anuncios NSD y multicast; las
vinculaciones guardadas permanecen. No se requiere internet para esta conexión.

Los teléfonos se conectan previamente a la misma Wi-Fi o uno a la zona Wi-Fi del
otro desde Ajustes de Android. TruchApp no crea ni configura automáticamente un
hotspot, Wi-Fi Direct o Bluetooth. Algunas redes aíslan sus clientes; si la
búsqueda no funciona se ofrece la dirección IPv4:puerto del administrador. Si la
red impide toda comunicación entre dispositivos, cambiar a una red que la permita.

Esta fase intercambia vinculación, permisos y un catálogo de cuatro campos por
lote: id, código, etapa y unidad. No transmite mediciones, diario, historial,
costos, proveedor, notas, almacén, finanzas ni respaldos. Registrar datos compartidos
continúa desactivado incluso si el administrador concede el permiso de registro.
No se añade un registro de ejemplo ni se modifica la información productiva local.
La sincronización de registros diarios y WebRTC son fases posteriores.

## Uso en dos teléfonos

1. Instalar la misma versión en ambos, conectarlos a la misma LAN y abrir TruchApp.
2. Administrador: Menú > Conexión local > Vincular colaborador. La invitación dura
   cinco minutos. Se muestra una dirección local con puerto dinámico.
3. Colaborador: Local > Buscar administrador > Conectar. Como alternativa escribir
   la dirección exacta del administrador. El nombre guardado se usa para identificarlo.
4. Comparar los ocho dígitos en ambos teléfonos. Si no coinciden, cancelar.
5. Administrador: seleccionar lotes, permiso y casilla de coincidencia; aprobar.
   Colaborador: marcar la casilla y confirmar el código. Hay dos minutos para
   completar esta comprobación, siempre dentro de la invitación del administrador.
6. Solo mostrar conectado después del guardado confirmado. Los equipos conocidos
   pueden reconectar con Activar reconexión y Buscar administrador, sin repetir el
   código cuando ambos conservan la vinculación.
7. Editar lotes/permisos los guarda y cierra la conexión actual; reconectar para
   actualizar el catálogo del colaborador. Retirar acceso pide confirmación.

La revocación se aplica en el administrador inmediatamente. Un colaborador
conectado recibe el retiro; uno desconectado lo conoce al volver a conectar.
La aplicación no puede borrar a distancia información que un equipo conserva
sin conexión. Los nombres de lotes recibidos son una copia de la última asignación
confirmada, no un indicador de que se hayan sincronizado los registros del lote.
Un código escrito en el formulario anterior sigue siendo un borrador; no concede
permisos y no sustituye al código de verificación de la sesión local.

## Arquitectura y límites

- `LocalPairingController`: API asíncrona de Android para la WebView, búsqueda y
  anuncio `_truchapp._tcp.`, sockets ligados a LAN Wi-Fi/hotspot, recursos de ciclo
  de vida, invitación y políticas. La dirección manual se limita a IP privada o
  de enlace local y un puerto no privilegiado; no habilita conexión por internet.
- `PairIdentity`: clave RSA de 2048 bits no exportable en Android Keystore y
  certificado propio. TLS 1.2 mutuo con ECDHE_RSA y AES-GCM. No se modifica la
  confianza HTTPS de WebView ni se permite tráfico sin cifrar en el manifiesto.
- `PairWire`: tramas con longitud y máximo de 256 KiB; UTF-8 válido, profundidad
  JSON acotada, rechazo de contenido adicional y límite temporal de tramas parciales.
  Conserva los fragmentos al vencer una lectura corta durante la verificación.
- `PairSession`: versión 1; compromisos SHA-256 de nonces antes de revelarlos,
  código de ocho dígitos ligado a roles, certificados y nonces; aprobación en ambos
  lados. En reconexión se compara el certificado presentado por TLS con el guardado.
  El nombre NSD, la IP, el nombre del colaborador y el modo visual no autentican.
- `PairStore`: confianza y asignaciones en preferencias privadas del dispositivo,
  con guardado `commit()` comprobado. No se añade una tabla ni una migración a Room.
  La clave y la confianza no se transportan en los respaldos de producción.
- `PairRecords`: catálogo permitido, permisos `view` o `record` y validación de IDs.
  La opción `record` se conserva para la siguiente fase; no hay comando remoto de
  escritura en este protocolo. Las cantidades, sumas y transacciones actuales no cambian.

Hasta 100 lotes por colaborador; se presentan los primeros 500 lotes válidos del
catálogo para asignar. Hasta 20 vinculaciones activas y 100 identidades guardadas,
incluidas las revocadas. Hasta veinte sesiones simultáneas, con
admisión y recursos acotados descritos en `CONCURRENCIA-20.md`. Se usan puertos dinámicos y anuncios
sin datos personales de la granja. Los mensajes remotos no se evalúan como código.

Cada dispositivo mantiene su identidad al actualizar el APK con la identidad y
firma actuales. Desinstalar o perder sus claves requiere volver a emparejarlo.
Cambiar a Administrador abre el espacio local de ese dispositivo; no concede
propiedad ni permisos sobre los equipos de otros administradores. El catálogo del
colaborador se mantiene separado de `truchapp_lotes_v1` y se identifica por su dueño.

## Validación y trabajo siguiente

Se compilan las diez clases del módulo con los tipos de la API Android 35; la prueba
usa un stub de `read` y `revisionStamp` del repositorio. El getter añadido es
de lectura y no cambia tablas ni escrituras. Esto comprueba
las referencias de Android del módulo, no equivale a compilar ni instalar el APK.

`tests/native-pairing/run_tests.py` ejecuta el protocolo de producción en sockets
mutuamente cifrados de loopback, con identidades temporales: 20 grupos. Cubre dos
confirmaciones, certificados reales, reconexión, invitación cerrada/vencida,
cancelación, fallos de guardado, revocación conectada y desconectada, desvinculación,
tramas fragmentadas, tamaños excesivos, JSON profundo, UTF-8 inválido, versión/rol
incorrectos, compromiso falso y catálogo sin datos productivos.
Requiere un JDK y `PAIR_JSON_JAR` con JSON-java; un JRE con `PAIR_ECJ_JAR` puede
sustituir a javac. Los jars y las claves temporales no se empaquetan.

Además pasan once grupos de carga con veinte conexiones TLS distintas y cien
lotes de catálogo por cliente. Chromium comprueba veintiún grupos de interfaz
con el puente Android simulado, además de las regresiones de bienvenida, diario
y tarjetas. La arquitectura y la investigación están en `CONCURRENCIA-20.md`.
El descubrimiento NSD,
Android Keystore/Conscrypt y el comportamiento concreto de Wi-Fi/hotspot todavía
requieren probar esta compilación en dos teléfonos reales. No se ejecutan Actions
ni se modifica el repositorio GitHub. La compilación y firma se realizan con el
flujo habitual de Yefferson, sin cambios en el workflow ni en la firma del APK.

Para incorporar sincronización: diseñar operaciones con ID, propietario, autor,
versión, confirmación tras transacción, reintento, conflictos y validación de
permisos por operación. No enviar un parche arbitrario del almacenamiento ni un
respaldo completo a un colaborador. Reutilizar ese protocolo sobre LAN y WebRTC.

Referencias técnicas:
- https://developer.android.com/develop/connectivity/wifi/use-nsd
- https://developer.android.com/privacy-and-security/keystore
- https://developer.android.com/reference/android/security/keystore/KeyGenParameterSpec
