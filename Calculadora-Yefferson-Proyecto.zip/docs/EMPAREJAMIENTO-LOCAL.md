# TruchApp 4.16.22 — Emparejamiento local

## Alcance de esta entrega

Un administrador y colaboradores pueden emparejarse por una LAN Wi-Fi, verificar
un código en ambos dispositivos, guardar la identidad autorizada, asignar lotes,
reconectar y retirar el acceso. Ambos deben mantener TruchApp en primer plano.
Al salir de la aplicación se cierran sockets, anuncios NSD y multicast; las
vinculaciones guardadas permanecen. No se requiere internet para esta conexión.

Los teléfonos se conectan previamente a la misma Wi-Fi o uno a la zona Wi-Fi del
otro desde Ajustes de Android. TruchApp no crea ni configura automáticamente un
hotspot, Wi-Fi Direct o Bluetooth. Algunas redes aíslan sus clientes; si la
búsqueda no funciona se ofrece la dirección IPv4:puerto del administrador. Si la
red impide toda comunicación entre dispositivos, cambiar a una red que la permita.

Esta fase intercambia vinculación, permisos y un catálogo de cuatro campos por
lote: id, código, etapa y unidad. No transmite mediciones, diario, historial,
costos, proveedor, notas, almacén, finanzas ni respaldos. Registrar datos compartidos
continúa desactivado incluso si el administrador concede el permiso de registro.
No se añade un registro de ejemplo ni se modifica la información productiva local.
La sincronización de registros diarios y WebRTC son fases posteriores.

## Uso en dos teléfonos

1. Instalar la misma versión en ambos, conectarlos a la misma LAN y abrir TruchApp.
2. Administrador: Menú > Conexión local > Vincular colaborador. La invitación dura
   cinco minutos. Se muestra una dirección local con puerto dinámico.
3. Colaborador: Local > Buscar administrador > Conectar. Como alternativa escribir
   la dirección exacta del administrador. El nombre guardado se usa para identificarlo.
4. Comparar los ocho dígitos en ambos teléfonos. Si no coinciden, cancelar.
5. Administrador: seleccionar lotes, permiso y casilla de coincidencia; aprobar.
   Colaborador: marcar la casilla y confirmar el código. Hay dos minutos para
   completar esta comprobación, siempre dentro de la invitación del administrador.
6. Solo mostrar conectado después del guardado confirmado. Los equipos conocidos
   pueden reconectar con Activar reconexión y Buscar administrador, sin repetir el
   código cuando ambos conservan la vinculación.
7. Editar lotes/permisos los guarda y cierra la conexión actual; reconectar para
   actualizar el catálogo del colaborador. Retirar acceso pide confirmación.

La revocación se aplica en el administrador inmediatamente. Un colaborador
conectado recibe el retiro; uno desconectado lo conoce al volver a conectar.
La aplicación no puede borrar a distancia información que un equipo conserva
sin conexión. Los nombres de lotes recibidos son una copia de la última asignación
confirmada, no un indicador de que se hayan sincronizado los registros del lote.
Un código escrito en el formulario anterior sigue siendo un borrador; no concede
permisos y no sustituye al código de verificación de la sesión local.

## Arquitectura y límites

- `LocalPairingController`: API asíncrona de Android para la WebView, búsqueda y
  anuncio `_truchapp._tcp.`, sockets ligados a LAN Wi-Fi/hotspot, recursos de ciclo
  de vida, invitación y políticas. La dirección manual se limita a IP privada o
  de enlace local y un puerto no privilegiado; no habilita conexión por internet.
- `PairIdentity`: clave RSA de 2048 bits no exportable en Android Keystore y
  certificado propio. TLS 1.2 mutuo con ECDHE_RSA y AES-GCM. No se modifica la
  confianza HTTPS de WebView ni se permite tráfico sin cifrar en el manifiesto.
- `PairWire`: tramas con longitud y máximo de 256 KiB; UTF-8 válido, profundidad
  JSON acotada, rechazo de contenido adicional y límite temporal de tramas parciales.
  Conserva los fragmentos al vencer una lectura corta durante la verificación.
- `PairSession`: versión 1; compromisos SHA-256 de nonces antes de revelarlos,
  código de ocho dígitos ligado a roles, certificados y nonces; aprobación en ambos
  lados. En reconexión se compara el certificado presentado por TLS con el guardado.
  El nombre NSD, la IP, el nombre del colaborador y el modo visual no autentican.
- `PairStore`: confianza y asignaciones en preferencias privadas del dispositivo,
  con guardado `commit()` comprobado. No se añade una tabla ni una migración a Room.
  La clave y la confianza no se transportan en los respaldos de producción.
- `PairRecords`: catálogo permitido, permisos `view` o `record` y validación de IDs.
  La opción `record` se conserva para la siguiente fase; no hay comando remoto de
  escritura en este protocolo. Las cantidades, sumas y transacciones actuales no cambian.

Hasta 100 lotes por colaborador; se presentan los primeros 500 lotes válidos del
catálogo para asignar. Hasta 20 vinculaciones activas y 100 identidades guardadas,
incluidas las revocadas. Hasta veinte sesiones simultáneas, con
admisión y recursos acotados descritos en `CONCURRENCIA-20.md`. Se usan puertos dinámicos y anuncios
sin datos personales de la granja. Los mensajes remotos no se evalúan como código.

Cada dispositivo mantiene su identidad al actualizar el APK con la identidad y
firma actuales. Desinstalar o perder sus claves requiere volver a emparejarlo.
Cambiar a Administrador abre el espacio local de ese dispositivo; no concede
propiedad ni permisos sobre los equipos de otros administradores. El catálogo del
colaborador se mantiene separado de `truchapp_lotes_v1` y se identifica por su dueño.

## Validación y trabajo siguiente

Se compilan las trece clases del módulo con los tipos de la API Android 35; la prueba
usa un stub de `read` y `revisionStamp` del repositorio. El getter añadido es
de lectura y no cambia tablas ni escrituras. Esto comprueba
las referencias de Android del módulo, no equivale a compilar ni instalar el APK.

`tests/native-pairing/run_tests.py` ejecuta el protocolo de producción en sockets
mutuamente cifrados de loopback, con identidades temporales: 20 grupos. Cubre dos
confirmaciones, certificados reales, reconexión, invitación cerrada/vencida,
cancelación, fallos de guardado, revocación conectada y desconectada, desvinculación,
tramas fragmentadas, tamaños excesivos, JSON profundo, UTF-8 inválido, versión/rol
incorrectos, compromiso falso y catálogo sin datos productivos.
Requiere un JDK y `PAIR_JSON_JAR` con JSON-java; un JRE con `PAIR_ECJ_JAR` puede
sustituir a javac. Los jars y las claves temporales no se empaquetan.

Además pasan once grupos de carga con veinte conexiones TLS distintas y cien
lotes de catálogo por cliente. Chromium comprueba veintiún grupos de interfaz
con el puente Android simulado, además de las regresiones de bienvenida, diario
y tarjetas. La arquitectura y la investigación están en `CONCURRENCIA-20.md`.
El descubrimiento NSD,
Android Keystore/Conscrypt y el comportamiento concreto de Wi-Fi/hotspot todavía
requieren probar esta compilación en dos teléfonos reales. No se ejecutan Actions
ni se modifica el repositorio GitHub. La compilación y firma se realizan con el
flujo habitual de Yefferson, sin cambios en el workflow ni en la firma del APK.

Para incorporar sincronización: diseñar operaciones con ID, propietario, autor,
versión, confirmación tras transacción, reintento, conflictos y validación de
permisos por operación. No enviar un parche arbitrario del almacenamiento ni un
respaldo completo a un colaborador. Reutilizar ese protocolo sobre LAN y WebRTC.

Referencias técnicas:
- https://developer.android.com/develop/connectivity/wifi/use-nsd
- https://developer.android.com/privacy-and-security/keystore
- https://developer.android.com/reference/android/security/keystore/KeyGenParameterSpec


## Reparación y diagnóstico de cifrado — 4.16.23 / 84

El 11 de noviembre Yefferson reportó un POCO administrador compartiendo punto de
acceso a un Samsung colaborador. Se observaron tanto ECONNREFUSED en el Samsung
como el aviso genérico SSL en el administrador, incluso con las fechas correctas.
Son evidencias de intentos/etapas distintos; no está probado un único origen.
No atribuir todos los fallos SSL al reloj, a una marca ni al límite de veinte.

Se extrae la configuración de identidad/trust a PairTls. La identidad de
Android Keystore existente, su alias y su certificado se conservan. Se usa
X509ExtendedKeyManager con selección explícita en sockets y SSLEngine, la extensión
recomendada por Android. Se comprueba certificado, vigencia, RSA >=2048 y firma
SHA256withRSA de un reto temporal, sin exportar la clave. Antes de activar la
primera conexión del controlador se negocia TLS mutuo contra loopback en este
mismo teléfono, con TLS 1.2 y las dos suites ECDHE_RSA/AES-GCM anteriores.
El trabajo va por el ejecutor de comandos; usa timeouts de cinco segundos por
operación, cierra sockets/hilo y no reserva una de las veinte plazas. No usa
internet ni guarda una vinculación consigo mismo. La comprobación se reutiliza
mientras viva el controlador. Si la actividad salió durante ella, no se activa
un listener de una generación cancelada. No se abre un servicio en segundo plano.

PairFailure conserva causas acotadas y separa TLS-LOCAL (fallo al preparar la
identidad o autocomprobar este teléfono), TLS-DATE (excepción de vigencia real),
TLS-CERT, TLS-KEY, TLS-HANDSHAKE, TLS-CONNECTION, TCP-CONNECT y NET-TIMEOUT.
El detalle del sistema se limita a 240 caracteres, sin controles ni caracteres
de formato. Se muestra como texto, sin evaluar HTML. No se escriben registros
productivos, claves, certificados ni diagnósticos a archivos o servidores.
No se desactiva la verificación de certificados ni se altera HTTPS/WebView.
Los errores del protocolo mantienen su texto previo.

La versión es una mejora de compatibilidad y diagnóstico: no hay todavía un
stack trace físico que confirme la causa del fallo POCO/Samsung. Debe actualizarse
en ambos dispositivos con la firma habitual, conservar los datos y volver a
vincular usando la dirección/puerto actuales. El nuevo código y su detalle de
ambos teléfonos son la evidencia necesaria si persiste. No prometer que esta
versión ya resolvió el fallo físico; no pedir borrar datos ni reinstalar.

La suite de escritorio ahora usa PairTls de producción en lugar de un
KeyManagerFactory/trust alternativo. Añade autocomprobación TLS exitosa/repetida,
fallida sin identidad, liberación del hilo, clave/certificado discordantes y
clasificación de causas. Siguen siendo claves PKCS12 temporales y JSSE de
escritorio: no sustituye Android Keystore, Conscrypt, NSD ni un hotspot físico.
Se conservan las pruebas de veinte pares y la fase de metadatos, sin nueva
sincronización productiva ni WebRTC.

Referencias primarias:
- https://developer.android.com/reference/javax/net/ssl/X509KeyManager
- https://developer.android.com/reference/javax/net/ssl/X509ExtendedKeyManager
- https://developer.android.com/reference/javax/net/ssl/SSLException
- https://developer.android.com/reference/java/security/cert/CertificateExpiredException
- https://man7.org/linux/man-pages/man2/connect.2.html


## Corrección RSA/Conscrypt — 4.16.24 / 85

Evidencia física nueva: ambos teléfonos actualizados a 4.16.23 informan
TLS-LOCAL, SSLProtocolException, código OpenSSL 04000044, RSA routines/internal
error. Se produce en la autocomprobación de cada teléfono sin tráfico hacia el
otro: la fecha, el router/hotspot y la capacidad de veinte no explican esta
operación local concreta. Las capturas no proporcionan el error de KeyMint
interno, pero sí permiten dirigir la reproducción al RSA delegado.

Se identificó y reprodujo un defecto de autorización de la clave v1. Conscrypt
prepara RSA-PSS y delega su bloque mediante Cipher RSA/ECB/NoPadding, ENCRYPT_MODE
con la clave privada. Android traduce esa operación a KM_PURPOSE_SIGN y
KM_PAD_NONE/DIGEST_NONE. La generación original autorizaba digest NONE y
padding PKCS1/PSS, pero no KM_PAD_NONE. Autorizar PSS no autoriza automáticamente
la primitiva cruda que esta ruta de Conscrypt solicita. La corrección añade
setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE) a la clave v2,
conservando exclusivamente PURPOSE_SIGN|PURPOSE_VERIFY y RSA 2048. No se habilitan
PURPOSE_ENCRYPT/DECRYPT ni se cambia el cifrado del canal. TLS 1.2,
ECDHE_RSA/AES-GCM, certificados, SAS/pins y aprobación en ambos lados siguen
siendo obligatorios. No se cambia el proveedor global de Android.

No basta cambiar el Builder para arreglar una clave ya creada: sus autorizaciones
previas no cambian. PairIdentityChoice elige v2 únicamente cuando no hay una
selección persistida ni registros de pares (incluidos revocados). Genera o reutiliza
v2 y conserva v1 sin borrarla. Si existen pares sin marcador, conserva v1; si ya
hay un marcador, siempre conserva la identidad seleccionada. Una clave marcada
pero ausente no se regenera silenciosamente. Una selección desconocida se rechaza.

Antes de recordar v2, se comprueban certificado/firma, la operación cruda con un
reto aleatorio y verificación pública modular, y TLS mutuo local completo. Solo
tras pasar y verificar que la activación sigue vigente se guarda identity_alias
en las mismas preferencias privadas. El commit vuelve a comprobar la política:
si aparecieron pares durante la prueba no se cambia su identidad. Un fallo de
commit no inicia la escucha y reintentar reutiliza la misma v2, evitando generar
identidades en cada intento. No se borra farm data ni la confianza anterior y
no se elimina ningún alias. Si v1 ya vinculada falla, se conserva y se informa
el fallo: su sustitución requeriría una reparación explícita y otra aprobación,
fuera de esta migración automática para equipos aún sin vincular.

Prueba adicional: PAIR_CONSCRYPT_JAR permite ejecutar PairingConscryptHarness con
Conscrypt OpenJDK 2.5.2 real y su biblioteca nativa. Una clave opaca de prueba
(getEncoded==null), con un proveedor JCA que modela las autorizaciones, permite
SHA256withRSA pero rechaza RSA/ECB/NoPadding. La negociación falla exactamente con
04000044, igual a las capturas. Permitir la operación hace pasar el reto crudo y
TLS mutuo en ambos roles. Es Conscrypt real con un modelo de autorización;
no es una ejecución de Android Keystore/TEE ni un ensayo en móviles físicos.
El jar es opcional, de prueba, no dependencia de la app ni contenido del ZIP.
Se obtiene del repositorio Maven de org.conscrypt/conscrypt-openjdk-uber/2.5.2.

La suite también verifica ocho decisiones/commits de identidad, los casos de TLS
y diagnóstico anteriores, los veinte grupos del protocolo y once grupos de
carga. Tipos Android 35/Java 8 verifican las trece clases. Sin Gradle/CMake ni
instalación en este entorno. Yefferson debe compilar con su firma habitual,
actualizar ambos sin desinstalar y volver a vincular. Falta confirmar la solución
en su POCO/Samsung; si falla, conservar el nuevo código y detalle.

Fuentes primarias que explican la ruta y las autorizaciones:
- https://android.googlesource.com/platform/prebuilts/fullsdk/sources/+/refs/heads/androidx-constraintlayout-release/android-35/com/android/org/conscrypt/CryptoUpcalls.java
- https://android.googlesource.com/platform/prebuilts/fullsdk/sources/android-30/+/refs/heads/androidx-room-release/android/security/keystore/AndroidKeyStoreRSACipherSpi.java
- https://developer.android.com/reference/android/security/keystore/KeyGenParameterSpec.Builder#setEncryptionPaddings(java.lang.String...)
- https://developer.android.com/reference/android/security/keystore/KeyInfo


## Diseño integrado desde la muestra v3 — 4.16.25 / 86

Yefferson confirmó que 4.16.24 ya conecta el POCO y Samsung y autorizó sustituir
la presentación anterior por el HTML adjunto TruchApp-Conexion-Local-v3.html.
Solo cambian presentación, eventos de UI y documentación: protocolo, bridge,
TLS/Keystore, confianza, persistencia y veinte conexiones permanecen idénticos.

La cabecera contiene el indicador circular con los conectados reales, estado
real de escucha/conexión y solicitudes pendientes. Administrador conserva dos
acciones en tarjetas con SVG; colaborador, búsqueda y dirección manual. Pasos,
fichas de equipo con inicial/permiso/asignación y botón Desactivar siguen el
HTML. No se copia su lógica simulada ni sus nombres/lotes de ejemplo. Se usan
las fuentes offline existentes y SVG de trazos, sin fuentes o dependencias web.

El editor inline se sustituye por una hoja inferior modal al tocar una ficha.
Mantiene selección y permisos con switches; Consultar es obligatorio y Autorizar
registro (próximamente) representa el mismo permiso record guardado anteriormente.
Este permiso todavía no registra datos compartidos. Se mantienen Guardar,
Desconectar y Retirar acceso con confirmación. Los errores aparecen en la hoja
activa, los cambios no se guardan al cerrar y los borradores conservan selecciones
para retomar. Se usa un solo editor, hasta 500 lotes visibles bajo demanda, con
el límite nativo/UI de 100 elegidos. Estados conectados no duplican fichas como
solicitudes. Se mantienen la comparación y aprobación explícitas del código.

La hoja atrapa el foco con dialog.showModal, Escape cierra primero la hoja y
vuelve al panel, se restaura el foco al cerrar y los nombres se renderizan como
texto. Se prueban nombres que parecen HTML sin crear imágenes. Ring, pulso y
entrada de hoja respetan prefers-reduced-motion. El panel tiene tokens oscuros
propios; el generador nocturno deja esas reglas a su CSS y continúa adaptando
las reglas de colaborador/bienvenida que ya compartían ese archivo. Las otras
secciones generadas conservan sus hashes/texto anterior.

Validación: 25 grupos de integración con Chromium/bridge aislado y 19 de modos;
320/390 px, claro/oscuro, captura visual, errores y conservación de datos.
Cinco pruebas del generador/paleta y ocho de continuidad. La confirmación física
de 4.16.24 no sustituye la revisión de esta UI en Android. No se ejecuta Gradle,
Actions ni instalación para esta entrega. WebRTC y sincronización de registros
productivos siguen pendientes como antes.


## Menús visibles y funcionales — 4.16.26 / 87

A petición de Yefferson, el diseño v3 se conserva dentro del área central entre
los menús originales de la app. La vista principal deja de ser modal y utiliza
show(), sin bloquear las barras. Se miden el botón superior y la barra inferior
reales de cada modo; se recalculan límites al abrir, redimensionar y cambiar el
visual viewport. La hoja inferior de ajustes continúa siendo modal y también
respeta esos límites. No se clonan menús ni se cambian sus archivos o rutas.

El contenido central subyacente queda inert mientras se muestra el panel, para
no editar campos ocultos al recorrer con teclado. Se conserva su estado previo
y se restaura al cerrar. Los menús permanecen utilizables. Usarlos cierra la
vista antes de ejecutar la ruta original y no envía comandos nativos de stop,
disconnect o revoke. La conexión sigue activa en primer plano. X y Escape
cierran solo la vista; Escape con la hoja abierta cierra primero la hoja. Se
restauran foco y observadores al salir; abrir otra vez conserva el estado real.
El envío de toda la aplicación al segundo plano conserva su comportamiento
nativo previo, sin crear un servicio nuevo.

Se prueban 29 grupos de integración del panel y 19 de acceso/modos con Chromium,
además de paleta y continuidad. Se comprueban hit testing y clics de las barras,
inert/restauración, tamaños 320/390, paisaje y escritorio, y que navegar no
produce stop/revoke. No se afirma una instalación nueva en Android. Código
nativo/Keystore, identidad, límites y datos permanecen idénticos a la base.


## Diseño ordenado desde HTML v4 — 4.16.27 / 88

Se integra TruchApp-Conexion-Local-v4.html sobre 4.16.26, conservando las barras
originales superior/inferior activas. Una cabecera compacta con flecha para volver
y dos pestañas sustituye el contador circular y la hoja de ajustes anterior.
Conexión presenta interruptor real, veinte cupos, acciones y ayuda. Colaboradores
muestra fichas con permisos y chips de los lotes; en modo colaborador la pestaña
se llama Administradores y sus asignaciones son de solo lectura.

El interruptor solicita listen (administrador), search (colaborador) o stop.
Su valor se confirma con la respuesta nativa, sin simular éxito. Vincular,
reconectar, búsqueda NSD, conexión manual, avisos y espera de reintento mantienen
sus comandos anteriores. Los conteos usan el estado nativo. Las solicitudes
nuevas muestran un distintivo y abren Conexión para comparar/aprobar el código
en ambos dispositivos; no se aprueba ni se asigna por la apariencia del equipo.

Los chips modifican un borrador y solo Guardar cambios envía update. Los cambios
sobreviven al alternar pestañas/equipos y a un fallo; el éxito recupera el estado
guardado. Hay un solo editor activo de equipo y uno de solicitud, cada uno con
hasta 500 opciones; las demás fichas son ligeras. Sigue el límite de 100 lotes.
Se conserva record como permiso futuro en un desplegable, sin habilitar registro
compartido. Desconectar no revoca; desvincular pide confirmación. Los nombres se
insertan como texto y no se copia la simulación ni los ejemplos del HTML.

Se conserva el encuadre no modal entre las barras de 4.16.26. Navegar, Volver y
Escape restauran el contenido central inert inmediatamente y cierran solo la
vista, sin parar/revocar la conexión. Se conservan las fuentes offline, el modo
oscuro y movimiento reducido. La regla nocturna del elemento lpPeerBusy retirado
se elimina al regenerar; las demás reglas generadas permanecen iguales.

Validación: 27 grupos Chromium del panel con bridge simulado, 19 de modos/acceso,
cinco de paleta y ocho de continuidad; 20 conectados, 20 solicitudes, 500 lotes,
borradores, errores y reintentos, navegación real, datos intactos, claro/oscuro,
320/390 px, paisaje y escritorio. Inspección visual y verificación del ZIP por
hashes, CRC y versión. No se recompila código nativo intacto ni se afirma una
instalación física nueva. Java, TLS/Keystore, Room, firma y workflow conservados.
WebRTC y sincronización de registros productivos siguen pendientes.


## Cabecera e inicio del colaborador aprobados — 4.16.28 / 89

Inicio, Mis lotes, Tareas y Equipo comparten la cabecera sin el logo de TruchApp.
El orden de la esquina derecha es Wi-Fi, cadena y perfil. Wi-Fi verde indica una
sesión conectada cuyo administrador sigue vinculado; rojo, ausencia de esa sesión.
La cadena verde indica confianza nativa vigente y permanece verde al perder la
conexión; sin vínculo o revocado pasa a rojo. Un estado aún no consultado o de
otro modo se presenta neutro, sin deducir estado desde navigator.onLine ni desde
un código guardado. Los indicadores abren el panel v4 existente, sin ejecutar
acciones destructivas. Se mantienen menú superior/inferior y sus rutas reales.

Inicio retira las tarjetas Tu equipo y Conexión del equipo y el adelanto de Tareas.
La conexión queda accesible en la cabecera y el menú. Mis lotes y asignaciones
continúan usando el catálogo autorizado; Equipo conserva su formulario y estado.
La barra inferior reduce su relleno para bajar la fila, conserva los destinos y
respeta el área segura del teléfono. Se adaptan los colores de los indicadores
al modo oscuro sin afectar a otros módulos.

Colaborador y Hola, nombre aparecen solo en la primera visita visible a Inicio
con un vínculo nativo. No se consumen mientras el panel de conexión cubre Inicio.
El marcador welcomeSeen se confirma mediante la transacción de preferencias
existente; cambia solo presentación. El nombre y el código siguen validados y
linkState local sigue siendo pending: la confianza procede de Android. Un fallo
de escritura deja el marcador sin confirmar y permite reintentar. Después de
salir de esa bienvenida, no vuelve al navegar, reconectar o recargar. Se conserva
al cambiar modo/nombre. Los indicadores se actualizan incluso con un formulario
enfocado y no sustituyen sus valores sin guardar.

35 grupos de integración Chromium con bridge simulado, 19 de modos/acceso,
nueve comprobaciones de datos de acceso, cinco de paleta y ocho de continuidad.
Incluyen tres estados, revocación con sesión antigua, solicitud aún sin vínculo,
error/reintento del marcador, recarga y diseño en 320/390/paisaje, cuatro módulos
y oscuro. Verificación visual y de integridad del ZIP. Protocolo/TLS/Keystore,
identidades, veinte conexiones, Room, firma y workflow permanecen intactos.
Esta entrega no afirma una compilación o instalación física nueva en Android.


## Reserva inferior duplicada corregida — 4.16.29 / 90

La captura física de 4.16.28 muestra una franja teal bajo los botones.
WebViewHost reserva el espacio de las barras del sistema fuera del WebView.
El CSS del colaborador añadía otra vez env(safe-area-inset-bottom) como relleno
de su menú. En el navegador con env cero parecía compacto; con 48 px de reserva
el relleno pasa a 48 px y la altura del menú sube de unos 63 a 107 px.

Se reproduce el problema antes del cambio con el override real de safe-area de
Chromium. Después, .co-nav usa padding fijo de 4px 8px y mantiene su borde
inferior al final del WebView. No cambia el manejo nativo de las barras ni se
superponen los botones con Android. Se conservan los cuatro destinos, estados,
vinculación, bienvenida y diseño de los demás elementos.

La regresión comprueba valores env de 0/24/48/80 px en los cuatro módulos,
320/390/paisaje, claro/oscuro, pulsación de botones y encuadre del panel local.
Falla en 4.16.28 y pasa con la corrección. Se inspeccionan capturas antes/después.
Pasan 36 grupos del panel/colaborador, 19 de modos, cinco de paleta y ocho de
continuidad. Código nativo/Java, TLS, datos, firma y workflow permanecen intactos.
No se afirma una nueva compilación o instalación física en este entorno.


## Inscripción dentro de Datos de vinculación — 4.16.30 / 91

Los dos botones de continuar se habilitan solo con un administrador vigente en
el estado nativo colaborador. El texto de invitación no concede membresía. El
bloque incorpora búsqueda NSD, lista de equipos, dirección manual, comparación
del código, confirmación y cancelación; no abre un panel externo ni los módulos
antes de completar el vínculo. La confirmación local espera la aprobación remota.
Se conservan errores, reintentos y la casilla para el mismo código si cambia el
descubrimiento. Los nombres remotos se insertan como texto.

La preparación guarda el modo/nombre que necesita el controlador existente.
El asistente no se cierra y no se marcan las portadas como completas por buscar.
Cancelar o volver detiene el intento, restaura la preferencia previa y conserva
producción/confianza. Cambiar a Administrador sigue el mismo cierre ordenado.
Antes de salir como colaborador se consulta de nuevo el estado nativo; errores
o revocación mantienen el bloqueo. Finalizar guarda la bienvenida atómicamente.

hasAdminLink deriva la vinculación de supported/mode y los registros no revocados
de administradores con fingerprint válido. enrollment limita los comandos de
esta UI y reutiliza la cola/framing/validación del puente existente; Android sigue
autorizando y persistiendo el vínculo. No se modifica Java, TLS ni el protocolo.
Acceso render/go impide saltarse la inscripción desde rutas o tras recarga.
Sin vínculo aparece una pantalla de vinculación y se oculta la barra de módulos.
Un vínculo guardado permite usar módulos sin conexión activa; su revocación los
bloquea. La bienvenida de una sola vez y el menú inferior corregido se conservan.
El registro productivo compartido no se habilita en esta entrega.

14 grupos nuevos de inscripción, 35 del panel/colaborador, 19 de modos/acceso,
nueve comprobaciones de access-data, cinco de paleta y ocho de continuidad.
Casos con errores atómicos, confirmación parcial, cancelación/restauración,
revocación silenciosa al continuar, reapertura pendiente y datos intactos.
Capturas inspeccionadas en 320/390/paisaje y oscuro. Se mantienen las regresiones
de reserva inferior real, veinte equipos y quinientos lotes. Sin instalación
física ni compilación Gradle/Actions nueva; integridad del ZIP comprobada.
