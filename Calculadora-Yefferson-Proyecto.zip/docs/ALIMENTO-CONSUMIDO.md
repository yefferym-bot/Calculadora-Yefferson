# Alimento total consumido — 4.16.38 / 99

La tarjeta abre el diseño aprobado: total del lote, alimento registrado hoy,
gráfico de línea con área verde y consulta por fechas. Funciona sin conexión y
usa los mismos registros del lote; consultar no escribe ni descuenta alimento.

| Filtro | Ventana |
| --- | --- |
| 1D | Hoy, con los horarios y cantidades de cada registro disponible |
| 5D | Hoy y los cuatro días anteriores |
| 1M | Último mes de calendario, desde el día siguiente a la fecha equivalente |
| 6M | Últimos seis meses de calendario, con el mismo criterio |
| 1A | Último año, con el mismo criterio y ajuste de años bisiestos |
| Max | Desde el ingreso del lote hasta hoy |

Todos los filtros se limitan a la fecha de ingreso. En un fin de mes se utiliza
el último día válido del mes de referencia. El gráfico muestra kg suministrados
por día, o por registro en 1D. El total superior mantiene el acumulado completo
del lote. Los valores representan alimento registrado, no ingestión medida.

Toca o arrastra sobre el gráfico para consultar un punto; también puedes usar
las flechas del teclado, Inicio y Fin. Debajo, elige mes, semana y día; Hoy vuelve
a la fecha actual. El calendario dibuja hasta siete días a la vez. Historias
largas muestran una vista resumida que conserva extremos y discontinuidades;
la selección sigue consultando el dato original.

Un día sin dato interrumpe la línea. Un día con 0 kg es un registro válido y se
muestra como cero. Los totales antiguos conservados se incluyen en el acumulado,
con un aviso separado, sin repartirlos artificialmente entre días. Sus fechas
conservan las restricciones de edición anteriores al balance.

Registrar alimentación abre el formulario habitual para la fecha seleccionada,
permitiendo añadir otro momento del mismo día. Al guardar vuelve al gráfico con
los totales recalculados. Ver historial diario abre el historial existente. El
modo de consulta del colaborador mantiene desactivado el botón de registro.

Se comprobaron las ventanas de fechas y los casos de datos incompletos con Node,
y la interfaz con Chromium, incluido guardado mediante un puente de padre de
prueba. El diseño se revisó en 320, 390 y 480 px y en modo oscuro. Faltan el APK
firmado en GitHub y la comprobación final en los teléfonos.
