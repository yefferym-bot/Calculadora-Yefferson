# Alimento total consumido — 4.16.39 / 100

La tarjeta abre el diseño aprobado: total del lote, alimento registrado hoy,
gráfico de línea con área verde y consulta por fechas. Funciona sin conexión y
usa los registros del lote y cierres automáticos identificados; consultar no modifica
las observaciones ni descuenta alimento.

| Filtro | Ventana |
| --- | --- |
| 1D | Hoy, con los horarios y cantidades de cada registro disponible |
| 5D | Hoy y los cuatro días anteriores |
| 1M | Último mes de calendario, desde el día siguiente a la fecha equivalente |
| 6M | Últimos seis meses de calendario, con el mismo criterio |
| 1A | Último año, con el mismo criterio y ajuste de años bisiestos |
| Max | Desde el ingreso del lote hasta hoy |

Todos los filtros se limitan a la fecha de ingreso. En un fin de mes se utiliza
el último día válido del mes de referencia. El gráfico muestra kg suministrados
por día, o por registro en 1D. El total superior mantiene el acumulado completo
del lote. Los valores representan alimento registrado, no ingestión medida.

Toca o arrastra sobre el gráfico para consultar un punto; también puedes usar
las flechas del teclado, Inicio y Fin. Debajo, elige mes, semana y día; Hoy vuelve
a la fecha actual. El calendario dibuja hasta siete días a la vez. Historias
largas muestran una vista resumida que conserva extremos y discontinuidades;
la selección sigue consultando el dato original.

Al terminar el día local, la alimentación que sigue sin cantidad pasa a **0 kg
automático**, identificado en ámbar como pendiente de revisión. Hoy permanece
«Sin registro» hasta terminar el día; los días futuros no se cierran. Un 0 kg
introducido por el usuario sigue siendo un cero confirmado, diferenciado del
automático. El sistema no puede deducir si hubo ayuno real o un olvido. Los totales antiguos conservados se incluyen en el acumulado,
con un aviso separado, sin repartirlos artificialmente entre días. Sus fechas
conservan las restricciones de edición anteriores al balance.

Tocar un botón de día abre **Resumen de alimentación** con la fecha y lote,
kg diarios, origen automático o manual, apetito, último horario, mortalidad y
descarte disponibles, y las entradas con sus horas, kg y observaciones. Los
campos desconocidos siguen «Sin registro». Las listas largas muestran 20
entradas por página. Cerrar o Escape vuelve al gráfico y a la fecha elegida.
Los totales anteriores conservan su restricción de edición.

Registrar alimentación abre el formulario habitual para la fecha seleccionada,
permitiendo añadir otro momento del mismo día. Al guardar vuelve al gráfico con
los totales recalculados. Ver historial diario abre el historial existente. El
modo de consulta del colaborador mantiene desactivado el botón de registro.

## Persistencia y cambio de día

Room conserva un cierre compacto interno `__system/feed_day_closure_v1` con la
política, fecha cerrada, zona horaria y momento de aplicación. Ese cierre define
0 kg para los días anteriores sin alimento observado, desde el ingreso o desde
el día posterior al balance antiguo. No crea entregas, no cambia los registros
manuales, no rellena las bajas, no inventa mediciones de agua ni mueve almacén.

Una cantidad manual, incluso 0, siempre tiene prioridad. Para confirmar ayuno
registra 0; para corregir un olvido añade la entrega real en esa fecha. No se suma
el cero como otra entrega. El cierre no convierte un dato ausente en observación
confirmada para las coberturas de FCR/TEA ni modifica las fórmulas existentes.

El cierre se intenta en el arranque, al cambiar el día en pantalla y al regresar
a la app, además de un trabajo periódico nativo de WorkManager cada 15 minutos.
Android puede retrasarlo por ahorro de energía, suspensión, cierre forzado o
teléfono apagado; se recuperan los días pendientes al volver a abrir. No se
solicita permiso de alarma exacta. Referencia oficial:
https://developer.android.com/reference/androidx/work/PeriodicWorkRequest

La fecha de cierre se envía a las fichas como metadato aparte de los lotes. No
incrementa la revisión productiva ni altera los hashes/documentos que usan los
colaboradores. Un borrador o envío pendiente no entra en conflicto por el mero
cambio de día. El cálculo visual puede recuperar inmediatamente un cierre
atrasado; el trabajo nativo persiste el punto de avance. Si falla esta tarea
derivada, la lectura de la granja conserva su funcionamiento y se reintenta.

## Validación de esta entrega

- Modelo de fechas/alimento: 11 grupos, con límites de mes, bisiestos, ceros
  automáticos y confirmados, correcciones, balances y ausencia de mutaciones.
- Chromium: 15 grupos del gráfico y resumen, incluidos registro posterior de 0
  o alimento omitido, teclado, listas largas, consulta, cambio de día, modo oscuro
  y 320/390/480 px. Se revisaron capturas; puente de guardado del padre simulado.
- Reloj controlado del puente: medianoche, reapertura, eventos concurrentes,
  reintento y guardado productivo simultáneo sin cambiar la revisión por el cierre.
- Java de producción `FeedDayClosure`: 14 comprobaciones JVM de fecha local,
  medianoche, UTC/Lima, bisiestos, horario estacional, recuperación e idempotencia.
- Regresión: registro diario real (24 comprobaciones), ficha compartida (11),
  almacenamiento, alimentación, bajas, agua, indicadores y anfitrión del detalle.
- Comprobación de tipos Java contra API Android y org.json: correcta, con
  sustitutos de Room/WorkManager/archivo para resolver dependencias; no ensambla
  Android ni ejecuta esas librerías. Se añaden pruebas Room en `StorageTest`
  para persistencia/revisión/solicitud compartida; su ejecución queda pendiente.

El APK firmado y las pruebas físicas Samsung/Poco quedan pendientes del flujo
de GitHub y de la instalación de Yefferson. Se mantienen ambos ABI ARM.
