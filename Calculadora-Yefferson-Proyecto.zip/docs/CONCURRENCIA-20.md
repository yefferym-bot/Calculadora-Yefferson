# TruchApp 4.16.22 — Veinte colaboradores simultáneos

## Alcance y arquitectura

El administrador admite veinte sesiones simultáneas: veinte colaboradores y el
propio administrador, veintiún teléfonos. Las sesiones que están iniciándose o
cerrándose reservan plaza hasta liberar sus recursos. Una conexión número 21 se
rechaza sin expulsar a otra. Cada identidad solo puede ocupar una sesión abierta.
Una identidad que ya está cerrándose puede sustituirse sin que su cierre tardío
borre la asociación de la nueva sesión.

Se mantiene el protocolo local versión 1 y el cifrado aprobado de 4.16.21. La
interfaz, la confianza y los permisos son independientes de los datos productivos.
Esta entrega endurece el transporte de las asignaciones y del catálogo permitido;
no implementa todavía sincronización de diario/agua ni WebRTC. La cola de socket
no es un diario persistente de operaciones. Para sincronizar registros hará falta
una cola durable en Room con IDs, autor, versión y confirmación tras transacción.

Para esta escala se conservan los SSLSocket de Android y la identidad en Keystore.
La lectura usa hasta un trabajador por sesión. La escucha, las escrituras, los
comandos y la limpieza usan recursos separados y acotados. Esto evita que la
escucha consuma una de las veinte plazas y permite conservar el protocolo de
verificación actual sin introducir un motor TLS/NIO nuevo en esta entrega.

## Límites y aislamiento

| Recurso | Configuración |
|---|---|
| Sesiones reservadas | 20 como máximo |
| Lectores | Bajo demanda, máximo 20, recuperación de hilos ociosos |
| Inicios TLS en curso | 4, con semáforo justo y espera máxima de 25 s |
| Inicio de una sesión | Máximo de 45 s antes de la revisión humana/conexión |
| Escrituras | 4 trabajadores compartidos y cola de tareas limitada |
| Turno de envío | Una trama por turno y FIFO por equipo |
| Cola por equipo | 8 tramas y 512 KiB, incluyendo el envío en curso |
| Memoria de envíos pendientes | Máximo global de 8 MiB |
| Trama de catálogo | Máximo 256 KiB, protocolo compatible |
| Mensajes de control | Máximo 1 KiB; 5/s con ráfaga inicial de 10 |
| Escritura lenta | Plazo de 3 s cuando empieza a ejecutarse |
| Permanencia de un envío en la cola | Plazo total de 20 s |
| Trama recibida incompleta | Plazo de 15 s, comprobado también por el supervisor |
| Equipo sin mensajes válidos | Se cierra tras 45 s, más la granularidad del supervisor |
| Admisión TCP | Ráfaga de 40 y recarga de 2 permisos por segundo |
| Comandos de interfaz pendientes | 32; los excesos reciben error explícito |

Estos plazos son límites de software, sujetos a la planificación de Android.
Al fallar una escritura se aborta su socket, se completan sus esperas y se liberan
sus bytes una sola vez. Un equipo no puede monopolizar un escritor enviando una
cola infinita: los turnos y presupuestos lo limitan. No se usa CallerRunsPolicy,
que trasladaría E/S a quien llama. El semáforo TLS permite conectar veinte equipos
sin ejecutar veinte operaciones de creación/verificación criptográfica a la vez.

El envío escribe bloques de hasta 16 KiB dentro de la trama existente; no añade
fragmentos lógicos ni otro formato incompatible. Los mensajes siguen conservando
orden por equipo. La concesión se reconoce solo tras el guardado confirmado.
Cerrar, cancelar o perder la red cancela las esperas y libera plazas. No se
reproducen automáticamente confirmaciones humanas ni escrituras con efectos.

## Actividad, reconexión y pantalla

Los avisos de actividad se encolan sin esperar a la red. Se distribuyen con una
variación aleatoria de 10 a 16 segundos, y se omiten si ya hay tráfico entrante
reciente. Un equipo que envía mensajes de control excesivos se desconecta sin
cerrar las otras sesiones. El plazo de trama parcial se supervisa incluso si un
lector está bloqueado esperando los bytes restantes.

Los fallos de conexión añaden una espera progresiva con variación aleatoria:
1–2 s en el primer fallo, creciendo hasta 30 s. El usuario inicia el reintento;
no hay bucle de reconexión, reenvío de permisos ni aprobación automática. La
pantalla muestra cuándo se puede volver a conectar. El éxito limpia la espera.
El límite de admisión permite una primera oleada de veinte y su reconexión, a la
vez que frena intentos indefinidos en ráfaga.

La pausa y destrucción de la Activity invalidan inmediatamente su generación y
mandan la limpieza de sockets/NSD a un trabajador. La limpieza antigua no cierra
una sesión de trabajo nueva. Las respuestas tardías no se envían a una WebView
destruida. Los trabajadores nativos usan prioridad de segundo plano.

Los avisos de Android a la pantalla se agrupan durante 120 ms. JavaScript admite
una consulta de estado en curso y una actualización posterior pendiente: no
crea cien consultas por cien avisos ni pierde el estado final. Reabrir el diálogo
antes de recibir un cierre antiguo no elimina el temporizador de la nueva apertura.
El catálogo de hasta 500 lotes se reutiliza mediante una marca de la generación
de base de datos y su revisión. La caché conserva solo los cuatro campos permitidos,
sin retener el documento de historiales. Una restauración con el mismo número de
revisión también la invalida. Se añade únicamente un getter de lectura al repositorio;
no cambia tablas, transacciones, versiones ni datos.

La pantalla muestra el contador de conectados sobre veinte y las sesiones
pendientes. Desconectar libera la conexión conservando la vinculación; Retirar
acceso conserva su confirmación y revoca la autorización. Solo una solicitud
muestra sus controles de aprobación completos cada vez. Los editores de lotes
se construyen al abrirlos y se retiran al cerrarlos, conservando el borrador.
Esto evita crear diez mil casillas con veinte equipos y quinientos lotes.

## Investigación aplicada

Se consultaron fuentes primarias el 10 de noviembre de 2026:

- Oracle, ThreadPoolExecutor: límites de trabajadores/colas, rechazo y consumo
  de recursos. Se aplican grupos separados, colas acotadas y rechazo explícito.
  https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/concurrent/ThreadPoolExecutor.html
- Amazon Builders' Library, Timeouts, retries, and backoff with jitter: plazos,
  espera progresiva, variación aleatoria y precaución con los efectos repetidos.
  Se aplica espera manual y se evita repetir automáticamente las aprobaciones.
  https://aws.amazon.com/builders-library/timeouts-retries-and-backoff-with-jitter/
- Android Developers, Better performance through threading: E/S fuera del hilo
  principal y prioridad apropiada de trabajadores. Se separa la limpieza del ciclo
  de vida y se agrupan las notificaciones a la WebView.
  https://developer.android.com/topic/performance/threads
- AOSP, Wi-Fi hotspot: el hardware y la configuración del punto de acceso también
  limitan los clientes. TruchApp no puede ampliar ese límite físico.
  https://source.android.com/docs/core/connect/wifi-softap

Son decisiones de esta implementación, no una afirmación de que esas fuentes
certifiquen veinte teléfonos concretos ni un rendimiento determinado del APK.

## Validación

- Las diez clases del módulo se compilan con sintaxis Java 8 y tipos de Android
  API 35. Se usa un stub de read y del nuevo getter revisionStamp del repositorio;
  su única adición es de lectura y no modifica tablas ni escritura de Room.
  Esto no equivale a compilar e instalar el APK completo.
- Se conservan veinte grupos del protocolo: TLS mutuo, códigos, doble aprobación,
  persistencia confirmada, fallos, revocación, JSON/UTF-8, tramas y catálogo.
- Once grupos de carga usan el PairRuntime y PairOutbound de producción con veinte
  certificados distintos, sockets TLS reales y cien lotes de catálogo por cliente,
  incluidos nombres Unicode. Comprueban veinte conectados, rechazo del número 21,
  separación de asignaciones, identidad duplicada, reutilización de plaza, tráfico
  paralelo, aislamiento de un emisor abusivo, caída/reconexión de veinte, actividad
  en reposo y liberación de recursos. También comprueban la reutilización del catálogo
  entre veinte consultas y su invalidación tras cambiar la base de datos.
  La saturación de escritores y los presupuestos
  se prueban además con flujos bloqueados controlados para provocar el fallo.
- Chromium con puente sintético: veintiún grupos, contador 20/20, quinientos lotes
  sin editores duplicados, borradores, desconexión sin revocación, espera de reintento,
  cien avisos agrupados, texto seguro, guardado/cancelación, 320/390 px y oscuro.
- Se conservan las regresiones de modos, editor de tarjetas, diario por momentos,
  almacenamiento, indicadores, alimentación y paleta nocturna reproducible.

Las pruebas TLS son en loopback del entorno de desarrollo; no son una medición
de veinte teléfonos Android ni de su batería o memoria. La red debe permitir la
comunicación y admitir veinte colaboradores, más el administrador si este también
es cliente del router. Compilación/firma GitHub e instalación con Keystore/NSD,
Wi-Fi/hotspot y carga física real quedan pendientes de validar en los teléfonos.
