# Almacén y sacos destinados a lotes — 4.16.41 / 102

## Uso

1. Almacén → **＋ Alimento y compra**: nombre/tipo de alimento, unidad saco,
   kg por saco, cantidad comprada, precio por saco, fecha, lote del proveedor y
   vencimiento. Producto y primera compra se confirman juntos. La opción anterior
   Registrar producto sigue disponible para separar catálogo y movimientos.
2. La tarjeta del producto muestra contenido del envase, precio por unidad,
   precio por kg y stock disponible. **Asignar alimento a lote** permite elegir
   el lote productivo, partida del proveedor, cantidad, fecha y hora.
3. Asignar retira esa cantidad del stock libre y la reserva para el lote. Se
   muestra antes el costo. Los lotes compiten por el mismo saldo real; no pueden
   reservar el mismo saco dos veces ni usar una compra posterior a la asignación.
4. En Mis lotes, el enlace de sacos abre el detalle de asignaciones. Dentro del
   lote, la tarjeta **Alimento destinado a este lote** muestra sacos/kg asignados,
   kg disponibles, costo y cada asignación con su consumo y saldo. El almacén
   también agrupa destinos por lote.
5. En Registro diario, elegir **Saco asignado** y escribir alimento suministrado
   en kg. Baja la reserva del lote. No genera otra salida del almacén ni otro
   cargo del costo del saco. Se puede añadir otro momento del mismo día.
6. Editar o eliminar ese consumo devuelve kg a la reserva del lote, no al stock
   libre. Se rechaza sobreuso, producto/precio ajeno, consumo anterior a la
   asignación o posterior al vencimiento.

Los sacos asignados se incorporan al capital por alevino al asignarlos, según la
solicitud de Yefferson. El consumo productivo permanece separado: una asignación
no inventa kg suministrados ni altera FCR, mortalidad, agua o biometrías.

## Correcciones

Una asignación conserva su precio capturado. Si no tiene consumo, se puede
**Retirar asignación sin consumir**, confirmando con un segundo toque; devuelve
su cantidad al stock libre. Para corregir precio/fecha/cantidad se retira la
asignación sin consumo y se crea una nueva. No se permite borrar una asignación
con consumo asociado. Esta versión no incluye la devolución parcial del remanente
de una asignación ya consumida; primero hay que corregir los registros ligados.

El costo se captura con el promedio por partida disponible en su fecha. El
movimiento de asignación conserva ese costo y no toma compras futuras. Una
corrección de la compra que deje sin respaldo el valor reservado se rechaza.
Las entregas directas antiguas conservan su ruta de valoración existente. Al
eliminar un lote, sus movimientos históricos siguen archivados, sin devolver
silenciosamente alimento ya destinado o consumido al stock disponible.

## Arquitectura

`detailState.feedAllocations[]` contiene hechos: id estable, fecha/hora, producto,
partida, unidad, kg por unidad, kg asignados y precio por unidad. Estos hechos
producen movimientos de origen `lot-allocation`; no hay una segunda tabla de
salidas que pueda duplicarlos. `feedStock.lines[].allocationId` enlaza cada
consumo a la reserva y conserva su instantánea de producto/partida/precio.
Los consumos reservados no producen movimientos adicionales del stock libre.

La compra inicial producto+entrada y cada asignación se guardan con la ruta
transaccional existente. El doble envío se bloquea. Un fallo de persistencia
revierte el dato confirmado y mantiene el borrador; reintentar no duplica.
No se crean movimientos a partir de alimento antiguo sin vínculo.

El administrador gestiona reservas. Un colaborador de registro completo puede
consumirlas sin tener acceso a la gestión general del almacén, también en su
outbox sin conexión. Consulta solo inspecciona. `PairProduction` comprueba la
inmutabilidad de asignaciones, referencias, capacidad global del documento,
fechas, vencimiento, instantáneas y concordancia entre entradas y resumen diario.
No se amplía el permiso sobre entregas directas antiguas o stock libre.
Actualizar todos los teléfonos para usar el mismo esquema económico v2.

Pruebas de datos, Chromium con persistencia simulada y JVM del validador de
producción acompañan el código. La comprobación física con APK firmado en
Samsung/Poco queda pendiente en el flujo habitual del proyecto.
