# Costos por alevino y pérdidas — 4.16.41 / 102

## Compra: precio unitario o total

En Resumen → Costos y gastos → Compra de alevinos se elige el tipo de importe.
**Precio por alevino** multiplica el precio por la cantidad inicial del lote;
**Costo total de la compra** conserva el importe ingresado como total.
Por ejemplo, 10,000 × S/0.28 = S/2,800.00. El total de compra se redondea a
céntimos; los cálculos internos de distribución conservan precisión y el valor
unitario se muestra con cuatro decimales (hasta seis para tarjetas muy pequeñas).
No se usa la cantidad sobreviviente para reconstruir cuánto costó la compra.

Los datos económicos v1 ya guardados eran acumulados. Se leen como **total**,
sin convertir automáticamente S/0.28 a S/2,800 ni modificar otros lotes. Si el
importe anterior representa el precio de cada alevino, se selecciona **Precio
por alevino**, se revisa la vista previa y se guarda. No hay un precio instalado
para todos los lotes. Un vacío sigue desconocido y 0 es un precio confirmado.

## Capital y bajas en orden cronológico

La base de **Valor por alevino vivo** y **Pérdida económica total** es la compra
más el alimento asignado o registrado con costo conocido. Se reconstruye desde
los hechos persistidos y sus fechas; consultar no guarda movimientos nuevos.

1. Comienza con los peces iniciales y el total de su compra.
2. Una asignación incorpora el costo completo del alimento reservado para el
   lote, aunque todavía no se haya consumido. Una entrega directa antigua o un
   alimento sin vínculo valorizado manualmente incorpora su costo registrado.
3. Antes de cada baja: `valor unitario = capital restante / peces disponibles`.
4. `pérdida = (muertos + descartados) × valor unitario de ese momento`.
5. Se retiran del capital y del conteo los peces que salieron. Su costo no se
   vuelve a cargar a los sobrevivientes.
6. Un saco posterior incrementa el valor de los peces que siguen vivos, sin
   cambiar las pérdidas de fechas anteriores. A igual fecha y hora se incorpora
   primero el alimento y luego se valoran las bajas; el criterio es determinista.

Ejemplo de comprobación, sin instalar importes en los datos: compra S/2,800;
100 bajas antes del alimento → S/28 de pérdida, 9,900 peces y S/2,772 de capital.
Asignar un saco de S/150 → `(2772 + 150) / 9900 = S/0.295151…` por pez vivo.
Diez bajas posteriores → S/2.951515… adicionales. Otro saco posterior no cambia
ninguna de esas bajas anteriores. La pérdida no se añade otra vez a los gastos:
ya estaba incluida en la compra/alimento distribuido.

El historial muestra fecha, hora, incorporación o baja, conteo antes/después y
valor unitario. Corregir un hecho anterior recalcula sus consecuencias; no se
trata de un cierre contable inmutable. Los importes de pérdidas se muestran a
céntimos, sin redondear cada pez durante los cálculos.

### Límites visibles

La pérdida es una **estimación de distribución de compra y alimento**, no un
pago nuevo ni una medición del precio de venta perdido. Incluye alimento
comprometido en sacos aún disponibles. Mortalidad y descarte aparecen separados;
no se descuenta una posible recuperación por venta de descartes.

Los otros gastos acumulados (sanidad, mano de obra, energía/oxígeno, otros y
fijos prorrateados) siguen en el costo total del lote y su proyección. No entran
en esta base de pérdida porque no tienen fechas de devengo. No se atribuye un
gasto posterior a un pez que murió antes.

Si falta precio de compra/alimento, hay bajas antiguas agregadas sin fecha
individual o un ajuste de existencias, se indica **Estimación parcial**. No se
inventa la fecha de cada muerte ni se considera un olvido como alimento gratuito.
La compra y los sacos nuevos quedan fechados; los históricos incompletos necesitan
revisión. Los ajustes de conteo no se suman como mortalidad económica confirmada.

## Alimento y total del lote

`costo alimento del lote = asignaciones completas + entregas directas + alimento
sin vínculo × precio manual`.

El consumo desde un saco asignado no vuelve a sumarse: ya se incorporó al reservarlo.
El resumen distingue los kg registrados, asignados/disponibles y sin valorizar.
La valoración manual solo aplica a kg sin costo vinculado. No crea una salida de
almacén ni reparte un alimento antiguo entre sacos nuevos sin confirmación.

El total del lote suma compra, alimento y otras categorías conocidas. Sigue
parcial hasta registrar las seis categorías (0 cuando corresponda) y valorizar
el alimento observado. Los ceros automáticos pendientes de revisión no pasan a
ser ayuno confirmado. FCR y cobertura productiva conservan su criterio original.
El panel de Finanzas basado en entregas conserva el costo **consumido**; puede
diferir del costo **comprometido** del lote si quedan sacos sin consumir.

La calculadora ponderada y el escenario de cosecha se conservan. La supervivencia
se aplica desde hoy sobre peces vivos; no descuenta de nuevo las bajas pasadas.
Ingreso, equilibrio y margen siguen siendo proyecciones con advertencia si hay
costos parciales, no ventas o utilidad realizada.

## Tarjetas y persistencia

Se añade **Pérdida económica total** al detalle y a las opciones de Mis lotes.
El catálogo tiene veinte opciones y conserva el máximo de ocho seleccionadas.
La tarjeta antes llamada Costo por pez ahora aclara **Valor por alevino vivo**
(compra + alimento). No sustituye el costo total por kg de biomasa.

Se guarda `detailState.economics` v2 con `seedMode: unit|total`; v1 sigue siendo
legible. Cantidades productivas e identidad del lote conservan sus fuentes.
Guardar confirma una vez; cerrar/cancelar no escribe; fallo mantiene borrador
para reintentar y Deshacer usa la ruta persistente existente. No cambia Room,
paquete, firma ni respaldos. Las asignaciones se describen en
`docs/ASIGNACIONES-ALIMENTO.md`.

Registro completo del colaborador utiliza el documento/outbox existente para
costos y consumos de sacos ya asignados. Solo consulta no permite editar. Solo
el administrador gestiona las asignaciones. El nativo valida esquema, números,
referencias/capacidad de reserva y hash. La huella económica cambia también por
una asignación aunque peces/biomasa no cambien. **Actualizar administrador y todos
los colaboradores a esta versión**: versiones anteriores no conocen economics v2.

## Verificación

Modelos: ocho grupos nuevos de asignación/pérdida y nueve de costos; stock,
alimentación, fechas, integridad por lote y ausencia/0. Chromium: compra real en
la vista, asignación, consumo, sobreuso, pérdida cronológica, dos lotes, retirada
sin consumo, fallo/reintento, recarga, pantallas 320/390/480 px y oscuro. La ficha
compartida cubre reserva y costos en cola sin conexión y consulta. JVM ejecuta
`PairProduction`/`PairWire` reales para aceptación y rechazo de datos económicos
y consumos reservados. Los puentes de persistencia UI son simulados: estas pruebas
no equivalen a instalación Android, Room o conexión Samsung/Poco física.

El ZIP es fuente para compilar y firmar con el flujo de GitHub existente. No se
ejecuta Actions ni se entrega un APK compilado aquí; ARM32/ARM64 y workflows se
conservan.
