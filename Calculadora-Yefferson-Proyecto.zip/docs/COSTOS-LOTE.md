# Costos y gastos del lote — 4.16.40 / 101

Se adapta el contenido económico de `TruchApp-Costos-Lote.html` al detalle real
de TruchApp: colores verde azulado/menta, modo oscuro, menús conservados y formulario
con cabecera y acciones fijas. No se instalan el Lote 1 ficticio, sus cantidades,
precios ni proyecciones de ejemplo. Los datos pertenecen a cada lote.

## Dónde encontrarlo

En Resumen aparece **Costos y gastos**, con alimento valorizado, kilos sin costo,
gastos sin alimento, total parcial o completo y **Ver costos y rentabilidad**.
Se añaden seis indicadores al resumen y al selector de tarjetas de Mis lotes:

| Tarjeta | Cálculo |
| --- | --- |
| Costo de alimentación | Costo vinculado a Almacén + kg sin vincular × precio manual |
| Gastos del lote | Suma de las seis categorías, excluyendo alimento |
| Costo total del lote | Alimentación valorizada + gastos registrados |
| Costo por pez | Costo conocido / peces vivos actuales |
| Costo por kg de biomasa | Costo conocido / biomasa actual estimada |
| Margen estimado | Ingreso proyectado − costo hasta cosecha |

El selector tiene 19 opciones y mantiene el máximo de ocho visibles y las
selecciones anteriores. Cambiar el diseño no modifica importes ni producción.
Las tarjetas monetarias usan S/ y aclaran si los costos están incompletos.

## Alimentación y precio ponderado

El alimento ya registrado es de solo lectura. Las entregas vinculadas usan los
costos del almacén disponibles en la ficha; el precio manual se aplica **solo**
a los kg sin vínculo. No se sustituye el precio de las entregas vinculadas ni se
crea otra salida de alimento. Los consumos históricos pueden valorizarse sin
inventar entregas, fechas, compras o movimientos de stock.

El administrador utiliza la valoración por fecha de la instantánea del almacén.
La ficha compartida sin ese catálogo utiliza los costos conservados en sus líneas
de entrega; una corrección retroactiva del almacén puede variar la valoración
actual del administrador. Los cambios de importes se guardan y sincronizan como
parte del documento del lote, no como movimientos independientes del almacén.

La calculadora ponderada usa:
`(kg actuales × precio actual + kg nuevos × precio nuevo) / kg totales`.
Exige precios para cantidades positivas; admite precio explícito 0 y no calcula
si no hay cantidad total. **Usar este precio** cambia el borrador. Se conserva
precisión de seis decimales al aplicarlo, y los totales monetarios se muestran
con dos decimales. Esta ayuda no cambia el inventario.

## Gastos acumulados

Se registran importes acumulados hasta hoy: alevines, sanidad, mano de obra,
energía y oxígeno, transporte y otros, y costos fijos prorrateados. Solo debe
asignarse la parte correspondiente a este lote. El alimento se incorpora una
sola vez, automáticamente. El campo de costos fijos no es una inversión completa.

Un vacío sigue sin registrar; 0 es un importe confirmado. El total suma únicamente
lo conocido y se indica como parcial hasta que estén las seis categorías (incluido
0 cuando corresponda) y todo el alimento observado esté valorizado. Los ceros
automáticos de alimentación pendientes de revisión no se convierten en ayuno
observado ni en cobertura completa de datos. No se supone que un gasto omitido
sea gratuito. No se modifica el cálculo productivo del FCR.

Estos campos son acumulados por categoría, como el HTML aprobado; no constituyen
un libro de transacciones con fecha, comprobante o pago. No se duplican en el
simulador global de Finanzas ni se generan pagos o compras automáticamente. El
apartado existente de Finanzas «Alimentación por lote» conserva su criterio de
costo documentado desde Almacén. El nuevo total del lote puede incluir además
la valoración manual y las demás categorías.

## Proyección

Se toma el peso objetivo del lote si el campo de cosecha está vacío. La supervivencia
esperada se aplica a los peces que siguen vivos **desde hoy**; no se vuelve a
restar la mortalidad pasada. Se ingresan gastos futuros (incluido alimento) y
precio de venta por kg. No se inventan supervivencia, precio ni costos futuros.

`biomasa de cosecha = peces vivos × supervivencia desde hoy / 100 × peso de cosecha / 1000`

`costo hasta cosecha = costo conocido actual + gastos futuros`

`ingreso = biomasa proyectada × precio de venta`

`margen = ingreso − costo hasta cosecha`

El costo por kg cosechado es el punto de equilibrio estimado. Las divisiones
sin denominador positivo no muestran un valor numérico; el margen negativo se
conserva. La proyección no es una venta ni una utilidad realizada. Si faltan
categorías, el margen se identifica como parcial y puede sobrestimar el resultado.

## Persistencia y permisos

Los datos se guardan en `detailState.economics`, versión 1, dentro del documento
Room existente. Se conserva esquema, respaldos, firma y paquete. Guardar hace
una confirmación y permite deshacer; cancelar o cerrar conserva la versión
anterior. Un fallo revierte el estado confirmado y mantiene el borrador para
reintentar. Restablecer vacía solo el borrador económico y requiere guardar;
no borra el lote, las biometrías, los registros diarios, el agua ni el stock.

La lectura no escribe. Las cantidades productivas proceden de sus registros.
La vista previa reutiliza el contexto productivo al abrir el formulario para
no recorrer toda la historia en cada pulsación. El resumen reutiliza el mismo
reporte económico dentro de cada renderizado.

El colaborador con registro completo puede guardar los datos económicos por
la misma cola de lotes compartidos, también sin conexión. Solo consulta bloquea
edición, cálculo aplicado, restablecimiento y envío. El validador nativo comprueba
versión, estructura, números finitos, importes no negativos y límites de peso/
supervivencia. El resumen compartido añade una huella de los datos económicos
para invalidar valores anteriores aunque no hayan cambiado peces o biomasa;
no transmite la granja completa. Persisten los controles de asignación y hash.

## Validación y límites

Se comprueban cálculos, ausencia/0, valoración mixta, ponderado, proyección,
round-trip por lote, importes inválidos, ocho tarjetas y no mutación de stock.
Pruebas Chromium con puente nativo simulado cubren formulario real, borrador,
guardado único, cancelación, fallo/reintento, deshacer, recarga, selección,
consulta y reutilización del lote, pantallas 320/390/480 px y modo oscuro.
Se revisan capturas. La ficha compartida prueba el gasto en la cola sin conexión.

El validador y patch de `PairProduction`/`PairWire` reales pasan 17 comprobaciones
JVM, incluyendo rechazos de importes, preservación de otro lote y cambio de huella.
No se sustituye por ello la prueba de una instalación Android, Room o de dos
Samsung/Poco físicos. La compilación del APK firmado queda en el flujo existente
de GitHub de Yefferson. Se conservan ARM de 32/64 bits y los workflows.
