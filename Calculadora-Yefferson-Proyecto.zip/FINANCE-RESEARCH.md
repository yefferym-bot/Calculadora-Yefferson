# TruchApp 4.4 — Finanzas

El módulo Finanzas reemplaza únicamente la navegación/interfaz visible de "Memoria". La memoria personal de la IA permanece en el core (LocalStore/AndroidAI) y su sección visual queda oculta.

## Base de investigación
- FAO. Woynarovich, Hoitsy & Moth-Poulsen (2011). *Small-scale rainbow trout farming*, Technical Paper 561. La sección económica describe costo total de inversión, VAN, TIR, periodo de recuperación, costo de producción, precio unitario, punto de equilibrio, ingreso bruto y utilidad. También recomienda registros de granja, existencias/mortalidad, alimentación, almacén y balance mensual.
  https://www.fao.org/4/i2125e/i2125e.pdf
- *Costos y viabilidad económica de la producción y comercialización de la conserva de trucha (Oncorhynchus mykiss) en escabeche* (Puno/UNAP, 2023). El estudio calcula costos con datos a precios de mercado y usa flujo de caja para VANf, TIR, B/C y recuperación.
  https://www.scielo.org.pe/scielo.php?pid=S1609-91172023000400012&script=sci_arttext
- Demircan, Diken, Sarica & Dalgic (2024). *Economic Analysis of Rainbow Trout Cage Farms Differing in Sizes*. AGRIS/FAO. El estudio reporta economías de escala en la muestra analizada; se trata de evidencia comparativa de Türkiye, no de precios para Perú.
  https://agris.fao.org/search/es/records/6878d9170868163a2f74f269
