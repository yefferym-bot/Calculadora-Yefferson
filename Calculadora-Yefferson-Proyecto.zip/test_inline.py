from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path('/mnt/data/truchapp_menu_work/app/src/main/assets')
s=(root/'index.html').read_text(encoding='utf-8')
for asset in re.findall(r'<link rel="stylesheet" href="([^"]+)">',s):
 f=root/asset
 if not f.exists(): print('missing CSS',asset);continue
 s=s.replace(f'<link rel="stylesheet" href="{asset}">', '<style>\n'+f.read_text(encoding='utf-8')+'\n</style>',1)
for asset in re.findall(r'<script src="([^"]+)"></script>',s):
 f=root/asset
 if not f.exists(): print('missing JS',asset);continue
 script=f.read_text(encoding='utf-8')
 s=s.replace(f'<script src="{asset}"></script>', '<script>\n'+script+'\n</script>',1)
# No external assets under server for these functional tests
s=re.sub(r'<link rel="preconnect"[^>]*>', '',s)
s=re.sub(r'<link href="https://fonts.googleapis.com/[^"]*"[^>]*>', '',s)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.evaluate("""() => {const vals={'truchapp_intro_v4_1_profile_done':'1','truchapp_lotes_tutorial_v2':'1'};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>Object.prototype.hasOwnProperty.call(vals,k)?vals[k]:null,setItem:(k,v)=>{vals[k]=String(v)},removeItem:k=>{delete vals[k]}}})}""")
 page.set_content(s,wait_until='domcontentloaded',timeout=60000)
 # Dismiss tour in harness only. App tour still untouched.
 page.evaluate('''() => {document.documentElement.classList.remove('truchapp-boot'); const intro=document.getElementById('yb-intro'); if(intro)intro.remove(); const body=document.body; body.style.overflow='';}''')
 page.wait_for_timeout(600)
 print('menu button:',page.locator('#tnMenuOpen').count(),'js:',page.evaluate('!!window.TruchAppMenu'),'errors',errs[:6])
 page.locator('#tnMenuOpen').click(timeout=6000)
 page.wait_for_timeout(420)
 print('open',page.locator('#tnSideMenu').get_attribute('class'),'bounds',page.locator('#tnMenuDrawer').bounding_box())
 page.screenshot(path='/mnt/data/truchapp_menu_work/menu-open.png')
 assert page.locator('#tnMenuOpen').get_attribute('aria-expanded')=='true'
 assert page.locator('#tnMenuDrawer').is_visible()
 page.locator('[data-menu-action="about"]').click()
 assert page.locator('#tnMenuDetail').is_visible()
 assert page.get_by_text('Versión 4.8.4').count()==1
 page.locator('#tnMenuDetailBack').click()
 page.locator('#tnMenuReducedMotion').check(force=True)
 assert page.locator('.phone.tn-menu-reduced').count()==1
 page.locator('#tnMenuClose').click()
 assert page.locator('#tnMenuOpen').get_attribute('aria-expanded')=='false'
 page.locator('#tnMenuOpen').click()
 page.locator('[data-menu-target="almacen"]').click()
 assert page.locator('#almacen.screen.active').count()==1
 assert page.locator('#tnMenuOpen').get_attribute('aria-expanded')=='false'
 page.locator('#tnMenuOpen').click()
 page.locator('[data-menu-action="new-product"]').click()
 page.wait_for_timeout(600)
 print('new-product modal',page.locator('#almacen [data-modal="item"]').count())
 assert page.locator('#almacen [data-modal="item"]').count()==1
 page.locator('#almacen [data-action="close-modal"]').first.click()
 page.locator('#tnMenuOpen').click()
 page.locator('[data-menu-action="water"]').click()
 page.wait_for_timeout(650)
 print('water modal',page.locator('#lotes #waterQualityModal.open').count())
 assert page.locator('#lotes #waterQualityModal.open').count()==1
 page.screenshot(path='/mnt/data/truchapp_menu_work/water-open.png')
 print('runtime errors',errs[:10],'n',len(errs))
 b.close()
