from playwright.sync_api import sync_playwright
from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
handler=partial(SimpleHTTPRequestHandler, directory='/mnt/data/truchapp_menu_work/app/src/main/assets')
server=ThreadingHTTPServer(('127.0.0.1',0),handler)
Thread(target=server.serve_forever,daemon=True).start()
file='http://127.0.0.1:%s/index.html'%server.server_port
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox','--allow-file-access-from-files','--disable-web-security'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 errs=[]; page.on('pageerror',lambda e:errs.append(str(e)))
 page.add_init_script("try{localStorage.setItem('truchapp_intro_v4_1_profile_done','1');localStorage.setItem('truchapp_lotes_tutorial_v2','1')}catch(e){}")
 page.goto(file,wait_until='domcontentloaded',timeout=25000)
 page.wait_for_timeout(450)
 print('header',page.locator('#tnMenuOpen').count(),'intro',page.locator('#yb-intro').count())
 page.locator('#tnMenuOpen').click(timeout=6000)
 page.wait_for_timeout(400)
 print('open',page.locator('#tnSideMenu').get_attribute('class'),'drawer bounding',page.locator('#tnMenuDrawer').bounding_box())
 page.screenshot(path='/mnt/data/truchapp_menu_work/menu-open.png')
 assert page.locator('#tnMenuOpen').get_attribute('aria-expanded')=='true'
 assert page.locator('#tnMenuDrawer').is_visible()
 page.locator('[data-menu-action="about"]').click()
 assert page.locator('#tnMenuDetail').is_visible()
 assert page.get_by_text('Versión 4.8.4').count()==1
 page.locator('#tnMenuDetailBack').click()
 page.locator('#tnMenuReducedMotion').check(force=True)
 assert page.locator('.phone.tn-menu-reduced').count()==1
 page.locator('#tnMenuClose').click()
 assert page.locator('#tnMenuOpen').get_attribute('aria-expanded')=='false'
 page.locator('#tnMenuOpen').click()
 page.locator('[data-menu-target="almacen"]').click()
 assert page.locator('#almacen.screen.active').count()==1
 assert page.locator('#tnMenuOpen').get_attribute('aria-expanded')=='false'
 page.locator('#tnMenuOpen').click()
 page.locator('[data-menu-action="new-product"]').click()
 page.wait_for_timeout(600)
 print('new-product modal',page.locator('#almacen [data-modal="item"]').count())
 assert page.locator('#almacen [data-modal="item"]').count()==1
 page.locator('#almacen [data-action="close-modal"]').first.click()
 page.locator('#tnMenuOpen').click()
 page.locator('[data-menu-action="water"]').click()
 page.wait_for_timeout(650)
 print('water modal',page.locator('#lotes #waterQualityModal.open').count())
 assert page.locator('#lotes #waterQualityModal.open').count()==1
 page.screenshot(path='/mnt/data/truchapp_menu_work/water-open.png')
 print('runtime errors',errs[:8], 'n',len(errs))
 b.close()
